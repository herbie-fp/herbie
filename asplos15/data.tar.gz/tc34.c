#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE problem 3.3.7 */

double f_if(float x) {
        float r74487 = x;
        float r74488 = exp(r74487);
        float r74489 = 2.0;
        float r74490 = r74488 - r74489;
        float r74491 = -r74487;
        float r74492 = exp(r74491);
        float r74493 = r74490 + r74492;
        return r74493;
}

double f_id(float x) {
        double r74494 = x;
        double r74495 = exp(r74494);
        double r74496 = 2.0;
        double r74497 = r74495 - r74496;
        double r74498 = -r74494;
        double r74499 = exp(r74498);
        double r74500 = r74497 + r74499;
        return r74500;
}

double f_il(float x) {
        long double r74501 = x;
        long double r74502 = exp(r74501);
        long double r74503 = 2.0;
        long double r74504 = r74502 - r74503;
        long double r74505 = -r74501;
        long double r74506 = exp(r74505);
        long double r74507 = r74504 + r74506;
        return r74507;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r74508 = x;
        float r74509 = exp(r74508);
        float r74510 = r74509 * r74509;
        float r74511 = -2.0;
        float r74512 = r74511 * r74511;
        float r74513 = 1.0/r74509;
        float r74514 = r74513 * r74513;
        float r74515 = r74512 - r74514;
        float r74516 = r74511 - r74513;
        float r74517 = r74516 * r74516;
        float r74518 = r74515 / r74517;
        float r74519 = r74515 * r74518;
        float r74520 = r74510 - r74519;
        float r74521 = r74511 + r74513;
        float r74522 = r74509 - r74521;
        float r74523 = r74520 / r74522;
        return r74523;
}

double f_od(float x) {
        double r74524 = x;
        double r74525 = exp(r74524);
        double r74526 = r74525 * r74525;
        double r74527 = -2.0;
        double r74528 = r74527 * r74527;
        double r74529 = 1.0/r74525;
        double r74530 = r74529 * r74529;
        double r74531 = r74528 - r74530;
        double r74532 = r74527 - r74529;
        double r74533 = r74532 * r74532;
        double r74534 = r74531 / r74533;
        double r74535 = r74531 * r74534;
        double r74536 = r74526 - r74535;
        double r74537 = r74527 + r74529;
        double r74538 = r74525 - r74537;
        double r74539 = r74536 / r74538;
        return r74539;
}

double f_ol(float x) {
        long double r74540 = x;
        long double r74541 = exp(r74540);
        long double r74542 = r74541 * r74541;
        long double r74543 = -2.0;
        long double r74544 = r74543 * r74543;
        long double r74545 = 1.0/r74541;
        long double r74546 = r74545 * r74545;
        long double r74547 = r74544 - r74546;
        long double r74548 = r74543 - r74545;
        long double r74549 = r74548 * r74548;
        long double r74550 = r74547 / r74549;
        long double r74551 = r74547 * r74550;
        long double r74552 = r74542 - r74551;
        long double r74553 = r74543 + r74545;
        long double r74554 = r74541 - r74553;
        long double r74555 = r74552 / r74554;
        return r74555;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r74556, r74557, r74558, r74559, r74560, r74561, r74562;

void setup_mpfr() {
        mpfr_set_default_prec(344);
        mpfr_init(r74556);
        mpfr_init(r74557);
        mpfr_init(r74558);
        mpfr_init(r74559);
        mpfr_init(r74560);
        mpfr_init(r74561);
        mpfr_init(r74562);
}

double f_im(float x) {
        mpfr_set_flt(r74556, x, MPFR_RNDN);
        mpfr_exp(r74557, r74556, MPFR_RNDN);
        mpfr_init_set_str(r74558, "2", 10, MPFR_RNDN);
        mpfr_sub(r74559, r74557, r74558, MPFR_RNDN);
        mpfr_neg(r74560, r74556, MPFR_RNDN);
        mpfr_exp(r74561, r74560, MPFR_RNDN);
        mpfr_add(r74562, r74559, r74561, MPFR_RNDN);
        return mpfr_get_d(r74562, MPFR_RNDN);
}

