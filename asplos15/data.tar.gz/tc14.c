#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* FastMath test5 */

double f_if(float d1) {
        float r72958 = d1;
        float r72959 = r72958 * r72958;
        float r72960 = r72958 * r72959;
        float r72961 = r72960 * r72958;
        float r72962 = r72961 * r72958;
        float r72963 = r72962 * r72959;
        float r72964 = r72963 * r72958;
        float r72965 = r72958 * r72964;
        float r72966 = r72965 * r72958;
        return r72966;
}

double f_id(float d1) {
        double r72967 = d1;
        double r72968 = r72967 * r72967;
        double r72969 = r72967 * r72968;
        double r72970 = r72969 * r72967;
        double r72971 = r72970 * r72967;
        double r72972 = r72971 * r72968;
        double r72973 = r72972 * r72967;
        double r72974 = r72967 * r72973;
        double r72975 = r72974 * r72967;
        return r72975;
}

double f_il(float d1) {
        long double r72976 = d1;
        long double r72977 = r72976 * r72976;
        long double r72978 = r72976 * r72977;
        long double r72979 = r72978 * r72976;
        long double r72980 = r72979 * r72976;
        long double r72981 = r72980 * r72977;
        long double r72982 = r72981 * r72976;
        long double r72983 = r72976 * r72982;
        long double r72984 = r72983 * r72976;
        return r72984;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float d1) {
        float r72985 = d1;
        float r72986 = r72985 * r72985;
        float r72987 = r72985 * r72986;
        float r72988 = r72987 * r72985;
        float r72989 = r72988 * r72985;
        float r72990 = r72989 * r72985;
        float r72991 = r72990 * r72985;
        float r72992 = r72991 * r72985;
        float r72993 = r72985 * r72992;
        float r72994 = r72993 * r72985;
        return r72994;
}

double f_od(float d1) {
        double r72995 = d1;
        double r72996 = r72995 * r72995;
        double r72997 = r72995 * r72996;
        double r72998 = r72997 * r72995;
        double r72999 = r72998 * r72995;
        double r73000 = r72999 * r72995;
        double r73001 = r73000 * r72995;
        double r73002 = r73001 * r72995;
        double r73003 = r72995 * r73002;
        double r73004 = r73003 * r72995;
        return r73004;
}

double f_ol(float d1) {
        long double r73005 = d1;
        long double r73006 = r73005 * r73005;
        long double r73007 = r73005 * r73006;
        long double r73008 = r73007 * r73005;
        long double r73009 = r73008 * r73005;
        long double r73010 = r73009 * r73005;
        long double r73011 = r73010 * r73005;
        long double r73012 = r73011 * r73005;
        long double r73013 = r73005 * r73012;
        long double r73014 = r73013 * r73005;
        return r73014;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r73015, r73016, r73017, r73018, r73019, r73020, r73021, r73022, r73023;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r73015);
        mpfr_init(r73016);
        mpfr_init(r73017);
        mpfr_init(r73018);
        mpfr_init(r73019);
        mpfr_init(r73020);
        mpfr_init(r73021);
        mpfr_init(r73022);
        mpfr_init(r73023);
}

double f_im(float d1) {
        mpfr_set_flt(r73015, d1, MPFR_RNDN);
        mpfr_mul(r73016, r73015, r73015, MPFR_RNDN);
        mpfr_mul(r73017, r73015, r73016, MPFR_RNDN);
        mpfr_mul(r73018, r73017, r73015, MPFR_RNDN);
        mpfr_mul(r73019, r73018, r73015, MPFR_RNDN);
        mpfr_mul(r73020, r73019, r73016, MPFR_RNDN);
        mpfr_mul(r73021, r73020, r73015, MPFR_RNDN);
        mpfr_mul(r73022, r73015, r73021, MPFR_RNDN);
        mpfr_mul(r73023, r73022, r73015, MPFR_RNDN);
        return mpfr_get_d(r73023, MPFR_RNDN);
}

