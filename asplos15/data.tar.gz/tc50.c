#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Falkner and Boettcher, Equation (20:1,3) */

double f_if(float v, float t) {
        float r76123 = 1.0;
        float r76124 = 5.0;
        float r76125 = v;
        float r76126 = r76125 * r76125;
        float r76127 = r76124 * r76126;
        float r76128 = r76123 - r76127;
        float r76129 = 3.141592653589793;
        float r76130 = t;
        float r76131 = r76129 * r76130;
        float r76132 = 2.0;
        float r76133 = 3.0;
        float r76134 = r76133 * r76126;
        float r76135 = r76123 - r76134;
        float r76136 = r76132 * r76135;
        float r76137 = sqrt(r76136);
        float r76138 = r76131 * r76137;
        float r76139 = r76123 - r76126;
        float r76140 = r76138 * r76139;
        float r76141 = r76128 / r76140;
        return r76141;
}

double f_id(float v, float t) {
        double r76142 = 1.0;
        double r76143 = 5.0;
        double r76144 = v;
        double r76145 = r76144 * r76144;
        double r76146 = r76143 * r76145;
        double r76147 = r76142 - r76146;
        double r76148 = 3.141592653589793;
        double r76149 = t;
        double r76150 = r76148 * r76149;
        double r76151 = 2.0;
        double r76152 = 3.0;
        double r76153 = r76152 * r76145;
        double r76154 = r76142 - r76153;
        double r76155 = r76151 * r76154;
        double r76156 = sqrt(r76155);
        double r76157 = r76150 * r76156;
        double r76158 = r76142 - r76145;
        double r76159 = r76157 * r76158;
        double r76160 = r76147 / r76159;
        return r76160;
}

double f_il(float v, float t) {
        long double r76161 = 1.0;
        long double r76162 = 5.0;
        long double r76163 = v;
        long double r76164 = r76163 * r76163;
        long double r76165 = r76162 * r76164;
        long double r76166 = r76161 - r76165;
        long double r76167 = 3.141592653589793;
        long double r76168 = t;
        long double r76169 = r76167 * r76168;
        long double r76170 = 2.0;
        long double r76171 = 3.0;
        long double r76172 = r76171 * r76164;
        long double r76173 = r76161 - r76172;
        long double r76174 = r76170 * r76173;
        long double r76175 = sqrt(r76174);
        long double r76176 = r76169 * r76175;
        long double r76177 = r76161 - r76164;
        long double r76178 = r76176 * r76177;
        long double r76179 = r76166 / r76178;
        return r76179;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float v, float t) {
        float r76180 = 3.141592653589793;
        float r76181 = t;
        float r76182 = r76180 * r76181;
        float r76183 = 2.0;
        float r76184 = r76183 * r76183;
        float r76185 = 3.0;
        float r76186 = v;
        float r76187 = r76186 * r76186;
        float r76188 = r76185 * r76187;
        float r76189 = r76183 * r76188;
        float r76190 = r76189 * r76189;
        float r76191 = r76184 - r76190;
        float r76192 = sqrt(r76191);
        float r76193 = r76182 * r76192;
        float r76194 = r76183 + r76189;
        float r76195 = sqrt(r76194);
        float r76196 = r76193 / r76195;
        float r76197 = r76183 - r76189;
        float r76198 = sqrt(r76197);
        float r76199 = r76182 * r76198;
        float r76200 = r76199 * r76187;
        float r76201 = r76196 - r76200;
        float r76202 = 1.0/r76201;
        float r76203 = r76199 - r76200;
        float r76204 = 1.0/r76203;
        float r76205 = 5.0;
        float r76206 = r76205 * r76187;
        float r76207 = r76204 * r76206;
        float r76208 = r76202 - r76207;
        return r76208;
}

double f_od(float v, float t) {
        double r76209 = 3.141592653589793;
        double r76210 = t;
        double r76211 = r76209 * r76210;
        double r76212 = 2.0;
        double r76213 = r76212 * r76212;
        double r76214 = 3.0;
        double r76215 = v;
        double r76216 = r76215 * r76215;
        double r76217 = r76214 * r76216;
        double r76218 = r76212 * r76217;
        double r76219 = r76218 * r76218;
        double r76220 = r76213 - r76219;
        double r76221 = sqrt(r76220);
        double r76222 = r76211 * r76221;
        double r76223 = r76212 + r76218;
        double r76224 = sqrt(r76223);
        double r76225 = r76222 / r76224;
        double r76226 = r76212 - r76218;
        double r76227 = sqrt(r76226);
        double r76228 = r76211 * r76227;
        double r76229 = r76228 * r76216;
        double r76230 = r76225 - r76229;
        double r76231 = 1.0/r76230;
        double r76232 = r76228 - r76229;
        double r76233 = 1.0/r76232;
        double r76234 = 5.0;
        double r76235 = r76234 * r76216;
        double r76236 = r76233 * r76235;
        double r76237 = r76231 - r76236;
        return r76237;
}

double f_ol(float v, float t) {
        long double r76238 = 3.141592653589793;
        long double r76239 = t;
        long double r76240 = r76238 * r76239;
        long double r76241 = 2.0;
        long double r76242 = r76241 * r76241;
        long double r76243 = 3.0;
        long double r76244 = v;
        long double r76245 = r76244 * r76244;
        long double r76246 = r76243 * r76245;
        long double r76247 = r76241 * r76246;
        long double r76248 = r76247 * r76247;
        long double r76249 = r76242 - r76248;
        long double r76250 = sqrt(r76249);
        long double r76251 = r76240 * r76250;
        long double r76252 = r76241 + r76247;
        long double r76253 = sqrt(r76252);
        long double r76254 = r76251 / r76253;
        long double r76255 = r76241 - r76247;
        long double r76256 = sqrt(r76255);
        long double r76257 = r76240 * r76256;
        long double r76258 = r76257 * r76245;
        long double r76259 = r76254 - r76258;
        long double r76260 = 1.0/r76259;
        long double r76261 = r76257 - r76258;
        long double r76262 = 1.0/r76261;
        long double r76263 = 5.0;
        long double r76264 = r76263 * r76245;
        long double r76265 = r76262 * r76264;
        long double r76266 = r76260 - r76265;
        return r76266;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r76267, r76268, r76269, r76270, r76271, r76272, r76273, r76274, r76275, r76276, r76277, r76278, r76279, r76280, r76281, r76282, r76283, r76284, r76285;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r76267);
        mpfr_init(r76268);
        mpfr_init(r76269);
        mpfr_init(r76270);
        mpfr_init(r76271);
        mpfr_init(r76272);
        mpfr_init(r76273);
        mpfr_init(r76274);
        mpfr_init(r76275);
        mpfr_init(r76276);
        mpfr_init(r76277);
        mpfr_init(r76278);
        mpfr_init(r76279);
        mpfr_init(r76280);
        mpfr_init(r76281);
        mpfr_init(r76282);
        mpfr_init(r76283);
        mpfr_init(r76284);
        mpfr_init(r76285);
}

double f_im(float v, float t) {
        mpfr_init_set_str(r76267, "1", 10, MPFR_RNDN);
        mpfr_init_set_str(r76268, "5", 10, MPFR_RNDN);
        mpfr_set_flt(r76269, v, MPFR_RNDN);
        mpfr_mul(r76270, r76269, r76269, MPFR_RNDN);
        mpfr_mul(r76271, r76268, r76270, MPFR_RNDN);
        mpfr_sub(r76272, r76267, r76271, MPFR_RNDN);
        mpfr_init_set_str(r76273, "3.141592653589793", 10, MPFR_RNDN);
        mpfr_set_flt(r76274, t, MPFR_RNDN);
        mpfr_mul(r76275, r76273, r76274, MPFR_RNDN);
        mpfr_init_set_str(r76276, "2", 10, MPFR_RNDN);
        mpfr_init_set_str(r76277, "3", 10, MPFR_RNDN);
        mpfr_mul(r76278, r76277, r76270, MPFR_RNDN);
        mpfr_sub(r76279, r76267, r76278, MPFR_RNDN);
        mpfr_mul(r76280, r76276, r76279, MPFR_RNDN);
        mpfr_sqrt(r76281, r76280, MPFR_RNDN);
        mpfr_mul(r76282, r76275, r76281, MPFR_RNDN);
        mpfr_sub(r76283, r76267, r76270, MPFR_RNDN);
        mpfr_mul(r76284, r76282, r76283, MPFR_RNDN);
        mpfr_div(r76285, r76272, r76284, MPFR_RNDN);
        return mpfr_get_d(r76285, MPFR_RNDN);
}

