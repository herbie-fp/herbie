#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE problem 3.3.5 */

double f_if(float x, float eps) {
        float r74282 = x;
        float r74283 = eps;
        float r74284 = r74282 + r74283;
        float r74285 = cos(r74284);
        float r74286 = cos(r74282);
        float r74287 = r74285 - r74286;
        return r74287;
}

double f_id(float x, float eps) {
        double r74288 = x;
        double r74289 = eps;
        double r74290 = r74288 + r74289;
        double r74291 = cos(r74290);
        double r74292 = cos(r74288);
        double r74293 = r74291 - r74292;
        return r74293;
}

double f_il(float x, float eps) {
        long double r74294 = x;
        long double r74295 = eps;
        long double r74296 = r74294 + r74295;
        long double r74297 = cos(r74296);
        long double r74298 = cos(r74294);
        long double r74299 = r74297 - r74298;
        return r74299;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x, float eps) {
        float r74300 = x;
        float r74301 = -779500847716577.8;
        bool r74302 = r74300 < r74301;
        float r74303 = -2.4028997348113442e+26;
        bool r74304 = r74300 < r74303;
        float r74305 = cos(r74300);
        float r74306 = eps;
        float r74307 = cos(r74306);
        float r74308 = r74305 * r74307;
        float r74309 = sin(r74300);
        float r74310 = sin(r74306);
        float r74311 = r74309 * r74310;
        float r74312 = r74308 - r74311;
        float r74313 = r74312 * r74312;
        float r74314 = r74305 * r74305;
        float r74315 = log(r74314);
        float r74316 = exp(r74315);
        float r74317 = exp(r74316);
        float r74318 = log(r74317);
        float r74319 = r74313 - r74318;
        float r74320 = r74312 + r74305;
        float r74321 = sqrt(r74320);
        float r74322 = r74321 * r74321;
        float r74323 = r74319 / r74322;
        float r74324 = r74313 - r74316;
        float r74325 = r74324 / r74320;
        float r74326 = r74304 ? r74323 : r74325;
        float r74327 = -4.113924940148221e-17;
        bool r74328 = r74300 < r74327;
        float r74329 = sqrt(r74305);
        float r74330 = r74329 * r74329;
        float r74331 = r74312 - r74330;
        float r74332 = 1.1942417708199496e+38;
        bool r74333 = r74300 < r74332;
        float r74334 = r74313 * r74313;
        float r74335 = r74314 * r74314;
        float r74336 = exp(r74335);
        float r74337 = log(r74336);
        float r74338 = r74334 - r74337;
        float r74339 = r74313 + r74314;
        float r74340 = sqrt(r74339);
        float r74341 = r74340 * r74340;
        float r74342 = r74338 / r74341;
        float r74343 = r74342 / r74320;
        float r74344 = r74333 ? r74326 : r74343;
        float r74345 = r74328 ? r74331 : r74344;
        float r74346 = r74302 ? r74326 : r74345;
        return r74346;
}

double f_od(float x, float eps) {
        double r74347 = x;
        double r74348 = -779500847716577.8;
        bool r74349 = r74347 < r74348;
        double r74350 = -2.4028997348113442e+26;
        bool r74351 = r74347 < r74350;
        double r74352 = cos(r74347);
        double r74353 = eps;
        double r74354 = cos(r74353);
        double r74355 = r74352 * r74354;
        double r74356 = sin(r74347);
        double r74357 = sin(r74353);
        double r74358 = r74356 * r74357;
        double r74359 = r74355 - r74358;
        double r74360 = r74359 * r74359;
        double r74361 = r74352 * r74352;
        double r74362 = log(r74361);
        double r74363 = exp(r74362);
        double r74364 = exp(r74363);
        double r74365 = log(r74364);
        double r74366 = r74360 - r74365;
        double r74367 = r74359 + r74352;
        double r74368 = sqrt(r74367);
        double r74369 = r74368 * r74368;
        double r74370 = r74366 / r74369;
        double r74371 = r74360 - r74363;
        double r74372 = r74371 / r74367;
        double r74373 = r74351 ? r74370 : r74372;
        double r74374 = -4.113924940148221e-17;
        bool r74375 = r74347 < r74374;
        double r74376 = sqrt(r74352);
        double r74377 = r74376 * r74376;
        double r74378 = r74359 - r74377;
        double r74379 = 1.1942417708199496e+38;
        bool r74380 = r74347 < r74379;
        double r74381 = r74360 * r74360;
        double r74382 = r74361 * r74361;
        double r74383 = exp(r74382);
        double r74384 = log(r74383);
        double r74385 = r74381 - r74384;
        double r74386 = r74360 + r74361;
        double r74387 = sqrt(r74386);
        double r74388 = r74387 * r74387;
        double r74389 = r74385 / r74388;
        double r74390 = r74389 / r74367;
        double r74391 = r74380 ? r74373 : r74390;
        double r74392 = r74375 ? r74378 : r74391;
        double r74393 = r74349 ? r74373 : r74392;
        return r74393;
}

double f_ol(float x, float eps) {
        long double r74394 = x;
        long double r74395 = -779500847716577.8;
        bool r74396 = r74394 < r74395;
        long double r74397 = -2.4028997348113442e+26;
        bool r74398 = r74394 < r74397;
        long double r74399 = cos(r74394);
        long double r74400 = eps;
        long double r74401 = cos(r74400);
        long double r74402 = r74399 * r74401;
        long double r74403 = sin(r74394);
        long double r74404 = sin(r74400);
        long double r74405 = r74403 * r74404;
        long double r74406 = r74402 - r74405;
        long double r74407 = r74406 * r74406;
        long double r74408 = r74399 * r74399;
        long double r74409 = log(r74408);
        long double r74410 = exp(r74409);
        long double r74411 = exp(r74410);
        long double r74412 = log(r74411);
        long double r74413 = r74407 - r74412;
        long double r74414 = r74406 + r74399;
        long double r74415 = sqrt(r74414);
        long double r74416 = r74415 * r74415;
        long double r74417 = r74413 / r74416;
        long double r74418 = r74407 - r74410;
        long double r74419 = r74418 / r74414;
        long double r74420 = r74398 ? r74417 : r74419;
        long double r74421 = -4.113924940148221e-17;
        bool r74422 = r74394 < r74421;
        long double r74423 = sqrt(r74399);
        long double r74424 = r74423 * r74423;
        long double r74425 = r74406 - r74424;
        long double r74426 = 1.1942417708199496e+38;
        bool r74427 = r74394 < r74426;
        long double r74428 = r74407 * r74407;
        long double r74429 = r74408 * r74408;
        long double r74430 = exp(r74429);
        long double r74431 = log(r74430);
        long double r74432 = r74428 - r74431;
        long double r74433 = r74407 + r74408;
        long double r74434 = sqrt(r74433);
        long double r74435 = r74434 * r74434;
        long double r74436 = r74432 / r74435;
        long double r74437 = r74436 / r74414;
        long double r74438 = r74427 ? r74420 : r74437;
        long double r74439 = r74422 ? r74425 : r74438;
        long double r74440 = r74396 ? r74420 : r74439;
        return r74440;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r74441, r74442, r74443, r74444, r74445, r74446;

void setup_mpfr() {
        mpfr_set_default_prec(328);
        mpfr_init(r74441);
        mpfr_init(r74442);
        mpfr_init(r74443);
        mpfr_init(r74444);
        mpfr_init(r74445);
        mpfr_init(r74446);
}

double f_im(float x, float eps) {
        mpfr_set_flt(r74441, x, MPFR_RNDN);
        mpfr_set_flt(r74442, eps, MPFR_RNDN);
        mpfr_add(r74443, r74441, r74442, MPFR_RNDN);
        mpfr_cos(r74444, r74443, MPFR_RNDN);
        mpfr_cos(r74445, r74441, MPFR_RNDN);
        mpfr_sub(r74446, r74444, r74445, MPFR_RNDN);
        return mpfr_get_d(r74446, MPFR_RNDN);
}

