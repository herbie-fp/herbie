#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE problem 3.3.3 */

double f_if(float x) {
        float r74134 = 1.0;
        float r74135 = x;
        float r74136 = r74135 + r74134;
        float r74137 = r74134 / r74136;
        float r74138 = 2.0;
        float r74139 = r74138 / r74135;
        float r74140 = r74137 - r74139;
        float r74141 = r74135 - r74134;
        float r74142 = r74134 / r74141;
        float r74143 = r74140 + r74142;
        return r74143;
}

double f_id(float x) {
        double r74144 = 1.0;
        double r74145 = x;
        double r74146 = r74145 + r74144;
        double r74147 = r74144 / r74146;
        double r74148 = 2.0;
        double r74149 = r74148 / r74145;
        double r74150 = r74147 - r74149;
        double r74151 = r74145 - r74144;
        double r74152 = r74144 / r74151;
        double r74153 = r74150 + r74152;
        return r74153;
}

double f_il(float x) {
        long double r74154 = 1.0;
        long double r74155 = x;
        long double r74156 = r74155 + r74154;
        long double r74157 = r74154 / r74156;
        long double r74158 = 2.0;
        long double r74159 = r74158 / r74155;
        long double r74160 = r74157 - r74159;
        long double r74161 = r74155 - r74154;
        long double r74162 = r74154 / r74161;
        long double r74163 = r74160 + r74162;
        return r74163;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r74164 = 1.0;
        float r74165 = x;
        float r74166 = r74164 * r74165;
        float r74167 = r74165 + r74164;
        float r74168 = 2.0;
        float r74169 = r74167 * r74168;
        float r74170 = r74166 - r74169;
        float r74171 = r74165 - r74164;
        float r74172 = r74170 * r74171;
        float r74173 = r74167 * r74165;
        float r74174 = r74173 * r74164;
        float r74175 = r74172 + r74174;
        float r74176 = r74165 * r74171;
        float r74177 = r74167 * r74176;
        float r74178 = r74175 / r74177;
        return r74178;
}

double f_od(float x) {
        double r74179 = 1.0;
        double r74180 = x;
        double r74181 = r74179 * r74180;
        double r74182 = r74180 + r74179;
        double r74183 = 2.0;
        double r74184 = r74182 * r74183;
        double r74185 = r74181 - r74184;
        double r74186 = r74180 - r74179;
        double r74187 = r74185 * r74186;
        double r74188 = r74182 * r74180;
        double r74189 = r74188 * r74179;
        double r74190 = r74187 + r74189;
        double r74191 = r74180 * r74186;
        double r74192 = r74182 * r74191;
        double r74193 = r74190 / r74192;
        return r74193;
}

double f_ol(float x) {
        long double r74194 = 1.0;
        long double r74195 = x;
        long double r74196 = r74194 * r74195;
        long double r74197 = r74195 + r74194;
        long double r74198 = 2.0;
        long double r74199 = r74197 * r74198;
        long double r74200 = r74196 - r74199;
        long double r74201 = r74195 - r74194;
        long double r74202 = r74200 * r74201;
        long double r74203 = r74197 * r74195;
        long double r74204 = r74203 * r74194;
        long double r74205 = r74202 + r74204;
        long double r74206 = r74195 * r74201;
        long double r74207 = r74197 * r74206;
        long double r74208 = r74205 / r74207;
        return r74208;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r74209, r74210, r74211, r74212, r74213, r74214, r74215, r74216, r74217, r74218;

void setup_mpfr() {
        mpfr_set_default_prec(344);
        mpfr_init(r74209);
        mpfr_init(r74210);
        mpfr_init(r74211);
        mpfr_init(r74212);
        mpfr_init(r74213);
        mpfr_init(r74214);
        mpfr_init(r74215);
        mpfr_init(r74216);
        mpfr_init(r74217);
        mpfr_init(r74218);
}

double f_im(float x) {
        mpfr_init_set_str(r74209, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r74210, x, MPFR_RNDN);
        mpfr_add(r74211, r74210, r74209, MPFR_RNDN);
        mpfr_div(r74212, r74209, r74211, MPFR_RNDN);
        mpfr_init_set_str(r74213, "2", 10, MPFR_RNDN);
        mpfr_div(r74214, r74213, r74210, MPFR_RNDN);
        mpfr_sub(r74215, r74212, r74214, MPFR_RNDN);
        mpfr_sub(r74216, r74210, r74209, MPFR_RNDN);
        mpfr_div(r74217, r74209, r74216, MPFR_RNDN);
        mpfr_add(r74218, r74215, r74217, MPFR_RNDN);
        return mpfr_get_d(r74218, MPFR_RNDN);
}

