#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE example 3.3 */

double f_if(float x, float eps) {
        float r73589 = x;
        float r73590 = eps;
        float r73591 = r73589 + r73590;
        float r73592 = sin(r73591);
        float r73593 = sin(r73589);
        float r73594 = r73592 - r73593;
        return r73594;
}

double f_id(float x, float eps) {
        double r73595 = x;
        double r73596 = eps;
        double r73597 = r73595 + r73596;
        double r73598 = sin(r73597);
        double r73599 = sin(r73595);
        double r73600 = r73598 - r73599;
        return r73600;
}

double f_il(float x, float eps) {
        long double r73601 = x;
        long double r73602 = eps;
        long double r73603 = r73601 + r73602;
        long double r73604 = sin(r73603);
        long double r73605 = sin(r73601);
        long double r73606 = r73604 - r73605;
        return r73606;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x, float eps) {
        float r73607 = x;
        float r73608 = sin(r73607);
        float r73609 = eps;
        float r73610 = cos(r73609);
        float r73611 = r73608 * r73610;
        float r73612 = cos(r73607);
        float r73613 = sin(r73609);
        float r73614 = r73612 * r73613;
        float r73615 = r73614 - r73608;
        float r73616 = 1.0;
        float r73617 = exp(r73616);
        float r73618 = log(r73617);
        float r73619 = r73615 * r73618;
        float r73620 = r73611 + r73619;
        return r73620;
}

double f_od(float x, float eps) {
        double r73621 = x;
        double r73622 = sin(r73621);
        double r73623 = eps;
        double r73624 = cos(r73623);
        double r73625 = r73622 * r73624;
        double r73626 = cos(r73621);
        double r73627 = sin(r73623);
        double r73628 = r73626 * r73627;
        double r73629 = r73628 - r73622;
        double r73630 = 1.0;
        double r73631 = exp(r73630);
        double r73632 = log(r73631);
        double r73633 = r73629 * r73632;
        double r73634 = r73625 + r73633;
        return r73634;
}

double f_ol(float x, float eps) {
        long double r73635 = x;
        long double r73636 = sin(r73635);
        long double r73637 = eps;
        long double r73638 = cos(r73637);
        long double r73639 = r73636 * r73638;
        long double r73640 = cos(r73635);
        long double r73641 = sin(r73637);
        long double r73642 = r73640 * r73641;
        long double r73643 = r73642 - r73636;
        long double r73644 = 1.0;
        long double r73645 = exp(r73644);
        long double r73646 = log(r73645);
        long double r73647 = r73643 * r73646;
        long double r73648 = r73639 + r73647;
        return r73648;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r73649, r73650, r73651, r73652, r73653, r73654;

void setup_mpfr() {
        mpfr_set_default_prec(328);
        mpfr_init(r73649);
        mpfr_init(r73650);
        mpfr_init(r73651);
        mpfr_init(r73652);
        mpfr_init(r73653);
        mpfr_init(r73654);
}

double f_im(float x, float eps) {
        mpfr_set_flt(r73649, x, MPFR_RNDN);
        mpfr_set_flt(r73650, eps, MPFR_RNDN);
        mpfr_add(r73651, r73649, r73650, MPFR_RNDN);
        mpfr_sin(r73652, r73651, MPFR_RNDN);
        mpfr_sin(r73653, r73649, MPFR_RNDN);
        mpfr_sub(r73654, r73652, r73653, MPFR_RNDN);
        return mpfr_get_d(r73654, MPFR_RNDN);
}

