#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Jmat.Real.lambertw, newton loop step */

double f_if(float wj, float x) {
        float r73268 = wj;
        float r73269 = exp(r73268);
        float r73270 = r73268 * r73269;
        float r73271 = x;
        float r73272 = r73270 - r73271;
        float r73273 = r73269 + r73270;
        float r73274 = r73272 / r73273;
        float r73275 = r73268 - r73274;
        return r73275;
}

double f_id(float wj, float x) {
        double r73276 = wj;
        double r73277 = exp(r73276);
        double r73278 = r73276 * r73277;
        double r73279 = x;
        double r73280 = r73278 - r73279;
        double r73281 = r73277 + r73278;
        double r73282 = r73280 / r73281;
        double r73283 = r73276 - r73282;
        return r73283;
}

double f_il(float wj, float x) {
        long double r73284 = wj;
        long double r73285 = exp(r73284);
        long double r73286 = r73284 * r73285;
        long double r73287 = x;
        long double r73288 = r73286 - r73287;
        long double r73289 = r73285 + r73286;
        long double r73290 = r73288 / r73289;
        long double r73291 = r73284 - r73290;
        return r73291;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float wj, float x) {
        float r73292 = wj;
        float r73293 = 1.799779313425716e-11;
        bool r73294 = r73292 < r73293;
        float r73295 = exp(r73292);
        float r73296 = r73292 * r73295;
        float r73297 = x;
        float r73298 = r73296 - r73297;
        float r73299 = r73295 + r73296;
        float r73300 = r73298 / r73299;
        float r73301 = r73292 - r73300;
        float r73302 = 0.00034110191677022865;
        bool r73303 = r73292 < r73302;
        float r73304 = r73292 * r73292;
        float r73305 = r73304 * r73304;
        float r73306 = r73300 * r73300;
        float r73307 = r73306 * r73306;
        float r73308 = r73305 - r73307;
        float r73309 = r73304 + r73306;
        float r73310 = r73308 / r73309;
        float r73311 = r73292 + r73300;
        float r73312 = r73310 / r73311;
        float r73313 = 1.0;
        float r73314 = r73292 + r73313;
        float r73315 = r73313 / r73314;
        float r73316 = r73297 / r73295;
        float r73317 = r73292 - r73316;
        float r73318 = r73313 * r73317;
        float r73319 = r73315 * r73318;
        float r73320 = r73292 - r73319;
        float r73321 = r73303 ? r73312 : r73320;
        float r73322 = r73294 ? r73301 : r73321;
        return r73322;
}

double f_od(float wj, float x) {
        double r73323 = wj;
        double r73324 = 1.799779313425716e-11;
        bool r73325 = r73323 < r73324;
        double r73326 = exp(r73323);
        double r73327 = r73323 * r73326;
        double r73328 = x;
        double r73329 = r73327 - r73328;
        double r73330 = r73326 + r73327;
        double r73331 = r73329 / r73330;
        double r73332 = r73323 - r73331;
        double r73333 = 0.00034110191677022865;
        bool r73334 = r73323 < r73333;
        double r73335 = r73323 * r73323;
        double r73336 = r73335 * r73335;
        double r73337 = r73331 * r73331;
        double r73338 = r73337 * r73337;
        double r73339 = r73336 - r73338;
        double r73340 = r73335 + r73337;
        double r73341 = r73339 / r73340;
        double r73342 = r73323 + r73331;
        double r73343 = r73341 / r73342;
        double r73344 = 1.0;
        double r73345 = r73323 + r73344;
        double r73346 = r73344 / r73345;
        double r73347 = r73328 / r73326;
        double r73348 = r73323 - r73347;
        double r73349 = r73344 * r73348;
        double r73350 = r73346 * r73349;
        double r73351 = r73323 - r73350;
        double r73352 = r73334 ? r73343 : r73351;
        double r73353 = r73325 ? r73332 : r73352;
        return r73353;
}

double f_ol(float wj, float x) {
        long double r73354 = wj;
        long double r73355 = 1.799779313425716e-11;
        bool r73356 = r73354 < r73355;
        long double r73357 = exp(r73354);
        long double r73358 = r73354 * r73357;
        long double r73359 = x;
        long double r73360 = r73358 - r73359;
        long double r73361 = r73357 + r73358;
        long double r73362 = r73360 / r73361;
        long double r73363 = r73354 - r73362;
        long double r73364 = 0.00034110191677022865;
        bool r73365 = r73354 < r73364;
        long double r73366 = r73354 * r73354;
        long double r73367 = r73366 * r73366;
        long double r73368 = r73362 * r73362;
        long double r73369 = r73368 * r73368;
        long double r73370 = r73367 - r73369;
        long double r73371 = r73366 + r73368;
        long double r73372 = r73370 / r73371;
        long double r73373 = r73354 + r73362;
        long double r73374 = r73372 / r73373;
        long double r73375 = 1.0;
        long double r73376 = r73354 + r73375;
        long double r73377 = r73375 / r73376;
        long double r73378 = r73359 / r73357;
        long double r73379 = r73354 - r73378;
        long double r73380 = r73375 * r73379;
        long double r73381 = r73377 * r73380;
        long double r73382 = r73354 - r73381;
        long double r73383 = r73365 ? r73374 : r73382;
        long double r73384 = r73356 ? r73363 : r73383;
        return r73384;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r73385, r73386, r73387, r73388, r73389, r73390, r73391, r73392;

void setup_mpfr() {
        mpfr_set_default_prec(152);
        mpfr_init(r73385);
        mpfr_init(r73386);
        mpfr_init(r73387);
        mpfr_init(r73388);
        mpfr_init(r73389);
        mpfr_init(r73390);
        mpfr_init(r73391);
        mpfr_init(r73392);
}

double f_im(float wj, float x) {
        mpfr_set_flt(r73385, wj, MPFR_RNDN);
        mpfr_exp(r73386, r73385, MPFR_RNDN);
        mpfr_mul(r73387, r73385, r73386, MPFR_RNDN);
        mpfr_set_flt(r73388, x, MPFR_RNDN);
        mpfr_sub(r73389, r73387, r73388, MPFR_RNDN);
        mpfr_add(r73390, r73386, r73387, MPFR_RNDN);
        mpfr_div(r73391, r73389, r73390, MPFR_RNDN);
        mpfr_sub(r73392, r73385, r73391, MPFR_RNDN);
        return mpfr_get_d(r73392, MPFR_RNDN);
}

