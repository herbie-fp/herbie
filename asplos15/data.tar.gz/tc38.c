#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Quotient of products */

double f_if(float a1, float a2, float b1, float b2) {
        float r74781 = a1;
        float r74782 = a2;
        float r74783 = r74781 * r74782;
        float r74784 = b1;
        float r74785 = b2;
        float r74786 = r74784 * r74785;
        float r74787 = r74783 / r74786;
        return r74787;
}

double f_id(float a1, float a2, float b1, float b2) {
        double r74788 = a1;
        double r74789 = a2;
        double r74790 = r74788 * r74789;
        double r74791 = b1;
        double r74792 = b2;
        double r74793 = r74791 * r74792;
        double r74794 = r74790 / r74793;
        return r74794;
}

double f_il(float a1, float a2, float b1, float b2) {
        long double r74795 = a1;
        long double r74796 = a2;
        long double r74797 = r74795 * r74796;
        long double r74798 = b1;
        long double r74799 = b2;
        long double r74800 = r74798 * r74799;
        long double r74801 = r74797 / r74800;
        return r74801;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a1, float a2, float b1, float b2) {
        float r74802 = a1;
        float r74803 = -5718546606.568445;
        bool r74804 = r74802 < r74803;
        float r74805 = b1;
        float r74806 = r74802 / r74805;
        float r74807 = a2;
        float r74808 = r74806 * r74807;
        float r74809 = b2;
        float r74810 = r74808 / r74809;
        float r74811 = -6.416838747498545e-25;
        bool r74812 = r74802 < r74811;
        float r74813 = r74802 * r74807;
        float r74814 = r74805 * r74809;
        float r74815 = r74813 / r74814;
        float r74816 = 2.427266233118075e-16;
        bool r74817 = r74802 < r74816;
        float r74818 = r74807 / r74809;
        float r74819 = r74806 * r74818;
        float r74820 = r74817 ? r74810 : r74819;
        float r74821 = r74812 ? r74815 : r74820;
        float r74822 = r74804 ? r74810 : r74821;
        return r74822;
}

double f_od(float a1, float a2, float b1, float b2) {
        double r74823 = a1;
        double r74824 = -5718546606.568445;
        bool r74825 = r74823 < r74824;
        double r74826 = b1;
        double r74827 = r74823 / r74826;
        double r74828 = a2;
        double r74829 = r74827 * r74828;
        double r74830 = b2;
        double r74831 = r74829 / r74830;
        double r74832 = -6.416838747498545e-25;
        bool r74833 = r74823 < r74832;
        double r74834 = r74823 * r74828;
        double r74835 = r74826 * r74830;
        double r74836 = r74834 / r74835;
        double r74837 = 2.427266233118075e-16;
        bool r74838 = r74823 < r74837;
        double r74839 = r74828 / r74830;
        double r74840 = r74827 * r74839;
        double r74841 = r74838 ? r74831 : r74840;
        double r74842 = r74833 ? r74836 : r74841;
        double r74843 = r74825 ? r74831 : r74842;
        return r74843;
}

double f_ol(float a1, float a2, float b1, float b2) {
        long double r74844 = a1;
        long double r74845 = -5718546606.568445;
        bool r74846 = r74844 < r74845;
        long double r74847 = b1;
        long double r74848 = r74844 / r74847;
        long double r74849 = a2;
        long double r74850 = r74848 * r74849;
        long double r74851 = b2;
        long double r74852 = r74850 / r74851;
        long double r74853 = -6.416838747498545e-25;
        bool r74854 = r74844 < r74853;
        long double r74855 = r74844 * r74849;
        long double r74856 = r74847 * r74851;
        long double r74857 = r74855 / r74856;
        long double r74858 = 2.427266233118075e-16;
        bool r74859 = r74844 < r74858;
        long double r74860 = r74849 / r74851;
        long double r74861 = r74848 * r74860;
        long double r74862 = r74859 ? r74852 : r74861;
        long double r74863 = r74854 ? r74857 : r74862;
        long double r74864 = r74846 ? r74852 : r74863;
        return r74864;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r74865, r74866, r74867, r74868, r74869, r74870, r74871;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r74865);
        mpfr_init(r74866);
        mpfr_init(r74867);
        mpfr_init(r74868);
        mpfr_init(r74869);
        mpfr_init(r74870);
        mpfr_init(r74871);
}

double f_im(float a1, float a2, float b1, float b2) {
        mpfr_set_flt(r74865, a1, MPFR_RNDN);
        mpfr_set_flt(r74866, a2, MPFR_RNDN);
        mpfr_mul(r74867, r74865, r74866, MPFR_RNDN);
        mpfr_set_flt(r74868, b1, MPFR_RNDN);
        mpfr_set_flt(r74869, b2, MPFR_RNDN);
        mpfr_mul(r74870, r74868, r74869, MPFR_RNDN);
        mpfr_div(r74871, r74867, r74870, MPFR_RNDN);
        return mpfr_get_d(r74871, MPFR_RNDN);
}

