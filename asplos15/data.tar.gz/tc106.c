#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* _divideComplex, real part */

double f_if(float x_re, float x_im, float y_re, float y_im) {
        float r84481 = x_re;
        float r84482 = y_re;
        float r84483 = r84481 * r84482;
        float r84484 = x_im;
        float r84485 = y_im;
        float r84486 = r84484 * r84485;
        float r84487 = r84483 + r84486;
        float r84488 = r84482 * r84482;
        float r84489 = r84485 * r84485;
        float r84490 = r84488 + r84489;
        float r84491 = r84487 / r84490;
        return r84491;
}

double f_id(float x_re, float x_im, float y_re, float y_im) {
        double r84492 = x_re;
        double r84493 = y_re;
        double r84494 = r84492 * r84493;
        double r84495 = x_im;
        double r84496 = y_im;
        double r84497 = r84495 * r84496;
        double r84498 = r84494 + r84497;
        double r84499 = r84493 * r84493;
        double r84500 = r84496 * r84496;
        double r84501 = r84499 + r84500;
        double r84502 = r84498 / r84501;
        return r84502;
}

double f_il(float x_re, float x_im, float y_re, float y_im) {
        long double r84503 = x_re;
        long double r84504 = y_re;
        long double r84505 = r84503 * r84504;
        long double r84506 = x_im;
        long double r84507 = y_im;
        long double r84508 = r84506 * r84507;
        long double r84509 = r84505 + r84508;
        long double r84510 = r84504 * r84504;
        long double r84511 = r84507 * r84507;
        long double r84512 = r84510 + r84511;
        long double r84513 = r84509 / r84512;
        return r84513;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x_re, float x_im, float y_re, float y_im) {
        float r84514 = 1.0;
        float r84515 = y_re;
        float r84516 = r84515 * r84515;
        float r84517 = y_im;
        float r84518 = r84517 * r84517;
        float r84519 = r84516 + r84518;
        float r84520 = 1.0/r84519;
        float r84521 = x_re;
        float r84522 = r84521 * r84515;
        float r84523 = r84520 * r84522;
        float r84524 = x_im;
        float r84525 = r84524 * r84517;
        float r84526 = r84519 / r84525;
        float r84527 = r84514 / r84526;
        float r84528 = r84523 + r84527;
        float r84529 = r84514 * r84528;
        return r84529;
}

double f_od(float x_re, float x_im, float y_re, float y_im) {
        double r84530 = 1.0;
        double r84531 = y_re;
        double r84532 = r84531 * r84531;
        double r84533 = y_im;
        double r84534 = r84533 * r84533;
        double r84535 = r84532 + r84534;
        double r84536 = 1.0/r84535;
        double r84537 = x_re;
        double r84538 = r84537 * r84531;
        double r84539 = r84536 * r84538;
        double r84540 = x_im;
        double r84541 = r84540 * r84533;
        double r84542 = r84535 / r84541;
        double r84543 = r84530 / r84542;
        double r84544 = r84539 + r84543;
        double r84545 = r84530 * r84544;
        return r84545;
}

double f_ol(float x_re, float x_im, float y_re, float y_im) {
        long double r84546 = 1.0;
        long double r84547 = y_re;
        long double r84548 = r84547 * r84547;
        long double r84549 = y_im;
        long double r84550 = r84549 * r84549;
        long double r84551 = r84548 + r84550;
        long double r84552 = 1.0/r84551;
        long double r84553 = x_re;
        long double r84554 = r84553 * r84547;
        long double r84555 = r84552 * r84554;
        long double r84556 = x_im;
        long double r84557 = r84556 * r84549;
        long double r84558 = r84551 / r84557;
        long double r84559 = r84546 / r84558;
        long double r84560 = r84555 + r84559;
        long double r84561 = r84546 * r84560;
        return r84561;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r84562, r84563, r84564, r84565, r84566, r84567, r84568, r84569, r84570, r84571, r84572;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r84562);
        mpfr_init(r84563);
        mpfr_init(r84564);
        mpfr_init(r84565);
        mpfr_init(r84566);
        mpfr_init(r84567);
        mpfr_init(r84568);
        mpfr_init(r84569);
        mpfr_init(r84570);
        mpfr_init(r84571);
        mpfr_init(r84572);
}

double f_im(float x_re, float x_im, float y_re, float y_im) {
        mpfr_set_flt(r84562, x_re, MPFR_RNDN);
        mpfr_set_flt(r84563, y_re, MPFR_RNDN);
        mpfr_mul(r84564, r84562, r84563, MPFR_RNDN);
        mpfr_set_flt(r84565, x_im, MPFR_RNDN);
        mpfr_set_flt(r84566, y_im, MPFR_RNDN);
        mpfr_mul(r84567, r84565, r84566, MPFR_RNDN);
        mpfr_add(r84568, r84564, r84567, MPFR_RNDN);
        mpfr_mul(r84569, r84563, r84563, MPFR_RNDN);
        mpfr_mul(r84570, r84566, r84566, MPFR_RNDN);
        mpfr_add(r84571, r84569, r84570, MPFR_RNDN);
        mpfr_div(r84572, r84568, r84571, MPFR_RNDN);
        return mpfr_get_d(r84572, MPFR_RNDN);
}

