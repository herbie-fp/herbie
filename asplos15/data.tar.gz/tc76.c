#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE example 3.8 */

double f_if(float N) {
        float r80178 = N;
        float r80179 = 1.0;
        float r80180 = r80178 + r80179;
        float r80181 = log(r80180);
        float r80182 = r80180 * r80181;
        float r80183 = log(r80178);
        float r80184 = r80178 * r80183;
        float r80185 = r80182 - r80184;
        float r80186 = r80185 - r80179;
        return r80186;
}

double f_id(float N) {
        double r80187 = N;
        double r80188 = 1.0;
        double r80189 = r80187 + r80188;
        double r80190 = log(r80189);
        double r80191 = r80189 * r80190;
        double r80192 = log(r80187);
        double r80193 = r80187 * r80192;
        double r80194 = r80191 - r80193;
        double r80195 = r80194 - r80188;
        return r80195;
}

double f_il(float N) {
        long double r80196 = N;
        long double r80197 = 1.0;
        long double r80198 = r80196 + r80197;
        long double r80199 = log(r80198);
        long double r80200 = r80198 * r80199;
        long double r80201 = log(r80196);
        long double r80202 = r80196 * r80201;
        long double r80203 = r80200 - r80202;
        long double r80204 = r80203 - r80197;
        return r80204;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float N) {
        float r80205 = N;
        float r80206 = 1.0;
        float r80207 = r80205 + r80206;
        float r80208 = log(r80207);
        float r80209 = sqrt(r80208);
        float r80210 = r80209 * r80209;
        float r80211 = r80210 * r80205;
        float r80212 = sqrt(r80211);
        float r80213 = r80212 * r80212;
        float r80214 = r80213 + r80208;
        float r80215 = r80214 * r80214;
        float r80216 = r80205 * r80205;
        float r80217 = log(r80205);
        float r80218 = r80217 * r80217;
        float r80219 = r80216 * r80218;
        float r80220 = r80215 - r80219;
        float r80221 = log(r80208);
        float r80222 = exp(r80221);
        float r80223 = r80222 * r80205;
        float r80224 = r80223 + r80208;
        float r80225 = r80205 * r80217;
        float r80226 = r80224 + r80225;
        float r80227 = r80220 / r80226;
        float r80228 = r80227 - r80206;
        return r80228;
}

double f_od(float N) {
        double r80229 = N;
        double r80230 = 1.0;
        double r80231 = r80229 + r80230;
        double r80232 = log(r80231);
        double r80233 = sqrt(r80232);
        double r80234 = r80233 * r80233;
        double r80235 = r80234 * r80229;
        double r80236 = sqrt(r80235);
        double r80237 = r80236 * r80236;
        double r80238 = r80237 + r80232;
        double r80239 = r80238 * r80238;
        double r80240 = r80229 * r80229;
        double r80241 = log(r80229);
        double r80242 = r80241 * r80241;
        double r80243 = r80240 * r80242;
        double r80244 = r80239 - r80243;
        double r80245 = log(r80232);
        double r80246 = exp(r80245);
        double r80247 = r80246 * r80229;
        double r80248 = r80247 + r80232;
        double r80249 = r80229 * r80241;
        double r80250 = r80248 + r80249;
        double r80251 = r80244 / r80250;
        double r80252 = r80251 - r80230;
        return r80252;
}

double f_ol(float N) {
        long double r80253 = N;
        long double r80254 = 1.0;
        long double r80255 = r80253 + r80254;
        long double r80256 = log(r80255);
        long double r80257 = sqrt(r80256);
        long double r80258 = r80257 * r80257;
        long double r80259 = r80258 * r80253;
        long double r80260 = sqrt(r80259);
        long double r80261 = r80260 * r80260;
        long double r80262 = r80261 + r80256;
        long double r80263 = r80262 * r80262;
        long double r80264 = r80253 * r80253;
        long double r80265 = log(r80253);
        long double r80266 = r80265 * r80265;
        long double r80267 = r80264 * r80266;
        long double r80268 = r80263 - r80267;
        long double r80269 = log(r80256);
        long double r80270 = exp(r80269);
        long double r80271 = r80270 * r80253;
        long double r80272 = r80271 + r80256;
        long double r80273 = r80253 * r80265;
        long double r80274 = r80272 + r80273;
        long double r80275 = r80268 / r80274;
        long double r80276 = r80275 - r80254;
        return r80276;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r80277, r80278, r80279, r80280, r80281, r80282, r80283, r80284, r80285;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r80277);
        mpfr_init(r80278);
        mpfr_init(r80279);
        mpfr_init(r80280);
        mpfr_init(r80281);
        mpfr_init(r80282);
        mpfr_init(r80283);
        mpfr_init(r80284);
        mpfr_init(r80285);
}

double f_im(float N) {
        mpfr_set_flt(r80277, N, MPFR_RNDN);
        mpfr_init_set_str(r80278, "1", 10, MPFR_RNDN);
        mpfr_add(r80279, r80277, r80278, MPFR_RNDN);
        mpfr_log(r80280, r80279, MPFR_RNDN);
        mpfr_mul(r80281, r80279, r80280, MPFR_RNDN);
        mpfr_log(r80282, r80277, MPFR_RNDN);
        mpfr_mul(r80283, r80277, r80282, MPFR_RNDN);
        mpfr_sub(r80284, r80281, r80283, MPFR_RNDN);
        mpfr_sub(r80285, r80284, r80278, MPFR_RNDN);
        return mpfr_get_d(r80285, MPFR_RNDN);
}

