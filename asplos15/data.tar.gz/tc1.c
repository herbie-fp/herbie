#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Associate and commute */

double f_if(float x) {
        float r72377 = x;
        float r72378 = 1.0;
        float r72379 = r72377 + r72378;
        float r72380 = r72379 - r72377;
        return r72380;
}

double f_id(float x) {
        double r72381 = x;
        double r72382 = 1.0;
        double r72383 = r72381 + r72382;
        double r72384 = r72383 - r72381;
        return r72384;
}

double f_il(float x) {
        long double r72385 = x;
        long double r72386 = 1.0;
        long double r72387 = r72385 + r72386;
        long double r72388 = r72387 - r72385;
        return r72388;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r72389 = 1.0;
        return r72389;
}

double f_od(float x) {
        double r72390 = 1.0;
        return r72390;
}

double f_ol(float x) {
        long double r72391 = 1.0;
        return r72391;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r72392, r72393, r72394, r72395;

void setup_mpfr() {
        mpfr_set_default_prec(152);
        mpfr_init(r72392);
        mpfr_init(r72393);
        mpfr_init(r72394);
        mpfr_init(r72395);
}

double f_im(float x) {
        mpfr_set_flt(r72392, x, MPFR_RNDN);
        mpfr_init_set_str(r72393, "1", 10, MPFR_RNDN);
        mpfr_add(r72394, r72392, r72393, MPFR_RNDN);
        mpfr_sub(r72395, r72394, r72392, MPFR_RNDN);
        return mpfr_get_d(r72395, MPFR_RNDN);
}

