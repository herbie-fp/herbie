#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE problem 3.2.1 */

double f_if(float a, float b_2F2, float c) {
        float r80495 = -2.0;
        float r80496 = b_2F2;
        float r80497 = r80495 * r80496;
        float r80498 = 2.0;
        float r80499 = r80498 * r80496;
        float r80500 = r80499 * r80499;
        float r80501 = 4.0;
        float r80502 = a;
        float r80503 = c;
        float r80504 = r80502 * r80503;
        float r80505 = r80501 * r80504;
        float r80506 = r80500 - r80505;
        float r80507 = sqrt(r80506);
        float r80508 = r80497 + r80507;
        float r80509 = r80498 * r80502;
        float r80510 = r80508 / r80509;
        return r80510;
}

double f_id(float a, float b_2F2, float c) {
        double r80511 = -2.0;
        double r80512 = b_2F2;
        double r80513 = r80511 * r80512;
        double r80514 = 2.0;
        double r80515 = r80514 * r80512;
        double r80516 = r80515 * r80515;
        double r80517 = 4.0;
        double r80518 = a;
        double r80519 = c;
        double r80520 = r80518 * r80519;
        double r80521 = r80517 * r80520;
        double r80522 = r80516 - r80521;
        double r80523 = sqrt(r80522);
        double r80524 = r80513 + r80523;
        double r80525 = r80514 * r80518;
        double r80526 = r80524 / r80525;
        return r80526;
}

double f_il(float a, float b_2F2, float c) {
        long double r80527 = -2.0;
        long double r80528 = b_2F2;
        long double r80529 = r80527 * r80528;
        long double r80530 = 2.0;
        long double r80531 = r80530 * r80528;
        long double r80532 = r80531 * r80531;
        long double r80533 = 4.0;
        long double r80534 = a;
        long double r80535 = c;
        long double r80536 = r80534 * r80535;
        long double r80537 = r80533 * r80536;
        long double r80538 = r80532 - r80537;
        long double r80539 = sqrt(r80538);
        long double r80540 = r80529 + r80539;
        long double r80541 = r80530 * r80534;
        long double r80542 = r80540 / r80541;
        return r80542;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a, float b_2F2, float c) {
        float r80543 = b_2F2;
        float r80544 = -0.0;
        bool r80545 = r80543 < r80544;
        float r80546 = -2.0;
        float r80547 = r80546 * r80543;
        float r80548 = 2.0;
        float r80549 = r80548 * r80543;
        float r80550 = r80549 * r80549;
        float r80551 = 4.0;
        float r80552 = a;
        float r80553 = c;
        float r80554 = r80552 * r80553;
        float r80555 = r80551 * r80554;
        float r80556 = r80550 - r80555;
        float r80557 = sqrt(r80556);
        float r80558 = r80547 + r80557;
        float r80559 = r80548 * r80552;
        float r80560 = r80558 / r80559;
        float r80561 = r80543 * r80543;
        float r80562 = r80551 * r80561;
        float r80563 = r80562 - r80555;
        float r80564 = sqrt(r80563);
        float r80565 = r80547 - r80564;
        float r80566 = r80555 / r80565;
        float r80567 = r80566 / r80559;
        float r80568 = r80545 ? r80560 : r80567;
        return r80568;
}

double f_od(float a, float b_2F2, float c) {
        double r80569 = b_2F2;
        double r80570 = -0.0;
        bool r80571 = r80569 < r80570;
        double r80572 = -2.0;
        double r80573 = r80572 * r80569;
        double r80574 = 2.0;
        double r80575 = r80574 * r80569;
        double r80576 = r80575 * r80575;
        double r80577 = 4.0;
        double r80578 = a;
        double r80579 = c;
        double r80580 = r80578 * r80579;
        double r80581 = r80577 * r80580;
        double r80582 = r80576 - r80581;
        double r80583 = sqrt(r80582);
        double r80584 = r80573 + r80583;
        double r80585 = r80574 * r80578;
        double r80586 = r80584 / r80585;
        double r80587 = r80569 * r80569;
        double r80588 = r80577 * r80587;
        double r80589 = r80588 - r80581;
        double r80590 = sqrt(r80589);
        double r80591 = r80573 - r80590;
        double r80592 = r80581 / r80591;
        double r80593 = r80592 / r80585;
        double r80594 = r80571 ? r80586 : r80593;
        return r80594;
}

double f_ol(float a, float b_2F2, float c) {
        long double r80595 = b_2F2;
        long double r80596 = -0.0;
        bool r80597 = r80595 < r80596;
        long double r80598 = -2.0;
        long double r80599 = r80598 * r80595;
        long double r80600 = 2.0;
        long double r80601 = r80600 * r80595;
        long double r80602 = r80601 * r80601;
        long double r80603 = 4.0;
        long double r80604 = a;
        long double r80605 = c;
        long double r80606 = r80604 * r80605;
        long double r80607 = r80603 * r80606;
        long double r80608 = r80602 - r80607;
        long double r80609 = sqrt(r80608);
        long double r80610 = r80599 + r80609;
        long double r80611 = r80600 * r80604;
        long double r80612 = r80610 / r80611;
        long double r80613 = r80595 * r80595;
        long double r80614 = r80603 * r80613;
        long double r80615 = r80614 - r80607;
        long double r80616 = sqrt(r80615);
        long double r80617 = r80599 - r80616;
        long double r80618 = r80607 / r80617;
        long double r80619 = r80618 / r80611;
        long double r80620 = r80597 ? r80612 : r80619;
        return r80620;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r80621, r80622, r80623, r80624, r80625, r80626, r80627, r80628, r80629, r80630, r80631, r80632, r80633, r80634, r80635, r80636;

void setup_mpfr() {
        mpfr_set_default_prec(536);
        mpfr_init(r80621);
        mpfr_init(r80622);
        mpfr_init(r80623);
        mpfr_init(r80624);
        mpfr_init(r80625);
        mpfr_init(r80626);
        mpfr_init(r80627);
        mpfr_init(r80628);
        mpfr_init(r80629);
        mpfr_init(r80630);
        mpfr_init(r80631);
        mpfr_init(r80632);
        mpfr_init(r80633);
        mpfr_init(r80634);
        mpfr_init(r80635);
        mpfr_init(r80636);
}

double f_im(float a, float b_2F2, float c) {
        mpfr_init_set_str(r80621, "-2", 10, MPFR_RNDN);
        mpfr_set_flt(r80622, b_2F2, MPFR_RNDN);
        mpfr_mul(r80623, r80621, r80622, MPFR_RNDN);
        mpfr_init_set_str(r80624, "2", 10, MPFR_RNDN);
        mpfr_mul(r80625, r80624, r80622, MPFR_RNDN);
        mpfr_mul(r80626, r80625, r80625, MPFR_RNDN);
        mpfr_init_set_str(r80627, "4", 10, MPFR_RNDN);
        mpfr_set_flt(r80628, a, MPFR_RNDN);
        mpfr_set_flt(r80629, c, MPFR_RNDN);
        mpfr_mul(r80630, r80628, r80629, MPFR_RNDN);
        mpfr_mul(r80631, r80627, r80630, MPFR_RNDN);
        mpfr_sub(r80632, r80626, r80631, MPFR_RNDN);
        mpfr_sqrt(r80633, r80632, MPFR_RNDN);
        mpfr_add(r80634, r80623, r80633, MPFR_RNDN);
        mpfr_mul(r80635, r80624, r80628, MPFR_RNDN);
        mpfr_div(r80636, r80634, r80635, MPFR_RNDN);
        return mpfr_get_d(r80636, MPFR_RNDN);
}

