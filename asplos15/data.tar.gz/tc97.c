#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Toniolo and Linder, Equation (2) */

double f_if(float t, float l, float Om, float Omc) {
        float r83316 = 1.0;
        float r83317 = Om;
        float r83318 = Omc;
        float r83319 = r83317 / r83318;
        float r83320 = r83319 * r83319;
        float r83321 = r83316 - r83320;
        float r83322 = 2.0;
        float r83323 = t;
        float r83324 = l;
        float r83325 = r83323 / r83324;
        float r83326 = r83325 * r83325;
        float r83327 = r83322 * r83326;
        float r83328 = r83316 + r83327;
        float r83329 = r83321 / r83328;
        float r83330 = sqrt(r83329);
        float r83331 = asin(r83330);
        return r83331;
}

double f_id(float t, float l, float Om, float Omc) {
        double r83332 = 1.0;
        double r83333 = Om;
        double r83334 = Omc;
        double r83335 = r83333 / r83334;
        double r83336 = r83335 * r83335;
        double r83337 = r83332 - r83336;
        double r83338 = 2.0;
        double r83339 = t;
        double r83340 = l;
        double r83341 = r83339 / r83340;
        double r83342 = r83341 * r83341;
        double r83343 = r83338 * r83342;
        double r83344 = r83332 + r83343;
        double r83345 = r83337 / r83344;
        double r83346 = sqrt(r83345);
        double r83347 = asin(r83346);
        return r83347;
}

double f_il(float t, float l, float Om, float Omc) {
        long double r83348 = 1.0;
        long double r83349 = Om;
        long double r83350 = Omc;
        long double r83351 = r83349 / r83350;
        long double r83352 = r83351 * r83351;
        long double r83353 = r83348 - r83352;
        long double r83354 = 2.0;
        long double r83355 = t;
        long double r83356 = l;
        long double r83357 = r83355 / r83356;
        long double r83358 = r83357 * r83357;
        long double r83359 = r83354 * r83358;
        long double r83360 = r83348 + r83359;
        long double r83361 = r83353 / r83360;
        long double r83362 = sqrt(r83361);
        long double r83363 = asin(r83362);
        return r83363;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float t, float l, float Om, float Omc) {
        float r83364 = t;
        float r83365 = -5718546606.568445;
        bool r83366 = r83364 < r83365;
        float r83367 = 1.0;
        float r83368 = Om;
        float r83369 = Omc;
        float r83370 = r83368 / r83369;
        float r83371 = r83370 * r83370;
        float r83372 = r83367 - r83371;
        float r83373 = 2.0;
        float r83374 = l;
        float r83375 = r83374 * r83374;
        float r83376 = r83364 / r83375;
        float r83377 = r83364 * r83376;
        float r83378 = r83373 * r83377;
        float r83379 = r83367 + r83378;
        float r83380 = r83372 / r83379;
        float r83381 = sqrt(r83380);
        float r83382 = asin(r83381);
        float r83383 = r83367 / r83374;
        float r83384 = r83364 * r83364;
        float r83385 = r83384 / r83374;
        float r83386 = r83383 * r83385;
        float r83387 = r83373 * r83386;
        float r83388 = r83367 + r83387;
        float r83389 = r83372 / r83388;
        float r83390 = sqrt(r83389);
        float r83391 = asin(r83390);
        float r83392 = r83366 ? r83382 : r83391;
        return r83392;
}

double f_od(float t, float l, float Om, float Omc) {
        double r83393 = t;
        double r83394 = -5718546606.568445;
        bool r83395 = r83393 < r83394;
        double r83396 = 1.0;
        double r83397 = Om;
        double r83398 = Omc;
        double r83399 = r83397 / r83398;
        double r83400 = r83399 * r83399;
        double r83401 = r83396 - r83400;
        double r83402 = 2.0;
        double r83403 = l;
        double r83404 = r83403 * r83403;
        double r83405 = r83393 / r83404;
        double r83406 = r83393 * r83405;
        double r83407 = r83402 * r83406;
        double r83408 = r83396 + r83407;
        double r83409 = r83401 / r83408;
        double r83410 = sqrt(r83409);
        double r83411 = asin(r83410);
        double r83412 = r83396 / r83403;
        double r83413 = r83393 * r83393;
        double r83414 = r83413 / r83403;
        double r83415 = r83412 * r83414;
        double r83416 = r83402 * r83415;
        double r83417 = r83396 + r83416;
        double r83418 = r83401 / r83417;
        double r83419 = sqrt(r83418);
        double r83420 = asin(r83419);
        double r83421 = r83395 ? r83411 : r83420;
        return r83421;
}

double f_ol(float t, float l, float Om, float Omc) {
        long double r83422 = t;
        long double r83423 = -5718546606.568445;
        bool r83424 = r83422 < r83423;
        long double r83425 = 1.0;
        long double r83426 = Om;
        long double r83427 = Omc;
        long double r83428 = r83426 / r83427;
        long double r83429 = r83428 * r83428;
        long double r83430 = r83425 - r83429;
        long double r83431 = 2.0;
        long double r83432 = l;
        long double r83433 = r83432 * r83432;
        long double r83434 = r83422 / r83433;
        long double r83435 = r83422 * r83434;
        long double r83436 = r83431 * r83435;
        long double r83437 = r83425 + r83436;
        long double r83438 = r83430 / r83437;
        long double r83439 = sqrt(r83438);
        long double r83440 = asin(r83439);
        long double r83441 = r83425 / r83432;
        long double r83442 = r83422 * r83422;
        long double r83443 = r83442 / r83432;
        long double r83444 = r83441 * r83443;
        long double r83445 = r83431 * r83444;
        long double r83446 = r83425 + r83445;
        long double r83447 = r83430 / r83446;
        long double r83448 = sqrt(r83447);
        long double r83449 = asin(r83448);
        long double r83450 = r83424 ? r83440 : r83449;
        return r83450;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r83451, r83452, r83453, r83454, r83455, r83456, r83457, r83458, r83459, r83460, r83461, r83462, r83463, r83464, r83465, r83466;

void setup_mpfr() {
        mpfr_set_default_prec(136);
        mpfr_init(r83451);
        mpfr_init(r83452);
        mpfr_init(r83453);
        mpfr_init(r83454);
        mpfr_init(r83455);
        mpfr_init(r83456);
        mpfr_init(r83457);
        mpfr_init(r83458);
        mpfr_init(r83459);
        mpfr_init(r83460);
        mpfr_init(r83461);
        mpfr_init(r83462);
        mpfr_init(r83463);
        mpfr_init(r83464);
        mpfr_init(r83465);
        mpfr_init(r83466);
}

double f_im(float t, float l, float Om, float Omc) {
        mpfr_init_set_str(r83451, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r83452, Om, MPFR_RNDN);
        mpfr_set_flt(r83453, Omc, MPFR_RNDN);
        mpfr_div(r83454, r83452, r83453, MPFR_RNDN);
        mpfr_mul(r83455, r83454, r83454, MPFR_RNDN);
        mpfr_sub(r83456, r83451, r83455, MPFR_RNDN);
        mpfr_init_set_str(r83457, "2", 10, MPFR_RNDN);
        mpfr_set_flt(r83458, t, MPFR_RNDN);
        mpfr_set_flt(r83459, l, MPFR_RNDN);
        mpfr_div(r83460, r83458, r83459, MPFR_RNDN);
        mpfr_mul(r83461, r83460, r83460, MPFR_RNDN);
        mpfr_mul(r83462, r83457, r83461, MPFR_RNDN);
        mpfr_add(r83463, r83451, r83462, MPFR_RNDN);
        mpfr_div(r83464, r83456, r83463, MPFR_RNDN);
        mpfr_sqrt(r83465, r83464, MPFR_RNDN);
        mpfr_asin(r83466, r83465, MPFR_RNDN);
        return mpfr_get_d(r83466, MPFR_RNDN);
}

