#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE p42 */

double f_if(float a, float b, float c) {
        float r73955 = b;
        float r73956 = -r73955;
        float r73957 = r73955 * r73955;
        float r73958 = 4.0;
        float r73959 = a;
        float r73960 = c;
        float r73961 = r73959 * r73960;
        float r73962 = r73958 * r73961;
        float r73963 = r73957 - r73962;
        float r73964 = sqrt(r73963);
        float r73965 = r73956 + r73964;
        float r73966 = 2.0;
        float r73967 = r73966 * r73959;
        float r73968 = r73965 / r73967;
        return r73968;
}

double f_id(float a, float b, float c) {
        double r73969 = b;
        double r73970 = -r73969;
        double r73971 = r73969 * r73969;
        double r73972 = 4.0;
        double r73973 = a;
        double r73974 = c;
        double r73975 = r73973 * r73974;
        double r73976 = r73972 * r73975;
        double r73977 = r73971 - r73976;
        double r73978 = sqrt(r73977);
        double r73979 = r73970 + r73978;
        double r73980 = 2.0;
        double r73981 = r73980 * r73973;
        double r73982 = r73979 / r73981;
        return r73982;
}

double f_il(float a, float b, float c) {
        long double r73983 = b;
        long double r73984 = -r73983;
        long double r73985 = r73983 * r73983;
        long double r73986 = 4.0;
        long double r73987 = a;
        long double r73988 = c;
        long double r73989 = r73987 * r73988;
        long double r73990 = r73986 * r73989;
        long double r73991 = r73985 - r73990;
        long double r73992 = sqrt(r73991);
        long double r73993 = r73984 + r73992;
        long double r73994 = 2.0;
        long double r73995 = r73994 * r73987;
        long double r73996 = r73993 / r73995;
        return r73996;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a, float b, float c) {
        float r73997 = a;
        float r73998 = -9.161047768334243e+16;
        bool r73999 = r73997 < r73998;
        float r74000 = 1.0;
        float r74001 = 0.5;
        float r74002 = b;
        float r74003 = r74002 / r73997;
        float r74004 = r74001 * r74003;
        float r74005 = -r74004;
        float r74006 = r74001 / r73997;
        float r74007 = r74002 * r74002;
        float r74008 = 4.0;
        float r74009 = c;
        float r74010 = r73997 * r74009;
        float r74011 = r74008 * r74010;
        float r74012 = r74007 - r74011;
        float r74013 = sqrt(r74012);
        float r74014 = r74006 * r74013;
        float r74015 = r74005 + r74014;
        float r74016 = r74000 * r74015;
        float r74017 = -r74002;
        float r74018 = r74017 + r74013;
        float r74019 = 2.0;
        float r74020 = r74019 * r73997;
        float r74021 = r74018 / r74020;
        float r74022 = r73999 ? r74016 : r74021;
        return r74022;
}

double f_od(float a, float b, float c) {
        double r74023 = a;
        double r74024 = -9.161047768334243e+16;
        bool r74025 = r74023 < r74024;
        double r74026 = 1.0;
        double r74027 = 0.5;
        double r74028 = b;
        double r74029 = r74028 / r74023;
        double r74030 = r74027 * r74029;
        double r74031 = -r74030;
        double r74032 = r74027 / r74023;
        double r74033 = r74028 * r74028;
        double r74034 = 4.0;
        double r74035 = c;
        double r74036 = r74023 * r74035;
        double r74037 = r74034 * r74036;
        double r74038 = r74033 - r74037;
        double r74039 = sqrt(r74038);
        double r74040 = r74032 * r74039;
        double r74041 = r74031 + r74040;
        double r74042 = r74026 * r74041;
        double r74043 = -r74028;
        double r74044 = r74043 + r74039;
        double r74045 = 2.0;
        double r74046 = r74045 * r74023;
        double r74047 = r74044 / r74046;
        double r74048 = r74025 ? r74042 : r74047;
        return r74048;
}

double f_ol(float a, float b, float c) {
        long double r74049 = a;
        long double r74050 = -9.161047768334243e+16;
        bool r74051 = r74049 < r74050;
        long double r74052 = 1.0;
        long double r74053 = 0.5;
        long double r74054 = b;
        long double r74055 = r74054 / r74049;
        long double r74056 = r74053 * r74055;
        long double r74057 = -r74056;
        long double r74058 = r74053 / r74049;
        long double r74059 = r74054 * r74054;
        long double r74060 = 4.0;
        long double r74061 = c;
        long double r74062 = r74049 * r74061;
        long double r74063 = r74060 * r74062;
        long double r74064 = r74059 - r74063;
        long double r74065 = sqrt(r74064);
        long double r74066 = r74058 * r74065;
        long double r74067 = r74057 + r74066;
        long double r74068 = r74052 * r74067;
        long double r74069 = -r74054;
        long double r74070 = r74069 + r74065;
        long double r74071 = 2.0;
        long double r74072 = r74071 * r74049;
        long double r74073 = r74070 / r74072;
        long double r74074 = r74051 ? r74068 : r74073;
        return r74074;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r74075, r74076, r74077, r74078, r74079, r74080, r74081, r74082, r74083, r74084, r74085, r74086, r74087, r74088;

void setup_mpfr() {
        mpfr_set_default_prec(536);
        mpfr_init(r74075);
        mpfr_init(r74076);
        mpfr_init(r74077);
        mpfr_init(r74078);
        mpfr_init(r74079);
        mpfr_init(r74080);
        mpfr_init(r74081);
        mpfr_init(r74082);
        mpfr_init(r74083);
        mpfr_init(r74084);
        mpfr_init(r74085);
        mpfr_init(r74086);
        mpfr_init(r74087);
        mpfr_init(r74088);
}

double f_im(float a, float b, float c) {
        mpfr_set_flt(r74075, b, MPFR_RNDN);
        mpfr_neg(r74076, r74075, MPFR_RNDN);
        mpfr_mul(r74077, r74075, r74075, MPFR_RNDN);
        mpfr_init_set_str(r74078, "4", 10, MPFR_RNDN);
        mpfr_set_flt(r74079, a, MPFR_RNDN);
        mpfr_set_flt(r74080, c, MPFR_RNDN);
        mpfr_mul(r74081, r74079, r74080, MPFR_RNDN);
        mpfr_mul(r74082, r74078, r74081, MPFR_RNDN);
        mpfr_sub(r74083, r74077, r74082, MPFR_RNDN);
        mpfr_sqrt(r74084, r74083, MPFR_RNDN);
        mpfr_add(r74085, r74076, r74084, MPFR_RNDN);
        mpfr_init_set_str(r74086, "2", 10, MPFR_RNDN);
        mpfr_mul(r74087, r74086, r74079, MPFR_RNDN);
        mpfr_div(r74088, r74085, r74087, MPFR_RNDN);
        return mpfr_get_d(r74088, MPFR_RNDN);
}

