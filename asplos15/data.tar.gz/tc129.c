#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* powComplex, imaginary part */

double f_if(float x_re, float x_im, float y_re, float y_im) {
        float r86494 = x_re;
        float r86495 = r86494 * r86494;
        float r86496 = x_im;
        float r86497 = r86496 * r86496;
        float r86498 = r86495 + r86497;
        float r86499 = sqrt(r86498);
        float r86500 = log(r86499);
        float r86501 = y_re;
        float r86502 = r86500 * r86501;
        float r86503 = atan2(r86496, r86494);
        float r86504 = y_im;
        float r86505 = r86503 * r86504;
        float r86506 = r86502 - r86505;
        float r86507 = exp(r86506);
        float r86508 = r86500 * r86504;
        float r86509 = r86503 * r86501;
        float r86510 = r86508 + r86509;
        float r86511 = sin(r86510);
        float r86512 = r86507 * r86511;
        return r86512;
}

double f_id(float x_re, float x_im, float y_re, float y_im) {
        double r86513 = x_re;
        double r86514 = r86513 * r86513;
        double r86515 = x_im;
        double r86516 = r86515 * r86515;
        double r86517 = r86514 + r86516;
        double r86518 = sqrt(r86517);
        double r86519 = log(r86518);
        double r86520 = y_re;
        double r86521 = r86519 * r86520;
        double r86522 = atan2(r86515, r86513);
        double r86523 = y_im;
        double r86524 = r86522 * r86523;
        double r86525 = r86521 - r86524;
        double r86526 = exp(r86525);
        double r86527 = r86519 * r86523;
        double r86528 = r86522 * r86520;
        double r86529 = r86527 + r86528;
        double r86530 = sin(r86529);
        double r86531 = r86526 * r86530;
        return r86531;
}

double f_il(float x_re, float x_im, float y_re, float y_im) {
        long double r86532 = x_re;
        long double r86533 = r86532 * r86532;
        long double r86534 = x_im;
        long double r86535 = r86534 * r86534;
        long double r86536 = r86533 + r86535;
        long double r86537 = sqrt(r86536);
        long double r86538 = log(r86537);
        long double r86539 = y_re;
        long double r86540 = r86538 * r86539;
        long double r86541 = atan2(r86534, r86532);
        long double r86542 = y_im;
        long double r86543 = r86541 * r86542;
        long double r86544 = r86540 - r86543;
        long double r86545 = exp(r86544);
        long double r86546 = r86538 * r86542;
        long double r86547 = r86541 * r86539;
        long double r86548 = r86546 + r86547;
        long double r86549 = sin(r86548);
        long double r86550 = r86545 * r86549;
        return r86550;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x_re, float x_im, float y_re, float y_im) {
        float r86551 = x_re;
        float r86552 = r86551 * r86551;
        float r86553 = x_im;
        float r86554 = r86553 * r86553;
        float r86555 = r86552 + r86554;
        float r86556 = sqrt(r86555);
        float r86557 = log(r86556);
        float r86558 = y_re;
        float r86559 = r86557 * r86558;
        float r86560 = y_im;
        float r86561 = atan2(r86553, r86551);
        float r86562 = exp(r86561);
        float r86563 = log(r86562);
        float r86564 = r86560 * r86563;
        float r86565 = r86559 - r86564;
        float r86566 = exp(r86565);
        float r86567 = r86557 * r86560;
        float r86568 = r86561 * r86558;
        float r86569 = r86567 + r86568;
        float r86570 = sin(r86569);
        float r86571 = r86566 * r86570;
        return r86571;
}

double f_od(float x_re, float x_im, float y_re, float y_im) {
        double r86572 = x_re;
        double r86573 = r86572 * r86572;
        double r86574 = x_im;
        double r86575 = r86574 * r86574;
        double r86576 = r86573 + r86575;
        double r86577 = sqrt(r86576);
        double r86578 = log(r86577);
        double r86579 = y_re;
        double r86580 = r86578 * r86579;
        double r86581 = y_im;
        double r86582 = atan2(r86574, r86572);
        double r86583 = exp(r86582);
        double r86584 = log(r86583);
        double r86585 = r86581 * r86584;
        double r86586 = r86580 - r86585;
        double r86587 = exp(r86586);
        double r86588 = r86578 * r86581;
        double r86589 = r86582 * r86579;
        double r86590 = r86588 + r86589;
        double r86591 = sin(r86590);
        double r86592 = r86587 * r86591;
        return r86592;
}

double f_ol(float x_re, float x_im, float y_re, float y_im) {
        long double r86593 = x_re;
        long double r86594 = r86593 * r86593;
        long double r86595 = x_im;
        long double r86596 = r86595 * r86595;
        long double r86597 = r86594 + r86596;
        long double r86598 = sqrt(r86597);
        long double r86599 = log(r86598);
        long double r86600 = y_re;
        long double r86601 = r86599 * r86600;
        long double r86602 = y_im;
        long double r86603 = atan2(r86595, r86593);
        long double r86604 = exp(r86603);
        long double r86605 = log(r86604);
        long double r86606 = r86602 * r86605;
        long double r86607 = r86601 - r86606;
        long double r86608 = exp(r86607);
        long double r86609 = r86599 * r86602;
        long double r86610 = r86603 * r86600;
        long double r86611 = r86609 + r86610;
        long double r86612 = sin(r86611);
        long double r86613 = r86608 * r86612;
        return r86613;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r86614, r86615, r86616, r86617, r86618, r86619, r86620, r86621, r86622, r86623, r86624, r86625, r86626, r86627, r86628, r86629, r86630, r86631, r86632;

void setup_mpfr() {
        mpfr_set_default_prec(232);
        mpfr_init(r86614);
        mpfr_init(r86615);
        mpfr_init(r86616);
        mpfr_init(r86617);
        mpfr_init(r86618);
        mpfr_init(r86619);
        mpfr_init(r86620);
        mpfr_init(r86621);
        mpfr_init(r86622);
        mpfr_init(r86623);
        mpfr_init(r86624);
        mpfr_init(r86625);
        mpfr_init(r86626);
        mpfr_init(r86627);
        mpfr_init(r86628);
        mpfr_init(r86629);
        mpfr_init(r86630);
        mpfr_init(r86631);
        mpfr_init(r86632);
}

double f_im(float x_re, float x_im, float y_re, float y_im) {
        mpfr_set_flt(r86614, x_re, MPFR_RNDN);
        mpfr_mul(r86615, r86614, r86614, MPFR_RNDN);
        mpfr_set_flt(r86616, x_im, MPFR_RNDN);
        mpfr_mul(r86617, r86616, r86616, MPFR_RNDN);
        mpfr_add(r86618, r86615, r86617, MPFR_RNDN);
        mpfr_sqrt(r86619, r86618, MPFR_RNDN);
        mpfr_log(r86620, r86619, MPFR_RNDN);
        mpfr_set_flt(r86621, y_re, MPFR_RNDN);
        mpfr_mul(r86622, r86620, r86621, MPFR_RNDN);
        mpfr_atan2(r86623, r86616, r86614, MPFR_RNDN);
        mpfr_set_flt(r86624, y_im, MPFR_RNDN);
        mpfr_mul(r86625, r86623, r86624, MPFR_RNDN);
        mpfr_sub(r86626, r86622, r86625, MPFR_RNDN);
        mpfr_exp(r86627, r86626, MPFR_RNDN);
        mpfr_mul(r86628, r86620, r86624, MPFR_RNDN);
        mpfr_mul(r86629, r86623, r86621, MPFR_RNDN);
        mpfr_add(r86630, r86628, r86629, MPFR_RNDN);
        mpfr_sin(r86631, r86630, MPFR_RNDN);
        mpfr_mul(r86632, r86627, r86631, MPFR_RNDN);
        return mpfr_get_d(r86632, MPFR_RNDN);
}

