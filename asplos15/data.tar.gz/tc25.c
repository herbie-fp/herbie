#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE example 3.6 */

double f_if(float x) {
        float r73759 = 1.0;
        float r73760 = x;
        float r73761 = r73760 + r73759;
        float r73762 = sqrt(r73761);
        float r73763 = r73759 / r73762;
        float r73764 = sqrt(r73760);
        float r73765 = r73759 / r73764;
        float r73766 = r73763 - r73765;
        return r73766;
}

double f_id(float x) {
        double r73767 = 1.0;
        double r73768 = x;
        double r73769 = r73768 + r73767;
        double r73770 = sqrt(r73769);
        double r73771 = r73767 / r73770;
        double r73772 = sqrt(r73768);
        double r73773 = r73767 / r73772;
        double r73774 = r73771 - r73773;
        return r73774;
}

double f_il(float x) {
        long double r73775 = 1.0;
        long double r73776 = x;
        long double r73777 = r73776 + r73775;
        long double r73778 = sqrt(r73777);
        long double r73779 = r73775 / r73778;
        long double r73780 = sqrt(r73776);
        long double r73781 = r73775 / r73780;
        long double r73782 = r73779 - r73781;
        return r73782;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r73783 = 1.0;
        float r73784 = x;
        float r73785 = sqrt(r73784);
        float r73786 = r73784 + r73783;
        float r73787 = sqrt(r73786);
        float r73788 = r73785 + r73787;
        float r73789 = r73783 / r73788;
        float r73790 = -r73789;
        float r73791 = r73783 * r73790;
        float r73792 = r73786 * r73784;
        float r73793 = 0.5;
        float r73794 = pow(r73792, r73793);
        float r73795 = r73791 / r73794;
        return r73795;
}

double f_od(float x) {
        double r73796 = 1.0;
        double r73797 = x;
        double r73798 = sqrt(r73797);
        double r73799 = r73797 + r73796;
        double r73800 = sqrt(r73799);
        double r73801 = r73798 + r73800;
        double r73802 = r73796 / r73801;
        double r73803 = -r73802;
        double r73804 = r73796 * r73803;
        double r73805 = r73799 * r73797;
        double r73806 = 0.5;
        double r73807 = pow(r73805, r73806);
        double r73808 = r73804 / r73807;
        return r73808;
}

double f_ol(float x) {
        long double r73809 = 1.0;
        long double r73810 = x;
        long double r73811 = sqrt(r73810);
        long double r73812 = r73810 + r73809;
        long double r73813 = sqrt(r73812);
        long double r73814 = r73811 + r73813;
        long double r73815 = r73809 / r73814;
        long double r73816 = -r73815;
        long double r73817 = r73809 * r73816;
        long double r73818 = r73812 * r73810;
        long double r73819 = 0.5;
        long double r73820 = pow(r73818, r73819);
        long double r73821 = r73817 / r73820;
        return r73821;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r73822, r73823, r73824, r73825, r73826, r73827, r73828, r73829;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r73822);
        mpfr_init(r73823);
        mpfr_init(r73824);
        mpfr_init(r73825);
        mpfr_init(r73826);
        mpfr_init(r73827);
        mpfr_init(r73828);
        mpfr_init(r73829);
}

double f_im(float x) {
        mpfr_init_set_str(r73822, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r73823, x, MPFR_RNDN);
        mpfr_add(r73824, r73823, r73822, MPFR_RNDN);
        mpfr_sqrt(r73825, r73824, MPFR_RNDN);
        mpfr_div(r73826, r73822, r73825, MPFR_RNDN);
        mpfr_sqrt(r73827, r73823, MPFR_RNDN);
        mpfr_div(r73828, r73822, r73827, MPFR_RNDN);
        mpfr_sub(r73829, r73826, r73828, MPFR_RNDN);
        return mpfr_get_d(r73829, MPFR_RNDN);
}

