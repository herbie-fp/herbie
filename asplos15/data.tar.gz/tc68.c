#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Jmat.Real.lambertw, estimator */

double f_if(float x) {
        float r79424 = x;
        float r79425 = log(r79424);
        float r79426 = log(r79425);
        float r79427 = r79425 - r79426;
        return r79427;
}

double f_id(float x) {
        double r79428 = x;
        double r79429 = log(r79428);
        double r79430 = log(r79429);
        double r79431 = r79429 - r79430;
        return r79431;
}

double f_il(float x) {
        long double r79432 = x;
        long double r79433 = log(r79432);
        long double r79434 = log(r79433);
        long double r79435 = r79433 - r79434;
        return r79435;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r79436 = x;
        float r79437 = log(r79436);
        float r79438 = r79436 / r79437;
        float r79439 = log(r79438);
        return r79439;
}

double f_od(float x) {
        double r79440 = x;
        double r79441 = log(r79440);
        double r79442 = r79440 / r79441;
        double r79443 = log(r79442);
        return r79443;
}

double f_ol(float x) {
        long double r79444 = x;
        long double r79445 = log(r79444);
        long double r79446 = r79444 / r79445;
        long double r79447 = log(r79446);
        return r79447;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r79448, r79449, r79450, r79451;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r79448);
        mpfr_init(r79449);
        mpfr_init(r79450);
        mpfr_init(r79451);
}

double f_im(float x) {
        mpfr_set_flt(r79448, x, MPFR_RNDN);
        mpfr_log(r79449, r79448, MPFR_RNDN);
        mpfr_log(r79450, r79449, MPFR_RNDN);
        mpfr_sub(r79451, r79449, r79450, MPFR_RNDN);
        return mpfr_get_d(r79451, MPFR_RNDN);
}

