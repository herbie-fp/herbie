#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Toniolo and Linder, Equation (3b), real */

double f_if(float kx, float ky, float th) {
        float r83628 = ky;
        float r83629 = sin(r83628);
        float r83630 = kx;
        float r83631 = sin(r83630);
        float r83632 = r83631 * r83631;
        float r83633 = r83629 * r83629;
        float r83634 = r83632 + r83633;
        float r83635 = sqrt(r83634);
        float r83636 = r83629 / r83635;
        float r83637 = th;
        float r83638 = sin(r83637);
        float r83639 = r83636 * r83638;
        return r83639;
}

double f_id(float kx, float ky, float th) {
        double r83640 = ky;
        double r83641 = sin(r83640);
        double r83642 = kx;
        double r83643 = sin(r83642);
        double r83644 = r83643 * r83643;
        double r83645 = r83641 * r83641;
        double r83646 = r83644 + r83645;
        double r83647 = sqrt(r83646);
        double r83648 = r83641 / r83647;
        double r83649 = th;
        double r83650 = sin(r83649);
        double r83651 = r83648 * r83650;
        return r83651;
}

double f_il(float kx, float ky, float th) {
        long double r83652 = ky;
        long double r83653 = sin(r83652);
        long double r83654 = kx;
        long double r83655 = sin(r83654);
        long double r83656 = r83655 * r83655;
        long double r83657 = r83653 * r83653;
        long double r83658 = r83656 + r83657;
        long double r83659 = sqrt(r83658);
        long double r83660 = r83653 / r83659;
        long double r83661 = th;
        long double r83662 = sin(r83661);
        long double r83663 = r83660 * r83662;
        return r83663;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float kx, float ky, float th) {
        float r83664 = ky;
        float r83665 = 2.0;
        float r83666 = 3.141592653589793;
        float r83667 = r83665 * r83666;
        float r83668 = fmod2(r83664, r83667);
        float r83669 = 0.5855520227754234;
        bool r83670 = r83668 < r83669;
        float r83671 = 1.0;
        float r83672 = sin(r83664);
        float r83673 = kx;
        float r83674 = sin(r83673);
        float r83675 = r83674 * r83674;
        float r83676 = r83672 * r83672;
        float r83677 = r83675 + r83676;
        float r83678 = sqrt(r83677);
        float r83679 = r83672 / r83678;
        float r83680 = th;
        float r83681 = sin(r83680);
        float r83682 = r83679 * r83681;
        float r83683 = r83671 * r83682;
        float r83684 = r83670 ? r83683 : r83682;
        return r83684;
}

double f_od(float kx, float ky, float th) {
        double r83685 = ky;
        double r83686 = 2.0;
        double r83687 = 3.141592653589793;
        double r83688 = r83686 * r83687;
        double r83689 = fmod2(r83685, r83688);
        double r83690 = 0.5855520227754234;
        bool r83691 = r83689 < r83690;
        double r83692 = 1.0;
        double r83693 = sin(r83685);
        double r83694 = kx;
        double r83695 = sin(r83694);
        double r83696 = r83695 * r83695;
        double r83697 = r83693 * r83693;
        double r83698 = r83696 + r83697;
        double r83699 = sqrt(r83698);
        double r83700 = r83693 / r83699;
        double r83701 = th;
        double r83702 = sin(r83701);
        double r83703 = r83700 * r83702;
        double r83704 = r83692 * r83703;
        double r83705 = r83691 ? r83704 : r83703;
        return r83705;
}

double f_ol(float kx, float ky, float th) {
        long double r83706 = ky;
        long double r83707 = 2.0;
        long double r83708 = 3.141592653589793;
        long double r83709 = r83707 * r83708;
        long double r83710 = fmod2(r83706, r83709);
        long double r83711 = 0.5855520227754234;
        bool r83712 = r83710 < r83711;
        long double r83713 = 1.0;
        long double r83714 = sin(r83706);
        long double r83715 = kx;
        long double r83716 = sin(r83715);
        long double r83717 = r83716 * r83716;
        long double r83718 = r83714 * r83714;
        long double r83719 = r83717 + r83718;
        long double r83720 = sqrt(r83719);
        long double r83721 = r83714 / r83720;
        long double r83722 = th;
        long double r83723 = sin(r83722);
        long double r83724 = r83721 * r83723;
        long double r83725 = r83713 * r83724;
        long double r83726 = r83712 ? r83725 : r83724;
        return r83726;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r83727, r83728, r83729, r83730, r83731, r83732, r83733, r83734, r83735, r83736, r83737, r83738;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r83727);
        mpfr_init(r83728);
        mpfr_init(r83729);
        mpfr_init(r83730);
        mpfr_init(r83731);
        mpfr_init(r83732);
        mpfr_init(r83733);
        mpfr_init(r83734);
        mpfr_init(r83735);
        mpfr_init(r83736);
        mpfr_init(r83737);
        mpfr_init(r83738);
}

double f_im(float kx, float ky, float th) {
        mpfr_set_flt(r83727, ky, MPFR_RNDN);
        mpfr_sin(r83728, r83727, MPFR_RNDN);
        mpfr_set_flt(r83729, kx, MPFR_RNDN);
        mpfr_sin(r83730, r83729, MPFR_RNDN);
        mpfr_mul(r83731, r83730, r83730, MPFR_RNDN);
        mpfr_mul(r83732, r83728, r83728, MPFR_RNDN);
        mpfr_add(r83733, r83731, r83732, MPFR_RNDN);
        mpfr_sqrt(r83734, r83733, MPFR_RNDN);
        mpfr_div(r83735, r83728, r83734, MPFR_RNDN);
        mpfr_set_flt(r83736, th, MPFR_RNDN);
        mpfr_sin(r83737, r83736, MPFR_RNDN);
        mpfr_mul(r83738, r83735, r83737, MPFR_RNDN);
        return mpfr_get_d(r83738, MPFR_RNDN);
}

