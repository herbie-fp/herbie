#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Maksimov and Kolovsky, Equation (32) */

double f_if(float K, float m, float n, float M, float l) {
        float r79574 = K;
        float r79575 = m;
        float r79576 = n;
        float r79577 = r79575 + r79576;
        float r79578 = r79574 * r79577;
        float r79579 = 2.0;
        float r79580 = r79578 / r79579;
        float r79581 = M;
        float r79582 = r79580 - r79581;
        float r79583 = cos(r79582);
        float r79584 = r79577 / r79579;
        float r79585 = r79584 - r79581;
        float r79586 = r79585 * r79585;
        float r79587 = -r79586;
        float r79588 = l;
        float r79589 = r79575 - r79576;
        float r79590 = fabs(r79589);
        float r79591 = r79588 - r79590;
        float r79592 = r79587 - r79591;
        float r79593 = exp(r79592);
        float r79594 = r79583 * r79593;
        return r79594;
}

double f_id(float K, float m, float n, float M, float l) {
        double r79595 = K;
        double r79596 = m;
        double r79597 = n;
        double r79598 = r79596 + r79597;
        double r79599 = r79595 * r79598;
        double r79600 = 2.0;
        double r79601 = r79599 / r79600;
        double r79602 = M;
        double r79603 = r79601 - r79602;
        double r79604 = cos(r79603);
        double r79605 = r79598 / r79600;
        double r79606 = r79605 - r79602;
        double r79607 = r79606 * r79606;
        double r79608 = -r79607;
        double r79609 = l;
        double r79610 = r79596 - r79597;
        double r79611 = fabs(r79610);
        double r79612 = r79609 - r79611;
        double r79613 = r79608 - r79612;
        double r79614 = exp(r79613);
        double r79615 = r79604 * r79614;
        return r79615;
}

double f_il(float K, float m, float n, float M, float l) {
        long double r79616 = K;
        long double r79617 = m;
        long double r79618 = n;
        long double r79619 = r79617 + r79618;
        long double r79620 = r79616 * r79619;
        long double r79621 = 2.0;
        long double r79622 = r79620 / r79621;
        long double r79623 = M;
        long double r79624 = r79622 - r79623;
        long double r79625 = cos(r79624);
        long double r79626 = r79619 / r79621;
        long double r79627 = r79626 - r79623;
        long double r79628 = r79627 * r79627;
        long double r79629 = -r79628;
        long double r79630 = l;
        long double r79631 = r79617 - r79618;
        long double r79632 = fabs(r79631);
        long double r79633 = r79630 - r79632;
        long double r79634 = r79629 - r79633;
        long double r79635 = exp(r79634);
        long double r79636 = r79625 * r79635;
        return r79636;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float K, float m, float n, float M, float l) {
        float r79637 = K;
        float r79638 = m;
        float r79639 = n;
        float r79640 = r79638 + r79639;
        float r79641 = r79637 * r79640;
        float r79642 = 2.0;
        float r79643 = r79641 / r79642;
        float r79644 = cos(r79643);
        float r79645 = M;
        float r79646 = cos(r79645);
        float r79647 = r79644 * r79646;
        float r79648 = sin(r79643);
        float r79649 = sin(r79645);
        float r79650 = r79648 * r79649;
        float r79651 = r79647 + r79650;
        float r79652 = r79640 / r79642;
        float r79653 = r79652 - r79645;
        float r79654 = r79653 * r79653;
        float r79655 = -r79654;
        float r79656 = l;
        float r79657 = r79638 - r79639;
        float r79658 = fabs(r79657);
        float r79659 = r79656 - r79658;
        float r79660 = r79655 - r79659;
        float r79661 = exp(r79660);
        float r79662 = r79651 * r79661;
        return r79662;
}

double f_od(float K, float m, float n, float M, float l) {
        double r79663 = K;
        double r79664 = m;
        double r79665 = n;
        double r79666 = r79664 + r79665;
        double r79667 = r79663 * r79666;
        double r79668 = 2.0;
        double r79669 = r79667 / r79668;
        double r79670 = cos(r79669);
        double r79671 = M;
        double r79672 = cos(r79671);
        double r79673 = r79670 * r79672;
        double r79674 = sin(r79669);
        double r79675 = sin(r79671);
        double r79676 = r79674 * r79675;
        double r79677 = r79673 + r79676;
        double r79678 = r79666 / r79668;
        double r79679 = r79678 - r79671;
        double r79680 = r79679 * r79679;
        double r79681 = -r79680;
        double r79682 = l;
        double r79683 = r79664 - r79665;
        double r79684 = fabs(r79683);
        double r79685 = r79682 - r79684;
        double r79686 = r79681 - r79685;
        double r79687 = exp(r79686);
        double r79688 = r79677 * r79687;
        return r79688;
}

double f_ol(float K, float m, float n, float M, float l) {
        long double r79689 = K;
        long double r79690 = m;
        long double r79691 = n;
        long double r79692 = r79690 + r79691;
        long double r79693 = r79689 * r79692;
        long double r79694 = 2.0;
        long double r79695 = r79693 / r79694;
        long double r79696 = cos(r79695);
        long double r79697 = M;
        long double r79698 = cos(r79697);
        long double r79699 = r79696 * r79698;
        long double r79700 = sin(r79695);
        long double r79701 = sin(r79697);
        long double r79702 = r79700 * r79701;
        long double r79703 = r79699 + r79702;
        long double r79704 = r79692 / r79694;
        long double r79705 = r79704 - r79697;
        long double r79706 = r79705 * r79705;
        long double r79707 = -r79706;
        long double r79708 = l;
        long double r79709 = r79690 - r79691;
        long double r79710 = fabs(r79709);
        long double r79711 = r79708 - r79710;
        long double r79712 = r79707 - r79711;
        long double r79713 = exp(r79712);
        long double r79714 = r79703 * r79713;
        return r79714;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r79715, r79716, r79717, r79718, r79719, r79720, r79721, r79722, r79723, r79724, r79725, r79726, r79727, r79728, r79729, r79730, r79731, r79732, r79733, r79734, r79735;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r79715);
        mpfr_init(r79716);
        mpfr_init(r79717);
        mpfr_init(r79718);
        mpfr_init(r79719);
        mpfr_init(r79720);
        mpfr_init(r79721);
        mpfr_init(r79722);
        mpfr_init(r79723);
        mpfr_init(r79724);
        mpfr_init(r79725);
        mpfr_init(r79726);
        mpfr_init(r79727);
        mpfr_init(r79728);
        mpfr_init(r79729);
        mpfr_init(r79730);
        mpfr_init(r79731);
        mpfr_init(r79732);
        mpfr_init(r79733);
        mpfr_init(r79734);
        mpfr_init(r79735);
}

double f_im(float K, float m, float n, float M, float l) {
        mpfr_set_flt(r79715, K, MPFR_RNDN);
        mpfr_set_flt(r79716, m, MPFR_RNDN);
        mpfr_set_flt(r79717, n, MPFR_RNDN);
        mpfr_add(r79718, r79716, r79717, MPFR_RNDN);
        mpfr_mul(r79719, r79715, r79718, MPFR_RNDN);
        mpfr_init_set_str(r79720, "2", 10, MPFR_RNDN);
        mpfr_div(r79721, r79719, r79720, MPFR_RNDN);
        mpfr_set_flt(r79722, M, MPFR_RNDN);
        mpfr_sub(r79723, r79721, r79722, MPFR_RNDN);
        mpfr_cos(r79724, r79723, MPFR_RNDN);
        mpfr_div(r79725, r79718, r79720, MPFR_RNDN);
        mpfr_sub(r79726, r79725, r79722, MPFR_RNDN);
        mpfr_mul(r79727, r79726, r79726, MPFR_RNDN);
        mpfr_neg(r79728, r79727, MPFR_RNDN);
        mpfr_set_flt(r79729, l, MPFR_RNDN);
        mpfr_sub(r79730, r79716, r79717, MPFR_RNDN);
        mpfr_abs(r79731, r79730, MPFR_RNDN);
        mpfr_sub(r79732, r79729, r79731, MPFR_RNDN);
        mpfr_sub(r79733, r79728, r79732, MPFR_RNDN);
        mpfr_exp(r79734, r79733, MPFR_RNDN);
        mpfr_mul(r79735, r79724, r79734, MPFR_RNDN);
        return mpfr_get_d(r79735, MPFR_RNDN);
}

