#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.exp on complex, real part */

double f_if(float re, float im) {
        float r85245 = re;
        float r85246 = exp(r85245);
        float r85247 = im;
        float r85248 = cos(r85247);
        float r85249 = r85246 * r85248;
        return r85249;
}

double f_id(float re, float im) {
        double r85250 = re;
        double r85251 = exp(r85250);
        double r85252 = im;
        double r85253 = cos(r85252);
        double r85254 = r85251 * r85253;
        return r85254;
}

double f_il(float re, float im) {
        long double r85255 = re;
        long double r85256 = exp(r85255);
        long double r85257 = im;
        long double r85258 = cos(r85257);
        long double r85259 = r85256 * r85258;
        return r85259;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r85260 = re;
        float r85261 = exp(r85260);
        float r85262 = im;
        float r85263 = cos(r85262);
        float r85264 = r85261 * r85263;
        return r85264;
}

double f_od(float re, float im) {
        double r85265 = re;
        double r85266 = exp(r85265);
        double r85267 = im;
        double r85268 = cos(r85267);
        double r85269 = r85266 * r85268;
        return r85269;
}

double f_ol(float re, float im) {
        long double r85270 = re;
        long double r85271 = exp(r85270);
        long double r85272 = im;
        long double r85273 = cos(r85272);
        long double r85274 = r85271 * r85273;
        return r85274;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r85275, r85276, r85277, r85278, r85279;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r85275);
        mpfr_init(r85276);
        mpfr_init(r85277);
        mpfr_init(r85278);
        mpfr_init(r85279);
}

double f_im(float re, float im) {
        mpfr_set_flt(r85275, re, MPFR_RNDN);
        mpfr_exp(r85276, r85275, MPFR_RNDN);
        mpfr_set_flt(r85277, im, MPFR_RNDN);
        mpfr_cos(r85278, r85277, MPFR_RNDN);
        mpfr_mul(r85279, r85276, r85278, MPFR_RNDN);
        return mpfr_get_d(r85279, MPFR_RNDN);
}

