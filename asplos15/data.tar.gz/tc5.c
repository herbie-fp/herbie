#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Exp of sum of logs */

double f_if(float a, float b) {
        float r72490 = a;
        float r72491 = log(r72490);
        float r72492 = b;
        float r72493 = log(r72492);
        float r72494 = r72491 + r72493;
        float r72495 = exp(r72494);
        return r72495;
}

double f_id(float a, float b) {
        double r72496 = a;
        double r72497 = log(r72496);
        double r72498 = b;
        double r72499 = log(r72498);
        double r72500 = r72497 + r72499;
        double r72501 = exp(r72500);
        return r72501;
}

double f_il(float a, float b) {
        long double r72502 = a;
        long double r72503 = log(r72502);
        long double r72504 = b;
        long double r72505 = log(r72504);
        long double r72506 = r72503 + r72505;
        long double r72507 = exp(r72506);
        return r72507;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a, float b) {
        float r72508 = a;
        float r72509 = b;
        float r72510 = r72508 * r72509;
        return r72510;
}

double f_od(float a, float b) {
        double r72511 = a;
        double r72512 = b;
        double r72513 = r72511 * r72512;
        return r72513;
}

double f_ol(float a, float b) {
        long double r72514 = a;
        long double r72515 = b;
        long double r72516 = r72514 * r72515;
        return r72516;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r72517, r72518, r72519, r72520, r72521, r72522;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r72517);
        mpfr_init(r72518);
        mpfr_init(r72519);
        mpfr_init(r72520);
        mpfr_init(r72521);
        mpfr_init(r72522);
}

double f_im(float a, float b) {
        mpfr_set_flt(r72517, a, MPFR_RNDN);
        mpfr_log(r72518, r72517, MPFR_RNDN);
        mpfr_set_flt(r72519, b, MPFR_RNDN);
        mpfr_log(r72520, r72519, MPFR_RNDN);
        mpfr_add(r72521, r72518, r72520, MPFR_RNDN);
        mpfr_exp(r72522, r72521, MPFR_RNDN);
        return mpfr_get_d(r72522, MPFR_RNDN);
}

