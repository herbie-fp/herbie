#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Rosa's DopplerBench */

double f_if(float u, float v, float t1) {
        float r81915 = t1;
        float r81916 = -r81915;
        float r81917 = v;
        float r81918 = r81916 * r81917;
        float r81919 = u;
        float r81920 = r81915 + r81919;
        float r81921 = r81920 * r81920;
        float r81922 = r81918 / r81921;
        return r81922;
}

double f_id(float u, float v, float t1) {
        double r81923 = t1;
        double r81924 = -r81923;
        double r81925 = v;
        double r81926 = r81924 * r81925;
        double r81927 = u;
        double r81928 = r81923 + r81927;
        double r81929 = r81928 * r81928;
        double r81930 = r81926 / r81929;
        return r81930;
}

double f_il(float u, float v, float t1) {
        long double r81931 = t1;
        long double r81932 = -r81931;
        long double r81933 = v;
        long double r81934 = r81932 * r81933;
        long double r81935 = u;
        long double r81936 = r81931 + r81935;
        long double r81937 = r81936 * r81936;
        long double r81938 = r81934 / r81937;
        return r81938;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float u, float v, float t1) {
        float r81939 = u;
        float r81940 = -6.968214905354539e+21;
        bool r81941 = r81939 < r81940;
        float r81942 = t1;
        float r81943 = r81942 + r81939;
        float r81944 = r81942 / r81943;
        float r81945 = -r81944;
        float r81946 = v;
        float r81947 = r81946 / r81943;
        float r81948 = r81945 * r81947;
        float r81949 = -6.141236723096619e-32;
        bool r81950 = r81939 < r81949;
        float r81951 = r81945 * r81946;
        float r81952 = r81951 / r81943;
        float r81953 = 25609692477.616104;
        bool r81954 = r81939 < r81953;
        float r81955 = -r81942;
        float r81956 = r81943 * r81943;
        float r81957 = r81946 / r81956;
        float r81958 = r81955 * r81957;
        float r81959 = r81954 ? r81948 : r81958;
        float r81960 = r81950 ? r81952 : r81959;
        float r81961 = r81941 ? r81948 : r81960;
        return r81961;
}

double f_od(float u, float v, float t1) {
        double r81962 = u;
        double r81963 = -6.968214905354539e+21;
        bool r81964 = r81962 < r81963;
        double r81965 = t1;
        double r81966 = r81965 + r81962;
        double r81967 = r81965 / r81966;
        double r81968 = -r81967;
        double r81969 = v;
        double r81970 = r81969 / r81966;
        double r81971 = r81968 * r81970;
        double r81972 = -6.141236723096619e-32;
        bool r81973 = r81962 < r81972;
        double r81974 = r81968 * r81969;
        double r81975 = r81974 / r81966;
        double r81976 = 25609692477.616104;
        bool r81977 = r81962 < r81976;
        double r81978 = -r81965;
        double r81979 = r81966 * r81966;
        double r81980 = r81969 / r81979;
        double r81981 = r81978 * r81980;
        double r81982 = r81977 ? r81971 : r81981;
        double r81983 = r81973 ? r81975 : r81982;
        double r81984 = r81964 ? r81971 : r81983;
        return r81984;
}

double f_ol(float u, float v, float t1) {
        long double r81985 = u;
        long double r81986 = -6.968214905354539e+21;
        bool r81987 = r81985 < r81986;
        long double r81988 = t1;
        long double r81989 = r81988 + r81985;
        long double r81990 = r81988 / r81989;
        long double r81991 = -r81990;
        long double r81992 = v;
        long double r81993 = r81992 / r81989;
        long double r81994 = r81991 * r81993;
        long double r81995 = -6.141236723096619e-32;
        bool r81996 = r81985 < r81995;
        long double r81997 = r81991 * r81992;
        long double r81998 = r81997 / r81989;
        long double r81999 = 25609692477.616104;
        bool r82000 = r81985 < r81999;
        long double r82001 = -r81988;
        long double r82002 = r81989 * r81989;
        long double r82003 = r81992 / r82002;
        long double r82004 = r82001 * r82003;
        long double r82005 = r82000 ? r81994 : r82004;
        long double r82006 = r81996 ? r81998 : r82005;
        long double r82007 = r81987 ? r81994 : r82006;
        return r82007;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r82008, r82009, r82010, r82011, r82012, r82013, r82014, r82015;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r82008);
        mpfr_init(r82009);
        mpfr_init(r82010);
        mpfr_init(r82011);
        mpfr_init(r82012);
        mpfr_init(r82013);
        mpfr_init(r82014);
        mpfr_init(r82015);
}

double f_im(float u, float v, float t1) {
        mpfr_set_flt(r82008, t1, MPFR_RNDN);
        mpfr_neg(r82009, r82008, MPFR_RNDN);
        mpfr_set_flt(r82010, v, MPFR_RNDN);
        mpfr_mul(r82011, r82009, r82010, MPFR_RNDN);
        mpfr_set_flt(r82012, u, MPFR_RNDN);
        mpfr_add(r82013, r82008, r82012, MPFR_RNDN);
        mpfr_mul(r82014, r82013, r82013, MPFR_RNDN);
        mpfr_div(r82015, r82011, r82014, MPFR_RNDN);
        return mpfr_get_d(r82015, MPFR_RNDN);
}

