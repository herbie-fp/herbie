#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE example 3.7 */

double f_if(float x) {
        float r80157 = x;
        float r80158 = exp(r80157);
        float r80159 = r80158 - r80157;
        return r80159;
}

double f_id(float x) {
        double r80160 = x;
        double r80161 = exp(r80160);
        double r80162 = r80161 - r80160;
        return r80162;
}

double f_il(float x) {
        long double r80163 = x;
        long double r80164 = exp(r80163);
        long double r80165 = r80164 - r80163;
        return r80165;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r80166 = x;
        float r80167 = exp(r80166);
        float r80168 = r80167 - r80166;
        return r80168;
}

double f_od(float x) {
        double r80169 = x;
        double r80170 = exp(r80169);
        double r80171 = r80170 - r80169;
        return r80171;
}

double f_ol(float x) {
        long double r80172 = x;
        long double r80173 = exp(r80172);
        long double r80174 = r80173 - r80172;
        return r80174;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r80175, r80176, r80177;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r80175);
        mpfr_init(r80176);
        mpfr_init(r80177);
}

double f_im(float x) {
        mpfr_set_flt(r80175, x, MPFR_RNDN);
        mpfr_exp(r80176, r80175, MPFR_RNDN);
        mpfr_sub(r80177, r80176, r80175, MPFR_RNDN);
        return mpfr_get_d(r80177, MPFR_RNDN);
}

