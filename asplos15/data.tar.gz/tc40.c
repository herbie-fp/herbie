#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.cube on real */

double f_if(float x) {
        float r74917 = x;
        float r74918 = r74917 * r74917;
        float r74919 = r74918 * r74917;
        return r74919;
}

double f_id(float x) {
        double r74920 = x;
        double r74921 = r74920 * r74920;
        double r74922 = r74921 * r74920;
        return r74922;
}

double f_il(float x) {
        long double r74923 = x;
        long double r74924 = r74923 * r74923;
        long double r74925 = r74924 * r74923;
        return r74925;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r74926 = x;
        float r74927 = 2.0;
        float r74928 = 1.0;
        float r74929 = r74927 + r74928;
        float r74930 = pow(r74926, r74929);
        return r74930;
}

double f_od(float x) {
        double r74931 = x;
        double r74932 = 2.0;
        double r74933 = 1.0;
        double r74934 = r74932 + r74933;
        double r74935 = pow(r74931, r74934);
        return r74935;
}

double f_ol(float x) {
        long double r74936 = x;
        long double r74937 = 2.0;
        long double r74938 = 1.0;
        long double r74939 = r74937 + r74938;
        long double r74940 = pow(r74936, r74939);
        return r74940;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r74941, r74942, r74943;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r74941);
        mpfr_init(r74942);
        mpfr_init(r74943);
}

double f_im(float x) {
        mpfr_set_flt(r74941, x, MPFR_RNDN);
        mpfr_mul(r74942, r74941, r74941, MPFR_RNDN);
        mpfr_mul(r74943, r74942, r74941, MPFR_RNDN);
        return mpfr_get_d(r74943, MPFR_RNDN);
}

