#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* FastMath dist */

double f_if(float d1, float d2, float d3) {
        float r72565 = d1;
        float r72566 = d2;
        float r72567 = r72565 * r72566;
        float r72568 = d3;
        float r72569 = r72565 * r72568;
        float r72570 = r72567 + r72569;
        return r72570;
}

double f_id(float d1, float d2, float d3) {
        double r72571 = d1;
        double r72572 = d2;
        double r72573 = r72571 * r72572;
        double r72574 = d3;
        double r72575 = r72571 * r72574;
        double r72576 = r72573 + r72575;
        return r72576;
}

double f_il(float d1, float d2, float d3) {
        long double r72577 = d1;
        long double r72578 = d2;
        long double r72579 = r72577 * r72578;
        long double r72580 = d3;
        long double r72581 = r72577 * r72580;
        long double r72582 = r72579 + r72581;
        return r72582;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float d1, float d2, float d3) {
        float r72583 = d1;
        float r72584 = d2;
        float r72585 = d3;
        float r72586 = r72584 + r72585;
        float r72587 = r72583 * r72586;
        return r72587;
}

double f_od(float d1, float d2, float d3) {
        double r72588 = d1;
        double r72589 = d2;
        double r72590 = d3;
        double r72591 = r72589 + r72590;
        double r72592 = r72588 * r72591;
        return r72592;
}

double f_ol(float d1, float d2, float d3) {
        long double r72593 = d1;
        long double r72594 = d2;
        long double r72595 = d3;
        long double r72596 = r72594 + r72595;
        long double r72597 = r72593 * r72596;
        return r72597;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r72598, r72599, r72600, r72601, r72602, r72603;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r72598);
        mpfr_init(r72599);
        mpfr_init(r72600);
        mpfr_init(r72601);
        mpfr_init(r72602);
        mpfr_init(r72603);
}

double f_im(float d1, float d2, float d3) {
        mpfr_set_flt(r72598, d1, MPFR_RNDN);
        mpfr_set_flt(r72599, d2, MPFR_RNDN);
        mpfr_mul(r72600, r72598, r72599, MPFR_RNDN);
        mpfr_set_flt(r72601, d3, MPFR_RNDN);
        mpfr_mul(r72602, r72598, r72601, MPFR_RNDN);
        mpfr_add(r72603, r72600, r72602, MPFR_RNDN);
        return mpfr_get_d(r72603, MPFR_RNDN);
}

