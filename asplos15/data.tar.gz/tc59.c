#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Hyperbolic secant */

double f_if(float x) {
        float r77332 = 2.0;
        float r77333 = x;
        float r77334 = exp(r77333);
        float r77335 = -r77333;
        float r77336 = exp(r77335);
        float r77337 = r77334 + r77336;
        float r77338 = r77332 / r77337;
        return r77338;
}

double f_id(float x) {
        double r77339 = 2.0;
        double r77340 = x;
        double r77341 = exp(r77340);
        double r77342 = -r77340;
        double r77343 = exp(r77342);
        double r77344 = r77341 + r77343;
        double r77345 = r77339 / r77344;
        return r77345;
}

double f_il(float x) {
        long double r77346 = 2.0;
        long double r77347 = x;
        long double r77348 = exp(r77347);
        long double r77349 = -r77347;
        long double r77350 = exp(r77349);
        long double r77351 = r77348 + r77350;
        long double r77352 = r77346 / r77351;
        return r77352;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r77353 = 2.0;
        float r77354 = x;
        float r77355 = exp(r77354);
        float r77356 = 1.0/r77355;
        float r77357 = r77355 + r77356;
        float r77358 = r77353 / r77357;
        return r77358;
}

double f_od(float x) {
        double r77359 = 2.0;
        double r77360 = x;
        double r77361 = exp(r77360);
        double r77362 = 1.0/r77361;
        double r77363 = r77361 + r77362;
        double r77364 = r77359 / r77363;
        return r77364;
}

double f_ol(float x) {
        long double r77365 = 2.0;
        long double r77366 = x;
        long double r77367 = exp(r77366);
        long double r77368 = 1.0/r77367;
        long double r77369 = r77367 + r77368;
        long double r77370 = r77365 / r77369;
        return r77370;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r77371, r77372, r77373, r77374, r77375, r77376, r77377;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r77371);
        mpfr_init(r77372);
        mpfr_init(r77373);
        mpfr_init(r77374);
        mpfr_init(r77375);
        mpfr_init(r77376);
        mpfr_init(r77377);
}

double f_im(float x) {
        mpfr_init_set_str(r77371, "2", 10, MPFR_RNDN);
        mpfr_set_flt(r77372, x, MPFR_RNDN);
        mpfr_exp(r77373, r77372, MPFR_RNDN);
        mpfr_neg(r77374, r77372, MPFR_RNDN);
        mpfr_exp(r77375, r77374, MPFR_RNDN);
        mpfr_add(r77376, r77373, r77375, MPFR_RNDN);
        mpfr_div(r77377, r77371, r77376, MPFR_RNDN);
        return mpfr_get_d(r77377, MPFR_RNDN);
}

