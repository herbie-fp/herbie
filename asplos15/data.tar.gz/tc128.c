#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* normal distribution */

double f_if(float u1, float u2) {
        float r86335 = 1.0;
        float r86336 = 6.0;
        float r86337 = r86335 / r86336;
        float r86338 = -2.0;
        float r86339 = u1;
        float r86340 = log(r86339);
        float r86341 = r86338 * r86340;
        float r86342 = 0.5;
        float r86343 = pow(r86341, r86342);
        float r86344 = r86337 * r86343;
        float r86345 = 2.0;
        float r86346 = 3.141592653589793;
        float r86347 = r86345 * r86346;
        float r86348 = u2;
        float r86349 = r86347 * r86348;
        float r86350 = cos(r86349);
        float r86351 = r86344 * r86350;
        float r86352 = r86351 + r86342;
        return r86352;
}

double f_id(float u1, float u2) {
        double r86353 = 1.0;
        double r86354 = 6.0;
        double r86355 = r86353 / r86354;
        double r86356 = -2.0;
        double r86357 = u1;
        double r86358 = log(r86357);
        double r86359 = r86356 * r86358;
        double r86360 = 0.5;
        double r86361 = pow(r86359, r86360);
        double r86362 = r86355 * r86361;
        double r86363 = 2.0;
        double r86364 = 3.141592653589793;
        double r86365 = r86363 * r86364;
        double r86366 = u2;
        double r86367 = r86365 * r86366;
        double r86368 = cos(r86367);
        double r86369 = r86362 * r86368;
        double r86370 = r86369 + r86360;
        return r86370;
}

double f_il(float u1, float u2) {
        long double r86371 = 1.0;
        long double r86372 = 6.0;
        long double r86373 = r86371 / r86372;
        long double r86374 = -2.0;
        long double r86375 = u1;
        long double r86376 = log(r86375);
        long double r86377 = r86374 * r86376;
        long double r86378 = 0.5;
        long double r86379 = pow(r86377, r86378);
        long double r86380 = r86373 * r86379;
        long double r86381 = 2.0;
        long double r86382 = 3.141592653589793;
        long double r86383 = r86381 * r86382;
        long double r86384 = u2;
        long double r86385 = r86383 * r86384;
        long double r86386 = cos(r86385);
        long double r86387 = r86380 * r86386;
        long double r86388 = r86387 + r86378;
        return r86388;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float u1, float u2) {
        float r86389 = u1;
        float r86390 = 5.923677454108429e-21;
        bool r86391 = r86389 < r86390;
        float r86392 = 1.0;
        float r86393 = 6.0;
        float r86394 = r86392 / r86393;
        float r86395 = -2.0;
        float r86396 = log(r86389);
        float r86397 = r86395 * r86396;
        float r86398 = 0.5;
        float r86399 = pow(r86397, r86398);
        float r86400 = sqrt(r86399);
        float r86401 = r86400 * r86400;
        float r86402 = 2.0;
        float r86403 = 3.141592653589793;
        float r86404 = r86402 * r86403;
        float r86405 = u2;
        float r86406 = r86404 * r86405;
        float r86407 = cos(r86406);
        float r86408 = r86401 * r86407;
        float r86409 = r86394 * r86408;
        float r86410 = r86409 + r86398;
        float r86411 = sqrt(r86397);
        float r86412 = r86411 * r86407;
        float r86413 = r86394 * r86412;
        float r86414 = r86413 + r86398;
        float r86415 = r86391 ? r86410 : r86414;
        return r86415;
}

double f_od(float u1, float u2) {
        double r86416 = u1;
        double r86417 = 5.923677454108429e-21;
        bool r86418 = r86416 < r86417;
        double r86419 = 1.0;
        double r86420 = 6.0;
        double r86421 = r86419 / r86420;
        double r86422 = -2.0;
        double r86423 = log(r86416);
        double r86424 = r86422 * r86423;
        double r86425 = 0.5;
        double r86426 = pow(r86424, r86425);
        double r86427 = sqrt(r86426);
        double r86428 = r86427 * r86427;
        double r86429 = 2.0;
        double r86430 = 3.141592653589793;
        double r86431 = r86429 * r86430;
        double r86432 = u2;
        double r86433 = r86431 * r86432;
        double r86434 = cos(r86433);
        double r86435 = r86428 * r86434;
        double r86436 = r86421 * r86435;
        double r86437 = r86436 + r86425;
        double r86438 = sqrt(r86424);
        double r86439 = r86438 * r86434;
        double r86440 = r86421 * r86439;
        double r86441 = r86440 + r86425;
        double r86442 = r86418 ? r86437 : r86441;
        return r86442;
}

double f_ol(float u1, float u2) {
        long double r86443 = u1;
        long double r86444 = 5.923677454108429e-21;
        bool r86445 = r86443 < r86444;
        long double r86446 = 1.0;
        long double r86447 = 6.0;
        long double r86448 = r86446 / r86447;
        long double r86449 = -2.0;
        long double r86450 = log(r86443);
        long double r86451 = r86449 * r86450;
        long double r86452 = 0.5;
        long double r86453 = pow(r86451, r86452);
        long double r86454 = sqrt(r86453);
        long double r86455 = r86454 * r86454;
        long double r86456 = 2.0;
        long double r86457 = 3.141592653589793;
        long double r86458 = r86456 * r86457;
        long double r86459 = u2;
        long double r86460 = r86458 * r86459;
        long double r86461 = cos(r86460);
        long double r86462 = r86455 * r86461;
        long double r86463 = r86448 * r86462;
        long double r86464 = r86463 + r86452;
        long double r86465 = sqrt(r86451);
        long double r86466 = r86465 * r86461;
        long double r86467 = r86448 * r86466;
        long double r86468 = r86467 + r86452;
        long double r86469 = r86445 ? r86464 : r86468;
        return r86469;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r86470, r86471, r86472, r86473, r86474, r86475, r86476, r86477, r86478, r86479, r86480, r86481, r86482, r86483, r86484, r86485, r86486, r86487;

void setup_mpfr() {
        mpfr_set_default_prec(136);
        mpfr_init(r86470);
        mpfr_init(r86471);
        mpfr_init(r86472);
        mpfr_init(r86473);
        mpfr_init(r86474);
        mpfr_init(r86475);
        mpfr_init(r86476);
        mpfr_init(r86477);
        mpfr_init(r86478);
        mpfr_init(r86479);
        mpfr_init(r86480);
        mpfr_init(r86481);
        mpfr_init(r86482);
        mpfr_init(r86483);
        mpfr_init(r86484);
        mpfr_init(r86485);
        mpfr_init(r86486);
        mpfr_init(r86487);
}

double f_im(float u1, float u2) {
        mpfr_init_set_str(r86470, "1", 10, MPFR_RNDN);
        mpfr_init_set_str(r86471, "6", 10, MPFR_RNDN);
        mpfr_div(r86472, r86470, r86471, MPFR_RNDN);
        mpfr_init_set_str(r86473, "-2", 10, MPFR_RNDN);
        mpfr_set_flt(r86474, u1, MPFR_RNDN);
        mpfr_log(r86475, r86474, MPFR_RNDN);
        mpfr_mul(r86476, r86473, r86475, MPFR_RNDN);
        mpfr_init_set_str(r86477, "0.5", 10, MPFR_RNDN);
        mpfr_pow(r86478, r86476, r86477, MPFR_RNDN);
        mpfr_mul(r86479, r86472, r86478, MPFR_RNDN);
        mpfr_init_set_str(r86480, "2", 10, MPFR_RNDN);
        mpfr_init_set_str(r86481, "3.141592653589793", 10, MPFR_RNDN);
        mpfr_mul(r86482, r86480, r86481, MPFR_RNDN);
        mpfr_set_flt(r86483, u2, MPFR_RNDN);
        mpfr_mul(r86484, r86482, r86483, MPFR_RNDN);
        mpfr_cos(r86485, r86484, MPFR_RNDN);
        mpfr_mul(r86486, r86479, r86485, MPFR_RNDN);
        mpfr_add(r86487, r86486, r86477, MPFR_RNDN);
        return mpfr_get_d(r86487, MPFR_RNDN);
}

