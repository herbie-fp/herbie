#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Hyperbolic tangent */

double f_if(float x) {
        float r77474 = x;
        float r77475 = exp(r77474);
        float r77476 = -r77474;
        float r77477 = exp(r77476);
        float r77478 = r77475 - r77477;
        float r77479 = r77475 + r77477;
        float r77480 = r77478 / r77479;
        return r77480;
}

double f_id(float x) {
        double r77481 = x;
        double r77482 = exp(r77481);
        double r77483 = -r77481;
        double r77484 = exp(r77483);
        double r77485 = r77482 - r77484;
        double r77486 = r77482 + r77484;
        double r77487 = r77485 / r77486;
        return r77487;
}

double f_il(float x) {
        long double r77488 = x;
        long double r77489 = exp(r77488);
        long double r77490 = -r77488;
        long double r77491 = exp(r77490);
        long double r77492 = r77489 - r77491;
        long double r77493 = r77489 + r77491;
        long double r77494 = r77492 / r77493;
        return r77494;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r77495 = x;
        float r77496 = -1.1102230246251565e-16;
        bool r77497 = r77495 < r77496;
        float r77498 = exp(r77495);
        float r77499 = 1.0;
        float r77500 = r77499 / r77498;
        float r77501 = r77498 + r77500;
        float r77502 = r77498 / r77501;
        float r77503 = r77498 * r77498;
        float r77504 = r77503 + r77499;
        float r77505 = r77499 / r77504;
        float r77506 = r77502 - r77505;
        float r77507 = -0.0;
        bool r77508 = r77495 < r77507;
        float r77509 = -r77495;
        float r77510 = exp(r77509);
        float r77511 = r77498 + r77510;
        float r77512 = sqrt(r77511);
        float r77513 = r77498 / r77512;
        float r77514 = r77513 * r77513;
        float r77515 = r77510 * r77510;
        float r77516 = r77515 / r77511;
        float r77517 = r77514 - r77516;
        float r77518 = r77517 / r77511;
        float r77519 = r77503 / r77511;
        float r77520 = sqrt(r77519);
        float r77521 = r77520 * r77520;
        float r77522 = r77521 - r77516;
        float r77523 = r77522 / r77511;
        float r77524 = r77508 ? r77518 : r77523;
        float r77525 = r77497 ? r77506 : r77524;
        return r77525;
}

double f_od(float x) {
        double r77526 = x;
        double r77527 = -1.1102230246251565e-16;
        bool r77528 = r77526 < r77527;
        double r77529 = exp(r77526);
        double r77530 = 1.0;
        double r77531 = r77530 / r77529;
        double r77532 = r77529 + r77531;
        double r77533 = r77529 / r77532;
        double r77534 = r77529 * r77529;
        double r77535 = r77534 + r77530;
        double r77536 = r77530 / r77535;
        double r77537 = r77533 - r77536;
        double r77538 = -0.0;
        bool r77539 = r77526 < r77538;
        double r77540 = -r77526;
        double r77541 = exp(r77540);
        double r77542 = r77529 + r77541;
        double r77543 = sqrt(r77542);
        double r77544 = r77529 / r77543;
        double r77545 = r77544 * r77544;
        double r77546 = r77541 * r77541;
        double r77547 = r77546 / r77542;
        double r77548 = r77545 - r77547;
        double r77549 = r77548 / r77542;
        double r77550 = r77534 / r77542;
        double r77551 = sqrt(r77550);
        double r77552 = r77551 * r77551;
        double r77553 = r77552 - r77547;
        double r77554 = r77553 / r77542;
        double r77555 = r77539 ? r77549 : r77554;
        double r77556 = r77528 ? r77537 : r77555;
        return r77556;
}

double f_ol(float x) {
        long double r77557 = x;
        long double r77558 = -1.1102230246251565e-16;
        bool r77559 = r77557 < r77558;
        long double r77560 = exp(r77557);
        long double r77561 = 1.0;
        long double r77562 = r77561 / r77560;
        long double r77563 = r77560 + r77562;
        long double r77564 = r77560 / r77563;
        long double r77565 = r77560 * r77560;
        long double r77566 = r77565 + r77561;
        long double r77567 = r77561 / r77566;
        long double r77568 = r77564 - r77567;
        long double r77569 = -0.0;
        bool r77570 = r77557 < r77569;
        long double r77571 = -r77557;
        long double r77572 = exp(r77571);
        long double r77573 = r77560 + r77572;
        long double r77574 = sqrt(r77573);
        long double r77575 = r77560 / r77574;
        long double r77576 = r77575 * r77575;
        long double r77577 = r77572 * r77572;
        long double r77578 = r77577 / r77573;
        long double r77579 = r77576 - r77578;
        long double r77580 = r77579 / r77573;
        long double r77581 = r77565 / r77573;
        long double r77582 = sqrt(r77581);
        long double r77583 = r77582 * r77582;
        long double r77584 = r77583 - r77578;
        long double r77585 = r77584 / r77573;
        long double r77586 = r77570 ? r77580 : r77585;
        long double r77587 = r77559 ? r77568 : r77586;
        return r77587;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r77588, r77589, r77590, r77591, r77592, r77593, r77594;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r77588);
        mpfr_init(r77589);
        mpfr_init(r77590);
        mpfr_init(r77591);
        mpfr_init(r77592);
        mpfr_init(r77593);
        mpfr_init(r77594);
}

double f_im(float x) {
        mpfr_set_flt(r77588, x, MPFR_RNDN);
        mpfr_exp(r77589, r77588, MPFR_RNDN);
        mpfr_neg(r77590, r77588, MPFR_RNDN);
        mpfr_exp(r77591, r77590, MPFR_RNDN);
        mpfr_sub(r77592, r77589, r77591, MPFR_RNDN);
        mpfr_add(r77593, r77589, r77591, MPFR_RNDN);
        mpfr_div(r77594, r77592, r77593, MPFR_RNDN);
        return mpfr_get_d(r77594, MPFR_RNDN);
}

