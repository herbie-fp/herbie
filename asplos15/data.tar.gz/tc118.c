#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.log/1 on complex, real part */

double f_if(float re, float im) {
        float r85301 = re;
        float r85302 = r85301 * r85301;
        float r85303 = im;
        float r85304 = r85303 * r85303;
        float r85305 = r85302 + r85304;
        float r85306 = sqrt(r85305);
        float r85307 = log(r85306);
        return r85307;
}

double f_id(float re, float im) {
        double r85308 = re;
        double r85309 = r85308 * r85308;
        double r85310 = im;
        double r85311 = r85310 * r85310;
        double r85312 = r85309 + r85311;
        double r85313 = sqrt(r85312);
        double r85314 = log(r85313);
        return r85314;
}

double f_il(float re, float im) {
        long double r85315 = re;
        long double r85316 = r85315 * r85315;
        long double r85317 = im;
        long double r85318 = r85317 * r85317;
        long double r85319 = r85316 + r85318;
        long double r85320 = sqrt(r85319);
        long double r85321 = log(r85320);
        return r85321;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r85322 = re;
        float r85323 = r85322 * r85322;
        float r85324 = im;
        float r85325 = r85324 * r85324;
        float r85326 = r85323 + r85325;
        float r85327 = log(r85326);
        float r85328 = exp(r85327);
        float r85329 = sqrt(r85328);
        float r85330 = log(r85329);
        return r85330;
}

double f_od(float re, float im) {
        double r85331 = re;
        double r85332 = r85331 * r85331;
        double r85333 = im;
        double r85334 = r85333 * r85333;
        double r85335 = r85332 + r85334;
        double r85336 = log(r85335);
        double r85337 = exp(r85336);
        double r85338 = sqrt(r85337);
        double r85339 = log(r85338);
        return r85339;
}

double f_ol(float re, float im) {
        long double r85340 = re;
        long double r85341 = r85340 * r85340;
        long double r85342 = im;
        long double r85343 = r85342 * r85342;
        long double r85344 = r85341 + r85343;
        long double r85345 = log(r85344);
        long double r85346 = exp(r85345);
        long double r85347 = sqrt(r85346);
        long double r85348 = log(r85347);
        return r85348;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r85349, r85350, r85351, r85352, r85353, r85354, r85355;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r85349);
        mpfr_init(r85350);
        mpfr_init(r85351);
        mpfr_init(r85352);
        mpfr_init(r85353);
        mpfr_init(r85354);
        mpfr_init(r85355);
}

double f_im(float re, float im) {
        mpfr_set_flt(r85349, re, MPFR_RNDN);
        mpfr_mul(r85350, r85349, r85349, MPFR_RNDN);
        mpfr_set_flt(r85351, im, MPFR_RNDN);
        mpfr_mul(r85352, r85351, r85351, MPFR_RNDN);
        mpfr_add(r85353, r85350, r85352, MPFR_RNDN);
        mpfr_sqrt(r85354, r85353, MPFR_RNDN);
        mpfr_log(r85355, r85354, MPFR_RNDN);
        return mpfr_get_d(r85355, MPFR_RNDN);
}

