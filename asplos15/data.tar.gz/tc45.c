#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Bouland and Aaronson, Equation (26) */

double f_if(float a, float b) {
        float r75562 = a;
        float r75563 = r75562 * r75562;
        float r75564 = b;
        float r75565 = r75564 * r75564;
        float r75566 = r75563 + r75565;
        float r75567 = r75566 * r75566;
        float r75568 = 4.0;
        float r75569 = r75568 * r75565;
        float r75570 = r75567 + r75569;
        float r75571 = 1.0;
        float r75572 = r75570 - r75571;
        return r75572;
}

double f_id(float a, float b) {
        double r75573 = a;
        double r75574 = r75573 * r75573;
        double r75575 = b;
        double r75576 = r75575 * r75575;
        double r75577 = r75574 + r75576;
        double r75578 = r75577 * r75577;
        double r75579 = 4.0;
        double r75580 = r75579 * r75576;
        double r75581 = r75578 + r75580;
        double r75582 = 1.0;
        double r75583 = r75581 - r75582;
        return r75583;
}

double f_il(float a, float b) {
        long double r75584 = a;
        long double r75585 = r75584 * r75584;
        long double r75586 = b;
        long double r75587 = r75586 * r75586;
        long double r75588 = r75585 + r75587;
        long double r75589 = r75588 * r75588;
        long double r75590 = 4.0;
        long double r75591 = r75590 * r75587;
        long double r75592 = r75589 + r75591;
        long double r75593 = 1.0;
        long double r75594 = r75592 - r75593;
        return r75594;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a, float b) {
        float r75595 = a;
        float r75596 = 6.848499547677975e+37;
        bool r75597 = r75595 < r75596;
        float r75598 = r75595 * r75595;
        float r75599 = b;
        float r75600 = r75599 * r75599;
        float r75601 = r75598 + r75600;
        float r75602 = r75601 * r75601;
        float r75603 = 4.0;
        float r75604 = r75603 * r75600;
        float r75605 = r75602 + r75604;
        float r75606 = -1.0;
        float r75607 = r75605 + r75606;
        float r75608 = r75602 * r75602;
        float r75609 = r75604 * r75604;
        float r75610 = r75608 - r75609;
        float r75611 = r75602 - r75604;
        float r75612 = r75610 / r75611;
        float r75613 = r75612 + r75606;
        float r75614 = r75597 ? r75607 : r75613;
        return r75614;
}

double f_od(float a, float b) {
        double r75615 = a;
        double r75616 = 6.848499547677975e+37;
        bool r75617 = r75615 < r75616;
        double r75618 = r75615 * r75615;
        double r75619 = b;
        double r75620 = r75619 * r75619;
        double r75621 = r75618 + r75620;
        double r75622 = r75621 * r75621;
        double r75623 = 4.0;
        double r75624 = r75623 * r75620;
        double r75625 = r75622 + r75624;
        double r75626 = -1.0;
        double r75627 = r75625 + r75626;
        double r75628 = r75622 * r75622;
        double r75629 = r75624 * r75624;
        double r75630 = r75628 - r75629;
        double r75631 = r75622 - r75624;
        double r75632 = r75630 / r75631;
        double r75633 = r75632 + r75626;
        double r75634 = r75617 ? r75627 : r75633;
        return r75634;
}

double f_ol(float a, float b) {
        long double r75635 = a;
        long double r75636 = 6.848499547677975e+37;
        bool r75637 = r75635 < r75636;
        long double r75638 = r75635 * r75635;
        long double r75639 = b;
        long double r75640 = r75639 * r75639;
        long double r75641 = r75638 + r75640;
        long double r75642 = r75641 * r75641;
        long double r75643 = 4.0;
        long double r75644 = r75643 * r75640;
        long double r75645 = r75642 + r75644;
        long double r75646 = -1.0;
        long double r75647 = r75645 + r75646;
        long double r75648 = r75642 * r75642;
        long double r75649 = r75644 * r75644;
        long double r75650 = r75648 - r75649;
        long double r75651 = r75642 - r75644;
        long double r75652 = r75650 / r75651;
        long double r75653 = r75652 + r75646;
        long double r75654 = r75637 ? r75647 : r75653;
        return r75654;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r75655, r75656, r75657, r75658, r75659, r75660, r75661, r75662, r75663, r75664, r75665;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r75655);
        mpfr_init(r75656);
        mpfr_init(r75657);
        mpfr_init(r75658);
        mpfr_init(r75659);
        mpfr_init(r75660);
        mpfr_init(r75661);
        mpfr_init(r75662);
        mpfr_init(r75663);
        mpfr_init(r75664);
        mpfr_init(r75665);
}

double f_im(float a, float b) {
        mpfr_set_flt(r75655, a, MPFR_RNDN);
        mpfr_mul(r75656, r75655, r75655, MPFR_RNDN);
        mpfr_set_flt(r75657, b, MPFR_RNDN);
        mpfr_mul(r75658, r75657, r75657, MPFR_RNDN);
        mpfr_add(r75659, r75656, r75658, MPFR_RNDN);
        mpfr_mul(r75660, r75659, r75659, MPFR_RNDN);
        mpfr_init_set_str(r75661, "4", 10, MPFR_RNDN);
        mpfr_mul(r75662, r75661, r75658, MPFR_RNDN);
        mpfr_add(r75663, r75660, r75662, MPFR_RNDN);
        mpfr_init_set_str(r75664, "1", 10, MPFR_RNDN);
        mpfr_sub(r75665, r75663, r75664, MPFR_RNDN);
        return mpfr_get_d(r75665, MPFR_RNDN);
}

