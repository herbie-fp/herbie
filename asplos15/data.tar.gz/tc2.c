#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Commute */

double f_if(float x, float y) {
        float r72397 = x;
        float r72398 = y;
        float r72399 = r72397 + r72398;
        float r72400 = r72398 + r72397;
        float r72401 = r72399 - r72400;
        return r72401;
}

double f_id(float x, float y) {
        double r72402 = x;
        double r72403 = y;
        double r72404 = r72402 + r72403;
        double r72405 = r72403 + r72402;
        double r72406 = r72404 - r72405;
        return r72406;
}

double f_il(float x, float y) {
        long double r72407 = x;
        long double r72408 = y;
        long double r72409 = r72407 + r72408;
        long double r72410 = r72408 + r72407;
        long double r72411 = r72409 - r72410;
        return r72411;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x, float y) {
        float r72412 = 0.0;
        return r72412;
}

double f_od(float x, float y) {
        double r72413 = 0.0;
        return r72413;
}

double f_ol(float x, float y) {
        long double r72414 = 0.0;
        return r72414;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r72415, r72416, r72417, r72418, r72419;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r72415);
        mpfr_init(r72416);
        mpfr_init(r72417);
        mpfr_init(r72418);
        mpfr_init(r72419);
}

double f_im(float x, float y) {
        mpfr_set_flt(r72415, x, MPFR_RNDN);
        mpfr_set_flt(r72416, y, MPFR_RNDN);
        mpfr_add(r72417, r72415, r72416, MPFR_RNDN);
        mpfr_add(r72418, r72416, r72415, MPFR_RNDN);
        mpfr_sub(r72419, r72417, r72418, MPFR_RNDN);
        return mpfr_get_d(r72419, MPFR_RNDN);
}

