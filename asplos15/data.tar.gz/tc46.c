#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Bulmash initializePoisson */

double f_if(float NdChar, float Ec, float Vef, float EDonor, float mu, float KbT, float NaChar, float Ev, float EAccept) {
        float r75668 = NdChar;
        float r75669 = 1.0;
        float r75670 = Ec;
        float r75671 = Vef;
        float r75672 = r75670 - r75671;
        float r75673 = EDonor;
        float r75674 = r75672 - r75673;
        float r75675 = mu;
        float r75676 = r75674 - r75675;
        float r75677 = -r75676;
        float r75678 = KbT;
        float r75679 = r75677 / r75678;
        float r75680 = exp(r75679);
        float r75681 = r75669 + r75680;
        float r75682 = r75668 / r75681;
        float r75683 = NaChar;
        float r75684 = Ev;
        float r75685 = r75684 + r75671;
        float r75686 = EAccept;
        float r75687 = r75685 + r75686;
        float r75688 = -r75675;
        float r75689 = r75687 + r75688;
        float r75690 = r75689 / r75678;
        float r75691 = exp(r75690);
        float r75692 = r75669 + r75691;
        float r75693 = r75683 / r75692;
        float r75694 = r75682 + r75693;
        return r75694;
}

double f_id(float NdChar, float Ec, float Vef, float EDonor, float mu, float KbT, float NaChar, float Ev, float EAccept) {
        double r75695 = NdChar;
        double r75696 = 1.0;
        double r75697 = Ec;
        double r75698 = Vef;
        double r75699 = r75697 - r75698;
        double r75700 = EDonor;
        double r75701 = r75699 - r75700;
        double r75702 = mu;
        double r75703 = r75701 - r75702;
        double r75704 = -r75703;
        double r75705 = KbT;
        double r75706 = r75704 / r75705;
        double r75707 = exp(r75706);
        double r75708 = r75696 + r75707;
        double r75709 = r75695 / r75708;
        double r75710 = NaChar;
        double r75711 = Ev;
        double r75712 = r75711 + r75698;
        double r75713 = EAccept;
        double r75714 = r75712 + r75713;
        double r75715 = -r75702;
        double r75716 = r75714 + r75715;
        double r75717 = r75716 / r75705;
        double r75718 = exp(r75717);
        double r75719 = r75696 + r75718;
        double r75720 = r75710 / r75719;
        double r75721 = r75709 + r75720;
        return r75721;
}

double f_il(float NdChar, float Ec, float Vef, float EDonor, float mu, float KbT, float NaChar, float Ev, float EAccept) {
        long double r75722 = NdChar;
        long double r75723 = 1.0;
        long double r75724 = Ec;
        long double r75725 = Vef;
        long double r75726 = r75724 - r75725;
        long double r75727 = EDonor;
        long double r75728 = r75726 - r75727;
        long double r75729 = mu;
        long double r75730 = r75728 - r75729;
        long double r75731 = -r75730;
        long double r75732 = KbT;
        long double r75733 = r75731 / r75732;
        long double r75734 = exp(r75733);
        long double r75735 = r75723 + r75734;
        long double r75736 = r75722 / r75735;
        long double r75737 = NaChar;
        long double r75738 = Ev;
        long double r75739 = r75738 + r75725;
        long double r75740 = EAccept;
        long double r75741 = r75739 + r75740;
        long double r75742 = -r75729;
        long double r75743 = r75741 + r75742;
        long double r75744 = r75743 / r75732;
        long double r75745 = exp(r75744);
        long double r75746 = r75723 + r75745;
        long double r75747 = r75737 / r75746;
        long double r75748 = r75736 + r75747;
        return r75748;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float NdChar, float Ec, float Vef, float EDonor, float mu, float KbT, float NaChar, float Ev, float EAccept) {
        float r75749 = NdChar;
        float r75750 = 1.0;
        float r75751 = exp(r75750);
        float r75752 = Ec;
        float r75753 = Vef;
        float r75754 = r75752 - r75753;
        float r75755 = EDonor;
        float r75756 = r75754 - r75755;
        float r75757 = mu;
        float r75758 = r75756 - r75757;
        float r75759 = -r75758;
        float r75760 = KbT;
        float r75761 = r75759 / r75760;
        float r75762 = pow(r75751, r75761);
        float r75763 = r75750 + r75762;
        float r75764 = r75749 / r75763;
        float r75765 = NaChar;
        float r75766 = Ev;
        float r75767 = r75766 + r75753;
        float r75768 = EAccept;
        float r75769 = r75767 + r75768;
        float r75770 = -r75757;
        float r75771 = r75769 + r75770;
        float r75772 = r75771 / r75760;
        float r75773 = exp(r75772);
        float r75774 = r75750 + r75773;
        float r75775 = r75765 / r75774;
        float r75776 = r75764 + r75775;
        return r75776;
}

double f_od(float NdChar, float Ec, float Vef, float EDonor, float mu, float KbT, float NaChar, float Ev, float EAccept) {
        double r75777 = NdChar;
        double r75778 = 1.0;
        double r75779 = exp(r75778);
        double r75780 = Ec;
        double r75781 = Vef;
        double r75782 = r75780 - r75781;
        double r75783 = EDonor;
        double r75784 = r75782 - r75783;
        double r75785 = mu;
        double r75786 = r75784 - r75785;
        double r75787 = -r75786;
        double r75788 = KbT;
        double r75789 = r75787 / r75788;
        double r75790 = pow(r75779, r75789);
        double r75791 = r75778 + r75790;
        double r75792 = r75777 / r75791;
        double r75793 = NaChar;
        double r75794 = Ev;
        double r75795 = r75794 + r75781;
        double r75796 = EAccept;
        double r75797 = r75795 + r75796;
        double r75798 = -r75785;
        double r75799 = r75797 + r75798;
        double r75800 = r75799 / r75788;
        double r75801 = exp(r75800);
        double r75802 = r75778 + r75801;
        double r75803 = r75793 / r75802;
        double r75804 = r75792 + r75803;
        return r75804;
}

double f_ol(float NdChar, float Ec, float Vef, float EDonor, float mu, float KbT, float NaChar, float Ev, float EAccept) {
        long double r75805 = NdChar;
        long double r75806 = 1.0;
        long double r75807 = exp(r75806);
        long double r75808 = Ec;
        long double r75809 = Vef;
        long double r75810 = r75808 - r75809;
        long double r75811 = EDonor;
        long double r75812 = r75810 - r75811;
        long double r75813 = mu;
        long double r75814 = r75812 - r75813;
        long double r75815 = -r75814;
        long double r75816 = KbT;
        long double r75817 = r75815 / r75816;
        long double r75818 = pow(r75807, r75817);
        long double r75819 = r75806 + r75818;
        long double r75820 = r75805 / r75819;
        long double r75821 = NaChar;
        long double r75822 = Ev;
        long double r75823 = r75822 + r75809;
        long double r75824 = EAccept;
        long double r75825 = r75823 + r75824;
        long double r75826 = -r75813;
        long double r75827 = r75825 + r75826;
        long double r75828 = r75827 / r75816;
        long double r75829 = exp(r75828);
        long double r75830 = r75806 + r75829;
        long double r75831 = r75821 / r75830;
        long double r75832 = r75820 + r75831;
        return r75832;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r75833, r75834, r75835, r75836, r75837, r75838, r75839, r75840, r75841, r75842, r75843, r75844, r75845, r75846, r75847, r75848, r75849, r75850, r75851, r75852, r75853, r75854, r75855, r75856, r75857, r75858, r75859;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r75833);
        mpfr_init(r75834);
        mpfr_init(r75835);
        mpfr_init(r75836);
        mpfr_init(r75837);
        mpfr_init(r75838);
        mpfr_init(r75839);
        mpfr_init(r75840);
        mpfr_init(r75841);
        mpfr_init(r75842);
        mpfr_init(r75843);
        mpfr_init(r75844);
        mpfr_init(r75845);
        mpfr_init(r75846);
        mpfr_init(r75847);
        mpfr_init(r75848);
        mpfr_init(r75849);
        mpfr_init(r75850);
        mpfr_init(r75851);
        mpfr_init(r75852);
        mpfr_init(r75853);
        mpfr_init(r75854);
        mpfr_init(r75855);
        mpfr_init(r75856);
        mpfr_init(r75857);
        mpfr_init(r75858);
        mpfr_init(r75859);
}

double f_im(float NdChar, float Ec, float Vef, float EDonor, float mu, float KbT, float NaChar, float Ev, float EAccept) {
        mpfr_set_flt(r75833, NdChar, MPFR_RNDN);
        mpfr_init_set_str(r75834, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r75835, Ec, MPFR_RNDN);
        mpfr_set_flt(r75836, Vef, MPFR_RNDN);
        mpfr_sub(r75837, r75835, r75836, MPFR_RNDN);
        mpfr_set_flt(r75838, EDonor, MPFR_RNDN);
        mpfr_sub(r75839, r75837, r75838, MPFR_RNDN);
        mpfr_set_flt(r75840, mu, MPFR_RNDN);
        mpfr_sub(r75841, r75839, r75840, MPFR_RNDN);
        mpfr_neg(r75842, r75841, MPFR_RNDN);
        mpfr_set_flt(r75843, KbT, MPFR_RNDN);
        mpfr_div(r75844, r75842, r75843, MPFR_RNDN);
        mpfr_exp(r75845, r75844, MPFR_RNDN);
        mpfr_add(r75846, r75834, r75845, MPFR_RNDN);
        mpfr_div(r75847, r75833, r75846, MPFR_RNDN);
        mpfr_set_flt(r75848, NaChar, MPFR_RNDN);
        mpfr_set_flt(r75849, Ev, MPFR_RNDN);
        mpfr_add(r75850, r75849, r75836, MPFR_RNDN);
        mpfr_set_flt(r75851, EAccept, MPFR_RNDN);
        mpfr_add(r75852, r75850, r75851, MPFR_RNDN);
        mpfr_neg(r75853, r75840, MPFR_RNDN);
        mpfr_add(r75854, r75852, r75853, MPFR_RNDN);
        mpfr_div(r75855, r75854, r75843, MPFR_RNDN);
        mpfr_exp(r75856, r75855, MPFR_RNDN);
        mpfr_add(r75857, r75834, r75856, MPFR_RNDN);
        mpfr_div(r75858, r75848, r75857, MPFR_RNDN);
        mpfr_add(r75859, r75847, r75858, MPFR_RNDN);
        return mpfr_get_d(r75859, MPFR_RNDN);
}

