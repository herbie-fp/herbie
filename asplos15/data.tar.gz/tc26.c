#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE p42 */

double f_if(float a, float b, float c) {
        float r73831 = b;
        float r73832 = -r73831;
        float r73833 = r73831 * r73831;
        float r73834 = 4.0;
        float r73835 = a;
        float r73836 = c;
        float r73837 = r73835 * r73836;
        float r73838 = r73834 * r73837;
        float r73839 = r73833 - r73838;
        float r73840 = sqrt(r73839);
        float r73841 = r73832 - r73840;
        float r73842 = 2.0;
        float r73843 = r73842 * r73835;
        float r73844 = r73841 / r73843;
        return r73844;
}

double f_id(float a, float b, float c) {
        double r73845 = b;
        double r73846 = -r73845;
        double r73847 = r73845 * r73845;
        double r73848 = 4.0;
        double r73849 = a;
        double r73850 = c;
        double r73851 = r73849 * r73850;
        double r73852 = r73848 * r73851;
        double r73853 = r73847 - r73852;
        double r73854 = sqrt(r73853);
        double r73855 = r73846 - r73854;
        double r73856 = 2.0;
        double r73857 = r73856 * r73849;
        double r73858 = r73855 / r73857;
        return r73858;
}

double f_il(float a, float b, float c) {
        long double r73859 = b;
        long double r73860 = -r73859;
        long double r73861 = r73859 * r73859;
        long double r73862 = 4.0;
        long double r73863 = a;
        long double r73864 = c;
        long double r73865 = r73863 * r73864;
        long double r73866 = r73862 * r73865;
        long double r73867 = r73861 - r73866;
        long double r73868 = sqrt(r73867);
        long double r73869 = r73860 - r73868;
        long double r73870 = 2.0;
        long double r73871 = r73870 * r73863;
        long double r73872 = r73869 / r73871;
        return r73872;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a, float b, float c) {
        float r73873 = b;
        float r73874 = 3.496821942292763e-20;
        bool r73875 = r73873 < r73874;
        float r73876 = 1.0;
        float r73877 = 4.0;
        float r73878 = a;
        float r73879 = c;
        float r73880 = r73878 * r73879;
        float r73881 = r73877 * r73880;
        float r73882 = r73876 * r73881;
        float r73883 = -r73873;
        float r73884 = r73873 * r73873;
        float r73885 = r73884 - r73881;
        float r73886 = sqrt(r73885);
        float r73887 = r73883 + r73886;
        float r73888 = r73882 / r73887;
        float r73889 = 2.0;
        float r73890 = r73889 * r73878;
        float r73891 = r73888 / r73890;
        float r73892 = r73883 - r73886;
        float r73893 = r73892 / r73890;
        float r73894 = r73875 ? r73891 : r73893;
        return r73894;
}

double f_od(float a, float b, float c) {
        double r73895 = b;
        double r73896 = 3.496821942292763e-20;
        bool r73897 = r73895 < r73896;
        double r73898 = 1.0;
        double r73899 = 4.0;
        double r73900 = a;
        double r73901 = c;
        double r73902 = r73900 * r73901;
        double r73903 = r73899 * r73902;
        double r73904 = r73898 * r73903;
        double r73905 = -r73895;
        double r73906 = r73895 * r73895;
        double r73907 = r73906 - r73903;
        double r73908 = sqrt(r73907);
        double r73909 = r73905 + r73908;
        double r73910 = r73904 / r73909;
        double r73911 = 2.0;
        double r73912 = r73911 * r73900;
        double r73913 = r73910 / r73912;
        double r73914 = r73905 - r73908;
        double r73915 = r73914 / r73912;
        double r73916 = r73897 ? r73913 : r73915;
        return r73916;
}

double f_ol(float a, float b, float c) {
        long double r73917 = b;
        long double r73918 = 3.496821942292763e-20;
        bool r73919 = r73917 < r73918;
        long double r73920 = 1.0;
        long double r73921 = 4.0;
        long double r73922 = a;
        long double r73923 = c;
        long double r73924 = r73922 * r73923;
        long double r73925 = r73921 * r73924;
        long double r73926 = r73920 * r73925;
        long double r73927 = -r73917;
        long double r73928 = r73917 * r73917;
        long double r73929 = r73928 - r73925;
        long double r73930 = sqrt(r73929);
        long double r73931 = r73927 + r73930;
        long double r73932 = r73926 / r73931;
        long double r73933 = 2.0;
        long double r73934 = r73933 * r73922;
        long double r73935 = r73932 / r73934;
        long double r73936 = r73927 - r73930;
        long double r73937 = r73936 / r73934;
        long double r73938 = r73919 ? r73935 : r73937;
        return r73938;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r73939, r73940, r73941, r73942, r73943, r73944, r73945, r73946, r73947, r73948, r73949, r73950, r73951, r73952;

void setup_mpfr() {
        mpfr_set_default_prec(536);
        mpfr_init(r73939);
        mpfr_init(r73940);
        mpfr_init(r73941);
        mpfr_init(r73942);
        mpfr_init(r73943);
        mpfr_init(r73944);
        mpfr_init(r73945);
        mpfr_init(r73946);
        mpfr_init(r73947);
        mpfr_init(r73948);
        mpfr_init(r73949);
        mpfr_init(r73950);
        mpfr_init(r73951);
        mpfr_init(r73952);
}

double f_im(float a, float b, float c) {
        mpfr_set_flt(r73939, b, MPFR_RNDN);
        mpfr_neg(r73940, r73939, MPFR_RNDN);
        mpfr_mul(r73941, r73939, r73939, MPFR_RNDN);
        mpfr_init_set_str(r73942, "4", 10, MPFR_RNDN);
        mpfr_set_flt(r73943, a, MPFR_RNDN);
        mpfr_set_flt(r73944, c, MPFR_RNDN);
        mpfr_mul(r73945, r73943, r73944, MPFR_RNDN);
        mpfr_mul(r73946, r73942, r73945, MPFR_RNDN);
        mpfr_sub(r73947, r73941, r73946, MPFR_RNDN);
        mpfr_sqrt(r73948, r73947, MPFR_RNDN);
        mpfr_sub(r73949, r73940, r73948, MPFR_RNDN);
        mpfr_init_set_str(r73950, "2", 10, MPFR_RNDN);
        mpfr_mul(r73951, r73950, r73943, MPFR_RNDN);
        mpfr_div(r73952, r73949, r73951, MPFR_RNDN);
        return mpfr_get_d(r73952, MPFR_RNDN);
}

