#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Expanding a square */

double f_if(float a) {
        float r72523 = a;
        float r72524 = 1.0;
        float r72525 = r72523 + r72524;
        float r72526 = r72525 * r72525;
        float r72527 = r72526 - r72524;
        return r72527;
}

double f_id(float a) {
        double r72528 = a;
        double r72529 = 1.0;
        double r72530 = r72528 + r72529;
        double r72531 = r72530 * r72530;
        double r72532 = r72531 - r72529;
        return r72532;
}

double f_il(float a) {
        long double r72533 = a;
        long double r72534 = 1.0;
        long double r72535 = r72533 + r72534;
        long double r72536 = r72535 * r72535;
        long double r72537 = r72536 - r72534;
        return r72537;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a) {
        float r72538 = 1.0;
        float r72539 = a;
        float r72540 = 2.0;
        float r72541 = r72539 * r72540;
        float r72542 = r72539 * r72539;
        float r72543 = r72541 + r72542;
        float r72544 = r72538 * r72543;
        return r72544;
}

double f_od(float a) {
        double r72545 = 1.0;
        double r72546 = a;
        double r72547 = 2.0;
        double r72548 = r72546 * r72547;
        double r72549 = r72546 * r72546;
        double r72550 = r72548 + r72549;
        double r72551 = r72545 * r72550;
        return r72551;
}

double f_ol(float a) {
        long double r72552 = 1.0;
        long double r72553 = a;
        long double r72554 = 2.0;
        long double r72555 = r72553 * r72554;
        long double r72556 = r72553 * r72553;
        long double r72557 = r72555 + r72556;
        long double r72558 = r72552 * r72557;
        return r72558;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r72559, r72560, r72561, r72562, r72563;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r72559);
        mpfr_init(r72560);
        mpfr_init(r72561);
        mpfr_init(r72562);
        mpfr_init(r72563);
}

double f_im(float a) {
        mpfr_set_flt(r72559, a, MPFR_RNDN);
        mpfr_init_set_str(r72560, "1", 10, MPFR_RNDN);
        mpfr_add(r72561, r72559, r72560, MPFR_RNDN);
        mpfr_mul(r72562, r72561, r72561, MPFR_RNDN);
        mpfr_sub(r72563, r72562, r72560, MPFR_RNDN);
        return mpfr_get_d(r72563, MPFR_RNDN);
}

