#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Falkner and Boettcher, Equation (22+) */

double f_if(float v) {
        float r76291 = 4.0;
        float r76292 = 3.0;
        float r76293 = atan2(1.0, 0.0);
        float r76294 = r76292 * r76293;
        float r76295 = 1.0;
        float r76296 = v;
        float r76297 = r76296 * r76296;
        float r76298 = r76295 - r76297;
        float r76299 = r76294 * r76298;
        float r76300 = 2.0;
        float r76301 = 6.0;
        float r76302 = r76301 * r76297;
        float r76303 = r76300 - r76302;
        float r76304 = sqrt(r76303);
        float r76305 = r76299 * r76304;
        float r76306 = r76291 / r76305;
        return r76306;
}

double f_id(float v) {
        double r76307 = 4.0;
        double r76308 = 3.0;
        double r76309 = atan2(1.0, 0.0);
        double r76310 = r76308 * r76309;
        double r76311 = 1.0;
        double r76312 = v;
        double r76313 = r76312 * r76312;
        double r76314 = r76311 - r76313;
        double r76315 = r76310 * r76314;
        double r76316 = 2.0;
        double r76317 = 6.0;
        double r76318 = r76317 * r76313;
        double r76319 = r76316 - r76318;
        double r76320 = sqrt(r76319);
        double r76321 = r76315 * r76320;
        double r76322 = r76307 / r76321;
        return r76322;
}

double f_il(float v) {
        long double r76323 = 4.0;
        long double r76324 = 3.0;
        long double r76325 = atan2(1.0, 0.0);
        long double r76326 = r76324 * r76325;
        long double r76327 = 1.0;
        long double r76328 = v;
        long double r76329 = r76328 * r76328;
        long double r76330 = r76327 - r76329;
        long double r76331 = r76326 * r76330;
        long double r76332 = 2.0;
        long double r76333 = 6.0;
        long double r76334 = r76333 * r76329;
        long double r76335 = r76332 - r76334;
        long double r76336 = sqrt(r76335);
        long double r76337 = r76331 * r76336;
        long double r76338 = r76323 / r76337;
        return r76338;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float v) {
        float r76339 = 4.0;
        float r76340 = 2.0;
        float r76341 = 6.0;
        float r76342 = v;
        float r76343 = r76342 * r76342;
        float r76344 = r76341 * r76343;
        float r76345 = r76340 - r76344;
        float r76346 = sqrt(r76345);
        float r76347 = 3.0;
        float r76348 = r76346 * r76347;
        float r76349 = atan2(1.0, 0.0);
        float r76350 = r76348 * r76349;
        float r76351 = sqrt(r76346);
        float r76352 = r76347 * r76349;
        float r76353 = sqrt(r76352);
        float r76354 = r76353 * r76342;
        float r76355 = r76351 * r76354;
        float r76356 = r76355 * r76355;
        float r76357 = r76350 - r76356;
        float r76358 = r76339 / r76357;
        return r76358;
}

double f_od(float v) {
        double r76359 = 4.0;
        double r76360 = 2.0;
        double r76361 = 6.0;
        double r76362 = v;
        double r76363 = r76362 * r76362;
        double r76364 = r76361 * r76363;
        double r76365 = r76360 - r76364;
        double r76366 = sqrt(r76365);
        double r76367 = 3.0;
        double r76368 = r76366 * r76367;
        double r76369 = atan2(1.0, 0.0);
        double r76370 = r76368 * r76369;
        double r76371 = sqrt(r76366);
        double r76372 = r76367 * r76369;
        double r76373 = sqrt(r76372);
        double r76374 = r76373 * r76362;
        double r76375 = r76371 * r76374;
        double r76376 = r76375 * r76375;
        double r76377 = r76370 - r76376;
        double r76378 = r76359 / r76377;
        return r76378;
}

double f_ol(float v) {
        long double r76379 = 4.0;
        long double r76380 = 2.0;
        long double r76381 = 6.0;
        long double r76382 = v;
        long double r76383 = r76382 * r76382;
        long double r76384 = r76381 * r76383;
        long double r76385 = r76380 - r76384;
        long double r76386 = sqrt(r76385);
        long double r76387 = 3.0;
        long double r76388 = r76386 * r76387;
        long double r76389 = atan2(1.0, 0.0);
        long double r76390 = r76388 * r76389;
        long double r76391 = sqrt(r76386);
        long double r76392 = r76387 * r76389;
        long double r76393 = sqrt(r76392);
        long double r76394 = r76393 * r76382;
        long double r76395 = r76391 * r76394;
        long double r76396 = r76395 * r76395;
        long double r76397 = r76390 - r76396;
        long double r76398 = r76379 / r76397;
        return r76398;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r76399, r76400, r76401, r76402, r76403, r76404, r76405, r76406, r76407, r76408, r76409, r76410, r76411, r76412, r76413, r76414;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r76399);
        mpfr_init(r76400);
        mpfr_init(r76401);
        mpfr_init(r76402);
        mpfr_init(r76403);
        mpfr_init(r76404);
        mpfr_init(r76405);
        mpfr_init(r76406);
        mpfr_init(r76407);
        mpfr_init(r76408);
        mpfr_init(r76409);
        mpfr_init(r76410);
        mpfr_init(r76411);
        mpfr_init(r76412);
        mpfr_init(r76413);
        mpfr_init(r76414);
}

double f_im(float v) {
        mpfr_init_set_str(r76399, "4", 10, MPFR_RNDN);
        mpfr_init_set_str(r76400, "3", 10, MPFR_RNDN);
        mpfr_const_pi(r76401, MPFR_RNDN);
        mpfr_mul(r76402, r76400, r76401, MPFR_RNDN);
        mpfr_init_set_str(r76403, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r76404, v, MPFR_RNDN);
        mpfr_mul(r76405, r76404, r76404, MPFR_RNDN);
        mpfr_sub(r76406, r76403, r76405, MPFR_RNDN);
        mpfr_mul(r76407, r76402, r76406, MPFR_RNDN);
        mpfr_init_set_str(r76408, "2", 10, MPFR_RNDN);
        mpfr_init_set_str(r76409, "6", 10, MPFR_RNDN);
        mpfr_mul(r76410, r76409, r76405, MPFR_RNDN);
        mpfr_sub(r76411, r76408, r76410, MPFR_RNDN);
        mpfr_sqrt(r76412, r76411, MPFR_RNDN);
        mpfr_mul(r76413, r76407, r76412, MPFR_RNDN);
        mpfr_div(r76414, r76399, r76413, MPFR_RNDN);
        return mpfr_get_d(r76414, MPFR_RNDN);
}

