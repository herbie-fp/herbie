#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Hyperbolic arc-(co)secant */

double f_if(float x) {
        float r77000 = 1.0;
        float r77001 = x;
        float r77002 = r77000 / r77001;
        float r77003 = r77001 * r77001;
        float r77004 = r77000 - r77003;
        float r77005 = sqrt(r77004);
        float r77006 = r77005 / r77001;
        float r77007 = r77002 + r77006;
        float r77008 = log(r77007);
        return r77008;
}

double f_id(float x) {
        double r77009 = 1.0;
        double r77010 = x;
        double r77011 = r77009 / r77010;
        double r77012 = r77010 * r77010;
        double r77013 = r77009 - r77012;
        double r77014 = sqrt(r77013);
        double r77015 = r77014 / r77010;
        double r77016 = r77011 + r77015;
        double r77017 = log(r77016);
        return r77017;
}

double f_il(float x) {
        long double r77018 = 1.0;
        long double r77019 = x;
        long double r77020 = r77018 / r77019;
        long double r77021 = r77019 * r77019;
        long double r77022 = r77018 - r77021;
        long double r77023 = sqrt(r77022);
        long double r77024 = r77023 / r77019;
        long double r77025 = r77020 + r77024;
        long double r77026 = log(r77025);
        return r77026;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r77027 = 1.0;
        float r77028 = x;
        float r77029 = r77027 / r77028;
        float r77030 = r77028 * r77028;
        float r77031 = r77027 - r77030;
        float r77032 = sqrt(r77031);
        float r77033 = exp(r77032);
        float r77034 = log(r77033);
        float r77035 = 1.0/r77028;
        float r77036 = r77034 * r77035;
        float r77037 = r77029 + r77036;
        float r77038 = log(r77037);
        return r77038;
}

double f_od(float x) {
        double r77039 = 1.0;
        double r77040 = x;
        double r77041 = r77039 / r77040;
        double r77042 = r77040 * r77040;
        double r77043 = r77039 - r77042;
        double r77044 = sqrt(r77043);
        double r77045 = exp(r77044);
        double r77046 = log(r77045);
        double r77047 = 1.0/r77040;
        double r77048 = r77046 * r77047;
        double r77049 = r77041 + r77048;
        double r77050 = log(r77049);
        return r77050;
}

double f_ol(float x) {
        long double r77051 = 1.0;
        long double r77052 = x;
        long double r77053 = r77051 / r77052;
        long double r77054 = r77052 * r77052;
        long double r77055 = r77051 - r77054;
        long double r77056 = sqrt(r77055);
        long double r77057 = exp(r77056);
        long double r77058 = log(r77057);
        long double r77059 = 1.0/r77052;
        long double r77060 = r77058 * r77059;
        long double r77061 = r77053 + r77060;
        long double r77062 = log(r77061);
        return r77062;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r77063, r77064, r77065, r77066, r77067, r77068, r77069, r77070, r77071;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r77063);
        mpfr_init(r77064);
        mpfr_init(r77065);
        mpfr_init(r77066);
        mpfr_init(r77067);
        mpfr_init(r77068);
        mpfr_init(r77069);
        mpfr_init(r77070);
        mpfr_init(r77071);
}

double f_im(float x) {
        mpfr_init_set_str(r77063, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r77064, x, MPFR_RNDN);
        mpfr_div(r77065, r77063, r77064, MPFR_RNDN);
        mpfr_mul(r77066, r77064, r77064, MPFR_RNDN);
        mpfr_sub(r77067, r77063, r77066, MPFR_RNDN);
        mpfr_sqrt(r77068, r77067, MPFR_RNDN);
        mpfr_div(r77069, r77068, r77064, MPFR_RNDN);
        mpfr_add(r77070, r77065, r77069, MPFR_RNDN);
        mpfr_log(r77071, r77070, MPFR_RNDN);
        return mpfr_get_d(r77071, MPFR_RNDN);
}

