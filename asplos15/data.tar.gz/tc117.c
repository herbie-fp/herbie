#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.log/1 on complex, imaginary part */

double f_if(float re, float im) {
        float r85280 = im;
        float r85281 = re;
        float r85282 = atan2(r85280, r85281);
        return r85282;
}

double f_id(float re, float im) {
        double r85283 = im;
        double r85284 = re;
        double r85285 = atan2(r85283, r85284);
        return r85285;
}

double f_il(float re, float im) {
        long double r85286 = im;
        long double r85287 = re;
        long double r85288 = atan2(r85286, r85287);
        return r85288;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r85289 = im;
        float r85290 = re;
        float r85291 = atan2(r85289, r85290);
        return r85291;
}

double f_od(float re, float im) {
        double r85292 = im;
        double r85293 = re;
        double r85294 = atan2(r85292, r85293);
        return r85294;
}

double f_ol(float re, float im) {
        long double r85295 = im;
        long double r85296 = re;
        long double r85297 = atan2(r85295, r85296);
        return r85297;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r85298, r85299, r85300;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r85298);
        mpfr_init(r85299);
        mpfr_init(r85300);
}

double f_im(float re, float im) {
        mpfr_set_flt(r85298, im, MPFR_RNDN);
        mpfr_set_flt(r85299, re, MPFR_RNDN);
        mpfr_atan2(r85300, r85298, r85299, MPFR_RNDN);
        return mpfr_get_d(r85300, MPFR_RNDN);
}

