#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.sin on complex, imaginary part */

double f_if(float re, float im) {
        float r85787 = 0.5;
        float r85788 = re;
        float r85789 = cos(r85788);
        float r85790 = r85787 * r85789;
        float r85791 = 0.0;
        float r85792 = im;
        float r85793 = r85791 - r85792;
        float r85794 = exp(r85793);
        float r85795 = exp(r85792);
        float r85796 = r85794 - r85795;
        float r85797 = r85790 * r85796;
        return r85797;
}

double f_id(float re, float im) {
        double r85798 = 0.5;
        double r85799 = re;
        double r85800 = cos(r85799);
        double r85801 = r85798 * r85800;
        double r85802 = 0.0;
        double r85803 = im;
        double r85804 = r85802 - r85803;
        double r85805 = exp(r85804);
        double r85806 = exp(r85803);
        double r85807 = r85805 - r85806;
        double r85808 = r85801 * r85807;
        return r85808;
}

double f_il(float re, float im) {
        long double r85809 = 0.5;
        long double r85810 = re;
        long double r85811 = cos(r85810);
        long double r85812 = r85809 * r85811;
        long double r85813 = 0.0;
        long double r85814 = im;
        long double r85815 = r85813 - r85814;
        long double r85816 = exp(r85815);
        long double r85817 = exp(r85814);
        long double r85818 = r85816 - r85817;
        long double r85819 = r85812 * r85818;
        return r85819;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r85820 = re;
        float r85821 = -5436243595618424.0;
        bool r85822 = r85820 < r85821;
        float r85823 = 1.0;
        float r85824 = im;
        float r85825 = exp(r85824);
        float r85826 = 0.5;
        float r85827 = cos(r85820);
        float r85828 = r85826 * r85827;
        float r85829 = r85825 / r85828;
        float r85830 = r85829 * r85829;
        float r85831 = r85823 / r85830;
        float r85832 = r85828 * r85825;
        float r85833 = r85832 * r85832;
        float r85834 = r85831 - r85833;
        float r85835 = r85823 / r85829;
        float r85836 = r85835 + r85832;
        float r85837 = r85834 / r85836;
        float r85838 = 27718.969391197512;
        bool r85839 = r85820 < r85838;
        float r85840 = -0.00950010741414906;
        bool r85841 = r85820 < r85840;
        float r85842 = -2.502603868978876e-146;
        bool r85843 = r85824 < r85842;
        float r85844 = r85835 * r85835;
        float r85845 = log(r85844);
        float r85846 = exp(r85845);
        float r85847 = exp(r85823);
        float r85848 = log(r85833);
        float r85849 = pow(r85847, r85848);
        float r85850 = r85846 - r85849;
        float r85851 = r85844 * r85844;
        float r85852 = r85833 * r85833;
        float r85853 = r85851 - r85852;
        float r85854 = r85844 + r85833;
        float r85855 = r85853 / r85854;
        float r85856 = r85835 - r85832;
        float r85857 = r85855 / r85856;
        float r85858 = r85850 / r85857;
        float r85859 = sqrt(r85836);
        float r85860 = r85859 * r85859;
        float r85861 = r85850 / r85860;
        float r85862 = r85843 ? r85858 : r85861;
        float r85863 = -0.00011639902259503462;
        bool r85864 = r85824 < r85863;
        float r85865 = r85831 - r85849;
        float r85866 = r85828 / r85825;
        float r85867 = exp(r85866);
        float r85868 = exp(r85832);
        float r85869 = r85867 * r85868;
        float r85870 = log(r85869);
        float r85871 = sqrt(r85870);
        float r85872 = r85871 * r85871;
        float r85873 = r85865 / r85872;
        float r85874 = 8.33534531056904e-163;
        bool r85875 = r85824 < r85874;
        float r85876 = r85823 * r85848;
        float r85877 = exp(r85876);
        float r85878 = exp(r85877);
        float r85879 = log(r85878);
        float r85880 = r85831 - r85879;
        float r85881 = r85880 / r85836;
        float r85882 = r85875 ? r85881 : r85873;
        float r85883 = r85864 ? r85873 : r85882;
        float r85884 = r85841 ? r85862 : r85883;
        float r85885 = 107625651.69608423;
        bool r85886 = r85820 < r85885;
        float r85887 = log(r85852);
        float r85888 = pow(r85847, r85887);
        float r85889 = r85851 - r85888;
        float r85890 = r85844 - r85833;
        float r85891 = r85853 / r85890;
        float r85892 = r85889 / r85891;
        float r85893 = r85892 / r85836;
        float r85894 = 469621811100.1188;
        bool r85895 = r85820 < r85894;
        float r85896 = r85830 * r85830;
        float r85897 = r85823 / r85896;
        float r85898 = exp(r85887);
        float r85899 = r85897 - r85898;
        float r85900 = r85899 / r85891;
        float r85901 = r85900 / r85836;
        float r85902 = r85851 - r85898;
        float r85903 = log(r85847);
        float r85904 = r85854 * r85903;
        float r85905 = r85902 / r85904;
        float r85906 = r85905 / r85836;
        float r85907 = r85895 ? r85901 : r85906;
        float r85908 = r85886 ? r85893 : r85907;
        float r85909 = r85839 ? r85884 : r85908;
        float r85910 = r85822 ? r85837 : r85909;
        return r85910;
}

double f_od(float re, float im) {
        double r85911 = re;
        double r85912 = -5436243595618424.0;
        bool r85913 = r85911 < r85912;
        double r85914 = 1.0;
        double r85915 = im;
        double r85916 = exp(r85915);
        double r85917 = 0.5;
        double r85918 = cos(r85911);
        double r85919 = r85917 * r85918;
        double r85920 = r85916 / r85919;
        double r85921 = r85920 * r85920;
        double r85922 = r85914 / r85921;
        double r85923 = r85919 * r85916;
        double r85924 = r85923 * r85923;
        double r85925 = r85922 - r85924;
        double r85926 = r85914 / r85920;
        double r85927 = r85926 + r85923;
        double r85928 = r85925 / r85927;
        double r85929 = 27718.969391197512;
        bool r85930 = r85911 < r85929;
        double r85931 = -0.00950010741414906;
        bool r85932 = r85911 < r85931;
        double r85933 = -2.502603868978876e-146;
        bool r85934 = r85915 < r85933;
        double r85935 = r85926 * r85926;
        double r85936 = log(r85935);
        double r85937 = exp(r85936);
        double r85938 = exp(r85914);
        double r85939 = log(r85924);
        double r85940 = pow(r85938, r85939);
        double r85941 = r85937 - r85940;
        double r85942 = r85935 * r85935;
        double r85943 = r85924 * r85924;
        double r85944 = r85942 - r85943;
        double r85945 = r85935 + r85924;
        double r85946 = r85944 / r85945;
        double r85947 = r85926 - r85923;
        double r85948 = r85946 / r85947;
        double r85949 = r85941 / r85948;
        double r85950 = sqrt(r85927);
        double r85951 = r85950 * r85950;
        double r85952 = r85941 / r85951;
        double r85953 = r85934 ? r85949 : r85952;
        double r85954 = -0.00011639902259503462;
        bool r85955 = r85915 < r85954;
        double r85956 = r85922 - r85940;
        double r85957 = r85919 / r85916;
        double r85958 = exp(r85957);
        double r85959 = exp(r85923);
        double r85960 = r85958 * r85959;
        double r85961 = log(r85960);
        double r85962 = sqrt(r85961);
        double r85963 = r85962 * r85962;
        double r85964 = r85956 / r85963;
        double r85965 = 8.33534531056904e-163;
        bool r85966 = r85915 < r85965;
        double r85967 = r85914 * r85939;
        double r85968 = exp(r85967);
        double r85969 = exp(r85968);
        double r85970 = log(r85969);
        double r85971 = r85922 - r85970;
        double r85972 = r85971 / r85927;
        double r85973 = r85966 ? r85972 : r85964;
        double r85974 = r85955 ? r85964 : r85973;
        double r85975 = r85932 ? r85953 : r85974;
        double r85976 = 107625651.69608423;
        bool r85977 = r85911 < r85976;
        double r85978 = log(r85943);
        double r85979 = pow(r85938, r85978);
        double r85980 = r85942 - r85979;
        double r85981 = r85935 - r85924;
        double r85982 = r85944 / r85981;
        double r85983 = r85980 / r85982;
        double r85984 = r85983 / r85927;
        double r85985 = 469621811100.1188;
        bool r85986 = r85911 < r85985;
        double r85987 = r85921 * r85921;
        double r85988 = r85914 / r85987;
        double r85989 = exp(r85978);
        double r85990 = r85988 - r85989;
        double r85991 = r85990 / r85982;
        double r85992 = r85991 / r85927;
        double r85993 = r85942 - r85989;
        double r85994 = log(r85938);
        double r85995 = r85945 * r85994;
        double r85996 = r85993 / r85995;
        double r85997 = r85996 / r85927;
        double r85998 = r85986 ? r85992 : r85997;
        double r85999 = r85977 ? r85984 : r85998;
        double r86000 = r85930 ? r85975 : r85999;
        double r86001 = r85913 ? r85928 : r86000;
        return r86001;
}

double f_ol(float re, float im) {
        long double r86002 = re;
        long double r86003 = -5436243595618424.0;
        bool r86004 = r86002 < r86003;
        long double r86005 = 1.0;
        long double r86006 = im;
        long double r86007 = exp(r86006);
        long double r86008 = 0.5;
        long double r86009 = cos(r86002);
        long double r86010 = r86008 * r86009;
        long double r86011 = r86007 / r86010;
        long double r86012 = r86011 * r86011;
        long double r86013 = r86005 / r86012;
        long double r86014 = r86010 * r86007;
        long double r86015 = r86014 * r86014;
        long double r86016 = r86013 - r86015;
        long double r86017 = r86005 / r86011;
        long double r86018 = r86017 + r86014;
        long double r86019 = r86016 / r86018;
        long double r86020 = 27718.969391197512;
        bool r86021 = r86002 < r86020;
        long double r86022 = -0.00950010741414906;
        bool r86023 = r86002 < r86022;
        long double r86024 = -2.502603868978876e-146;
        bool r86025 = r86006 < r86024;
        long double r86026 = r86017 * r86017;
        long double r86027 = log(r86026);
        long double r86028 = exp(r86027);
        long double r86029 = exp(r86005);
        long double r86030 = log(r86015);
        long double r86031 = pow(r86029, r86030);
        long double r86032 = r86028 - r86031;
        long double r86033 = r86026 * r86026;
        long double r86034 = r86015 * r86015;
        long double r86035 = r86033 - r86034;
        long double r86036 = r86026 + r86015;
        long double r86037 = r86035 / r86036;
        long double r86038 = r86017 - r86014;
        long double r86039 = r86037 / r86038;
        long double r86040 = r86032 / r86039;
        long double r86041 = sqrt(r86018);
        long double r86042 = r86041 * r86041;
        long double r86043 = r86032 / r86042;
        long double r86044 = r86025 ? r86040 : r86043;
        long double r86045 = -0.00011639902259503462;
        bool r86046 = r86006 < r86045;
        long double r86047 = r86013 - r86031;
        long double r86048 = r86010 / r86007;
        long double r86049 = exp(r86048);
        long double r86050 = exp(r86014);
        long double r86051 = r86049 * r86050;
        long double r86052 = log(r86051);
        long double r86053 = sqrt(r86052);
        long double r86054 = r86053 * r86053;
        long double r86055 = r86047 / r86054;
        long double r86056 = 8.33534531056904e-163;
        bool r86057 = r86006 < r86056;
        long double r86058 = r86005 * r86030;
        long double r86059 = exp(r86058);
        long double r86060 = exp(r86059);
        long double r86061 = log(r86060);
        long double r86062 = r86013 - r86061;
        long double r86063 = r86062 / r86018;
        long double r86064 = r86057 ? r86063 : r86055;
        long double r86065 = r86046 ? r86055 : r86064;
        long double r86066 = r86023 ? r86044 : r86065;
        long double r86067 = 107625651.69608423;
        bool r86068 = r86002 < r86067;
        long double r86069 = log(r86034);
        long double r86070 = pow(r86029, r86069);
        long double r86071 = r86033 - r86070;
        long double r86072 = r86026 - r86015;
        long double r86073 = r86035 / r86072;
        long double r86074 = r86071 / r86073;
        long double r86075 = r86074 / r86018;
        long double r86076 = 469621811100.1188;
        bool r86077 = r86002 < r86076;
        long double r86078 = r86012 * r86012;
        long double r86079 = r86005 / r86078;
        long double r86080 = exp(r86069);
        long double r86081 = r86079 - r86080;
        long double r86082 = r86081 / r86073;
        long double r86083 = r86082 / r86018;
        long double r86084 = r86033 - r86080;
        long double r86085 = log(r86029);
        long double r86086 = r86036 * r86085;
        long double r86087 = r86084 / r86086;
        long double r86088 = r86087 / r86018;
        long double r86089 = r86077 ? r86083 : r86088;
        long double r86090 = r86068 ? r86075 : r86089;
        long double r86091 = r86021 ? r86066 : r86090;
        long double r86092 = r86004 ? r86019 : r86091;
        return r86092;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r86093, r86094, r86095, r86096, r86097, r86098, r86099, r86100, r86101, r86102, r86103;

void setup_mpfr() {
        mpfr_set_default_prec(200);
        mpfr_init(r86093);
        mpfr_init(r86094);
        mpfr_init(r86095);
        mpfr_init(r86096);
        mpfr_init(r86097);
        mpfr_init(r86098);
        mpfr_init(r86099);
        mpfr_init(r86100);
        mpfr_init(r86101);
        mpfr_init(r86102);
        mpfr_init(r86103);
}

double f_im(float re, float im) {
        mpfr_init_set_str(r86093, "0.5", 10, MPFR_RNDN);
        mpfr_set_flt(r86094, re, MPFR_RNDN);
        mpfr_cos(r86095, r86094, MPFR_RNDN);
        mpfr_mul(r86096, r86093, r86095, MPFR_RNDN);
        mpfr_init_set_str(r86097, "0", 10, MPFR_RNDN);
        mpfr_set_flt(r86098, im, MPFR_RNDN);
        mpfr_sub(r86099, r86097, r86098, MPFR_RNDN);
        mpfr_exp(r86100, r86099, MPFR_RNDN);
        mpfr_exp(r86101, r86098, MPFR_RNDN);
        mpfr_sub(r86102, r86100, r86101, MPFR_RNDN);
        mpfr_mul(r86103, r86096, r86102, MPFR_RNDN);
        return mpfr_get_d(r86103, MPFR_RNDN);
}

