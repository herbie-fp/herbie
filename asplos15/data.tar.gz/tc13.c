#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* FastMath test3 */

double f_if(float d1, float d2, float d3) {
        float r72900 = d1;
        float r72901 = 3.0;
        float r72902 = r72900 * r72901;
        float r72903 = d2;
        float r72904 = r72900 * r72903;
        float r72905 = r72902 + r72904;
        float r72906 = d3;
        float r72907 = r72900 * r72906;
        float r72908 = r72905 + r72907;
        return r72908;
}

double f_id(float d1, float d2, float d3) {
        double r72909 = d1;
        double r72910 = 3.0;
        double r72911 = r72909 * r72910;
        double r72912 = d2;
        double r72913 = r72909 * r72912;
        double r72914 = r72911 + r72913;
        double r72915 = d3;
        double r72916 = r72909 * r72915;
        double r72917 = r72914 + r72916;
        return r72917;
}

double f_il(float d1, float d2, float d3) {
        long double r72918 = d1;
        long double r72919 = 3.0;
        long double r72920 = r72918 * r72919;
        long double r72921 = d2;
        long double r72922 = r72918 * r72921;
        long double r72923 = r72920 + r72922;
        long double r72924 = d3;
        long double r72925 = r72918 * r72924;
        long double r72926 = r72923 + r72925;
        return r72926;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float d1, float d2, float d3) {
        float r72927 = d1;
        float r72928 = 3.0;
        float r72929 = d2;
        float r72930 = r72928 + r72929;
        float r72931 = d3;
        float r72932 = r72930 + r72931;
        float r72933 = r72927 * r72932;
        return r72933;
}

double f_od(float d1, float d2, float d3) {
        double r72934 = d1;
        double r72935 = 3.0;
        double r72936 = d2;
        double r72937 = r72935 + r72936;
        double r72938 = d3;
        double r72939 = r72937 + r72938;
        double r72940 = r72934 * r72939;
        return r72940;
}

double f_ol(float d1, float d2, float d3) {
        long double r72941 = d1;
        long double r72942 = 3.0;
        long double r72943 = d2;
        long double r72944 = r72942 + r72943;
        long double r72945 = d3;
        long double r72946 = r72944 + r72945;
        long double r72947 = r72941 * r72946;
        return r72947;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r72948, r72949, r72950, r72951, r72952, r72953, r72954, r72955, r72956;

void setup_mpfr() {
        mpfr_set_default_prec(136);
        mpfr_init(r72948);
        mpfr_init(r72949);
        mpfr_init(r72950);
        mpfr_init(r72951);
        mpfr_init(r72952);
        mpfr_init(r72953);
        mpfr_init(r72954);
        mpfr_init(r72955);
        mpfr_init(r72956);
}

double f_im(float d1, float d2, float d3) {
        mpfr_set_flt(r72948, d1, MPFR_RNDN);
        mpfr_init_set_str(r72949, "3", 10, MPFR_RNDN);
        mpfr_mul(r72950, r72948, r72949, MPFR_RNDN);
        mpfr_set_flt(r72951, d2, MPFR_RNDN);
        mpfr_mul(r72952, r72948, r72951, MPFR_RNDN);
        mpfr_add(r72953, r72950, r72952, MPFR_RNDN);
        mpfr_set_flt(r72954, d3, MPFR_RNDN);
        mpfr_mul(r72955, r72948, r72954, MPFR_RNDN);
        mpfr_add(r72956, r72953, r72955, MPFR_RNDN);
        return mpfr_get_d(r72956, MPFR_RNDN);
}

