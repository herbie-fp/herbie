#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Henrywood and Agarwal, Equation (13) */

double f_if(float c0, float w, float h, float D, float d, float M) {
        float r76618 = c0;
        float r76619 = 2.0;
        float r76620 = w;
        float r76621 = r76619 * r76620;
        float r76622 = r76618 / r76621;
        float r76623 = d;
        float r76624 = r76623 * r76623;
        float r76625 = r76618 * r76624;
        float r76626 = h;
        float r76627 = r76620 * r76626;
        float r76628 = D;
        float r76629 = r76628 * r76628;
        float r76630 = r76627 * r76629;
        float r76631 = r76625 / r76630;
        float r76632 = r76631 * r76631;
        float r76633 = M;
        float r76634 = r76633 * r76633;
        float r76635 = r76632 - r76634;
        float r76636 = sqrt(r76635);
        float r76637 = r76631 + r76636;
        float r76638 = r76622 * r76637;
        return r76638;
}

double f_id(float c0, float w, float h, float D, float d, float M) {
        double r76639 = c0;
        double r76640 = 2.0;
        double r76641 = w;
        double r76642 = r76640 * r76641;
        double r76643 = r76639 / r76642;
        double r76644 = d;
        double r76645 = r76644 * r76644;
        double r76646 = r76639 * r76645;
        double r76647 = h;
        double r76648 = r76641 * r76647;
        double r76649 = D;
        double r76650 = r76649 * r76649;
        double r76651 = r76648 * r76650;
        double r76652 = r76646 / r76651;
        double r76653 = r76652 * r76652;
        double r76654 = M;
        double r76655 = r76654 * r76654;
        double r76656 = r76653 - r76655;
        double r76657 = sqrt(r76656);
        double r76658 = r76652 + r76657;
        double r76659 = r76643 * r76658;
        return r76659;
}

double f_il(float c0, float w, float h, float D, float d, float M) {
        long double r76660 = c0;
        long double r76661 = 2.0;
        long double r76662 = w;
        long double r76663 = r76661 * r76662;
        long double r76664 = r76660 / r76663;
        long double r76665 = d;
        long double r76666 = r76665 * r76665;
        long double r76667 = r76660 * r76666;
        long double r76668 = h;
        long double r76669 = r76662 * r76668;
        long double r76670 = D;
        long double r76671 = r76670 * r76670;
        long double r76672 = r76669 * r76671;
        long double r76673 = r76667 / r76672;
        long double r76674 = r76673 * r76673;
        long double r76675 = M;
        long double r76676 = r76675 * r76675;
        long double r76677 = r76674 - r76676;
        long double r76678 = sqrt(r76677);
        long double r76679 = r76673 + r76678;
        long double r76680 = r76664 * r76679;
        return r76680;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float c0, float w, float h, float D, float d, float M) {
        float r76681 = c0;
        float r76682 = 3.36105961546752e-29;
        bool r76683 = r76681 < r76682;
        float r76684 = 2.0;
        float r76685 = w;
        float r76686 = r76684 * r76685;
        float r76687 = r76681 / r76686;
        float r76688 = d;
        float r76689 = r76688 * r76688;
        float r76690 = r76681 * r76689;
        float r76691 = h;
        float r76692 = r76685 * r76691;
        float r76693 = D;
        float r76694 = r76693 * r76693;
        float r76695 = r76692 * r76694;
        float r76696 = r76690 / r76695;
        float r76697 = r76681 * r76688;
        float r76698 = r76697 * r76688;
        float r76699 = r76698 / r76695;
        float r76700 = r76699 * r76699;
        float r76701 = M;
        float r76702 = r76701 * r76701;
        float r76703 = r76700 - r76702;
        float r76704 = sqrt(r76703);
        float r76705 = r76696 + r76704;
        float r76706 = r76687 * r76705;
        float r76707 = 1.0;
        float r76708 = r76686 / r76681;
        float r76709 = r76707 / r76708;
        float r76710 = 1.0/r76695;
        float r76711 = r76690 * r76710;
        float r76712 = r76696 * r76696;
        float r76713 = r76712 - r76702;
        float r76714 = sqrt(r76713);
        float r76715 = r76711 + r76714;
        float r76716 = r76709 * r76715;
        float r76717 = r76683 ? r76706 : r76716;
        return r76717;
}

double f_od(float c0, float w, float h, float D, float d, float M) {
        double r76718 = c0;
        double r76719 = 3.36105961546752e-29;
        bool r76720 = r76718 < r76719;
        double r76721 = 2.0;
        double r76722 = w;
        double r76723 = r76721 * r76722;
        double r76724 = r76718 / r76723;
        double r76725 = d;
        double r76726 = r76725 * r76725;
        double r76727 = r76718 * r76726;
        double r76728 = h;
        double r76729 = r76722 * r76728;
        double r76730 = D;
        double r76731 = r76730 * r76730;
        double r76732 = r76729 * r76731;
        double r76733 = r76727 / r76732;
        double r76734 = r76718 * r76725;
        double r76735 = r76734 * r76725;
        double r76736 = r76735 / r76732;
        double r76737 = r76736 * r76736;
        double r76738 = M;
        double r76739 = r76738 * r76738;
        double r76740 = r76737 - r76739;
        double r76741 = sqrt(r76740);
        double r76742 = r76733 + r76741;
        double r76743 = r76724 * r76742;
        double r76744 = 1.0;
        double r76745 = r76723 / r76718;
        double r76746 = r76744 / r76745;
        double r76747 = 1.0/r76732;
        double r76748 = r76727 * r76747;
        double r76749 = r76733 * r76733;
        double r76750 = r76749 - r76739;
        double r76751 = sqrt(r76750);
        double r76752 = r76748 + r76751;
        double r76753 = r76746 * r76752;
        double r76754 = r76720 ? r76743 : r76753;
        return r76754;
}

double f_ol(float c0, float w, float h, float D, float d, float M) {
        long double r76755 = c0;
        long double r76756 = 3.36105961546752e-29;
        bool r76757 = r76755 < r76756;
        long double r76758 = 2.0;
        long double r76759 = w;
        long double r76760 = r76758 * r76759;
        long double r76761 = r76755 / r76760;
        long double r76762 = d;
        long double r76763 = r76762 * r76762;
        long double r76764 = r76755 * r76763;
        long double r76765 = h;
        long double r76766 = r76759 * r76765;
        long double r76767 = D;
        long double r76768 = r76767 * r76767;
        long double r76769 = r76766 * r76768;
        long double r76770 = r76764 / r76769;
        long double r76771 = r76755 * r76762;
        long double r76772 = r76771 * r76762;
        long double r76773 = r76772 / r76769;
        long double r76774 = r76773 * r76773;
        long double r76775 = M;
        long double r76776 = r76775 * r76775;
        long double r76777 = r76774 - r76776;
        long double r76778 = sqrt(r76777);
        long double r76779 = r76770 + r76778;
        long double r76780 = r76761 * r76779;
        long double r76781 = 1.0;
        long double r76782 = r76760 / r76755;
        long double r76783 = r76781 / r76782;
        long double r76784 = 1.0/r76769;
        long double r76785 = r76764 * r76784;
        long double r76786 = r76770 * r76770;
        long double r76787 = r76786 - r76776;
        long double r76788 = sqrt(r76787);
        long double r76789 = r76785 + r76788;
        long double r76790 = r76783 * r76789;
        long double r76791 = r76757 ? r76780 : r76790;
        return r76791;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r76792, r76793, r76794, r76795, r76796, r76797, r76798, r76799, r76800, r76801, r76802, r76803, r76804, r76805, r76806, r76807, r76808, r76809, r76810, r76811, r76812;

void setup_mpfr() {
        mpfr_set_default_prec(1448);
        mpfr_init(r76792);
        mpfr_init(r76793);
        mpfr_init(r76794);
        mpfr_init(r76795);
        mpfr_init(r76796);
        mpfr_init(r76797);
        mpfr_init(r76798);
        mpfr_init(r76799);
        mpfr_init(r76800);
        mpfr_init(r76801);
        mpfr_init(r76802);
        mpfr_init(r76803);
        mpfr_init(r76804);
        mpfr_init(r76805);
        mpfr_init(r76806);
        mpfr_init(r76807);
        mpfr_init(r76808);
        mpfr_init(r76809);
        mpfr_init(r76810);
        mpfr_init(r76811);
        mpfr_init(r76812);
}

double f_im(float c0, float w, float h, float D, float d, float M) {
        mpfr_set_flt(r76792, c0, MPFR_RNDN);
        mpfr_init_set_str(r76793, "2", 10, MPFR_RNDN);
        mpfr_set_flt(r76794, w, MPFR_RNDN);
        mpfr_mul(r76795, r76793, r76794, MPFR_RNDN);
        mpfr_div(r76796, r76792, r76795, MPFR_RNDN);
        mpfr_set_flt(r76797, d, MPFR_RNDN);
        mpfr_mul(r76798, r76797, r76797, MPFR_RNDN);
        mpfr_mul(r76799, r76792, r76798, MPFR_RNDN);
        mpfr_set_flt(r76800, h, MPFR_RNDN);
        mpfr_mul(r76801, r76794, r76800, MPFR_RNDN);
        mpfr_set_flt(r76802, D, MPFR_RNDN);
        mpfr_mul(r76803, r76802, r76802, MPFR_RNDN);
        mpfr_mul(r76804, r76801, r76803, MPFR_RNDN);
        mpfr_div(r76805, r76799, r76804, MPFR_RNDN);
        mpfr_mul(r76806, r76805, r76805, MPFR_RNDN);
        mpfr_set_flt(r76807, M, MPFR_RNDN);
        mpfr_mul(r76808, r76807, r76807, MPFR_RNDN);
        mpfr_sub(r76809, r76806, r76808, MPFR_RNDN);
        mpfr_sqrt(r76810, r76809, MPFR_RNDN);
        mpfr_add(r76811, r76805, r76810, MPFR_RNDN);
        mpfr_mul(r76812, r76796, r76811, MPFR_RNDN);
        return mpfr_get_d(r76812, MPFR_RNDN);
}

