#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Bouland and Aaronson, Equation (24) */

double f_if(float a, float b) {
        float r75119 = a;
        float r75120 = r75119 * r75119;
        float r75121 = b;
        float r75122 = r75121 * r75121;
        float r75123 = r75120 + r75122;
        float r75124 = r75123 * r75123;
        float r75125 = 4.0;
        float r75126 = 1.0;
        float r75127 = r75126 - r75119;
        float r75128 = r75120 * r75127;
        float r75129 = 3.0;
        float r75130 = r75129 + r75119;
        float r75131 = r75122 * r75130;
        float r75132 = r75128 + r75131;
        float r75133 = r75125 * r75132;
        float r75134 = r75124 + r75133;
        float r75135 = r75134 - r75126;
        return r75135;
}

double f_id(float a, float b) {
        double r75136 = a;
        double r75137 = r75136 * r75136;
        double r75138 = b;
        double r75139 = r75138 * r75138;
        double r75140 = r75137 + r75139;
        double r75141 = r75140 * r75140;
        double r75142 = 4.0;
        double r75143 = 1.0;
        double r75144 = r75143 - r75136;
        double r75145 = r75137 * r75144;
        double r75146 = 3.0;
        double r75147 = r75146 + r75136;
        double r75148 = r75139 * r75147;
        double r75149 = r75145 + r75148;
        double r75150 = r75142 * r75149;
        double r75151 = r75141 + r75150;
        double r75152 = r75151 - r75143;
        return r75152;
}

double f_il(float a, float b) {
        long double r75153 = a;
        long double r75154 = r75153 * r75153;
        long double r75155 = b;
        long double r75156 = r75155 * r75155;
        long double r75157 = r75154 + r75156;
        long double r75158 = r75157 * r75157;
        long double r75159 = 4.0;
        long double r75160 = 1.0;
        long double r75161 = r75160 - r75153;
        long double r75162 = r75154 * r75161;
        long double r75163 = 3.0;
        long double r75164 = r75163 + r75153;
        long double r75165 = r75156 * r75164;
        long double r75166 = r75162 + r75165;
        long double r75167 = r75159 * r75166;
        long double r75168 = r75158 + r75167;
        long double r75169 = r75168 - r75160;
        return r75169;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a, float b) {
        float r75170 = a;
        float r75171 = -2.374520147406146e+26;
        bool r75172 = r75170 < r75171;
        float r75173 = r75170 * r75170;
        float r75174 = r75173 * r75173;
        float r75175 = b;
        float r75176 = r75175 * r75175;
        float r75177 = r75176 * r75176;
        float r75178 = r75174 - r75177;
        float r75179 = r75178 * r75178;
        float r75180 = r75173 - r75176;
        float r75181 = r75173 + r75176;
        float r75182 = r75178 / r75181;
        float r75183 = r75180 * r75180;
        float r75184 = r75182 * r75183;
        float r75185 = r75180 * r75184;
        float r75186 = r75170 - r75175;
        float r75187 = r75170 + r75175;
        float r75188 = r75187 * r75187;
        float r75189 = r75186 * r75188;
        float r75190 = r75186 * r75189;
        float r75191 = r75185 / r75190;
        float r75192 = r75179 / r75191;
        float r75193 = 4.0;
        float r75194 = 1.0;
        float r75195 = r75194 - r75170;
        float r75196 = r75173 * r75195;
        float r75197 = 3.0;
        float r75198 = r75197 + r75170;
        float r75199 = r75176 * r75198;
        float r75200 = r75196 + r75199;
        float r75201 = r75193 * r75200;
        float r75202 = r75192 + r75201;
        float r75203 = r75202 - r75194;
        float r75204 = 4.06101251138032e+24;
        bool r75205 = r75170 < r75204;
        float r75206 = r75181 * r75181;
        float r75207 = r75206 + r75201;
        float r75208 = r75207 - r75194;
        float r75209 = 2.2077063450382992e+25;
        bool r75210 = r75170 < r75209;
        float r75211 = r75181 * r75180;
        float r75212 = r75211 * r75211;
        float r75213 = r75212 / r75183;
        float r75214 = r75213 + r75201;
        float r75215 = r75214 - r75194;
        float r75216 = r75210 ? r75203 : r75215;
        float r75217 = r75205 ? r75208 : r75216;
        float r75218 = r75172 ? r75203 : r75217;
        return r75218;
}

double f_od(float a, float b) {
        double r75219 = a;
        double r75220 = -2.374520147406146e+26;
        bool r75221 = r75219 < r75220;
        double r75222 = r75219 * r75219;
        double r75223 = r75222 * r75222;
        double r75224 = b;
        double r75225 = r75224 * r75224;
        double r75226 = r75225 * r75225;
        double r75227 = r75223 - r75226;
        double r75228 = r75227 * r75227;
        double r75229 = r75222 - r75225;
        double r75230 = r75222 + r75225;
        double r75231 = r75227 / r75230;
        double r75232 = r75229 * r75229;
        double r75233 = r75231 * r75232;
        double r75234 = r75229 * r75233;
        double r75235 = r75219 - r75224;
        double r75236 = r75219 + r75224;
        double r75237 = r75236 * r75236;
        double r75238 = r75235 * r75237;
        double r75239 = r75235 * r75238;
        double r75240 = r75234 / r75239;
        double r75241 = r75228 / r75240;
        double r75242 = 4.0;
        double r75243 = 1.0;
        double r75244 = r75243 - r75219;
        double r75245 = r75222 * r75244;
        double r75246 = 3.0;
        double r75247 = r75246 + r75219;
        double r75248 = r75225 * r75247;
        double r75249 = r75245 + r75248;
        double r75250 = r75242 * r75249;
        double r75251 = r75241 + r75250;
        double r75252 = r75251 - r75243;
        double r75253 = 4.06101251138032e+24;
        bool r75254 = r75219 < r75253;
        double r75255 = r75230 * r75230;
        double r75256 = r75255 + r75250;
        double r75257 = r75256 - r75243;
        double r75258 = 2.2077063450382992e+25;
        bool r75259 = r75219 < r75258;
        double r75260 = r75230 * r75229;
        double r75261 = r75260 * r75260;
        double r75262 = r75261 / r75232;
        double r75263 = r75262 + r75250;
        double r75264 = r75263 - r75243;
        double r75265 = r75259 ? r75252 : r75264;
        double r75266 = r75254 ? r75257 : r75265;
        double r75267 = r75221 ? r75252 : r75266;
        return r75267;
}

double f_ol(float a, float b) {
        long double r75268 = a;
        long double r75269 = -2.374520147406146e+26;
        bool r75270 = r75268 < r75269;
        long double r75271 = r75268 * r75268;
        long double r75272 = r75271 * r75271;
        long double r75273 = b;
        long double r75274 = r75273 * r75273;
        long double r75275 = r75274 * r75274;
        long double r75276 = r75272 - r75275;
        long double r75277 = r75276 * r75276;
        long double r75278 = r75271 - r75274;
        long double r75279 = r75271 + r75274;
        long double r75280 = r75276 / r75279;
        long double r75281 = r75278 * r75278;
        long double r75282 = r75280 * r75281;
        long double r75283 = r75278 * r75282;
        long double r75284 = r75268 - r75273;
        long double r75285 = r75268 + r75273;
        long double r75286 = r75285 * r75285;
        long double r75287 = r75284 * r75286;
        long double r75288 = r75284 * r75287;
        long double r75289 = r75283 / r75288;
        long double r75290 = r75277 / r75289;
        long double r75291 = 4.0;
        long double r75292 = 1.0;
        long double r75293 = r75292 - r75268;
        long double r75294 = r75271 * r75293;
        long double r75295 = 3.0;
        long double r75296 = r75295 + r75268;
        long double r75297 = r75274 * r75296;
        long double r75298 = r75294 + r75297;
        long double r75299 = r75291 * r75298;
        long double r75300 = r75290 + r75299;
        long double r75301 = r75300 - r75292;
        long double r75302 = 4.06101251138032e+24;
        bool r75303 = r75268 < r75302;
        long double r75304 = r75279 * r75279;
        long double r75305 = r75304 + r75299;
        long double r75306 = r75305 - r75292;
        long double r75307 = 2.2077063450382992e+25;
        bool r75308 = r75268 < r75307;
        long double r75309 = r75279 * r75278;
        long double r75310 = r75309 * r75309;
        long double r75311 = r75310 / r75281;
        long double r75312 = r75311 + r75299;
        long double r75313 = r75312 - r75292;
        long double r75314 = r75308 ? r75301 : r75313;
        long double r75315 = r75303 ? r75306 : r75314;
        long double r75316 = r75270 ? r75301 : r75315;
        return r75316;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r75317, r75318, r75319, r75320, r75321, r75322, r75323, r75324, r75325, r75326, r75327, r75328, r75329, r75330, r75331, r75332, r75333;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r75317);
        mpfr_init(r75318);
        mpfr_init(r75319);
        mpfr_init(r75320);
        mpfr_init(r75321);
        mpfr_init(r75322);
        mpfr_init(r75323);
        mpfr_init(r75324);
        mpfr_init(r75325);
        mpfr_init(r75326);
        mpfr_init(r75327);
        mpfr_init(r75328);
        mpfr_init(r75329);
        mpfr_init(r75330);
        mpfr_init(r75331);
        mpfr_init(r75332);
        mpfr_init(r75333);
}

double f_im(float a, float b) {
        mpfr_set_flt(r75317, a, MPFR_RNDN);
        mpfr_mul(r75318, r75317, r75317, MPFR_RNDN);
        mpfr_set_flt(r75319, b, MPFR_RNDN);
        mpfr_mul(r75320, r75319, r75319, MPFR_RNDN);
        mpfr_add(r75321, r75318, r75320, MPFR_RNDN);
        mpfr_mul(r75322, r75321, r75321, MPFR_RNDN);
        mpfr_init_set_str(r75323, "4", 10, MPFR_RNDN);
        mpfr_init_set_str(r75324, "1", 10, MPFR_RNDN);
        mpfr_sub(r75325, r75324, r75317, MPFR_RNDN);
        mpfr_mul(r75326, r75318, r75325, MPFR_RNDN);
        mpfr_init_set_str(r75327, "3", 10, MPFR_RNDN);
        mpfr_add(r75328, r75327, r75317, MPFR_RNDN);
        mpfr_mul(r75329, r75320, r75328, MPFR_RNDN);
        mpfr_add(r75330, r75326, r75329, MPFR_RNDN);
        mpfr_mul(r75331, r75323, r75330, MPFR_RNDN);
        mpfr_add(r75332, r75322, r75331, MPFR_RNDN);
        mpfr_sub(r75333, r75332, r75324, MPFR_RNDN);
        return mpfr_get_d(r75333, MPFR_RNDN);
}

