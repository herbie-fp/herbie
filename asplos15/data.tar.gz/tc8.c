#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* FastMath dist3 */

double f_if(float d1, float d2, float d3) {
        float r72604 = d1;
        float r72605 = d2;
        float r72606 = r72604 * r72605;
        float r72607 = d3;
        float r72608 = 5.0;
        float r72609 = r72607 + r72608;
        float r72610 = r72609 * r72604;
        float r72611 = r72606 + r72610;
        float r72612 = 32.0;
        float r72613 = r72604 * r72612;
        float r72614 = r72611 + r72613;
        return r72614;
}

double f_id(float d1, float d2, float d3) {
        double r72615 = d1;
        double r72616 = d2;
        double r72617 = r72615 * r72616;
        double r72618 = d3;
        double r72619 = 5.0;
        double r72620 = r72618 + r72619;
        double r72621 = r72620 * r72615;
        double r72622 = r72617 + r72621;
        double r72623 = 32.0;
        double r72624 = r72615 * r72623;
        double r72625 = r72622 + r72624;
        return r72625;
}

double f_il(float d1, float d2, float d3) {
        long double r72626 = d1;
        long double r72627 = d2;
        long double r72628 = r72626 * r72627;
        long double r72629 = d3;
        long double r72630 = 5.0;
        long double r72631 = r72629 + r72630;
        long double r72632 = r72631 * r72626;
        long double r72633 = r72628 + r72632;
        long double r72634 = 32.0;
        long double r72635 = r72626 * r72634;
        long double r72636 = r72633 + r72635;
        return r72636;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float d1, float d2, float d3) {
        float r72637 = 37.0;
        float r72638 = d1;
        float r72639 = r72637 * r72638;
        float r72640 = d2;
        float r72641 = d3;
        float r72642 = r72640 + r72641;
        float r72643 = r72638 * r72642;
        float r72644 = r72639 + r72643;
        return r72644;
}

double f_od(float d1, float d2, float d3) {
        double r72645 = 37.0;
        double r72646 = d1;
        double r72647 = r72645 * r72646;
        double r72648 = d2;
        double r72649 = d3;
        double r72650 = r72648 + r72649;
        double r72651 = r72646 * r72650;
        double r72652 = r72647 + r72651;
        return r72652;
}

double f_ol(float d1, float d2, float d3) {
        long double r72653 = 37.0;
        long double r72654 = d1;
        long double r72655 = r72653 * r72654;
        long double r72656 = d2;
        long double r72657 = d3;
        long double r72658 = r72656 + r72657;
        long double r72659 = r72654 * r72658;
        long double r72660 = r72655 + r72659;
        return r72660;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r72661, r72662, r72663, r72664, r72665, r72666, r72667, r72668, r72669, r72670, r72671;

void setup_mpfr() {
        mpfr_set_default_prec(152);
        mpfr_init(r72661);
        mpfr_init(r72662);
        mpfr_init(r72663);
        mpfr_init(r72664);
        mpfr_init(r72665);
        mpfr_init(r72666);
        mpfr_init(r72667);
        mpfr_init(r72668);
        mpfr_init(r72669);
        mpfr_init(r72670);
        mpfr_init(r72671);
}

double f_im(float d1, float d2, float d3) {
        mpfr_set_flt(r72661, d1, MPFR_RNDN);
        mpfr_set_flt(r72662, d2, MPFR_RNDN);
        mpfr_mul(r72663, r72661, r72662, MPFR_RNDN);
        mpfr_set_flt(r72664, d3, MPFR_RNDN);
        mpfr_init_set_str(r72665, "5", 10, MPFR_RNDN);
        mpfr_add(r72666, r72664, r72665, MPFR_RNDN);
        mpfr_mul(r72667, r72666, r72661, MPFR_RNDN);
        mpfr_add(r72668, r72663, r72667, MPFR_RNDN);
        mpfr_init_set_str(r72669, "32", 10, MPFR_RNDN);
        mpfr_mul(r72670, r72661, r72669, MPFR_RNDN);
        mpfr_add(r72671, r72668, r72670, MPFR_RNDN);
        return mpfr_get_d(r72671, MPFR_RNDN);
}

