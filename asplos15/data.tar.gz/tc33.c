#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE problem 3.3.6 */

double f_if(float N) {
        float r74447 = N;
        float r74448 = 1.0;
        float r74449 = r74447 + r74448;
        float r74450 = log(r74449);
        float r74451 = log(r74447);
        float r74452 = r74450 - r74451;
        return r74452;
}

double f_id(float N) {
        double r74453 = N;
        double r74454 = 1.0;
        double r74455 = r74453 + r74454;
        double r74456 = log(r74455);
        double r74457 = log(r74453);
        double r74458 = r74456 - r74457;
        return r74458;
}

double f_il(float N) {
        long double r74459 = N;
        long double r74460 = 1.0;
        long double r74461 = r74459 + r74460;
        long double r74462 = log(r74461);
        long double r74463 = log(r74459);
        long double r74464 = r74462 - r74463;
        return r74464;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float N) {
        float r74465 = 1.0;
        float r74466 = N;
        float r74467 = r74465 / r74466;
        float r74468 = r74465 + r74467;
        float r74469 = log(r74468);
        return r74469;
}

double f_od(float N) {
        double r74470 = 1.0;
        double r74471 = N;
        double r74472 = r74470 / r74471;
        double r74473 = r74470 + r74472;
        double r74474 = log(r74473);
        return r74474;
}

double f_ol(float N) {
        long double r74475 = 1.0;
        long double r74476 = N;
        long double r74477 = r74475 / r74476;
        long double r74478 = r74475 + r74477;
        long double r74479 = log(r74478);
        return r74479;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r74480, r74481, r74482, r74483, r74484, r74485;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r74480);
        mpfr_init(r74481);
        mpfr_init(r74482);
        mpfr_init(r74483);
        mpfr_init(r74484);
        mpfr_init(r74485);
}

double f_im(float N) {
        mpfr_set_flt(r74480, N, MPFR_RNDN);
        mpfr_init_set_str(r74481, "1", 10, MPFR_RNDN);
        mpfr_add(r74482, r74480, r74481, MPFR_RNDN);
        mpfr_log(r74483, r74482, MPFR_RNDN);
        mpfr_log(r74484, r74480, MPFR_RNDN);
        mpfr_sub(r74485, r74483, r74484, MPFR_RNDN);
        return mpfr_get_d(r74485, MPFR_RNDN);
}

