#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.cube on complex, real part */

double f_if(float x_re, float x_im) {
        float r85127 = x_re;
        float r85128 = r85127 * r85127;
        float r85129 = x_im;
        float r85130 = r85129 * r85129;
        float r85131 = r85128 - r85130;
        float r85132 = r85131 * r85127;
        float r85133 = r85127 * r85129;
        float r85134 = r85129 * r85127;
        float r85135 = r85133 + r85134;
        float r85136 = r85135 * r85129;
        float r85137 = r85132 - r85136;
        return r85137;
}

double f_id(float x_re, float x_im) {
        double r85138 = x_re;
        double r85139 = r85138 * r85138;
        double r85140 = x_im;
        double r85141 = r85140 * r85140;
        double r85142 = r85139 - r85141;
        double r85143 = r85142 * r85138;
        double r85144 = r85138 * r85140;
        double r85145 = r85140 * r85138;
        double r85146 = r85144 + r85145;
        double r85147 = r85146 * r85140;
        double r85148 = r85143 - r85147;
        return r85148;
}

double f_il(float x_re, float x_im) {
        long double r85149 = x_re;
        long double r85150 = r85149 * r85149;
        long double r85151 = x_im;
        long double r85152 = r85151 * r85151;
        long double r85153 = r85150 - r85152;
        long double r85154 = r85153 * r85149;
        long double r85155 = r85149 * r85151;
        long double r85156 = r85151 * r85149;
        long double r85157 = r85155 + r85156;
        long double r85158 = r85157 * r85151;
        long double r85159 = r85154 - r85158;
        return r85159;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x_re, float x_im) {
        float r85160 = x_re;
        float r85161 = r85160 * r85160;
        float r85162 = sqrt(r85161);
        float r85163 = x_im;
        float r85164 = r85162 + r85163;
        float r85165 = r85162 - r85163;
        float r85166 = r85164 * r85165;
        float r85167 = r85166 * r85160;
        float r85168 = r85160 * r85163;
        float r85169 = r85163 * r85160;
        float r85170 = r85168 + r85169;
        float r85171 = r85170 * r85163;
        float r85172 = r85167 - r85171;
        return r85172;
}

double f_od(float x_re, float x_im) {
        double r85173 = x_re;
        double r85174 = r85173 * r85173;
        double r85175 = sqrt(r85174);
        double r85176 = x_im;
        double r85177 = r85175 + r85176;
        double r85178 = r85175 - r85176;
        double r85179 = r85177 * r85178;
        double r85180 = r85179 * r85173;
        double r85181 = r85173 * r85176;
        double r85182 = r85176 * r85173;
        double r85183 = r85181 + r85182;
        double r85184 = r85183 * r85176;
        double r85185 = r85180 - r85184;
        return r85185;
}

double f_ol(float x_re, float x_im) {
        long double r85186 = x_re;
        long double r85187 = r85186 * r85186;
        long double r85188 = sqrt(r85187);
        long double r85189 = x_im;
        long double r85190 = r85188 + r85189;
        long double r85191 = r85188 - r85189;
        long double r85192 = r85190 * r85191;
        long double r85193 = r85192 * r85186;
        long double r85194 = r85186 * r85189;
        long double r85195 = r85189 * r85186;
        long double r85196 = r85194 + r85195;
        long double r85197 = r85196 * r85189;
        long double r85198 = r85193 - r85197;
        return r85198;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r85199, r85200, r85201, r85202, r85203, r85204, r85205, r85206, r85207, r85208, r85209;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r85199);
        mpfr_init(r85200);
        mpfr_init(r85201);
        mpfr_init(r85202);
        mpfr_init(r85203);
        mpfr_init(r85204);
        mpfr_init(r85205);
        mpfr_init(r85206);
        mpfr_init(r85207);
        mpfr_init(r85208);
        mpfr_init(r85209);
}

double f_im(float x_re, float x_im) {
        mpfr_set_flt(r85199, x_re, MPFR_RNDN);
        mpfr_mul(r85200, r85199, r85199, MPFR_RNDN);
        mpfr_set_flt(r85201, x_im, MPFR_RNDN);
        mpfr_mul(r85202, r85201, r85201, MPFR_RNDN);
        mpfr_sub(r85203, r85200, r85202, MPFR_RNDN);
        mpfr_mul(r85204, r85203, r85199, MPFR_RNDN);
        mpfr_mul(r85205, r85199, r85201, MPFR_RNDN);
        mpfr_mul(r85206, r85201, r85199, MPFR_RNDN);
        mpfr_add(r85207, r85205, r85206, MPFR_RNDN);
        mpfr_mul(r85208, r85207, r85201, MPFR_RNDN);
        mpfr_sub(r85209, r85204, r85208, MPFR_RNDN);
        return mpfr_get_d(r85209, MPFR_RNDN);
}

