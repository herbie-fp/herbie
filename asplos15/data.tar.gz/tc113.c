#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.cube on complex, imaginary part */

double f_if(float x_re, float x_im) {
        float r85038 = x_re;
        float r85039 = r85038 * r85038;
        float r85040 = x_im;
        float r85041 = r85040 * r85040;
        float r85042 = r85039 - r85041;
        float r85043 = r85042 * r85040;
        float r85044 = r85038 * r85040;
        float r85045 = r85040 * r85038;
        float r85046 = r85044 + r85045;
        float r85047 = r85046 * r85038;
        float r85048 = r85043 + r85047;
        return r85048;
}

double f_id(float x_re, float x_im) {
        double r85049 = x_re;
        double r85050 = r85049 * r85049;
        double r85051 = x_im;
        double r85052 = r85051 * r85051;
        double r85053 = r85050 - r85052;
        double r85054 = r85053 * r85051;
        double r85055 = r85049 * r85051;
        double r85056 = r85051 * r85049;
        double r85057 = r85055 + r85056;
        double r85058 = r85057 * r85049;
        double r85059 = r85054 + r85058;
        return r85059;
}

double f_il(float x_re, float x_im) {
        long double r85060 = x_re;
        long double r85061 = r85060 * r85060;
        long double r85062 = x_im;
        long double r85063 = r85062 * r85062;
        long double r85064 = r85061 - r85063;
        long double r85065 = r85064 * r85062;
        long double r85066 = r85060 * r85062;
        long double r85067 = r85062 * r85060;
        long double r85068 = r85066 + r85067;
        long double r85069 = r85068 * r85060;
        long double r85070 = r85065 + r85069;
        return r85070;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x_re, float x_im) {
        float r85071 = x_re;
        float r85072 = r85071 * r85071;
        float r85073 = sqrt(r85072);
        float r85074 = x_im;
        float r85075 = r85074 * r85074;
        float r85076 = sqrt(r85075);
        float r85077 = r85073 + r85076;
        float r85078 = r85073 - r85076;
        float r85079 = r85078 * r85074;
        float r85080 = r85077 * r85079;
        float r85081 = r85071 * r85074;
        float r85082 = r85074 * r85071;
        float r85083 = r85081 + r85082;
        float r85084 = r85083 * r85071;
        float r85085 = r85080 + r85084;
        return r85085;
}

double f_od(float x_re, float x_im) {
        double r85086 = x_re;
        double r85087 = r85086 * r85086;
        double r85088 = sqrt(r85087);
        double r85089 = x_im;
        double r85090 = r85089 * r85089;
        double r85091 = sqrt(r85090);
        double r85092 = r85088 + r85091;
        double r85093 = r85088 - r85091;
        double r85094 = r85093 * r85089;
        double r85095 = r85092 * r85094;
        double r85096 = r85086 * r85089;
        double r85097 = r85089 * r85086;
        double r85098 = r85096 + r85097;
        double r85099 = r85098 * r85086;
        double r85100 = r85095 + r85099;
        return r85100;
}

double f_ol(float x_re, float x_im) {
        long double r85101 = x_re;
        long double r85102 = r85101 * r85101;
        long double r85103 = sqrt(r85102);
        long double r85104 = x_im;
        long double r85105 = r85104 * r85104;
        long double r85106 = sqrt(r85105);
        long double r85107 = r85103 + r85106;
        long double r85108 = r85103 - r85106;
        long double r85109 = r85108 * r85104;
        long double r85110 = r85107 * r85109;
        long double r85111 = r85101 * r85104;
        long double r85112 = r85104 * r85101;
        long double r85113 = r85111 + r85112;
        long double r85114 = r85113 * r85101;
        long double r85115 = r85110 + r85114;
        return r85115;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r85116, r85117, r85118, r85119, r85120, r85121, r85122, r85123, r85124, r85125, r85126;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r85116);
        mpfr_init(r85117);
        mpfr_init(r85118);
        mpfr_init(r85119);
        mpfr_init(r85120);
        mpfr_init(r85121);
        mpfr_init(r85122);
        mpfr_init(r85123);
        mpfr_init(r85124);
        mpfr_init(r85125);
        mpfr_init(r85126);
}

double f_im(float x_re, float x_im) {
        mpfr_set_flt(r85116, x_re, MPFR_RNDN);
        mpfr_mul(r85117, r85116, r85116, MPFR_RNDN);
        mpfr_set_flt(r85118, x_im, MPFR_RNDN);
        mpfr_mul(r85119, r85118, r85118, MPFR_RNDN);
        mpfr_sub(r85120, r85117, r85119, MPFR_RNDN);
        mpfr_mul(r85121, r85120, r85118, MPFR_RNDN);
        mpfr_mul(r85122, r85116, r85118, MPFR_RNDN);
        mpfr_mul(r85123, r85118, r85116, MPFR_RNDN);
        mpfr_add(r85124, r85122, r85123, MPFR_RNDN);
        mpfr_mul(r85125, r85124, r85116, MPFR_RNDN);
        mpfr_add(r85126, r85121, r85125, MPFR_RNDN);
        return mpfr_get_d(r85126, MPFR_RNDN);
}

