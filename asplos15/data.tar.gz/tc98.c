#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Toniolo and Linder, Equation (3a) */

double f_if(float l, float Om, float kx, float ky) {
        float r83469 = 1.0;
        float r83470 = 2.0;
        float r83471 = r83469 / r83470;
        float r83472 = l;
        float r83473 = r83470 * r83472;
        float r83474 = Om;
        float r83475 = r83473 / r83474;
        float r83476 = r83475 * r83475;
        float r83477 = kx;
        float r83478 = sin(r83477);
        float r83479 = r83478 * r83478;
        float r83480 = ky;
        float r83481 = sin(r83480);
        float r83482 = r83481 * r83481;
        float r83483 = r83479 + r83482;
        float r83484 = r83476 * r83483;
        float r83485 = r83469 + r83484;
        float r83486 = sqrt(r83485);
        float r83487 = 1.0/r83486;
        float r83488 = r83469 + r83487;
        float r83489 = r83471 * r83488;
        float r83490 = sqrt(r83489);
        return r83490;
}

double f_id(float l, float Om, float kx, float ky) {
        double r83491 = 1.0;
        double r83492 = 2.0;
        double r83493 = r83491 / r83492;
        double r83494 = l;
        double r83495 = r83492 * r83494;
        double r83496 = Om;
        double r83497 = r83495 / r83496;
        double r83498 = r83497 * r83497;
        double r83499 = kx;
        double r83500 = sin(r83499);
        double r83501 = r83500 * r83500;
        double r83502 = ky;
        double r83503 = sin(r83502);
        double r83504 = r83503 * r83503;
        double r83505 = r83501 + r83504;
        double r83506 = r83498 * r83505;
        double r83507 = r83491 + r83506;
        double r83508 = sqrt(r83507);
        double r83509 = 1.0/r83508;
        double r83510 = r83491 + r83509;
        double r83511 = r83493 * r83510;
        double r83512 = sqrt(r83511);
        return r83512;
}

double f_il(float l, float Om, float kx, float ky) {
        long double r83513 = 1.0;
        long double r83514 = 2.0;
        long double r83515 = r83513 / r83514;
        long double r83516 = l;
        long double r83517 = r83514 * r83516;
        long double r83518 = Om;
        long double r83519 = r83517 / r83518;
        long double r83520 = r83519 * r83519;
        long double r83521 = kx;
        long double r83522 = sin(r83521);
        long double r83523 = r83522 * r83522;
        long double r83524 = ky;
        long double r83525 = sin(r83524);
        long double r83526 = r83525 * r83525;
        long double r83527 = r83523 + r83526;
        long double r83528 = r83520 * r83527;
        long double r83529 = r83513 + r83528;
        long double r83530 = sqrt(r83529);
        long double r83531 = 1.0/r83530;
        long double r83532 = r83513 + r83531;
        long double r83533 = r83515 * r83532;
        long double r83534 = sqrt(r83533);
        return r83534;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float l, float Om, float kx, float ky) {
        float r83535 = 1.0;
        float r83536 = 2.0;
        float r83537 = r83535 / r83536;
        float r83538 = l;
        float r83539 = r83536 * r83538;
        float r83540 = Om;
        float r83541 = r83539 / r83540;
        float r83542 = r83541 * r83541;
        float r83543 = kx;
        float r83544 = sin(r83543);
        float r83545 = r83544 * r83544;
        float r83546 = ky;
        float r83547 = sin(r83546);
        float r83548 = r83547 * r83547;
        float r83549 = r83545 + r83548;
        float r83550 = r83535 * r83549;
        float r83551 = r83542 * r83550;
        float r83552 = r83535 + r83551;
        float r83553 = sqrt(r83552);
        float r83554 = 1.0/r83553;
        float r83555 = r83535 + r83554;
        float r83556 = r83537 * r83555;
        float r83557 = sqrt(r83556);
        return r83557;
}

double f_od(float l, float Om, float kx, float ky) {
        double r83558 = 1.0;
        double r83559 = 2.0;
        double r83560 = r83558 / r83559;
        double r83561 = l;
        double r83562 = r83559 * r83561;
        double r83563 = Om;
        double r83564 = r83562 / r83563;
        double r83565 = r83564 * r83564;
        double r83566 = kx;
        double r83567 = sin(r83566);
        double r83568 = r83567 * r83567;
        double r83569 = ky;
        double r83570 = sin(r83569);
        double r83571 = r83570 * r83570;
        double r83572 = r83568 + r83571;
        double r83573 = r83558 * r83572;
        double r83574 = r83565 * r83573;
        double r83575 = r83558 + r83574;
        double r83576 = sqrt(r83575);
        double r83577 = 1.0/r83576;
        double r83578 = r83558 + r83577;
        double r83579 = r83560 * r83578;
        double r83580 = sqrt(r83579);
        return r83580;
}

double f_ol(float l, float Om, float kx, float ky) {
        long double r83581 = 1.0;
        long double r83582 = 2.0;
        long double r83583 = r83581 / r83582;
        long double r83584 = l;
        long double r83585 = r83582 * r83584;
        long double r83586 = Om;
        long double r83587 = r83585 / r83586;
        long double r83588 = r83587 * r83587;
        long double r83589 = kx;
        long double r83590 = sin(r83589);
        long double r83591 = r83590 * r83590;
        long double r83592 = ky;
        long double r83593 = sin(r83592);
        long double r83594 = r83593 * r83593;
        long double r83595 = r83591 + r83594;
        long double r83596 = r83581 * r83595;
        long double r83597 = r83588 * r83596;
        long double r83598 = r83581 + r83597;
        long double r83599 = sqrt(r83598);
        long double r83600 = 1.0/r83599;
        long double r83601 = r83581 + r83600;
        long double r83602 = r83583 * r83601;
        long double r83603 = sqrt(r83602);
        return r83603;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r83604, r83605, r83606, r83607, r83608, r83609, r83610, r83611, r83612, r83613, r83614, r83615, r83616, r83617, r83618, r83619, r83620, r83621, r83622, r83623, r83624, r83625;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r83604);
        mpfr_init(r83605);
        mpfr_init(r83606);
        mpfr_init(r83607);
        mpfr_init(r83608);
        mpfr_init(r83609);
        mpfr_init(r83610);
        mpfr_init(r83611);
        mpfr_init(r83612);
        mpfr_init(r83613);
        mpfr_init(r83614);
        mpfr_init(r83615);
        mpfr_init(r83616);
        mpfr_init(r83617);
        mpfr_init(r83618);
        mpfr_init(r83619);
        mpfr_init(r83620);
        mpfr_init(r83621);
        mpfr_init(r83622);
        mpfr_init(r83623);
        mpfr_init(r83624);
        mpfr_init(r83625);
}

double f_im(float l, float Om, float kx, float ky) {
        mpfr_init_set_str(r83604, "1", 10, MPFR_RNDN);
        mpfr_init_set_str(r83605, "2", 10, MPFR_RNDN);
        mpfr_div(r83606, r83604, r83605, MPFR_RNDN);
        mpfr_set_flt(r83607, l, MPFR_RNDN);
        mpfr_mul(r83608, r83605, r83607, MPFR_RNDN);
        mpfr_set_flt(r83609, Om, MPFR_RNDN);
        mpfr_div(r83610, r83608, r83609, MPFR_RNDN);
        mpfr_mul(r83611, r83610, r83610, MPFR_RNDN);
        mpfr_set_flt(r83612, kx, MPFR_RNDN);
        mpfr_sin(r83613, r83612, MPFR_RNDN);
        mpfr_mul(r83614, r83613, r83613, MPFR_RNDN);
        mpfr_set_flt(r83615, ky, MPFR_RNDN);
        mpfr_sin(r83616, r83615, MPFR_RNDN);
        mpfr_mul(r83617, r83616, r83616, MPFR_RNDN);
        mpfr_add(r83618, r83614, r83617, MPFR_RNDN);
        mpfr_mul(r83619, r83611, r83618, MPFR_RNDN);
        mpfr_add(r83620, r83604, r83619, MPFR_RNDN);
        mpfr_sqrt(r83621, r83620, MPFR_RNDN);
        mpfr_ui_div(r83622, 1, r83621, MPFR_RNDN);
        mpfr_add(r83623, r83604, r83622, MPFR_RNDN);
        mpfr_mul(r83624, r83606, r83623, MPFR_RNDN);
        mpfr_sqrt(r83625, r83624, MPFR_RNDN);
        return mpfr_get_d(r83625, MPFR_RNDN);
}

