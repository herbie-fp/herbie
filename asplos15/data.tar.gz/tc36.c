#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE section 3.11 */

double f_if(float x) {
        float r74615 = x;
        float r74616 = exp(r74615);
        float r74617 = 1.0;
        float r74618 = r74616 - r74617;
        float r74619 = r74616 / r74618;
        return r74619;
}

double f_id(float x) {
        double r74620 = x;
        double r74621 = exp(r74620);
        double r74622 = 1.0;
        double r74623 = r74621 - r74622;
        double r74624 = r74621 / r74623;
        return r74624;
}

double f_il(float x) {
        long double r74625 = x;
        long double r74626 = exp(r74625);
        long double r74627 = 1.0;
        long double r74628 = r74626 - r74627;
        long double r74629 = r74626 / r74628;
        return r74629;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r74630 = x;
        float r74631 = -0.0;
        bool r74632 = r74630 < r74631;
        float r74633 = 1.0;
        float r74634 = exp(r74630);
        float r74635 = r74634 + r74633;
        float r74636 = r74633 / r74635;
        float r74637 = 1.0/r74635;
        float r74638 = r74634 * r74637;
        float r74639 = sqrt(r74636);
        float r74640 = r74639 * r74639;
        float r74641 = r74638 - r74640;
        float r74642 = r74634 / r74641;
        float r74643 = r74636 * r74642;
        float r74644 = r74633 / r74634;
        float r74645 = r74644 * r74644;
        float r74646 = r74633 - r74645;
        float r74647 = -1.0;
        float r74648 = r74647 / r74634;
        float r74649 = r74633 - r74648;
        float r74650 = r74646 / r74649;
        float r74651 = r74633 / r74650;
        float r74652 = r74632 ? r74643 : r74651;
        return r74652;
}

double f_od(float x) {
        double r74653 = x;
        double r74654 = -0.0;
        bool r74655 = r74653 < r74654;
        double r74656 = 1.0;
        double r74657 = exp(r74653);
        double r74658 = r74657 + r74656;
        double r74659 = r74656 / r74658;
        double r74660 = 1.0/r74658;
        double r74661 = r74657 * r74660;
        double r74662 = sqrt(r74659);
        double r74663 = r74662 * r74662;
        double r74664 = r74661 - r74663;
        double r74665 = r74657 / r74664;
        double r74666 = r74659 * r74665;
        double r74667 = r74656 / r74657;
        double r74668 = r74667 * r74667;
        double r74669 = r74656 - r74668;
        double r74670 = -1.0;
        double r74671 = r74670 / r74657;
        double r74672 = r74656 - r74671;
        double r74673 = r74669 / r74672;
        double r74674 = r74656 / r74673;
        double r74675 = r74655 ? r74666 : r74674;
        return r74675;
}

double f_ol(float x) {
        long double r74676 = x;
        long double r74677 = -0.0;
        bool r74678 = r74676 < r74677;
        long double r74679 = 1.0;
        long double r74680 = exp(r74676);
        long double r74681 = r74680 + r74679;
        long double r74682 = r74679 / r74681;
        long double r74683 = 1.0/r74681;
        long double r74684 = r74680 * r74683;
        long double r74685 = sqrt(r74682);
        long double r74686 = r74685 * r74685;
        long double r74687 = r74684 - r74686;
        long double r74688 = r74680 / r74687;
        long double r74689 = r74682 * r74688;
        long double r74690 = r74679 / r74680;
        long double r74691 = r74690 * r74690;
        long double r74692 = r74679 - r74691;
        long double r74693 = -1.0;
        long double r74694 = r74693 / r74680;
        long double r74695 = r74679 - r74694;
        long double r74696 = r74692 / r74695;
        long double r74697 = r74679 / r74696;
        long double r74698 = r74678 ? r74689 : r74697;
        return r74698;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r74699, r74700, r74701, r74702, r74703;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r74699);
        mpfr_init(r74700);
        mpfr_init(r74701);
        mpfr_init(r74702);
        mpfr_init(r74703);
}

double f_im(float x) {
        mpfr_set_flt(r74699, x, MPFR_RNDN);
        mpfr_exp(r74700, r74699, MPFR_RNDN);
        mpfr_init_set_str(r74701, "1", 10, MPFR_RNDN);
        mpfr_sub(r74702, r74700, r74701, MPFR_RNDN);
        mpfr_div(r74703, r74700, r74702, MPFR_RNDN);
        return mpfr_get_d(r74703, MPFR_RNDN);
}

