#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE problem 3.3.4 */

double f_if(float x) {
        float r74221 = x;
        float r74222 = 1.0;
        float r74223 = r74221 + r74222;
        float r74224 = 3.0;
        float r74225 = r74222 / r74224;
        float r74226 = pow(r74223, r74225);
        float r74227 = pow(r74221, r74225);
        float r74228 = r74226 - r74227;
        return r74228;
}

double f_id(float x) {
        double r74229 = x;
        double r74230 = 1.0;
        double r74231 = r74229 + r74230;
        double r74232 = 3.0;
        double r74233 = r74230 / r74232;
        double r74234 = pow(r74231, r74233);
        double r74235 = pow(r74229, r74233);
        double r74236 = r74234 - r74235;
        return r74236;
}

double f_il(float x) {
        long double r74237 = x;
        long double r74238 = 1.0;
        long double r74239 = r74237 + r74238;
        long double r74240 = 3.0;
        long double r74241 = r74238 / r74240;
        long double r74242 = pow(r74239, r74241);
        long double r74243 = pow(r74237, r74241);
        long double r74244 = r74242 - r74243;
        return r74244;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r74245 = 0.3333333333333333;
        float r74246 = exp(r74245);
        float r74247 = x;
        float r74248 = 1.0;
        float r74249 = r74247 + r74248;
        float r74250 = log(r74249);
        float r74251 = pow(r74246, r74250);
        float r74252 = pow(r74247, r74245);
        float r74253 = r74251 - r74252;
        return r74253;
}

double f_od(float x) {
        double r74254 = 0.3333333333333333;
        double r74255 = exp(r74254);
        double r74256 = x;
        double r74257 = 1.0;
        double r74258 = r74256 + r74257;
        double r74259 = log(r74258);
        double r74260 = pow(r74255, r74259);
        double r74261 = pow(r74256, r74254);
        double r74262 = r74260 - r74261;
        return r74262;
}

double f_ol(float x) {
        long double r74263 = 0.3333333333333333;
        long double r74264 = exp(r74263);
        long double r74265 = x;
        long double r74266 = 1.0;
        long double r74267 = r74265 + r74266;
        long double r74268 = log(r74267);
        long double r74269 = pow(r74264, r74268);
        long double r74270 = pow(r74265, r74263);
        long double r74271 = r74269 - r74270;
        return r74271;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r74272, r74273, r74274, r74275, r74276, r74277, r74278, r74279;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r74272);
        mpfr_init(r74273);
        mpfr_init(r74274);
        mpfr_init(r74275);
        mpfr_init(r74276);
        mpfr_init(r74277);
        mpfr_init(r74278);
        mpfr_init(r74279);
}

double f_im(float x) {
        mpfr_set_flt(r74272, x, MPFR_RNDN);
        mpfr_init_set_str(r74273, "1", 10, MPFR_RNDN);
        mpfr_add(r74274, r74272, r74273, MPFR_RNDN);
        mpfr_init_set_str(r74275, "3", 10, MPFR_RNDN);
        mpfr_div(r74276, r74273, r74275, MPFR_RNDN);
        mpfr_pow(r74277, r74274, r74276, MPFR_RNDN);
        mpfr_pow(r74278, r74272, r74276, MPFR_RNDN);
        mpfr_sub(r74279, r74277, r74278, MPFR_RNDN);
        return mpfr_get_d(r74279, MPFR_RNDN);
}

