#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE example 3.9 */

double f_if(float x) {
        float r80287 = 1.0;
        float r80288 = x;
        float r80289 = r80287 / r80288;
        float r80290 = 1.0 / tan(r80288);
        float r80291 = r80289 - r80290;
        return r80291;
}

double f_id(float x) {
        double r80292 = 1.0;
        double r80293 = x;
        double r80294 = r80292 / r80293;
        double r80295 = 1.0 / tan(r80293);
        double r80296 = r80294 - r80295;
        return r80296;
}

double f_il(float x) {
        long double r80297 = 1.0;
        long double r80298 = x;
        long double r80299 = r80297 / r80298;
        long double r80300 = 1.0 / tan(r80298);
        long double r80301 = r80299 - r80300;
        return r80301;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r80302 = x;
        float r80303 = 1.0/r80302;
        float r80304 = r80303 * r80303;
        float r80305 = log(r80304);
        float r80306 = exp(r80305);
        float r80307 = 1.0;
        float r80308 = exp(r80307);
        float r80309 = 1.0 / tan(r80302);
        float r80310 = r80309 * r80309;
        float r80311 = log(r80310);
        float r80312 = pow(r80308, r80311);
        float r80313 = r80306 - r80312;
        float r80314 = r80303 + r80309;
        float r80315 = r80313 / r80314;
        return r80315;
}

double f_od(float x) {
        double r80316 = x;
        double r80317 = 1.0/r80316;
        double r80318 = r80317 * r80317;
        double r80319 = log(r80318);
        double r80320 = exp(r80319);
        double r80321 = 1.0;
        double r80322 = exp(r80321);
        double r80323 = 1.0 / tan(r80316);
        double r80324 = r80323 * r80323;
        double r80325 = log(r80324);
        double r80326 = pow(r80322, r80325);
        double r80327 = r80320 - r80326;
        double r80328 = r80317 + r80323;
        double r80329 = r80327 / r80328;
        return r80329;
}

double f_ol(float x) {
        long double r80330 = x;
        long double r80331 = 1.0/r80330;
        long double r80332 = r80331 * r80331;
        long double r80333 = log(r80332);
        long double r80334 = exp(r80333);
        long double r80335 = 1.0;
        long double r80336 = exp(r80335);
        long double r80337 = 1.0 / tan(r80330);
        long double r80338 = r80337 * r80337;
        long double r80339 = log(r80338);
        long double r80340 = pow(r80336, r80339);
        long double r80341 = r80334 - r80340;
        long double r80342 = r80331 + r80337;
        long double r80343 = r80341 / r80342;
        return r80343;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r80344, r80345, r80346, r80347, r80348;

void setup_mpfr() {
        mpfr_set_default_prec(344);
        mpfr_init(r80344);
        mpfr_init(r80345);
        mpfr_init(r80346);
        mpfr_init(r80347);
        mpfr_init(r80348);
}

double f_im(float x) {
        mpfr_init_set_str(r80344, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r80345, x, MPFR_RNDN);
        mpfr_div(r80346, r80344, r80345, MPFR_RNDN);
        mpfr_cot(r80347, r80345, MPFR_RNDN);
        mpfr_sub(r80348, r80346, r80347, MPFR_RNDN);
        return mpfr_get_d(r80348, MPFR_RNDN);
}

