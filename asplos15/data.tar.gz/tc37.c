#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE section 3.5 */

double f_if(float a, float x) {
        float r74705 = a;
        float r74706 = x;
        float r74707 = r74705 * r74706;
        float r74708 = exp(r74707);
        float r74709 = 1.0;
        float r74710 = r74708 - r74709;
        return r74710;
}

double f_id(float a, float x) {
        double r74711 = a;
        double r74712 = x;
        double r74713 = r74711 * r74712;
        double r74714 = exp(r74713);
        double r74715 = 1.0;
        double r74716 = r74714 - r74715;
        return r74716;
}

double f_il(float a, float x) {
        long double r74717 = a;
        long double r74718 = x;
        long double r74719 = r74717 * r74718;
        long double r74720 = exp(r74719);
        long double r74721 = 1.0;
        long double r74722 = r74720 - r74721;
        return r74722;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a, float x) {
        float r74723 = a;
        float r74724 = 398435570463209.1;
        bool r74725 = r74723 < r74724;
        float r74726 = x;
        float r74727 = r74723 * r74726;
        float r74728 = exp(r74727);
        float r74729 = 1.0;
        float r74730 = r74728 + r74729;
        float r74731 = sqrt(r74730);
        float r74732 = r74731 * r74731;
        float r74733 = r74728 / r74732;
        float r74734 = r74729 / r74730;
        float r74735 = r74733 - r74734;
        float r74736 = r74730 * r74735;
        float r74737 = -1.0;
        float r74738 = r74728 + r74737;
        float r74739 = r74725 ? r74736 : r74738;
        return r74739;
}

double f_od(float a, float x) {
        double r74740 = a;
        double r74741 = 398435570463209.1;
        bool r74742 = r74740 < r74741;
        double r74743 = x;
        double r74744 = r74740 * r74743;
        double r74745 = exp(r74744);
        double r74746 = 1.0;
        double r74747 = r74745 + r74746;
        double r74748 = sqrt(r74747);
        double r74749 = r74748 * r74748;
        double r74750 = r74745 / r74749;
        double r74751 = r74746 / r74747;
        double r74752 = r74750 - r74751;
        double r74753 = r74747 * r74752;
        double r74754 = -1.0;
        double r74755 = r74745 + r74754;
        double r74756 = r74742 ? r74753 : r74755;
        return r74756;
}

double f_ol(float a, float x) {
        long double r74757 = a;
        long double r74758 = 398435570463209.1;
        bool r74759 = r74757 < r74758;
        long double r74760 = x;
        long double r74761 = r74757 * r74760;
        long double r74762 = exp(r74761);
        long double r74763 = 1.0;
        long double r74764 = r74762 + r74763;
        long double r74765 = sqrt(r74764);
        long double r74766 = r74765 * r74765;
        long double r74767 = r74762 / r74766;
        long double r74768 = r74763 / r74764;
        long double r74769 = r74767 - r74768;
        long double r74770 = r74764 * r74769;
        long double r74771 = -1.0;
        long double r74772 = r74762 + r74771;
        long double r74773 = r74759 ? r74770 : r74772;
        return r74773;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r74774, r74775, r74776, r74777, r74778, r74779;

void setup_mpfr() {
        mpfr_set_default_prec(344);
        mpfr_init(r74774);
        mpfr_init(r74775);
        mpfr_init(r74776);
        mpfr_init(r74777);
        mpfr_init(r74778);
        mpfr_init(r74779);
}

double f_im(float a, float x) {
        mpfr_set_flt(r74774, a, MPFR_RNDN);
        mpfr_set_flt(r74775, x, MPFR_RNDN);
        mpfr_mul(r74776, r74774, r74775, MPFR_RNDN);
        mpfr_exp(r74777, r74776, MPFR_RNDN);
        mpfr_init_set_str(r74778, "1", 10, MPFR_RNDN);
        mpfr_sub(r74779, r74777, r74778, MPFR_RNDN);
        return mpfr_get_d(r74779, MPFR_RNDN);
}

