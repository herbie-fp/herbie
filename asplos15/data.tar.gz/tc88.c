#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Octave 3.8, jcobi/4 */

double f_if(float alpha, float beta, float i) {
        float r81562 = i;
        float r81563 = alpha;
        float r81564 = beta;
        float r81565 = r81563 + r81564;
        float r81566 = r81565 + r81562;
        float r81567 = r81562 * r81566;
        float r81568 = r81564 * r81563;
        float r81569 = r81568 + r81567;
        float r81570 = r81567 * r81569;
        float r81571 = 2.0;
        float r81572 = r81571 * r81562;
        float r81573 = r81565 + r81572;
        float r81574 = r81573 * r81573;
        float r81575 = r81570 / r81574;
        float r81576 = 1.0;
        float r81577 = r81574 - r81576;
        float r81578 = r81575 / r81577;
        return r81578;
}

double f_id(float alpha, float beta, float i) {
        double r81579 = i;
        double r81580 = alpha;
        double r81581 = beta;
        double r81582 = r81580 + r81581;
        double r81583 = r81582 + r81579;
        double r81584 = r81579 * r81583;
        double r81585 = r81581 * r81580;
        double r81586 = r81585 + r81584;
        double r81587 = r81584 * r81586;
        double r81588 = 2.0;
        double r81589 = r81588 * r81579;
        double r81590 = r81582 + r81589;
        double r81591 = r81590 * r81590;
        double r81592 = r81587 / r81591;
        double r81593 = 1.0;
        double r81594 = r81591 - r81593;
        double r81595 = r81592 / r81594;
        return r81595;
}

double f_il(float alpha, float beta, float i) {
        long double r81596 = i;
        long double r81597 = alpha;
        long double r81598 = beta;
        long double r81599 = r81597 + r81598;
        long double r81600 = r81599 + r81596;
        long double r81601 = r81596 * r81600;
        long double r81602 = r81598 * r81597;
        long double r81603 = r81602 + r81601;
        long double r81604 = r81601 * r81603;
        long double r81605 = 2.0;
        long double r81606 = r81605 * r81596;
        long double r81607 = r81599 + r81606;
        long double r81608 = r81607 * r81607;
        long double r81609 = r81604 / r81608;
        long double r81610 = 1.0;
        long double r81611 = r81608 - r81610;
        long double r81612 = r81609 / r81611;
        return r81612;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float alpha, float beta, float i) {
        float r81613 = alpha;
        float r81614 = -9.161047768334243e+16;
        bool r81615 = r81613 < r81614;
        float r81616 = i;
        float r81617 = beta;
        float r81618 = r81613 + r81617;
        float r81619 = r81618 + r81616;
        float r81620 = 2.0;
        float r81621 = r81620 * r81616;
        float r81622 = r81618 + r81621;
        float r81623 = r81619 / r81622;
        float r81624 = r81616 * r81623;
        float r81625 = r81617 * r81613;
        float r81626 = r81616 * r81619;
        float r81627 = r81625 + r81626;
        float r81628 = r81627 / r81622;
        float r81629 = r81624 * r81628;
        float r81630 = r81618 * r81622;
        float r81631 = r81621 * r81622;
        float r81632 = r81630 + r81631;
        float r81633 = 1.0;
        float r81634 = r81632 - r81633;
        float r81635 = 1.0/r81634;
        float r81636 = sqrt(r81635);
        float r81637 = r81636 * r81636;
        float r81638 = r81629 * r81637;
        bool r81639 = r81613 < r81633;
        float r81640 = r81626 * r81627;
        float r81641 = r81622 * r81622;
        float r81642 = r81640 / r81641;
        float r81643 = r81641 * r81641;
        float r81644 = r81633 * r81633;
        float r81645 = r81643 - r81644;
        float r81646 = r81641 + r81633;
        float r81647 = r81645 / r81646;
        float r81648 = r81642 / r81647;
        float r81649 = r81639 ? r81648 : r81638;
        float r81650 = r81615 ? r81638 : r81649;
        return r81650;
}

double f_od(float alpha, float beta, float i) {
        double r81651 = alpha;
        double r81652 = -9.161047768334243e+16;
        bool r81653 = r81651 < r81652;
        double r81654 = i;
        double r81655 = beta;
        double r81656 = r81651 + r81655;
        double r81657 = r81656 + r81654;
        double r81658 = 2.0;
        double r81659 = r81658 * r81654;
        double r81660 = r81656 + r81659;
        double r81661 = r81657 / r81660;
        double r81662 = r81654 * r81661;
        double r81663 = r81655 * r81651;
        double r81664 = r81654 * r81657;
        double r81665 = r81663 + r81664;
        double r81666 = r81665 / r81660;
        double r81667 = r81662 * r81666;
        double r81668 = r81656 * r81660;
        double r81669 = r81659 * r81660;
        double r81670 = r81668 + r81669;
        double r81671 = 1.0;
        double r81672 = r81670 - r81671;
        double r81673 = 1.0/r81672;
        double r81674 = sqrt(r81673);
        double r81675 = r81674 * r81674;
        double r81676 = r81667 * r81675;
        bool r81677 = r81651 < r81671;
        double r81678 = r81664 * r81665;
        double r81679 = r81660 * r81660;
        double r81680 = r81678 / r81679;
        double r81681 = r81679 * r81679;
        double r81682 = r81671 * r81671;
        double r81683 = r81681 - r81682;
        double r81684 = r81679 + r81671;
        double r81685 = r81683 / r81684;
        double r81686 = r81680 / r81685;
        double r81687 = r81677 ? r81686 : r81676;
        double r81688 = r81653 ? r81676 : r81687;
        return r81688;
}

double f_ol(float alpha, float beta, float i) {
        long double r81689 = alpha;
        long double r81690 = -9.161047768334243e+16;
        bool r81691 = r81689 < r81690;
        long double r81692 = i;
        long double r81693 = beta;
        long double r81694 = r81689 + r81693;
        long double r81695 = r81694 + r81692;
        long double r81696 = 2.0;
        long double r81697 = r81696 * r81692;
        long double r81698 = r81694 + r81697;
        long double r81699 = r81695 / r81698;
        long double r81700 = r81692 * r81699;
        long double r81701 = r81693 * r81689;
        long double r81702 = r81692 * r81695;
        long double r81703 = r81701 + r81702;
        long double r81704 = r81703 / r81698;
        long double r81705 = r81700 * r81704;
        long double r81706 = r81694 * r81698;
        long double r81707 = r81697 * r81698;
        long double r81708 = r81706 + r81707;
        long double r81709 = 1.0;
        long double r81710 = r81708 - r81709;
        long double r81711 = 1.0/r81710;
        long double r81712 = sqrt(r81711);
        long double r81713 = r81712 * r81712;
        long double r81714 = r81705 * r81713;
        bool r81715 = r81689 < r81709;
        long double r81716 = r81702 * r81703;
        long double r81717 = r81698 * r81698;
        long double r81718 = r81716 / r81717;
        long double r81719 = r81717 * r81717;
        long double r81720 = r81709 * r81709;
        long double r81721 = r81719 - r81720;
        long double r81722 = r81717 + r81709;
        long double r81723 = r81721 / r81722;
        long double r81724 = r81718 / r81723;
        long double r81725 = r81715 ? r81724 : r81714;
        long double r81726 = r81691 ? r81714 : r81725;
        return r81726;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r81727, r81728, r81729, r81730, r81731, r81732, r81733, r81734, r81735, r81736, r81737, r81738, r81739, r81740, r81741, r81742, r81743;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r81727);
        mpfr_init(r81728);
        mpfr_init(r81729);
        mpfr_init(r81730);
        mpfr_init(r81731);
        mpfr_init(r81732);
        mpfr_init(r81733);
        mpfr_init(r81734);
        mpfr_init(r81735);
        mpfr_init(r81736);
        mpfr_init(r81737);
        mpfr_init(r81738);
        mpfr_init(r81739);
        mpfr_init(r81740);
        mpfr_init(r81741);
        mpfr_init(r81742);
        mpfr_init(r81743);
}

double f_im(float alpha, float beta, float i) {
        mpfr_set_flt(r81727, i, MPFR_RNDN);
        mpfr_set_flt(r81728, alpha, MPFR_RNDN);
        mpfr_set_flt(r81729, beta, MPFR_RNDN);
        mpfr_add(r81730, r81728, r81729, MPFR_RNDN);
        mpfr_add(r81731, r81730, r81727, MPFR_RNDN);
        mpfr_mul(r81732, r81727, r81731, MPFR_RNDN);
        mpfr_mul(r81733, r81729, r81728, MPFR_RNDN);
        mpfr_add(r81734, r81733, r81732, MPFR_RNDN);
        mpfr_mul(r81735, r81732, r81734, MPFR_RNDN);
        mpfr_init_set_str(r81736, "2", 10, MPFR_RNDN);
        mpfr_mul(r81737, r81736, r81727, MPFR_RNDN);
        mpfr_add(r81738, r81730, r81737, MPFR_RNDN);
        mpfr_mul(r81739, r81738, r81738, MPFR_RNDN);
        mpfr_div(r81740, r81735, r81739, MPFR_RNDN);
        mpfr_init_set_str(r81741, "1.0", 10, MPFR_RNDN);
        mpfr_sub(r81742, r81739, r81741, MPFR_RNDN);
        mpfr_div(r81743, r81740, r81742, MPFR_RNDN);
        return mpfr_get_d(r81743, MPFR_RNDN);
}

