#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE problem 3.4.1 */

double f_if(float x) {
        float r74564 = 1.0;
        float r74565 = x;
        float r74566 = cos(r74565);
        float r74567 = r74564 - r74566;
        float r74568 = 2.0;
        float r74569 = pow(r74565, r74568);
        float r74570 = r74567 / r74569;
        return r74570;
}

double f_id(float x) {
        double r74571 = 1.0;
        double r74572 = x;
        double r74573 = cos(r74572);
        double r74574 = r74571 - r74573;
        double r74575 = 2.0;
        double r74576 = pow(r74572, r74575);
        double r74577 = r74574 / r74576;
        return r74577;
}

double f_il(float x) {
        long double r74578 = 1.0;
        long double r74579 = x;
        long double r74580 = cos(r74579);
        long double r74581 = r74578 - r74580;
        long double r74582 = 2.0;
        long double r74583 = pow(r74579, r74582);
        long double r74584 = r74581 / r74583;
        return r74584;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r74585 = x;
        float r74586 = 2.0;
        float r74587 = pow(r74585, r74586);
        float r74588 = 1.0/r74587;
        float r74589 = cos(r74585);
        float r74590 = r74588 * r74589;
        float r74591 = r74588 - r74590;
        return r74591;
}

double f_od(float x) {
        double r74592 = x;
        double r74593 = 2.0;
        double r74594 = pow(r74592, r74593);
        double r74595 = 1.0/r74594;
        double r74596 = cos(r74592);
        double r74597 = r74595 * r74596;
        double r74598 = r74595 - r74597;
        return r74598;
}

double f_ol(float x) {
        long double r74599 = x;
        long double r74600 = 2.0;
        long double r74601 = pow(r74599, r74600);
        long double r74602 = 1.0/r74601;
        long double r74603 = cos(r74599);
        long double r74604 = r74602 * r74603;
        long double r74605 = r74602 - r74604;
        return r74605;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r74606, r74607, r74608, r74609, r74610, r74611, r74612;

void setup_mpfr() {
        mpfr_set_default_prec(344);
        mpfr_init(r74606);
        mpfr_init(r74607);
        mpfr_init(r74608);
        mpfr_init(r74609);
        mpfr_init(r74610);
        mpfr_init(r74611);
        mpfr_init(r74612);
}

double f_im(float x) {
        mpfr_init_set_str(r74606, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r74607, x, MPFR_RNDN);
        mpfr_cos(r74608, r74607, MPFR_RNDN);
        mpfr_sub(r74609, r74606, r74608, MPFR_RNDN);
        mpfr_init_set_str(r74610, "2", 10, MPFR_RNDN);
        mpfr_pow(r74611, r74607, r74610, MPFR_RNDN);
        mpfr_div(r74612, r74609, r74611, MPFR_RNDN);
        return mpfr_get_d(r74612, MPFR_RNDN);
}

