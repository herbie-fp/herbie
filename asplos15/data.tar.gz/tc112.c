#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.cos on complex, real part */

double f_if(float re, float im) {
        float r84970 = 0.5;
        float r84971 = re;
        float r84972 = cos(r84971);
        float r84973 = r84970 * r84972;
        float r84974 = im;
        float r84975 = -r84974;
        float r84976 = exp(r84975);
        float r84977 = exp(r84974);
        float r84978 = r84976 + r84977;
        float r84979 = r84973 * r84978;
        return r84979;
}

double f_id(float re, float im) {
        double r84980 = 0.5;
        double r84981 = re;
        double r84982 = cos(r84981);
        double r84983 = r84980 * r84982;
        double r84984 = im;
        double r84985 = -r84984;
        double r84986 = exp(r84985);
        double r84987 = exp(r84984);
        double r84988 = r84986 + r84987;
        double r84989 = r84983 * r84988;
        return r84989;
}

double f_il(float re, float im) {
        long double r84990 = 0.5;
        long double r84991 = re;
        long double r84992 = cos(r84991);
        long double r84993 = r84990 * r84992;
        long double r84994 = im;
        long double r84995 = -r84994;
        long double r84996 = exp(r84995);
        long double r84997 = exp(r84994);
        long double r84998 = r84996 + r84997;
        long double r84999 = r84993 * r84998;
        return r84999;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r85000 = 0.5;
        float r85001 = re;
        float r85002 = cos(r85001);
        float r85003 = r85000 * r85002;
        float r85004 = im;
        float r85005 = exp(r85004);
        float r85006 = r85003 / r85005;
        float r85007 = r85003 * r85005;
        float r85008 = r85006 + r85007;
        return r85008;
}

double f_od(float re, float im) {
        double r85009 = 0.5;
        double r85010 = re;
        double r85011 = cos(r85010);
        double r85012 = r85009 * r85011;
        double r85013 = im;
        double r85014 = exp(r85013);
        double r85015 = r85012 / r85014;
        double r85016 = r85012 * r85014;
        double r85017 = r85015 + r85016;
        return r85017;
}

double f_ol(float re, float im) {
        long double r85018 = 0.5;
        long double r85019 = re;
        long double r85020 = cos(r85019);
        long double r85021 = r85018 * r85020;
        long double r85022 = im;
        long double r85023 = exp(r85022);
        long double r85024 = r85021 / r85023;
        long double r85025 = r85021 * r85023;
        long double r85026 = r85024 + r85025;
        return r85026;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r85027, r85028, r85029, r85030, r85031, r85032, r85033, r85034, r85035, r85036;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r85027);
        mpfr_init(r85028);
        mpfr_init(r85029);
        mpfr_init(r85030);
        mpfr_init(r85031);
        mpfr_init(r85032);
        mpfr_init(r85033);
        mpfr_init(r85034);
        mpfr_init(r85035);
        mpfr_init(r85036);
}

double f_im(float re, float im) {
        mpfr_init_set_str(r85027, "0.5", 10, MPFR_RNDN);
        mpfr_set_flt(r85028, re, MPFR_RNDN);
        mpfr_cos(r85029, r85028, MPFR_RNDN);
        mpfr_mul(r85030, r85027, r85029, MPFR_RNDN);
        mpfr_set_flt(r85031, im, MPFR_RNDN);
        mpfr_neg(r85032, r85031, MPFR_RNDN);
        mpfr_exp(r85033, r85032, MPFR_RNDN);
        mpfr_exp(r85034, r85031, MPFR_RNDN);
        mpfr_add(r85035, r85033, r85034, MPFR_RNDN);
        mpfr_mul(r85036, r85030, r85035, MPFR_RNDN);
        return mpfr_get_d(r85036, MPFR_RNDN);
}

