#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Falkner and Boettcher, Appendix B, 2 */

double f_if(float v) {
        float r76030 = 2.0;
        float r76031 = sqrt(r76030);
        float r76032 = 4.0;
        float r76033 = r76031 / r76032;
        float r76034 = 1.0;
        float r76035 = 3.0;
        float r76036 = v;
        float r76037 = r76036 * r76036;
        float r76038 = r76035 * r76037;
        float r76039 = r76034 - r76038;
        float r76040 = sqrt(r76039);
        float r76041 = r76033 * r76040;
        float r76042 = r76034 - r76037;
        float r76043 = r76041 * r76042;
        return r76043;
}

double f_id(float v) {
        double r76044 = 2.0;
        double r76045 = sqrt(r76044);
        double r76046 = 4.0;
        double r76047 = r76045 / r76046;
        double r76048 = 1.0;
        double r76049 = 3.0;
        double r76050 = v;
        double r76051 = r76050 * r76050;
        double r76052 = r76049 * r76051;
        double r76053 = r76048 - r76052;
        double r76054 = sqrt(r76053);
        double r76055 = r76047 * r76054;
        double r76056 = r76048 - r76051;
        double r76057 = r76055 * r76056;
        return r76057;
}

double f_il(float v) {
        long double r76058 = 2.0;
        long double r76059 = sqrt(r76058);
        long double r76060 = 4.0;
        long double r76061 = r76059 / r76060;
        long double r76062 = 1.0;
        long double r76063 = 3.0;
        long double r76064 = v;
        long double r76065 = r76064 * r76064;
        long double r76066 = r76063 * r76065;
        long double r76067 = r76062 - r76066;
        long double r76068 = sqrt(r76067);
        long double r76069 = r76061 * r76068;
        long double r76070 = r76062 - r76065;
        long double r76071 = r76069 * r76070;
        return r76071;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float v) {
        float r76072 = 0.3535533905932738;
        float r76073 = 1.0;
        float r76074 = 3.0;
        float r76075 = v;
        float r76076 = r76075 * r76075;
        float r76077 = r76074 * r76076;
        float r76078 = r76073 - r76077;
        float r76079 = sqrt(r76078);
        float r76080 = r76072 * r76079;
        float r76081 = r76080 * r76076;
        float r76082 = r76080 - r76081;
        return r76082;
}

double f_od(float v) {
        double r76083 = 0.3535533905932738;
        double r76084 = 1.0;
        double r76085 = 3.0;
        double r76086 = v;
        double r76087 = r76086 * r76086;
        double r76088 = r76085 * r76087;
        double r76089 = r76084 - r76088;
        double r76090 = sqrt(r76089);
        double r76091 = r76083 * r76090;
        double r76092 = r76091 * r76087;
        double r76093 = r76091 - r76092;
        return r76093;
}

double f_ol(float v) {
        long double r76094 = 0.3535533905932738;
        long double r76095 = 1.0;
        long double r76096 = 3.0;
        long double r76097 = v;
        long double r76098 = r76097 * r76097;
        long double r76099 = r76096 * r76098;
        long double r76100 = r76095 - r76099;
        long double r76101 = sqrt(r76100);
        long double r76102 = r76094 * r76101;
        long double r76103 = r76102 * r76098;
        long double r76104 = r76102 - r76103;
        return r76104;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r76105, r76106, r76107, r76108, r76109, r76110, r76111, r76112, r76113, r76114, r76115, r76116, r76117, r76118;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r76105);
        mpfr_init(r76106);
        mpfr_init(r76107);
        mpfr_init(r76108);
        mpfr_init(r76109);
        mpfr_init(r76110);
        mpfr_init(r76111);
        mpfr_init(r76112);
        mpfr_init(r76113);
        mpfr_init(r76114);
        mpfr_init(r76115);
        mpfr_init(r76116);
        mpfr_init(r76117);
        mpfr_init(r76118);
}

double f_im(float v) {
        mpfr_init_set_str(r76105, "2", 10, MPFR_RNDN);
        mpfr_sqrt(r76106, r76105, MPFR_RNDN);
        mpfr_init_set_str(r76107, "4", 10, MPFR_RNDN);
        mpfr_div(r76108, r76106, r76107, MPFR_RNDN);
        mpfr_init_set_str(r76109, "1", 10, MPFR_RNDN);
        mpfr_init_set_str(r76110, "3", 10, MPFR_RNDN);
        mpfr_set_flt(r76111, v, MPFR_RNDN);
        mpfr_mul(r76112, r76111, r76111, MPFR_RNDN);
        mpfr_mul(r76113, r76110, r76112, MPFR_RNDN);
        mpfr_sub(r76114, r76109, r76113, MPFR_RNDN);
        mpfr_sqrt(r76115, r76114, MPFR_RNDN);
        mpfr_mul(r76116, r76108, r76115, MPFR_RNDN);
        mpfr_sub(r76117, r76109, r76112, MPFR_RNDN);
        mpfr_mul(r76118, r76116, r76117, MPFR_RNDN);
        return mpfr_get_d(r76118, MPFR_RNDN);
}

