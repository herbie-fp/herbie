#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Toniolo and Linder, Equation (7) */

double f_if(float x, float l, float t) {
        float r83739 = 2.0;
        float r83740 = sqrt(r83739);
        float r83741 = t;
        float r83742 = r83740 * r83741;
        float r83743 = x;
        float r83744 = 1.0;
        float r83745 = r83743 + r83744;
        float r83746 = r83743 - r83744;
        float r83747 = r83745 / r83746;
        float r83748 = l;
        float r83749 = r83748 * r83748;
        float r83750 = r83741 * r83741;
        float r83751 = r83739 * r83750;
        float r83752 = r83749 + r83751;
        float r83753 = r83747 * r83752;
        float r83754 = r83753 - r83749;
        float r83755 = sqrt(r83754);
        float r83756 = r83742 / r83755;
        return r83756;
}

double f_id(float x, float l, float t) {
        double r83757 = 2.0;
        double r83758 = sqrt(r83757);
        double r83759 = t;
        double r83760 = r83758 * r83759;
        double r83761 = x;
        double r83762 = 1.0;
        double r83763 = r83761 + r83762;
        double r83764 = r83761 - r83762;
        double r83765 = r83763 / r83764;
        double r83766 = l;
        double r83767 = r83766 * r83766;
        double r83768 = r83759 * r83759;
        double r83769 = r83757 * r83768;
        double r83770 = r83767 + r83769;
        double r83771 = r83765 * r83770;
        double r83772 = r83771 - r83767;
        double r83773 = sqrt(r83772);
        double r83774 = r83760 / r83773;
        return r83774;
}

double f_il(float x, float l, float t) {
        long double r83775 = 2.0;
        long double r83776 = sqrt(r83775);
        long double r83777 = t;
        long double r83778 = r83776 * r83777;
        long double r83779 = x;
        long double r83780 = 1.0;
        long double r83781 = r83779 + r83780;
        long double r83782 = r83779 - r83780;
        long double r83783 = r83781 / r83782;
        long double r83784 = l;
        long double r83785 = r83784 * r83784;
        long double r83786 = r83777 * r83777;
        long double r83787 = r83775 * r83786;
        long double r83788 = r83785 + r83787;
        long double r83789 = r83783 * r83788;
        long double r83790 = r83789 - r83785;
        long double r83791 = sqrt(r83790);
        long double r83792 = r83778 / r83791;
        return r83792;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x, float l, float t) {
        float r83793 = x;
        float r83794 = -9.161047768334243e+16;
        bool r83795 = r83793 < r83794;
        float r83796 = 2.0;
        float r83797 = sqrt(r83796);
        float r83798 = t;
        float r83799 = r83797 * r83798;
        float r83800 = 1.0;
        float r83801 = r83793 + r83800;
        float r83802 = r83793 - r83800;
        float r83803 = r83801 / r83802;
        float r83804 = l;
        float r83805 = r83804 * r83804;
        float r83806 = r83798 * r83798;
        float r83807 = r83796 * r83806;
        float r83808 = r83805 + r83807;
        float r83809 = r83803 * r83808;
        float r83810 = r83809 * r83809;
        float r83811 = r83810 * r83810;
        float r83812 = r83805 * r83805;
        float r83813 = r83812 * r83812;
        float r83814 = r83811 - r83813;
        float r83815 = r83810 - r83812;
        float r83816 = r83814 / r83815;
        float r83817 = r83814 / r83816;
        float r83818 = r83809 + r83805;
        float r83819 = r83817 / r83818;
        float r83820 = sqrt(r83819);
        float r83821 = r83799 / r83820;
        float r83822 = r83807 * r83807;
        float r83823 = r83812 - r83822;
        float r83824 = r83801 * r83823;
        float r83825 = r83805 - r83807;
        float r83826 = r83802 * r83825;
        float r83827 = r83824 / r83826;
        float r83828 = r83827 * r83827;
        float r83829 = r83828 - r83812;
        float r83830 = log(r83812);
        float r83831 = exp(r83830);
        float r83832 = r83831 - r83822;
        float r83833 = r83801 * r83832;
        float r83834 = r83833 / r83826;
        float r83835 = r83834 + r83805;
        float r83836 = sqrt(r83835);
        float r83837 = r83836 * r83836;
        float r83838 = r83829 / r83837;
        float r83839 = sqrt(r83838);
        float r83840 = r83799 / r83839;
        float r83841 = r83795 ? r83821 : r83840;
        return r83841;
}

double f_od(float x, float l, float t) {
        double r83842 = x;
        double r83843 = -9.161047768334243e+16;
        bool r83844 = r83842 < r83843;
        double r83845 = 2.0;
        double r83846 = sqrt(r83845);
        double r83847 = t;
        double r83848 = r83846 * r83847;
        double r83849 = 1.0;
        double r83850 = r83842 + r83849;
        double r83851 = r83842 - r83849;
        double r83852 = r83850 / r83851;
        double r83853 = l;
        double r83854 = r83853 * r83853;
        double r83855 = r83847 * r83847;
        double r83856 = r83845 * r83855;
        double r83857 = r83854 + r83856;
        double r83858 = r83852 * r83857;
        double r83859 = r83858 * r83858;
        double r83860 = r83859 * r83859;
        double r83861 = r83854 * r83854;
        double r83862 = r83861 * r83861;
        double r83863 = r83860 - r83862;
        double r83864 = r83859 - r83861;
        double r83865 = r83863 / r83864;
        double r83866 = r83863 / r83865;
        double r83867 = r83858 + r83854;
        double r83868 = r83866 / r83867;
        double r83869 = sqrt(r83868);
        double r83870 = r83848 / r83869;
        double r83871 = r83856 * r83856;
        double r83872 = r83861 - r83871;
        double r83873 = r83850 * r83872;
        double r83874 = r83854 - r83856;
        double r83875 = r83851 * r83874;
        double r83876 = r83873 / r83875;
        double r83877 = r83876 * r83876;
        double r83878 = r83877 - r83861;
        double r83879 = log(r83861);
        double r83880 = exp(r83879);
        double r83881 = r83880 - r83871;
        double r83882 = r83850 * r83881;
        double r83883 = r83882 / r83875;
        double r83884 = r83883 + r83854;
        double r83885 = sqrt(r83884);
        double r83886 = r83885 * r83885;
        double r83887 = r83878 / r83886;
        double r83888 = sqrt(r83887);
        double r83889 = r83848 / r83888;
        double r83890 = r83844 ? r83870 : r83889;
        return r83890;
}

double f_ol(float x, float l, float t) {
        long double r83891 = x;
        long double r83892 = -9.161047768334243e+16;
        bool r83893 = r83891 < r83892;
        long double r83894 = 2.0;
        long double r83895 = sqrt(r83894);
        long double r83896 = t;
        long double r83897 = r83895 * r83896;
        long double r83898 = 1.0;
        long double r83899 = r83891 + r83898;
        long double r83900 = r83891 - r83898;
        long double r83901 = r83899 / r83900;
        long double r83902 = l;
        long double r83903 = r83902 * r83902;
        long double r83904 = r83896 * r83896;
        long double r83905 = r83894 * r83904;
        long double r83906 = r83903 + r83905;
        long double r83907 = r83901 * r83906;
        long double r83908 = r83907 * r83907;
        long double r83909 = r83908 * r83908;
        long double r83910 = r83903 * r83903;
        long double r83911 = r83910 * r83910;
        long double r83912 = r83909 - r83911;
        long double r83913 = r83908 - r83910;
        long double r83914 = r83912 / r83913;
        long double r83915 = r83912 / r83914;
        long double r83916 = r83907 + r83903;
        long double r83917 = r83915 / r83916;
        long double r83918 = sqrt(r83917);
        long double r83919 = r83897 / r83918;
        long double r83920 = r83905 * r83905;
        long double r83921 = r83910 - r83920;
        long double r83922 = r83899 * r83921;
        long double r83923 = r83903 - r83905;
        long double r83924 = r83900 * r83923;
        long double r83925 = r83922 / r83924;
        long double r83926 = r83925 * r83925;
        long double r83927 = r83926 - r83910;
        long double r83928 = log(r83910);
        long double r83929 = exp(r83928);
        long double r83930 = r83929 - r83920;
        long double r83931 = r83899 * r83930;
        long double r83932 = r83931 / r83924;
        long double r83933 = r83932 + r83903;
        long double r83934 = sqrt(r83933);
        long double r83935 = r83934 * r83934;
        long double r83936 = r83927 / r83935;
        long double r83937 = sqrt(r83936);
        long double r83938 = r83897 / r83937;
        long double r83939 = r83893 ? r83919 : r83938;
        return r83939;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r83940, r83941, r83942, r83943, r83944, r83945, r83946, r83947, r83948, r83949, r83950, r83951, r83952, r83953, r83954, r83955, r83956, r83957;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r83940);
        mpfr_init(r83941);
        mpfr_init(r83942);
        mpfr_init(r83943);
        mpfr_init(r83944);
        mpfr_init(r83945);
        mpfr_init(r83946);
        mpfr_init(r83947);
        mpfr_init(r83948);
        mpfr_init(r83949);
        mpfr_init(r83950);
        mpfr_init(r83951);
        mpfr_init(r83952);
        mpfr_init(r83953);
        mpfr_init(r83954);
        mpfr_init(r83955);
        mpfr_init(r83956);
        mpfr_init(r83957);
}

double f_im(float x, float l, float t) {
        mpfr_init_set_str(r83940, "2", 10, MPFR_RNDN);
        mpfr_sqrt(r83941, r83940, MPFR_RNDN);
        mpfr_set_flt(r83942, t, MPFR_RNDN);
        mpfr_mul(r83943, r83941, r83942, MPFR_RNDN);
        mpfr_set_flt(r83944, x, MPFR_RNDN);
        mpfr_init_set_str(r83945, "1", 10, MPFR_RNDN);
        mpfr_add(r83946, r83944, r83945, MPFR_RNDN);
        mpfr_sub(r83947, r83944, r83945, MPFR_RNDN);
        mpfr_div(r83948, r83946, r83947, MPFR_RNDN);
        mpfr_set_flt(r83949, l, MPFR_RNDN);
        mpfr_mul(r83950, r83949, r83949, MPFR_RNDN);
        mpfr_mul(r83951, r83942, r83942, MPFR_RNDN);
        mpfr_mul(r83952, r83940, r83951, MPFR_RNDN);
        mpfr_add(r83953, r83950, r83952, MPFR_RNDN);
        mpfr_mul(r83954, r83948, r83953, MPFR_RNDN);
        mpfr_sub(r83955, r83954, r83950, MPFR_RNDN);
        mpfr_sqrt(r83956, r83955, MPFR_RNDN);
        mpfr_div(r83957, r83943, r83956, MPFR_RNDN);
        return mpfr_get_d(r83957, MPFR_RNDN);
}

