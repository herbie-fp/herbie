#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Hyperbolic arc-cosine */

double f_if(float x) {
        float r77267 = x;
        float r77268 = r77267 * r77267;
        float r77269 = 1.0;
        float r77270 = r77268 - r77269;
        float r77271 = sqrt(r77270);
        float r77272 = r77267 + r77271;
        float r77273 = log(r77272);
        return r77273;
}

double f_id(float x) {
        double r77274 = x;
        double r77275 = r77274 * r77274;
        double r77276 = 1.0;
        double r77277 = r77275 - r77276;
        double r77278 = sqrt(r77277);
        double r77279 = r77274 + r77278;
        double r77280 = log(r77279);
        return r77280;
}

double f_il(float x) {
        long double r77281 = x;
        long double r77282 = r77281 * r77281;
        long double r77283 = 1.0;
        long double r77284 = r77282 - r77283;
        long double r77285 = sqrt(r77284);
        long double r77286 = r77281 + r77285;
        long double r77287 = log(r77286);
        return r77287;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r77288 = x;
        float r77289 = r77288 * r77288;
        float r77290 = r77289 * r77289;
        float r77291 = -1.0;
        float r77292 = r77291 * r77291;
        float r77293 = r77290 - r77292;
        float r77294 = sqrt(r77293);
        float r77295 = r77289 - r77291;
        float r77296 = sqrt(r77295);
        float r77297 = r77294 / r77296;
        float r77298 = r77288 + r77297;
        float r77299 = log(r77298);
        return r77299;
}

double f_od(float x) {
        double r77300 = x;
        double r77301 = r77300 * r77300;
        double r77302 = r77301 * r77301;
        double r77303 = -1.0;
        double r77304 = r77303 * r77303;
        double r77305 = r77302 - r77304;
        double r77306 = sqrt(r77305);
        double r77307 = r77301 - r77303;
        double r77308 = sqrt(r77307);
        double r77309 = r77306 / r77308;
        double r77310 = r77300 + r77309;
        double r77311 = log(r77310);
        return r77311;
}

double f_ol(float x) {
        long double r77312 = x;
        long double r77313 = r77312 * r77312;
        long double r77314 = r77313 * r77313;
        long double r77315 = -1.0;
        long double r77316 = r77315 * r77315;
        long double r77317 = r77314 - r77316;
        long double r77318 = sqrt(r77317);
        long double r77319 = r77313 - r77315;
        long double r77320 = sqrt(r77319);
        long double r77321 = r77318 / r77320;
        long double r77322 = r77312 + r77321;
        long double r77323 = log(r77322);
        return r77323;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r77324, r77325, r77326, r77327, r77328, r77329, r77330;

void setup_mpfr() {
        mpfr_set_default_prec(280);
        mpfr_init(r77324);
        mpfr_init(r77325);
        mpfr_init(r77326);
        mpfr_init(r77327);
        mpfr_init(r77328);
        mpfr_init(r77329);
        mpfr_init(r77330);
}

double f_im(float x) {
        mpfr_set_flt(r77324, x, MPFR_RNDN);
        mpfr_mul(r77325, r77324, r77324, MPFR_RNDN);
        mpfr_init_set_str(r77326, "1", 10, MPFR_RNDN);
        mpfr_sub(r77327, r77325, r77326, MPFR_RNDN);
        mpfr_sqrt(r77328, r77327, MPFR_RNDN);
        mpfr_add(r77329, r77324, r77328, MPFR_RNDN);
        mpfr_log(r77330, r77329, MPFR_RNDN);
        return mpfr_get_d(r77330, MPFR_RNDN);
}

