#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.abs on complex */

double f_if(float re, float im) {
        float r84671 = re;
        float r84672 = r84671 * r84671;
        float r84673 = im;
        float r84674 = r84673 * r84673;
        float r84675 = r84672 + r84674;
        float r84676 = sqrt(r84675);
        return r84676;
}

double f_id(float re, float im) {
        double r84677 = re;
        double r84678 = r84677 * r84677;
        double r84679 = im;
        double r84680 = r84679 * r84679;
        double r84681 = r84678 + r84680;
        double r84682 = sqrt(r84681);
        return r84682;
}

double f_il(float re, float im) {
        long double r84683 = re;
        long double r84684 = r84683 * r84683;
        long double r84685 = im;
        long double r84686 = r84685 * r84685;
        long double r84687 = r84684 + r84686;
        long double r84688 = sqrt(r84687);
        return r84688;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r84689 = re;
        float r84690 = r84689 * r84689;
        float r84691 = im;
        float r84692 = r84691 * r84691;
        float r84693 = r84690 + r84692;
        float r84694 = sqrt(r84693);
        return r84694;
}

double f_od(float re, float im) {
        double r84695 = re;
        double r84696 = r84695 * r84695;
        double r84697 = im;
        double r84698 = r84697 * r84697;
        double r84699 = r84696 + r84698;
        double r84700 = sqrt(r84699);
        return r84700;
}

double f_ol(float re, float im) {
        long double r84701 = re;
        long double r84702 = r84701 * r84701;
        long double r84703 = im;
        long double r84704 = r84703 * r84703;
        long double r84705 = r84702 + r84704;
        long double r84706 = sqrt(r84705);
        return r84706;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r84707, r84708, r84709, r84710, r84711, r84712;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r84707);
        mpfr_init(r84708);
        mpfr_init(r84709);
        mpfr_init(r84710);
        mpfr_init(r84711);
        mpfr_init(r84712);
}

double f_im(float re, float im) {
        mpfr_set_flt(r84707, re, MPFR_RNDN);
        mpfr_mul(r84708, r84707, r84707, MPFR_RNDN);
        mpfr_set_flt(r84709, im, MPFR_RNDN);
        mpfr_mul(r84710, r84709, r84709, MPFR_RNDN);
        mpfr_add(r84711, r84708, r84710, MPFR_RNDN);
        mpfr_sqrt(r84712, r84711, MPFR_RNDN);
        return mpfr_get_d(r84712, MPFR_RNDN);
}

