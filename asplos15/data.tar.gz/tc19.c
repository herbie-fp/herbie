#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Logistic regression 2 */

double f_if(float x, float y) {
        float r73444 = 1.0;
        float r73445 = x;
        float r73446 = exp(r73445);
        float r73447 = r73444 + r73446;
        float r73448 = log(r73447);
        float r73449 = y;
        float r73450 = r73445 * r73449;
        float r73451 = r73448 - r73450;
        return r73451;
}

double f_id(float x, float y) {
        double r73452 = 1.0;
        double r73453 = x;
        double r73454 = exp(r73453);
        double r73455 = r73452 + r73454;
        double r73456 = log(r73455);
        double r73457 = y;
        double r73458 = r73453 * r73457;
        double r73459 = r73456 - r73458;
        return r73459;
}

double f_il(float x, float y) {
        long double r73460 = 1.0;
        long double r73461 = x;
        long double r73462 = exp(r73461);
        long double r73463 = r73460 + r73462;
        long double r73464 = log(r73463);
        long double r73465 = y;
        long double r73466 = r73461 * r73465;
        long double r73467 = r73464 - r73466;
        return r73467;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x, float y) {
        float r73468 = x;
        float r73469 = -4.935130638702295e-10;
        bool r73470 = r73468 < r73469;
        float r73471 = 1.0;
        float r73472 = exp(r73468);
        float r73473 = r73471 + r73472;
        float r73474 = sqrt(r73473);
        float r73475 = r73474 * r73474;
        float r73476 = log(r73475);
        float r73477 = y;
        float r73478 = r73468 * r73477;
        float r73479 = r73476 - r73478;
        float r73480 = log(r73473);
        float r73481 = r73480 - r73478;
        float r73482 = r73470 ? r73479 : r73481;
        return r73482;
}

double f_od(float x, float y) {
        double r73483 = x;
        double r73484 = -4.935130638702295e-10;
        bool r73485 = r73483 < r73484;
        double r73486 = 1.0;
        double r73487 = exp(r73483);
        double r73488 = r73486 + r73487;
        double r73489 = sqrt(r73488);
        double r73490 = r73489 * r73489;
        double r73491 = log(r73490);
        double r73492 = y;
        double r73493 = r73483 * r73492;
        double r73494 = r73491 - r73493;
        double r73495 = log(r73488);
        double r73496 = r73495 - r73493;
        double r73497 = r73485 ? r73494 : r73496;
        return r73497;
}

double f_ol(float x, float y) {
        long double r73498 = x;
        long double r73499 = -4.935130638702295e-10;
        bool r73500 = r73498 < r73499;
        long double r73501 = 1.0;
        long double r73502 = exp(r73498);
        long double r73503 = r73501 + r73502;
        long double r73504 = sqrt(r73503);
        long double r73505 = r73504 * r73504;
        long double r73506 = log(r73505);
        long double r73507 = y;
        long double r73508 = r73498 * r73507;
        long double r73509 = r73506 - r73508;
        long double r73510 = log(r73503);
        long double r73511 = r73510 - r73508;
        long double r73512 = r73500 ? r73509 : r73511;
        return r73512;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r73513, r73514, r73515, r73516, r73517, r73518, r73519, r73520;

void setup_mpfr() {
        mpfr_set_default_prec(152);
        mpfr_init(r73513);
        mpfr_init(r73514);
        mpfr_init(r73515);
        mpfr_init(r73516);
        mpfr_init(r73517);
        mpfr_init(r73518);
        mpfr_init(r73519);
        mpfr_init(r73520);
}

double f_im(float x, float y) {
        mpfr_init_set_str(r73513, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r73514, x, MPFR_RNDN);
        mpfr_exp(r73515, r73514, MPFR_RNDN);
        mpfr_add(r73516, r73513, r73515, MPFR_RNDN);
        mpfr_log(r73517, r73516, MPFR_RNDN);
        mpfr_set_flt(r73518, y, MPFR_RNDN);
        mpfr_mul(r73519, r73514, r73518, MPFR_RNDN);
        mpfr_sub(r73520, r73517, r73519, MPFR_RNDN);
        return mpfr_get_d(r73520, MPFR_RNDN);
}

