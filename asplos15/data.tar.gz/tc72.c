#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Migdal et al, Equation (51) */

double f_if(float k, float n) {
        float r79836 = k;
        float r79837 = sqrt(r79836);
        float r79838 = 1.0/r79837;
        float r79839 = 2.0;
        float r79840 = atan2(1.0, 0.0);
        float r79841 = r79839 * r79840;
        float r79842 = n;
        float r79843 = r79841 * r79842;
        float r79844 = 1.0;
        float r79845 = r79844 - r79836;
        float r79846 = r79845 / r79839;
        float r79847 = pow(r79843, r79846);
        float r79848 = r79838 * r79847;
        return r79848;
}

double f_id(float k, float n) {
        double r79849 = k;
        double r79850 = sqrt(r79849);
        double r79851 = 1.0/r79850;
        double r79852 = 2.0;
        double r79853 = atan2(1.0, 0.0);
        double r79854 = r79852 * r79853;
        double r79855 = n;
        double r79856 = r79854 * r79855;
        double r79857 = 1.0;
        double r79858 = r79857 - r79849;
        double r79859 = r79858 / r79852;
        double r79860 = pow(r79856, r79859);
        double r79861 = r79851 * r79860;
        return r79861;
}

double f_il(float k, float n) {
        long double r79862 = k;
        long double r79863 = sqrt(r79862);
        long double r79864 = 1.0/r79863;
        long double r79865 = 2.0;
        long double r79866 = atan2(1.0, 0.0);
        long double r79867 = r79865 * r79866;
        long double r79868 = n;
        long double r79869 = r79867 * r79868;
        long double r79870 = 1.0;
        long double r79871 = r79870 - r79862;
        long double r79872 = r79871 / r79865;
        long double r79873 = pow(r79869, r79872);
        long double r79874 = r79864 * r79873;
        return r79874;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float k, float n) {
        float r79875 = k;
        float r79876 = sqrt(r79875);
        float r79877 = 1.0/r79876;
        float r79878 = 2.0;
        float r79879 = atan2(1.0, 0.0);
        float r79880 = r79878 * r79879;
        float r79881 = n;
        float r79882 = r79880 * r79881;
        float r79883 = 1.0;
        float r79884 = r79883 - r79875;
        float r79885 = r79884 / r79878;
        float r79886 = pow(r79882, r79885);
        float r79887 = r79877 * r79886;
        return r79887;
}

double f_od(float k, float n) {
        double r79888 = k;
        double r79889 = sqrt(r79888);
        double r79890 = 1.0/r79889;
        double r79891 = 2.0;
        double r79892 = atan2(1.0, 0.0);
        double r79893 = r79891 * r79892;
        double r79894 = n;
        double r79895 = r79893 * r79894;
        double r79896 = 1.0;
        double r79897 = r79896 - r79888;
        double r79898 = r79897 / r79891;
        double r79899 = pow(r79895, r79898);
        double r79900 = r79890 * r79899;
        return r79900;
}

double f_ol(float k, float n) {
        long double r79901 = k;
        long double r79902 = sqrt(r79901);
        long double r79903 = 1.0/r79902;
        long double r79904 = 2.0;
        long double r79905 = atan2(1.0, 0.0);
        long double r79906 = r79904 * r79905;
        long double r79907 = n;
        long double r79908 = r79906 * r79907;
        long double r79909 = 1.0;
        long double r79910 = r79909 - r79901;
        long double r79911 = r79910 / r79904;
        long double r79912 = pow(r79908, r79911);
        long double r79913 = r79903 * r79912;
        return r79913;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r79914, r79915, r79916, r79917, r79918, r79919, r79920, r79921, r79922, r79923, r79924, r79925, r79926;

void setup_mpfr() {
        mpfr_set_default_prec(152);
        mpfr_init(r79914);
        mpfr_init(r79915);
        mpfr_init(r79916);
        mpfr_init(r79917);
        mpfr_init(r79918);
        mpfr_init(r79919);
        mpfr_init(r79920);
        mpfr_init(r79921);
        mpfr_init(r79922);
        mpfr_init(r79923);
        mpfr_init(r79924);
        mpfr_init(r79925);
        mpfr_init(r79926);
}

double f_im(float k, float n) {
        mpfr_set_flt(r79914, k, MPFR_RNDN);
        mpfr_sqrt(r79915, r79914, MPFR_RNDN);
        mpfr_ui_div(r79916, 1, r79915, MPFR_RNDN);
        mpfr_init_set_str(r79917, "2", 10, MPFR_RNDN);
        mpfr_const_pi(r79918, MPFR_RNDN);
        mpfr_mul(r79919, r79917, r79918, MPFR_RNDN);
        mpfr_set_flt(r79920, n, MPFR_RNDN);
        mpfr_mul(r79921, r79919, r79920, MPFR_RNDN);
        mpfr_init_set_str(r79922, "1", 10, MPFR_RNDN);
        mpfr_sub(r79923, r79922, r79914, MPFR_RNDN);
        mpfr_div(r79924, r79923, r79917, MPFR_RNDN);
        mpfr_pow(r79925, r79921, r79924, MPFR_RNDN);
        mpfr_mul(r79926, r79916, r79925, MPFR_RNDN);
        return mpfr_get_d(r79926, MPFR_RNDN);
}

