#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* A la Freetype's FT_MulDiv */

double f_if(float a, float b, float c) {
        float r75069 = a;
        float r75070 = c;
        float r75071 = 2.0;
        float r75072 = r75070 / r75071;
        float r75073 = r75069 + r75072;
        float r75074 = b;
        float r75075 = r75073 / r75074;
        return r75075;
}

double f_id(float a, float b, float c) {
        double r75076 = a;
        double r75077 = c;
        double r75078 = 2.0;
        double r75079 = r75077 / r75078;
        double r75080 = r75076 + r75079;
        double r75081 = b;
        double r75082 = r75080 / r75081;
        return r75082;
}

double f_il(float a, float b, float c) {
        long double r75083 = a;
        long double r75084 = c;
        long double r75085 = 2.0;
        long double r75086 = r75084 / r75085;
        long double r75087 = r75083 + r75086;
        long double r75088 = b;
        long double r75089 = r75087 / r75088;
        return r75089;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a, float b, float c) {
        float r75090 = a;
        float r75091 = c;
        float r75092 = 2.0;
        float r75093 = r75091 / r75092;
        float r75094 = r75090 + r75093;
        float r75095 = b;
        float r75096 = r75094 / r75095;
        return r75096;
}

double f_od(float a, float b, float c) {
        double r75097 = a;
        double r75098 = c;
        double r75099 = 2.0;
        double r75100 = r75098 / r75099;
        double r75101 = r75097 + r75100;
        double r75102 = b;
        double r75103 = r75101 / r75102;
        return r75103;
}

double f_ol(float a, float b, float c) {
        long double r75104 = a;
        long double r75105 = c;
        long double r75106 = 2.0;
        long double r75107 = r75105 / r75106;
        long double r75108 = r75104 + r75107;
        long double r75109 = b;
        long double r75110 = r75108 / r75109;
        return r75110;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r75111, r75112, r75113, r75114, r75115, r75116, r75117;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r75111);
        mpfr_init(r75112);
        mpfr_init(r75113);
        mpfr_init(r75114);
        mpfr_init(r75115);
        mpfr_init(r75116);
        mpfr_init(r75117);
}

double f_im(float a, float b, float c) {
        mpfr_set_flt(r75111, a, MPFR_RNDN);
        mpfr_set_flt(r75112, c, MPFR_RNDN);
        mpfr_init_set_str(r75113, "2", 10, MPFR_RNDN);
        mpfr_div(r75114, r75112, r75113, MPFR_RNDN);
        mpfr_add(r75115, r75111, r75114, MPFR_RNDN);
        mpfr_set_flt(r75116, b, MPFR_RNDN);
        mpfr_div(r75117, r75115, r75116, MPFR_RNDN);
        return mpfr_get_d(r75117, MPFR_RNDN);
}

