#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Bouland and Aaronson, Equation (25) */

double f_if(float a, float b) {
        float r75337 = a;
        float r75338 = r75337 * r75337;
        float r75339 = b;
        float r75340 = r75339 * r75339;
        float r75341 = r75338 + r75340;
        float r75342 = r75341 * r75341;
        float r75343 = 4.0;
        float r75344 = 1.0;
        float r75345 = r75344 + r75337;
        float r75346 = r75338 * r75345;
        float r75347 = 3.0;
        float r75348 = r75347 * r75337;
        float r75349 = r75344 - r75348;
        float r75350 = r75340 * r75349;
        float r75351 = r75346 + r75350;
        float r75352 = r75343 * r75351;
        float r75353 = r75342 + r75352;
        float r75354 = r75353 - r75344;
        return r75354;
}

double f_id(float a, float b) {
        double r75355 = a;
        double r75356 = r75355 * r75355;
        double r75357 = b;
        double r75358 = r75357 * r75357;
        double r75359 = r75356 + r75358;
        double r75360 = r75359 * r75359;
        double r75361 = 4.0;
        double r75362 = 1.0;
        double r75363 = r75362 + r75355;
        double r75364 = r75356 * r75363;
        double r75365 = 3.0;
        double r75366 = r75365 * r75355;
        double r75367 = r75362 - r75366;
        double r75368 = r75358 * r75367;
        double r75369 = r75364 + r75368;
        double r75370 = r75361 * r75369;
        double r75371 = r75360 + r75370;
        double r75372 = r75371 - r75362;
        return r75372;
}

double f_il(float a, float b) {
        long double r75373 = a;
        long double r75374 = r75373 * r75373;
        long double r75375 = b;
        long double r75376 = r75375 * r75375;
        long double r75377 = r75374 + r75376;
        long double r75378 = r75377 * r75377;
        long double r75379 = 4.0;
        long double r75380 = 1.0;
        long double r75381 = r75380 + r75373;
        long double r75382 = r75374 * r75381;
        long double r75383 = 3.0;
        long double r75384 = r75383 * r75373;
        long double r75385 = r75380 - r75384;
        long double r75386 = r75376 * r75385;
        long double r75387 = r75382 + r75386;
        long double r75388 = r75379 * r75387;
        long double r75389 = r75378 + r75388;
        long double r75390 = r75389 - r75380;
        return r75390;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a, float b) {
        float r75391 = a;
        float r75392 = -2.374520147406146e+26;
        bool r75393 = r75391 < r75392;
        float r75394 = r75391 * r75391;
        float r75395 = r75394 * r75394;
        float r75396 = b;
        float r75397 = r75396 * r75396;
        float r75398 = r75397 * r75397;
        float r75399 = r75395 - r75398;
        float r75400 = r75399 * r75399;
        float r75401 = r75394 - r75397;
        float r75402 = r75391 + r75396;
        float r75403 = r75391 - r75396;
        float r75404 = r75402 * r75403;
        float r75405 = r75401 * r75401;
        float r75406 = r75404 * r75405;
        float r75407 = r75401 * r75406;
        float r75408 = r75402 * r75402;
        float r75409 = r75403 * r75408;
        float r75410 = r75403 * r75409;
        float r75411 = r75407 / r75410;
        float r75412 = r75400 / r75411;
        float r75413 = 4.0;
        float r75414 = 1.0;
        float r75415 = r75414 + r75391;
        float r75416 = r75394 * r75415;
        float r75417 = 3.0;
        float r75418 = r75417 * r75391;
        float r75419 = r75414 - r75418;
        float r75420 = r75397 * r75419;
        float r75421 = r75416 + r75420;
        float r75422 = r75413 * r75421;
        float r75423 = r75412 + r75422;
        float r75424 = r75423 - r75414;
        float r75425 = 51458982194205.95;
        bool r75426 = r75391 < r75425;
        float r75427 = r75394 + r75397;
        float r75428 = r75427 * r75427;
        float r75429 = r75428 + r75422;
        float r75430 = r75429 - r75414;
        float r75431 = 2.2077063450382992e+25;
        bool r75432 = r75391 < r75431;
        float r75433 = r75427 * r75401;
        float r75434 = r75433 * r75433;
        float r75435 = r75434 / r75405;
        float r75436 = r75435 + r75422;
        float r75437 = r75436 - r75414;
        float r75438 = r75432 ? r75424 : r75437;
        float r75439 = r75426 ? r75430 : r75438;
        float r75440 = r75393 ? r75424 : r75439;
        return r75440;
}

double f_od(float a, float b) {
        double r75441 = a;
        double r75442 = -2.374520147406146e+26;
        bool r75443 = r75441 < r75442;
        double r75444 = r75441 * r75441;
        double r75445 = r75444 * r75444;
        double r75446 = b;
        double r75447 = r75446 * r75446;
        double r75448 = r75447 * r75447;
        double r75449 = r75445 - r75448;
        double r75450 = r75449 * r75449;
        double r75451 = r75444 - r75447;
        double r75452 = r75441 + r75446;
        double r75453 = r75441 - r75446;
        double r75454 = r75452 * r75453;
        double r75455 = r75451 * r75451;
        double r75456 = r75454 * r75455;
        double r75457 = r75451 * r75456;
        double r75458 = r75452 * r75452;
        double r75459 = r75453 * r75458;
        double r75460 = r75453 * r75459;
        double r75461 = r75457 / r75460;
        double r75462 = r75450 / r75461;
        double r75463 = 4.0;
        double r75464 = 1.0;
        double r75465 = r75464 + r75441;
        double r75466 = r75444 * r75465;
        double r75467 = 3.0;
        double r75468 = r75467 * r75441;
        double r75469 = r75464 - r75468;
        double r75470 = r75447 * r75469;
        double r75471 = r75466 + r75470;
        double r75472 = r75463 * r75471;
        double r75473 = r75462 + r75472;
        double r75474 = r75473 - r75464;
        double r75475 = 51458982194205.95;
        bool r75476 = r75441 < r75475;
        double r75477 = r75444 + r75447;
        double r75478 = r75477 * r75477;
        double r75479 = r75478 + r75472;
        double r75480 = r75479 - r75464;
        double r75481 = 2.2077063450382992e+25;
        bool r75482 = r75441 < r75481;
        double r75483 = r75477 * r75451;
        double r75484 = r75483 * r75483;
        double r75485 = r75484 / r75455;
        double r75486 = r75485 + r75472;
        double r75487 = r75486 - r75464;
        double r75488 = r75482 ? r75474 : r75487;
        double r75489 = r75476 ? r75480 : r75488;
        double r75490 = r75443 ? r75474 : r75489;
        return r75490;
}

double f_ol(float a, float b) {
        long double r75491 = a;
        long double r75492 = -2.374520147406146e+26;
        bool r75493 = r75491 < r75492;
        long double r75494 = r75491 * r75491;
        long double r75495 = r75494 * r75494;
        long double r75496 = b;
        long double r75497 = r75496 * r75496;
        long double r75498 = r75497 * r75497;
        long double r75499 = r75495 - r75498;
        long double r75500 = r75499 * r75499;
        long double r75501 = r75494 - r75497;
        long double r75502 = r75491 + r75496;
        long double r75503 = r75491 - r75496;
        long double r75504 = r75502 * r75503;
        long double r75505 = r75501 * r75501;
        long double r75506 = r75504 * r75505;
        long double r75507 = r75501 * r75506;
        long double r75508 = r75502 * r75502;
        long double r75509 = r75503 * r75508;
        long double r75510 = r75503 * r75509;
        long double r75511 = r75507 / r75510;
        long double r75512 = r75500 / r75511;
        long double r75513 = 4.0;
        long double r75514 = 1.0;
        long double r75515 = r75514 + r75491;
        long double r75516 = r75494 * r75515;
        long double r75517 = 3.0;
        long double r75518 = r75517 * r75491;
        long double r75519 = r75514 - r75518;
        long double r75520 = r75497 * r75519;
        long double r75521 = r75516 + r75520;
        long double r75522 = r75513 * r75521;
        long double r75523 = r75512 + r75522;
        long double r75524 = r75523 - r75514;
        long double r75525 = 51458982194205.95;
        bool r75526 = r75491 < r75525;
        long double r75527 = r75494 + r75497;
        long double r75528 = r75527 * r75527;
        long double r75529 = r75528 + r75522;
        long double r75530 = r75529 - r75514;
        long double r75531 = 2.2077063450382992e+25;
        bool r75532 = r75491 < r75531;
        long double r75533 = r75527 * r75501;
        long double r75534 = r75533 * r75533;
        long double r75535 = r75534 / r75505;
        long double r75536 = r75535 + r75522;
        long double r75537 = r75536 - r75514;
        long double r75538 = r75532 ? r75524 : r75537;
        long double r75539 = r75526 ? r75530 : r75538;
        long double r75540 = r75493 ? r75524 : r75539;
        return r75540;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r75541, r75542, r75543, r75544, r75545, r75546, r75547, r75548, r75549, r75550, r75551, r75552, r75553, r75554, r75555, r75556, r75557, r75558;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r75541);
        mpfr_init(r75542);
        mpfr_init(r75543);
        mpfr_init(r75544);
        mpfr_init(r75545);
        mpfr_init(r75546);
        mpfr_init(r75547);
        mpfr_init(r75548);
        mpfr_init(r75549);
        mpfr_init(r75550);
        mpfr_init(r75551);
        mpfr_init(r75552);
        mpfr_init(r75553);
        mpfr_init(r75554);
        mpfr_init(r75555);
        mpfr_init(r75556);
        mpfr_init(r75557);
        mpfr_init(r75558);
}

double f_im(float a, float b) {
        mpfr_set_flt(r75541, a, MPFR_RNDN);
        mpfr_mul(r75542, r75541, r75541, MPFR_RNDN);
        mpfr_set_flt(r75543, b, MPFR_RNDN);
        mpfr_mul(r75544, r75543, r75543, MPFR_RNDN);
        mpfr_add(r75545, r75542, r75544, MPFR_RNDN);
        mpfr_mul(r75546, r75545, r75545, MPFR_RNDN);
        mpfr_init_set_str(r75547, "4", 10, MPFR_RNDN);
        mpfr_init_set_str(r75548, "1", 10, MPFR_RNDN);
        mpfr_add(r75549, r75548, r75541, MPFR_RNDN);
        mpfr_mul(r75550, r75542, r75549, MPFR_RNDN);
        mpfr_init_set_str(r75551, "3", 10, MPFR_RNDN);
        mpfr_mul(r75552, r75551, r75541, MPFR_RNDN);
        mpfr_sub(r75553, r75548, r75552, MPFR_RNDN);
        mpfr_mul(r75554, r75544, r75553, MPFR_RNDN);
        mpfr_add(r75555, r75550, r75554, MPFR_RNDN);
        mpfr_mul(r75556, r75547, r75555, MPFR_RNDN);
        mpfr_add(r75557, r75546, r75556, MPFR_RNDN);
        mpfr_sub(r75558, r75557, r75548, MPFR_RNDN);
        return mpfr_get_d(r75558, MPFR_RNDN);
}

