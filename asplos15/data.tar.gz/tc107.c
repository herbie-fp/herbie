#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* _multiplyComplex, imaginary part */

double f_if(float x_re, float x_im, float y_re, float y_im) {
        float r84573 = x_re;
        float r84574 = y_im;
        float r84575 = r84573 * r84574;
        float r84576 = x_im;
        float r84577 = y_re;
        float r84578 = r84576 * r84577;
        float r84579 = r84575 + r84578;
        return r84579;
}

double f_id(float x_re, float x_im, float y_re, float y_im) {
        double r84580 = x_re;
        double r84581 = y_im;
        double r84582 = r84580 * r84581;
        double r84583 = x_im;
        double r84584 = y_re;
        double r84585 = r84583 * r84584;
        double r84586 = r84582 + r84585;
        return r84586;
}

double f_il(float x_re, float x_im, float y_re, float y_im) {
        long double r84587 = x_re;
        long double r84588 = y_im;
        long double r84589 = r84587 * r84588;
        long double r84590 = x_im;
        long double r84591 = y_re;
        long double r84592 = r84590 * r84591;
        long double r84593 = r84589 + r84592;
        return r84593;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x_re, float x_im, float y_re, float y_im) {
        float r84594 = x_re;
        float r84595 = y_im;
        float r84596 = r84594 * r84595;
        float r84597 = x_im;
        float r84598 = y_re;
        float r84599 = r84597 * r84598;
        float r84600 = r84596 + r84599;
        return r84600;
}

double f_od(float x_re, float x_im, float y_re, float y_im) {
        double r84601 = x_re;
        double r84602 = y_im;
        double r84603 = r84601 * r84602;
        double r84604 = x_im;
        double r84605 = y_re;
        double r84606 = r84604 * r84605;
        double r84607 = r84603 + r84606;
        return r84607;
}

double f_ol(float x_re, float x_im, float y_re, float y_im) {
        long double r84608 = x_re;
        long double r84609 = y_im;
        long double r84610 = r84608 * r84609;
        long double r84611 = x_im;
        long double r84612 = y_re;
        long double r84613 = r84611 * r84612;
        long double r84614 = r84610 + r84613;
        return r84614;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r84615, r84616, r84617, r84618, r84619, r84620, r84621;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r84615);
        mpfr_init(r84616);
        mpfr_init(r84617);
        mpfr_init(r84618);
        mpfr_init(r84619);
        mpfr_init(r84620);
        mpfr_init(r84621);
}

double f_im(float x_re, float x_im, float y_re, float y_im) {
        mpfr_set_flt(r84615, x_re, MPFR_RNDN);
        mpfr_set_flt(r84616, y_im, MPFR_RNDN);
        mpfr_mul(r84617, r84615, r84616, MPFR_RNDN);
        mpfr_set_flt(r84618, x_im, MPFR_RNDN);
        mpfr_set_flt(r84619, y_re, MPFR_RNDN);
        mpfr_mul(r84620, r84618, r84619, MPFR_RNDN);
        mpfr_add(r84621, r84617, r84620, MPFR_RNDN);
        return mpfr_get_d(r84621, MPFR_RNDN);
}

