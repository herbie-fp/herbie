#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* _divideComplex, imaginary part */

double f_if(float x_re, float x_im, float y_re, float y_im) {
        float r84359 = x_im;
        float r84360 = y_re;
        float r84361 = r84359 * r84360;
        float r84362 = x_re;
        float r84363 = y_im;
        float r84364 = r84362 * r84363;
        float r84365 = r84361 - r84364;
        float r84366 = r84360 * r84360;
        float r84367 = r84363 * r84363;
        float r84368 = r84366 + r84367;
        float r84369 = r84365 / r84368;
        return r84369;
}

double f_id(float x_re, float x_im, float y_re, float y_im) {
        double r84370 = x_im;
        double r84371 = y_re;
        double r84372 = r84370 * r84371;
        double r84373 = x_re;
        double r84374 = y_im;
        double r84375 = r84373 * r84374;
        double r84376 = r84372 - r84375;
        double r84377 = r84371 * r84371;
        double r84378 = r84374 * r84374;
        double r84379 = r84377 + r84378;
        double r84380 = r84376 / r84379;
        return r84380;
}

double f_il(float x_re, float x_im, float y_re, float y_im) {
        long double r84381 = x_im;
        long double r84382 = y_re;
        long double r84383 = r84381 * r84382;
        long double r84384 = x_re;
        long double r84385 = y_im;
        long double r84386 = r84384 * r84385;
        long double r84387 = r84383 - r84386;
        long double r84388 = r84382 * r84382;
        long double r84389 = r84385 * r84385;
        long double r84390 = r84388 + r84389;
        long double r84391 = r84387 / r84390;
        return r84391;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x_re, float x_im, float y_re, float y_im) {
        float r84392 = x_re;
        float r84393 = -5718546606.568445;
        bool r84394 = r84392 < r84393;
        float r84395 = x_im;
        float r84396 = y_re;
        float r84397 = r84396 * r84396;
        float r84398 = y_im;
        float r84399 = r84398 * r84398;
        float r84400 = r84397 + r84399;
        float r84401 = r84395 / r84400;
        float r84402 = r84401 * r84396;
        float r84403 = r84398 / r84400;
        float r84404 = r84392 * r84403;
        float r84405 = r84402 - r84404;
        float r84406 = 2.427266233118075e-16;
        bool r84407 = r84392 < r84406;
        float r84408 = r84395 * r84396;
        float r84409 = r84392 * r84398;
        float r84410 = r84408 - r84409;
        float r84411 = r84398 * r84398;
        float r84412 = r84397 + r84411;
        float r84413 = sqrt(r84412);
        float r84414 = r84413 * r84413;
        float r84415 = r84410 / r84414;
        float r84416 = r84407 ? r84415 : r84405;
        float r84417 = r84394 ? r84405 : r84416;
        return r84417;
}

double f_od(float x_re, float x_im, float y_re, float y_im) {
        double r84418 = x_re;
        double r84419 = -5718546606.568445;
        bool r84420 = r84418 < r84419;
        double r84421 = x_im;
        double r84422 = y_re;
        double r84423 = r84422 * r84422;
        double r84424 = y_im;
        double r84425 = r84424 * r84424;
        double r84426 = r84423 + r84425;
        double r84427 = r84421 / r84426;
        double r84428 = r84427 * r84422;
        double r84429 = r84424 / r84426;
        double r84430 = r84418 * r84429;
        double r84431 = r84428 - r84430;
        double r84432 = 2.427266233118075e-16;
        bool r84433 = r84418 < r84432;
        double r84434 = r84421 * r84422;
        double r84435 = r84418 * r84424;
        double r84436 = r84434 - r84435;
        double r84437 = r84424 * r84424;
        double r84438 = r84423 + r84437;
        double r84439 = sqrt(r84438);
        double r84440 = r84439 * r84439;
        double r84441 = r84436 / r84440;
        double r84442 = r84433 ? r84441 : r84431;
        double r84443 = r84420 ? r84431 : r84442;
        return r84443;
}

double f_ol(float x_re, float x_im, float y_re, float y_im) {
        long double r84444 = x_re;
        long double r84445 = -5718546606.568445;
        bool r84446 = r84444 < r84445;
        long double r84447 = x_im;
        long double r84448 = y_re;
        long double r84449 = r84448 * r84448;
        long double r84450 = y_im;
        long double r84451 = r84450 * r84450;
        long double r84452 = r84449 + r84451;
        long double r84453 = r84447 / r84452;
        long double r84454 = r84453 * r84448;
        long double r84455 = r84450 / r84452;
        long double r84456 = r84444 * r84455;
        long double r84457 = r84454 - r84456;
        long double r84458 = 2.427266233118075e-16;
        bool r84459 = r84444 < r84458;
        long double r84460 = r84447 * r84448;
        long double r84461 = r84444 * r84450;
        long double r84462 = r84460 - r84461;
        long double r84463 = r84450 * r84450;
        long double r84464 = r84449 + r84463;
        long double r84465 = sqrt(r84464);
        long double r84466 = r84465 * r84465;
        long double r84467 = r84462 / r84466;
        long double r84468 = r84459 ? r84467 : r84457;
        long double r84469 = r84446 ? r84457 : r84468;
        return r84469;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r84470, r84471, r84472, r84473, r84474, r84475, r84476, r84477, r84478, r84479, r84480;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r84470);
        mpfr_init(r84471);
        mpfr_init(r84472);
        mpfr_init(r84473);
        mpfr_init(r84474);
        mpfr_init(r84475);
        mpfr_init(r84476);
        mpfr_init(r84477);
        mpfr_init(r84478);
        mpfr_init(r84479);
        mpfr_init(r84480);
}

double f_im(float x_re, float x_im, float y_re, float y_im) {
        mpfr_set_flt(r84470, x_im, MPFR_RNDN);
        mpfr_set_flt(r84471, y_re, MPFR_RNDN);
        mpfr_mul(r84472, r84470, r84471, MPFR_RNDN);
        mpfr_set_flt(r84473, x_re, MPFR_RNDN);
        mpfr_set_flt(r84474, y_im, MPFR_RNDN);
        mpfr_mul(r84475, r84473, r84474, MPFR_RNDN);
        mpfr_sub(r84476, r84472, r84475, MPFR_RNDN);
        mpfr_mul(r84477, r84471, r84471, MPFR_RNDN);
        mpfr_mul(r84478, r84474, r84474, MPFR_RNDN);
        mpfr_add(r84479, r84477, r84478, MPFR_RNDN);
        mpfr_div(r84480, r84476, r84479, MPFR_RNDN);
        return mpfr_get_d(r84480, MPFR_RNDN);
}

