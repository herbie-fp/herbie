#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Kahan's exp quotient */

double f_if(float x) {
        float r73393 = x;
        float r73394 = exp(r73393);
        float r73395 = 1.0;
        float r73396 = r73394 - r73395;
        float r73397 = r73396 / r73393;
        return r73397;
}

double f_id(float x) {
        double r73398 = x;
        double r73399 = exp(r73398);
        double r73400 = 1.0;
        double r73401 = r73399 - r73400;
        double r73402 = r73401 / r73398;
        return r73402;
}

double f_il(float x) {
        long double r73403 = x;
        long double r73404 = exp(r73403);
        long double r73405 = 1.0;
        long double r73406 = r73404 - r73405;
        long double r73407 = r73406 / r73403;
        return r73407;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r73408 = x;
        float r73409 = 1.0/r73408;
        float r73410 = exp(r73408);
        float r73411 = r73409 * r73410;
        float r73412 = r73411 * r73411;
        float r73413 = r73409 * r73409;
        float r73414 = r73412 - r73413;
        float r73415 = r73411 - r73409;
        float r73416 = r73414 / r73415;
        float r73417 = r73414 / r73416;
        return r73417;
}

double f_od(float x) {
        double r73418 = x;
        double r73419 = 1.0/r73418;
        double r73420 = exp(r73418);
        double r73421 = r73419 * r73420;
        double r73422 = r73421 * r73421;
        double r73423 = r73419 * r73419;
        double r73424 = r73422 - r73423;
        double r73425 = r73421 - r73419;
        double r73426 = r73424 / r73425;
        double r73427 = r73424 / r73426;
        return r73427;
}

double f_ol(float x) {
        long double r73428 = x;
        long double r73429 = 1.0/r73428;
        long double r73430 = exp(r73428);
        long double r73431 = r73429 * r73430;
        long double r73432 = r73431 * r73431;
        long double r73433 = r73429 * r73429;
        long double r73434 = r73432 - r73433;
        long double r73435 = r73431 - r73429;
        long double r73436 = r73434 / r73435;
        long double r73437 = r73434 / r73436;
        return r73437;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r73438, r73439, r73440, r73441, r73442;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r73438);
        mpfr_init(r73439);
        mpfr_init(r73440);
        mpfr_init(r73441);
        mpfr_init(r73442);
}

double f_im(float x) {
        mpfr_set_flt(r73438, x, MPFR_RNDN);
        mpfr_exp(r73439, r73438, MPFR_RNDN);
        mpfr_init_set_str(r73440, "1", 10, MPFR_RNDN);
        mpfr_sub(r73441, r73439, r73440, MPFR_RNDN);
        mpfr_div(r73442, r73441, r73438, MPFR_RNDN);
        return mpfr_get_d(r73442, MPFR_RNDN);
}

