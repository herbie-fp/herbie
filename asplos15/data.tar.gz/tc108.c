#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* _multiplyComplex, real part */

double f_if(float x_re, float x_im, float y_re, float y_im) {
        float r84622 = x_re;
        float r84623 = y_re;
        float r84624 = r84622 * r84623;
        float r84625 = x_im;
        float r84626 = y_im;
        float r84627 = r84625 * r84626;
        float r84628 = r84624 - r84627;
        return r84628;
}

double f_id(float x_re, float x_im, float y_re, float y_im) {
        double r84629 = x_re;
        double r84630 = y_re;
        double r84631 = r84629 * r84630;
        double r84632 = x_im;
        double r84633 = y_im;
        double r84634 = r84632 * r84633;
        double r84635 = r84631 - r84634;
        return r84635;
}

double f_il(float x_re, float x_im, float y_re, float y_im) {
        long double r84636 = x_re;
        long double r84637 = y_re;
        long double r84638 = r84636 * r84637;
        long double r84639 = x_im;
        long double r84640 = y_im;
        long double r84641 = r84639 * r84640;
        long double r84642 = r84638 - r84641;
        return r84642;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x_re, float x_im, float y_re, float y_im) {
        float r84643 = x_re;
        float r84644 = y_re;
        float r84645 = r84643 * r84644;
        float r84646 = x_im;
        float r84647 = y_im;
        float r84648 = r84646 * r84647;
        float r84649 = r84645 - r84648;
        return r84649;
}

double f_od(float x_re, float x_im, float y_re, float y_im) {
        double r84650 = x_re;
        double r84651 = y_re;
        double r84652 = r84650 * r84651;
        double r84653 = x_im;
        double r84654 = y_im;
        double r84655 = r84653 * r84654;
        double r84656 = r84652 - r84655;
        return r84656;
}

double f_ol(float x_re, float x_im, float y_re, float y_im) {
        long double r84657 = x_re;
        long double r84658 = y_re;
        long double r84659 = r84657 * r84658;
        long double r84660 = x_im;
        long double r84661 = y_im;
        long double r84662 = r84660 * r84661;
        long double r84663 = r84659 - r84662;
        return r84663;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r84664, r84665, r84666, r84667, r84668, r84669, r84670;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r84664);
        mpfr_init(r84665);
        mpfr_init(r84666);
        mpfr_init(r84667);
        mpfr_init(r84668);
        mpfr_init(r84669);
        mpfr_init(r84670);
}

double f_im(float x_re, float x_im, float y_re, float y_im) {
        mpfr_set_flt(r84664, x_re, MPFR_RNDN);
        mpfr_set_flt(r84665, y_re, MPFR_RNDN);
        mpfr_mul(r84666, r84664, r84665, MPFR_RNDN);
        mpfr_set_flt(r84667, x_im, MPFR_RNDN);
        mpfr_set_flt(r84668, y_im, MPFR_RNDN);
        mpfr_mul(r84669, r84667, r84668, MPFR_RNDN);
        mpfr_sub(r84670, r84666, r84669, MPFR_RNDN);
        return mpfr_get_d(r84670, MPFR_RNDN);
}

