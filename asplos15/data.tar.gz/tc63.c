#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Jmat.Real.erf */

double f_if(float x) {
        float r77924 = 1.0;
        float r77925 = 0.3275911;
        float r77926 = x;
        float r77927 = r77925 * r77926;
        float r77928 = r77924 + r77927;
        float r77929 = r77924 / r77928;
        float r77930 = 0.254829592;
        float r77931 = -0.284496736;
        float r77932 = 1.421413741;
        float r77933 = -1.453152027;
        float r77934 = 1.061405429;
        float r77935 = r77929 * r77934;
        float r77936 = r77933 + r77935;
        float r77937 = r77929 * r77936;
        float r77938 = r77932 + r77937;
        float r77939 = r77929 * r77938;
        float r77940 = r77931 + r77939;
        float r77941 = r77929 * r77940;
        float r77942 = r77930 + r77941;
        float r77943 = r77929 * r77942;
        float r77944 = r77926 - r77926;
        float r77945 = exp(r77944);
        float r77946 = r77943 * r77945;
        float r77947 = r77924 - r77946;
        return r77947;
}

double f_id(float x) {
        double r77948 = 1.0;
        double r77949 = 0.3275911;
        double r77950 = x;
        double r77951 = r77949 * r77950;
        double r77952 = r77948 + r77951;
        double r77953 = r77948 / r77952;
        double r77954 = 0.254829592;
        double r77955 = -0.284496736;
        double r77956 = 1.421413741;
        double r77957 = -1.453152027;
        double r77958 = 1.061405429;
        double r77959 = r77953 * r77958;
        double r77960 = r77957 + r77959;
        double r77961 = r77953 * r77960;
        double r77962 = r77956 + r77961;
        double r77963 = r77953 * r77962;
        double r77964 = r77955 + r77963;
        double r77965 = r77953 * r77964;
        double r77966 = r77954 + r77965;
        double r77967 = r77953 * r77966;
        double r77968 = r77950 - r77950;
        double r77969 = exp(r77968);
        double r77970 = r77967 * r77969;
        double r77971 = r77948 - r77970;
        return r77971;
}

double f_il(float x) {
        long double r77972 = 1.0;
        long double r77973 = 0.3275911;
        long double r77974 = x;
        long double r77975 = r77973 * r77974;
        long double r77976 = r77972 + r77975;
        long double r77977 = r77972 / r77976;
        long double r77978 = 0.254829592;
        long double r77979 = -0.284496736;
        long double r77980 = 1.421413741;
        long double r77981 = -1.453152027;
        long double r77982 = 1.061405429;
        long double r77983 = r77977 * r77982;
        long double r77984 = r77981 + r77983;
        long double r77985 = r77977 * r77984;
        long double r77986 = r77980 + r77985;
        long double r77987 = r77977 * r77986;
        long double r77988 = r77979 + r77987;
        long double r77989 = r77977 * r77988;
        long double r77990 = r77978 + r77989;
        long double r77991 = r77977 * r77990;
        long double r77992 = r77974 - r77974;
        long double r77993 = exp(r77992);
        long double r77994 = r77991 * r77993;
        long double r77995 = r77972 - r77994;
        return r77995;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r77996 = 1.0;
        float r77997 = 0.3275911;
        float r77998 = x;
        float r77999 = r77997 * r77998;
        float r78000 = r77996 + r77999;
        float r78001 = r77996 / r78000;
        float r78002 = 0.254829592;
        float r78003 = -0.284496736;
        float r78004 = 1.421413741;
        float r78005 = r78004 * r78001;
        float r78006 = r78003 + r78005;
        float r78007 = 2.111650813574209;
        float r78008 = r77996 * r77996;
        float r78009 = r77999 * r77999;
        float r78010 = r78008 - r78009;
        float r78011 = r78010 * r78010;
        float r78012 = r77996 - r77999;
        float r78013 = r78012 * r78012;
        float r78014 = r78011 / r78013;
        float r78015 = r77996 / r78014;
        float r78016 = 1.1265814847106739;
        float r78017 = r78015 * r78016;
        float r78018 = r78007 - r78017;
        float r78019 = -1.453152027;
        float r78020 = 1.061405429;
        float r78021 = r78001 * r78020;
        float r78022 = r78019 - r78021;
        float r78023 = r78000 * r78022;
        float r78024 = r78023 * r78000;
        float r78025 = r78018 / r78024;
        float r78026 = r78006 + r78025;
        float r78027 = r78001 * r78026;
        float r78028 = r78002 + r78027;
        float r78029 = r78001 * r78028;
        float r78030 = r77998 - r77998;
        float r78031 = exp(r78030);
        float r78032 = r78029 * r78031;
        float r78033 = r77996 - r78032;
        return r78033;
}

double f_od(float x) {
        double r78034 = 1.0;
        double r78035 = 0.3275911;
        double r78036 = x;
        double r78037 = r78035 * r78036;
        double r78038 = r78034 + r78037;
        double r78039 = r78034 / r78038;
        double r78040 = 0.254829592;
        double r78041 = -0.284496736;
        double r78042 = 1.421413741;
        double r78043 = r78042 * r78039;
        double r78044 = r78041 + r78043;
        double r78045 = 2.111650813574209;
        double r78046 = r78034 * r78034;
        double r78047 = r78037 * r78037;
        double r78048 = r78046 - r78047;
        double r78049 = r78048 * r78048;
        double r78050 = r78034 - r78037;
        double r78051 = r78050 * r78050;
        double r78052 = r78049 / r78051;
        double r78053 = r78034 / r78052;
        double r78054 = 1.1265814847106739;
        double r78055 = r78053 * r78054;
        double r78056 = r78045 - r78055;
        double r78057 = -1.453152027;
        double r78058 = 1.061405429;
        double r78059 = r78039 * r78058;
        double r78060 = r78057 - r78059;
        double r78061 = r78038 * r78060;
        double r78062 = r78061 * r78038;
        double r78063 = r78056 / r78062;
        double r78064 = r78044 + r78063;
        double r78065 = r78039 * r78064;
        double r78066 = r78040 + r78065;
        double r78067 = r78039 * r78066;
        double r78068 = r78036 - r78036;
        double r78069 = exp(r78068);
        double r78070 = r78067 * r78069;
        double r78071 = r78034 - r78070;
        return r78071;
}

double f_ol(float x) {
        long double r78072 = 1.0;
        long double r78073 = 0.3275911;
        long double r78074 = x;
        long double r78075 = r78073 * r78074;
        long double r78076 = r78072 + r78075;
        long double r78077 = r78072 / r78076;
        long double r78078 = 0.254829592;
        long double r78079 = -0.284496736;
        long double r78080 = 1.421413741;
        long double r78081 = r78080 * r78077;
        long double r78082 = r78079 + r78081;
        long double r78083 = 2.111650813574209;
        long double r78084 = r78072 * r78072;
        long double r78085 = r78075 * r78075;
        long double r78086 = r78084 - r78085;
        long double r78087 = r78086 * r78086;
        long double r78088 = r78072 - r78075;
        long double r78089 = r78088 * r78088;
        long double r78090 = r78087 / r78089;
        long double r78091 = r78072 / r78090;
        long double r78092 = 1.1265814847106739;
        long double r78093 = r78091 * r78092;
        long double r78094 = r78083 - r78093;
        long double r78095 = -1.453152027;
        long double r78096 = 1.061405429;
        long double r78097 = r78077 * r78096;
        long double r78098 = r78095 - r78097;
        long double r78099 = r78076 * r78098;
        long double r78100 = r78099 * r78076;
        long double r78101 = r78094 / r78100;
        long double r78102 = r78082 + r78101;
        long double r78103 = r78077 * r78102;
        long double r78104 = r78078 + r78103;
        long double r78105 = r78077 * r78104;
        long double r78106 = r78074 - r78074;
        long double r78107 = exp(r78106);
        long double r78108 = r78105 * r78107;
        long double r78109 = r78072 - r78108;
        return r78109;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r78110, r78111, r78112, r78113, r78114, r78115, r78116, r78117, r78118, r78119, r78120, r78121, r78122, r78123, r78124, r78125, r78126, r78127, r78128, r78129, r78130, r78131, r78132, r78133;

void setup_mpfr() {
        mpfr_set_default_prec(136);
        mpfr_init(r78110);
        mpfr_init(r78111);
        mpfr_init(r78112);
        mpfr_init(r78113);
        mpfr_init(r78114);
        mpfr_init(r78115);
        mpfr_init(r78116);
        mpfr_init(r78117);
        mpfr_init(r78118);
        mpfr_init(r78119);
        mpfr_init(r78120);
        mpfr_init(r78121);
        mpfr_init(r78122);
        mpfr_init(r78123);
        mpfr_init(r78124);
        mpfr_init(r78125);
        mpfr_init(r78126);
        mpfr_init(r78127);
        mpfr_init(r78128);
        mpfr_init(r78129);
        mpfr_init(r78130);
        mpfr_init(r78131);
        mpfr_init(r78132);
        mpfr_init(r78133);
}

double f_im(float x) {
        mpfr_init_set_str(r78110, "1", 10, MPFR_RNDN);
        mpfr_init_set_str(r78111, "0.3275911", 10, MPFR_RNDN);
        mpfr_set_flt(r78112, x, MPFR_RNDN);
        mpfr_mul(r78113, r78111, r78112, MPFR_RNDN);
        mpfr_add(r78114, r78110, r78113, MPFR_RNDN);
        mpfr_div(r78115, r78110, r78114, MPFR_RNDN);
        mpfr_init_set_str(r78116, "0.254829592", 10, MPFR_RNDN);
        mpfr_init_set_str(r78117, "-0.284496736", 10, MPFR_RNDN);
        mpfr_init_set_str(r78118, "1.421413741", 10, MPFR_RNDN);
        mpfr_init_set_str(r78119, "-1.453152027", 10, MPFR_RNDN);
        mpfr_init_set_str(r78120, "1.061405429", 10, MPFR_RNDN);
        mpfr_mul(r78121, r78115, r78120, MPFR_RNDN);
        mpfr_add(r78122, r78119, r78121, MPFR_RNDN);
        mpfr_mul(r78123, r78115, r78122, MPFR_RNDN);
        mpfr_add(r78124, r78118, r78123, MPFR_RNDN);
        mpfr_mul(r78125, r78115, r78124, MPFR_RNDN);
        mpfr_add(r78126, r78117, r78125, MPFR_RNDN);
        mpfr_mul(r78127, r78115, r78126, MPFR_RNDN);
        mpfr_add(r78128, r78116, r78127, MPFR_RNDN);
        mpfr_mul(r78129, r78115, r78128, MPFR_RNDN);
        mpfr_sub(r78130, r78112, r78112, MPFR_RNDN);
        mpfr_exp(r78131, r78130, MPFR_RNDN);
        mpfr_mul(r78132, r78129, r78131, MPFR_RNDN);
        mpfr_sub(r78133, r78110, r78132, MPFR_RNDN);
        return mpfr_get_d(r78133, MPFR_RNDN);
}

