#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Rosa's TurbineBenchmark */

double f_if(float v, float w, float r) {
        float r82665 = 3.0;
        float r82666 = 2.0;
        float r82667 = r;
        float r82668 = r82667 * r82667;
        float r82669 = r82666 / r82668;
        float r82670 = r82665 + r82669;
        float r82671 = 0.125;
        float r82672 = v;
        float r82673 = r82666 * r82672;
        float r82674 = r82665 - r82673;
        float r82675 = r82671 * r82674;
        float r82676 = w;
        float r82677 = r82676 * r82676;
        float r82678 = r82677 * r82667;
        float r82679 = r82678 * r82667;
        float r82680 = r82675 * r82679;
        float r82681 = 1.0;
        float r82682 = r82681 - r82672;
        float r82683 = r82680 / r82682;
        float r82684 = r82670 - r82683;
        float r82685 = 4.5;
        float r82686 = r82684 - r82685;
        return r82686;
}

double f_id(float v, float w, float r) {
        double r82687 = 3.0;
        double r82688 = 2.0;
        double r82689 = r;
        double r82690 = r82689 * r82689;
        double r82691 = r82688 / r82690;
        double r82692 = r82687 + r82691;
        double r82693 = 0.125;
        double r82694 = v;
        double r82695 = r82688 * r82694;
        double r82696 = r82687 - r82695;
        double r82697 = r82693 * r82696;
        double r82698 = w;
        double r82699 = r82698 * r82698;
        double r82700 = r82699 * r82689;
        double r82701 = r82700 * r82689;
        double r82702 = r82697 * r82701;
        double r82703 = 1.0;
        double r82704 = r82703 - r82694;
        double r82705 = r82702 / r82704;
        double r82706 = r82692 - r82705;
        double r82707 = 4.5;
        double r82708 = r82706 - r82707;
        return r82708;
}

double f_il(float v, float w, float r) {
        long double r82709 = 3.0;
        long double r82710 = 2.0;
        long double r82711 = r;
        long double r82712 = r82711 * r82711;
        long double r82713 = r82710 / r82712;
        long double r82714 = r82709 + r82713;
        long double r82715 = 0.125;
        long double r82716 = v;
        long double r82717 = r82710 * r82716;
        long double r82718 = r82709 - r82717;
        long double r82719 = r82715 * r82718;
        long double r82720 = w;
        long double r82721 = r82720 * r82720;
        long double r82722 = r82721 * r82711;
        long double r82723 = r82722 * r82711;
        long double r82724 = r82719 * r82723;
        long double r82725 = 1.0;
        long double r82726 = r82725 - r82716;
        long double r82727 = r82724 / r82726;
        long double r82728 = r82714 - r82727;
        long double r82729 = 4.5;
        long double r82730 = r82728 - r82729;
        return r82730;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float v, float w, float r) {
        float r82731 = v;
        float r82732 = 25609692477.616104;
        bool r82733 = r82731 < r82732;
        float r82734 = 3.0;
        float r82735 = 2.0;
        float r82736 = r;
        float r82737 = r82736 * r82736;
        float r82738 = r82735 / r82737;
        float r82739 = r82734 + r82738;
        float r82740 = 0.125;
        float r82741 = r82735 * r82731;
        float r82742 = r82734 - r82741;
        float r82743 = r82740 * r82742;
        float r82744 = w;
        float r82745 = r82743 * r82744;
        float r82746 = r82744 * r82737;
        float r82747 = r82745 * r82746;
        float r82748 = 1.0;
        float r82749 = r82748 - r82731;
        float r82750 = r82747 / r82749;
        float r82751 = r82739 - r82750;
        float r82752 = 4.5;
        float r82753 = r82751 - r82752;
        float r82754 = r82744 * r82744;
        float r82755 = r82743 * r82754;
        float r82756 = r82755 * r82737;
        float r82757 = r82756 / r82749;
        float r82758 = r82739 - r82757;
        float r82759 = r82758 - r82752;
        float r82760 = r82733 ? r82753 : r82759;
        return r82760;
}

double f_od(float v, float w, float r) {
        double r82761 = v;
        double r82762 = 25609692477.616104;
        bool r82763 = r82761 < r82762;
        double r82764 = 3.0;
        double r82765 = 2.0;
        double r82766 = r;
        double r82767 = r82766 * r82766;
        double r82768 = r82765 / r82767;
        double r82769 = r82764 + r82768;
        double r82770 = 0.125;
        double r82771 = r82765 * r82761;
        double r82772 = r82764 - r82771;
        double r82773 = r82770 * r82772;
        double r82774 = w;
        double r82775 = r82773 * r82774;
        double r82776 = r82774 * r82767;
        double r82777 = r82775 * r82776;
        double r82778 = 1.0;
        double r82779 = r82778 - r82761;
        double r82780 = r82777 / r82779;
        double r82781 = r82769 - r82780;
        double r82782 = 4.5;
        double r82783 = r82781 - r82782;
        double r82784 = r82774 * r82774;
        double r82785 = r82773 * r82784;
        double r82786 = r82785 * r82767;
        double r82787 = r82786 / r82779;
        double r82788 = r82769 - r82787;
        double r82789 = r82788 - r82782;
        double r82790 = r82763 ? r82783 : r82789;
        return r82790;
}

double f_ol(float v, float w, float r) {
        long double r82791 = v;
        long double r82792 = 25609692477.616104;
        bool r82793 = r82791 < r82792;
        long double r82794 = 3.0;
        long double r82795 = 2.0;
        long double r82796 = r;
        long double r82797 = r82796 * r82796;
        long double r82798 = r82795 / r82797;
        long double r82799 = r82794 + r82798;
        long double r82800 = 0.125;
        long double r82801 = r82795 * r82791;
        long double r82802 = r82794 - r82801;
        long double r82803 = r82800 * r82802;
        long double r82804 = w;
        long double r82805 = r82803 * r82804;
        long double r82806 = r82804 * r82797;
        long double r82807 = r82805 * r82806;
        long double r82808 = 1.0;
        long double r82809 = r82808 - r82791;
        long double r82810 = r82807 / r82809;
        long double r82811 = r82799 - r82810;
        long double r82812 = 4.5;
        long double r82813 = r82811 - r82812;
        long double r82814 = r82804 * r82804;
        long double r82815 = r82803 * r82814;
        long double r82816 = r82815 * r82797;
        long double r82817 = r82816 / r82809;
        long double r82818 = r82799 - r82817;
        long double r82819 = r82818 - r82812;
        long double r82820 = r82793 ? r82813 : r82819;
        return r82820;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r82821, r82822, r82823, r82824, r82825, r82826, r82827, r82828, r82829, r82830, r82831, r82832, r82833, r82834, r82835, r82836, r82837, r82838, r82839, r82840, r82841, r82842;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r82821);
        mpfr_init(r82822);
        mpfr_init(r82823);
        mpfr_init(r82824);
        mpfr_init(r82825);
        mpfr_init(r82826);
        mpfr_init(r82827);
        mpfr_init(r82828);
        mpfr_init(r82829);
        mpfr_init(r82830);
        mpfr_init(r82831);
        mpfr_init(r82832);
        mpfr_init(r82833);
        mpfr_init(r82834);
        mpfr_init(r82835);
        mpfr_init(r82836);
        mpfr_init(r82837);
        mpfr_init(r82838);
        mpfr_init(r82839);
        mpfr_init(r82840);
        mpfr_init(r82841);
        mpfr_init(r82842);
}

double f_im(float v, float w, float r) {
        mpfr_init_set_str(r82821, "3", 10, MPFR_RNDN);
        mpfr_init_set_str(r82822, "2", 10, MPFR_RNDN);
        mpfr_set_flt(r82823, r, MPFR_RNDN);
        mpfr_mul(r82824, r82823, r82823, MPFR_RNDN);
        mpfr_div(r82825, r82822, r82824, MPFR_RNDN);
        mpfr_add(r82826, r82821, r82825, MPFR_RNDN);
        mpfr_init_set_str(r82827, "0.125", 10, MPFR_RNDN);
        mpfr_set_flt(r82828, v, MPFR_RNDN);
        mpfr_mul(r82829, r82822, r82828, MPFR_RNDN);
        mpfr_sub(r82830, r82821, r82829, MPFR_RNDN);
        mpfr_mul(r82831, r82827, r82830, MPFR_RNDN);
        mpfr_set_flt(r82832, w, MPFR_RNDN);
        mpfr_mul(r82833, r82832, r82832, MPFR_RNDN);
        mpfr_mul(r82834, r82833, r82823, MPFR_RNDN);
        mpfr_mul(r82835, r82834, r82823, MPFR_RNDN);
        mpfr_mul(r82836, r82831, r82835, MPFR_RNDN);
        mpfr_init_set_str(r82837, "1", 10, MPFR_RNDN);
        mpfr_sub(r82838, r82837, r82828, MPFR_RNDN);
        mpfr_div(r82839, r82836, r82838, MPFR_RNDN);
        mpfr_sub(r82840, r82826, r82839, MPFR_RNDN);
        mpfr_init_set_str(r82841, "4.5", 10, MPFR_RNDN);
        mpfr_sub(r82842, r82840, r82841, MPFR_RNDN);
        return mpfr_get_d(r82842, MPFR_RNDN);
}

