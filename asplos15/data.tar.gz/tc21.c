#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE example 3.2 */

double f_if(float x) {
        float r73568 = x;
        float r73569 = sin(r73568);
        float r73570 = r73569 / r73568;
        return r73570;
}

double f_id(float x) {
        double r73571 = x;
        double r73572 = sin(r73571);
        double r73573 = r73572 / r73571;
        return r73573;
}

double f_il(float x) {
        long double r73574 = x;
        long double r73575 = sin(r73574);
        long double r73576 = r73575 / r73574;
        return r73576;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r73577 = x;
        float r73578 = sin(r73577);
        float r73579 = r73578 / r73577;
        return r73579;
}

double f_od(float x) {
        double r73580 = x;
        double r73581 = sin(r73580);
        double r73582 = r73581 / r73580;
        return r73582;
}

double f_ol(float x) {
        long double r73583 = x;
        long double r73584 = sin(r73583);
        long double r73585 = r73584 / r73583;
        return r73585;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r73586, r73587, r73588;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r73586);
        mpfr_init(r73587);
        mpfr_init(r73588);
}

double f_im(float x) {
        mpfr_set_flt(r73586, x, MPFR_RNDN);
        mpfr_sin(r73587, r73586, MPFR_RNDN);
        mpfr_div(r73588, r73587, r73586, MPFR_RNDN);
        return mpfr_get_d(r73588, MPFR_RNDN);
}

