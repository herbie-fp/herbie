#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Difference of squares */

double f_if(float a, float b) {
        float r72455 = a;
        float r72456 = r72455 * r72455;
        float r72457 = b;
        float r72458 = r72457 * r72457;
        float r72459 = r72456 - r72458;
        return r72459;
}

double f_id(float a, float b) {
        double r72460 = a;
        double r72461 = r72460 * r72460;
        double r72462 = b;
        double r72463 = r72462 * r72462;
        double r72464 = r72461 - r72463;
        return r72464;
}

double f_il(float a, float b) {
        long double r72465 = a;
        long double r72466 = r72465 * r72465;
        long double r72467 = b;
        long double r72468 = r72467 * r72467;
        long double r72469 = r72466 - r72468;
        return r72469;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a, float b) {
        float r72470 = a;
        float r72471 = b;
        float r72472 = r72470 + r72471;
        float r72473 = r72470 - r72471;
        float r72474 = r72472 * r72473;
        return r72474;
}

double f_od(float a, float b) {
        double r72475 = a;
        double r72476 = b;
        double r72477 = r72475 + r72476;
        double r72478 = r72475 - r72476;
        double r72479 = r72477 * r72478;
        return r72479;
}

double f_ol(float a, float b) {
        long double r72480 = a;
        long double r72481 = b;
        long double r72482 = r72480 + r72481;
        long double r72483 = r72480 - r72481;
        long double r72484 = r72482 * r72483;
        return r72484;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r72485, r72486, r72487, r72488, r72489;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r72485);
        mpfr_init(r72486);
        mpfr_init(r72487);
        mpfr_init(r72488);
        mpfr_init(r72489);
}

double f_im(float a, float b) {
        mpfr_set_flt(r72485, a, MPFR_RNDN);
        mpfr_mul(r72486, r72485, r72485, MPFR_RNDN);
        mpfr_set_flt(r72487, b, MPFR_RNDN);
        mpfr_mul(r72488, r72487, r72487, MPFR_RNDN);
        mpfr_sub(r72489, r72486, r72488, MPFR_RNDN);
        return mpfr_get_d(r72489, MPFR_RNDN);
}

