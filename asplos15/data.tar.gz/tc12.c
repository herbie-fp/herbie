#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* FastMath test2 */

double f_if(float d1, float d2) {
        float r72844 = d1;
        float r72845 = 10.0;
        float r72846 = r72844 * r72845;
        float r72847 = d2;
        float r72848 = r72844 * r72847;
        float r72849 = r72846 + r72848;
        float r72850 = 20.0;
        float r72851 = r72844 * r72850;
        float r72852 = r72849 + r72851;
        return r72852;
}

double f_id(float d1, float d2) {
        double r72853 = d1;
        double r72854 = 10.0;
        double r72855 = r72853 * r72854;
        double r72856 = d2;
        double r72857 = r72853 * r72856;
        double r72858 = r72855 + r72857;
        double r72859 = 20.0;
        double r72860 = r72853 * r72859;
        double r72861 = r72858 + r72860;
        return r72861;
}

double f_il(float d1, float d2) {
        long double r72862 = d1;
        long double r72863 = 10.0;
        long double r72864 = r72862 * r72863;
        long double r72865 = d2;
        long double r72866 = r72862 * r72865;
        long double r72867 = r72864 + r72866;
        long double r72868 = 20.0;
        long double r72869 = r72862 * r72868;
        long double r72870 = r72867 + r72869;
        return r72870;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float d1, float d2) {
        float r72871 = 30.0;
        float r72872 = d1;
        float r72873 = r72871 * r72872;
        float r72874 = d2;
        float r72875 = r72872 * r72874;
        float r72876 = r72873 + r72875;
        return r72876;
}

double f_od(float d1, float d2) {
        double r72877 = 30.0;
        double r72878 = d1;
        double r72879 = r72877 * r72878;
        double r72880 = d2;
        double r72881 = r72878 * r72880;
        double r72882 = r72879 + r72881;
        return r72882;
}

double f_ol(float d1, float d2) {
        long double r72883 = 30.0;
        long double r72884 = d1;
        long double r72885 = r72883 * r72884;
        long double r72886 = d2;
        long double r72887 = r72884 * r72886;
        long double r72888 = r72885 + r72887;
        return r72888;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r72889, r72890, r72891, r72892, r72893, r72894, r72895, r72896, r72897;

void setup_mpfr() {
        mpfr_set_default_prec(168);
        mpfr_init(r72889);
        mpfr_init(r72890);
        mpfr_init(r72891);
        mpfr_init(r72892);
        mpfr_init(r72893);
        mpfr_init(r72894);
        mpfr_init(r72895);
        mpfr_init(r72896);
        mpfr_init(r72897);
}

double f_im(float d1, float d2) {
        mpfr_set_flt(r72889, d1, MPFR_RNDN);
        mpfr_init_set_str(r72890, "10", 10, MPFR_RNDN);
        mpfr_mul(r72891, r72889, r72890, MPFR_RNDN);
        mpfr_set_flt(r72892, d2, MPFR_RNDN);
        mpfr_mul(r72893, r72889, r72892, MPFR_RNDN);
        mpfr_add(r72894, r72891, r72893, MPFR_RNDN);
        mpfr_init_set_str(r72895, "20", 10, MPFR_RNDN);
        mpfr_mul(r72896, r72889, r72895, MPFR_RNDN);
        mpfr_add(r72897, r72894, r72896, MPFR_RNDN);
        return mpfr_get_d(r72897, MPFR_RNDN);
}

