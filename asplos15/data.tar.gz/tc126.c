#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.square on complex, imaginary part */

double f_if(float re, float im) {
        float r86265 = re;
        float r86266 = im;
        float r86267 = r86265 * r86266;
        float r86268 = r86266 * r86265;
        float r86269 = r86267 + r86268;
        return r86269;
}

double f_id(float re, float im) {
        double r86270 = re;
        double r86271 = im;
        double r86272 = r86270 * r86271;
        double r86273 = r86271 * r86270;
        double r86274 = r86272 + r86273;
        return r86274;
}

double f_il(float re, float im) {
        long double r86275 = re;
        long double r86276 = im;
        long double r86277 = r86275 * r86276;
        long double r86278 = r86276 * r86275;
        long double r86279 = r86277 + r86278;
        return r86279;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r86280 = 2.0;
        float r86281 = im;
        float r86282 = re;
        float r86283 = r86281 * r86282;
        float r86284 = r86280 * r86283;
        return r86284;
}

double f_od(float re, float im) {
        double r86285 = 2.0;
        double r86286 = im;
        double r86287 = re;
        double r86288 = r86286 * r86287;
        double r86289 = r86285 * r86288;
        return r86289;
}

double f_ol(float re, float im) {
        long double r86290 = 2.0;
        long double r86291 = im;
        long double r86292 = re;
        long double r86293 = r86291 * r86292;
        long double r86294 = r86290 * r86293;
        return r86294;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r86295, r86296, r86297, r86298, r86299;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r86295);
        mpfr_init(r86296);
        mpfr_init(r86297);
        mpfr_init(r86298);
        mpfr_init(r86299);
}

double f_im(float re, float im) {
        mpfr_set_flt(r86295, re, MPFR_RNDN);
        mpfr_set_flt(r86296, im, MPFR_RNDN);
        mpfr_mul(r86297, r86295, r86296, MPFR_RNDN);
        mpfr_mul(r86298, r86296, r86295, MPFR_RNDN);
        mpfr_add(r86299, r86297, r86298, MPFR_RNDN);
        return mpfr_get_d(r86299, MPFR_RNDN);
}

