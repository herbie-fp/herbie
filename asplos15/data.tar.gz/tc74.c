#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE example 3.10 */

double f_if(float x) {
        float r80068 = 1.0;
        float r80069 = x;
        float r80070 = r80068 - r80069;
        float r80071 = log(r80070);
        float r80072 = r80068 + r80069;
        float r80073 = log(r80072);
        float r80074 = r80071 / r80073;
        return r80074;
}

double f_id(float x) {
        double r80075 = 1.0;
        double r80076 = x;
        double r80077 = r80075 - r80076;
        double r80078 = log(r80077);
        double r80079 = r80075 + r80076;
        double r80080 = log(r80079);
        double r80081 = r80078 / r80080;
        return r80081;
}

double f_il(float x) {
        long double r80082 = 1.0;
        long double r80083 = x;
        long double r80084 = r80082 - r80083;
        long double r80085 = log(r80084);
        long double r80086 = r80082 + r80083;
        long double r80087 = log(r80086);
        long double r80088 = r80085 / r80087;
        return r80088;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r80089 = x;
        float r80090 = 1.1102230246251565e-16;
        bool r80091 = r80089 < r80090;
        float r80092 = 1.0;
        float r80093 = r80092 - r80089;
        float r80094 = log(r80093);
        float r80095 = r80092 / r80093;
        float r80096 = r80089 * r80089;
        float r80097 = r80096 / r80093;
        float r80098 = r80095 - r80097;
        float r80099 = log(r80098);
        float r80100 = r80094 / r80099;
        float r80101 = r80092 + r80089;
        float r80102 = r80092 / r80101;
        float r80103 = r80096 / r80101;
        float r80104 = r80102 - r80103;
        float r80105 = log(r80104);
        float r80106 = log(r80101);
        float r80107 = r80105 / r80106;
        float r80108 = r80091 ? r80100 : r80107;
        return r80108;
}

double f_od(float x) {
        double r80109 = x;
        double r80110 = 1.1102230246251565e-16;
        bool r80111 = r80109 < r80110;
        double r80112 = 1.0;
        double r80113 = r80112 - r80109;
        double r80114 = log(r80113);
        double r80115 = r80112 / r80113;
        double r80116 = r80109 * r80109;
        double r80117 = r80116 / r80113;
        double r80118 = r80115 - r80117;
        double r80119 = log(r80118);
        double r80120 = r80114 / r80119;
        double r80121 = r80112 + r80109;
        double r80122 = r80112 / r80121;
        double r80123 = r80116 / r80121;
        double r80124 = r80122 - r80123;
        double r80125 = log(r80124);
        double r80126 = log(r80121);
        double r80127 = r80125 / r80126;
        double r80128 = r80111 ? r80120 : r80127;
        return r80128;
}

double f_ol(float x) {
        long double r80129 = x;
        long double r80130 = 1.1102230246251565e-16;
        bool r80131 = r80129 < r80130;
        long double r80132 = 1.0;
        long double r80133 = r80132 - r80129;
        long double r80134 = log(r80133);
        long double r80135 = r80132 / r80133;
        long double r80136 = r80129 * r80129;
        long double r80137 = r80136 / r80133;
        long double r80138 = r80135 - r80137;
        long double r80139 = log(r80138);
        long double r80140 = r80134 / r80139;
        long double r80141 = r80132 + r80129;
        long double r80142 = r80132 / r80141;
        long double r80143 = r80136 / r80141;
        long double r80144 = r80142 - r80143;
        long double r80145 = log(r80144);
        long double r80146 = log(r80141);
        long double r80147 = r80145 / r80146;
        long double r80148 = r80131 ? r80140 : r80147;
        return r80148;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r80149, r80150, r80151, r80152, r80153, r80154, r80155;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r80149);
        mpfr_init(r80150);
        mpfr_init(r80151);
        mpfr_init(r80152);
        mpfr_init(r80153);
        mpfr_init(r80154);
        mpfr_init(r80155);
}

double f_im(float x) {
        mpfr_init_set_str(r80149, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r80150, x, MPFR_RNDN);
        mpfr_sub(r80151, r80149, r80150, MPFR_RNDN);
        mpfr_log(r80152, r80151, MPFR_RNDN);
        mpfr_add(r80153, r80149, r80150, MPFR_RNDN);
        mpfr_log(r80154, r80153, MPFR_RNDN);
        mpfr_div(r80155, r80152, r80154, MPFR_RNDN);
        return mpfr_get_d(r80155, MPFR_RNDN);
}

