#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* VandenBroeck and Keller, Equation (20) */

double f_if(float f) {
        float r83960 = atan2(1.0, 0.0);
        float r83961 = 4.0;
        float r83962 = r83960 / r83961;
        float r83963 = 1.0/r83962;
        float r83964 = f;
        float r83965 = r83962 * r83964;
        float r83966 = exp(r83965);
        float r83967 = -r83965;
        float r83968 = exp(r83967);
        float r83969 = r83966 + r83968;
        float r83970 = r83966 - r83968;
        float r83971 = r83969 / r83970;
        float r83972 = log(r83971);
        float r83973 = r83963 * r83972;
        float r83974 = -r83973;
        return r83974;
}

double f_id(float f) {
        double r83975 = atan2(1.0, 0.0);
        double r83976 = 4.0;
        double r83977 = r83975 / r83976;
        double r83978 = 1.0/r83977;
        double r83979 = f;
        double r83980 = r83977 * r83979;
        double r83981 = exp(r83980);
        double r83982 = -r83980;
        double r83983 = exp(r83982);
        double r83984 = r83981 + r83983;
        double r83985 = r83981 - r83983;
        double r83986 = r83984 / r83985;
        double r83987 = log(r83986);
        double r83988 = r83978 * r83987;
        double r83989 = -r83988;
        return r83989;
}

double f_il(float f) {
        long double r83990 = atan2(1.0, 0.0);
        long double r83991 = 4.0;
        long double r83992 = r83990 / r83991;
        long double r83993 = 1.0/r83992;
        long double r83994 = f;
        long double r83995 = r83992 * r83994;
        long double r83996 = exp(r83995);
        long double r83997 = -r83995;
        long double r83998 = exp(r83997);
        long double r83999 = r83996 + r83998;
        long double r84000 = r83996 - r83998;
        long double r84001 = r83999 / r84000;
        long double r84002 = log(r84001);
        long double r84003 = r83993 * r84002;
        long double r84004 = -r84003;
        return r84004;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float f) {
        float r84005 = 4.0;
        float r84006 = atan2(1.0, 0.0);
        float r84007 = r84005 / r84006;
        float r84008 = 0.25;
        float r84009 = r84006 * r84008;
        float r84010 = f;
        float r84011 = r84009 * r84010;
        float r84012 = exp(r84011);
        float r84013 = log(r84012);
        float r84014 = 1.0/r84012;
        float r84015 = r84012 - r84014;
        float r84016 = log(r84015);
        float r84017 = r84013 - r84016;
        float r84018 = exp(r84017);
        float r84019 = r84012 * r84012;
        float r84020 = r84014 * r84014;
        float r84021 = r84019 - r84020;
        float r84022 = r84012 + r84014;
        float r84023 = r84021 / r84022;
        float r84024 = r84023 * r84012;
        float r84025 = 1.0/r84024;
        float r84026 = r84018 + r84025;
        float r84027 = log(r84026);
        float r84028 = r84007 * r84027;
        float r84029 = -r84028;
        return r84029;
}

double f_od(float f) {
        double r84030 = 4.0;
        double r84031 = atan2(1.0, 0.0);
        double r84032 = r84030 / r84031;
        double r84033 = 0.25;
        double r84034 = r84031 * r84033;
        double r84035 = f;
        double r84036 = r84034 * r84035;
        double r84037 = exp(r84036);
        double r84038 = log(r84037);
        double r84039 = 1.0/r84037;
        double r84040 = r84037 - r84039;
        double r84041 = log(r84040);
        double r84042 = r84038 - r84041;
        double r84043 = exp(r84042);
        double r84044 = r84037 * r84037;
        double r84045 = r84039 * r84039;
        double r84046 = r84044 - r84045;
        double r84047 = r84037 + r84039;
        double r84048 = r84046 / r84047;
        double r84049 = r84048 * r84037;
        double r84050 = 1.0/r84049;
        double r84051 = r84043 + r84050;
        double r84052 = log(r84051);
        double r84053 = r84032 * r84052;
        double r84054 = -r84053;
        return r84054;
}

double f_ol(float f) {
        long double r84055 = 4.0;
        long double r84056 = atan2(1.0, 0.0);
        long double r84057 = r84055 / r84056;
        long double r84058 = 0.25;
        long double r84059 = r84056 * r84058;
        long double r84060 = f;
        long double r84061 = r84059 * r84060;
        long double r84062 = exp(r84061);
        long double r84063 = log(r84062);
        long double r84064 = 1.0/r84062;
        long double r84065 = r84062 - r84064;
        long double r84066 = log(r84065);
        long double r84067 = r84063 - r84066;
        long double r84068 = exp(r84067);
        long double r84069 = r84062 * r84062;
        long double r84070 = r84064 * r84064;
        long double r84071 = r84069 - r84070;
        long double r84072 = r84062 + r84064;
        long double r84073 = r84071 / r84072;
        long double r84074 = r84073 * r84062;
        long double r84075 = 1.0/r84074;
        long double r84076 = r84068 + r84075;
        long double r84077 = log(r84076);
        long double r84078 = r84057 * r84077;
        long double r84079 = -r84078;
        return r84079;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r84080, r84081, r84082, r84083, r84084, r84085, r84086, r84087, r84088, r84089, r84090, r84091, r84092, r84093, r84094;

void setup_mpfr() {
        mpfr_set_default_prec(1112);
        mpfr_init(r84080);
        mpfr_init(r84081);
        mpfr_init(r84082);
        mpfr_init(r84083);
        mpfr_init(r84084);
        mpfr_init(r84085);
        mpfr_init(r84086);
        mpfr_init(r84087);
        mpfr_init(r84088);
        mpfr_init(r84089);
        mpfr_init(r84090);
        mpfr_init(r84091);
        mpfr_init(r84092);
        mpfr_init(r84093);
        mpfr_init(r84094);
}

double f_im(float f) {
        mpfr_const_pi(r84080, MPFR_RNDN);
        mpfr_init_set_str(r84081, "4", 10, MPFR_RNDN);
        mpfr_div(r84082, r84080, r84081, MPFR_RNDN);
        mpfr_ui_div(r84083, 1, r84082, MPFR_RNDN);
        mpfr_set_flt(r84084, f, MPFR_RNDN);
        mpfr_mul(r84085, r84082, r84084, MPFR_RNDN);
        mpfr_exp(r84086, r84085, MPFR_RNDN);
        mpfr_neg(r84087, r84085, MPFR_RNDN);
        mpfr_exp(r84088, r84087, MPFR_RNDN);
        mpfr_add(r84089, r84086, r84088, MPFR_RNDN);
        mpfr_sub(r84090, r84086, r84088, MPFR_RNDN);
        mpfr_div(r84091, r84089, r84090, MPFR_RNDN);
        mpfr_log(r84092, r84091, MPFR_RNDN);
        mpfr_mul(r84093, r84083, r84092, MPFR_RNDN);
        mpfr_neg(r84094, r84093, MPFR_RNDN);
        return mpfr_get_d(r84094, MPFR_RNDN);
}

