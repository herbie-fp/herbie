#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Hyperbolic arc-(co)tangent */

double f_if(float x) {
        float r77073 = 1.0;
        float r77074 = 2.0;
        float r77075 = r77073 / r77074;
        float r77076 = x;
        float r77077 = r77073 + r77076;
        float r77078 = r77073 - r77076;
        float r77079 = r77077 / r77078;
        float r77080 = log(r77079);
        float r77081 = r77075 * r77080;
        return r77081;
}

double f_id(float x) {
        double r77082 = 1.0;
        double r77083 = 2.0;
        double r77084 = r77082 / r77083;
        double r77085 = x;
        double r77086 = r77082 + r77085;
        double r77087 = r77082 - r77085;
        double r77088 = r77086 / r77087;
        double r77089 = log(r77088);
        double r77090 = r77084 * r77089;
        return r77090;
}

double f_il(float x) {
        long double r77091 = 1.0;
        long double r77092 = 2.0;
        long double r77093 = r77091 / r77092;
        long double r77094 = x;
        long double r77095 = r77091 + r77094;
        long double r77096 = r77091 - r77094;
        long double r77097 = r77095 / r77096;
        long double r77098 = log(r77097);
        long double r77099 = r77093 * r77098;
        return r77099;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r77100 = x;
        float r77101 = 1.0349480369446343e-38;
        bool r77102 = r77100 < r77101;
        float r77103 = 0.5;
        float r77104 = 1.0;
        float r77105 = r77104 - r77100;
        float r77106 = r77104 / r77105;
        float r77107 = r77106 * r77106;
        float r77108 = r77100 * r77100;
        float r77109 = r77107 * r77108;
        float r77110 = sqrt(r77109);
        float r77111 = r77106 + r77110;
        float r77112 = r77111 / r77104;
        float r77113 = log(r77112);
        float r77114 = sqrt(r77106);
        float r77115 = sqrt(r77110);
        float r77116 = r77114 + r77115;
        float r77117 = r77116 / r77104;
        float r77118 = log(r77117);
        float r77119 = sqrt(r77118);
        float r77120 = r77119 * r77119;
        float r77121 = r77114 * r77114;
        float r77122 = r77115 * r77115;
        float r77123 = r77121 - r77122;
        float r77124 = r77123 / r77116;
        float r77125 = r77100 / r77105;
        float r77126 = r77106 - r77125;
        float r77127 = 1.0/r77126;
        float r77128 = r77124 * r77127;
        float r77129 = log(r77128);
        float r77130 = r77120 + r77129;
        float r77131 = r77113 + r77130;
        float r77132 = r77103 * r77131;
        float r77133 = r77107 * r77107;
        float r77134 = 1.0/r77105;
        float r77135 = r77134 * r77100;
        float r77136 = r77135 * r77135;
        float r77137 = r77136 * r77136;
        float r77138 = r77133 - r77137;
        float r77139 = log(r77138);
        float r77140 = r77107 + r77136;
        float r77141 = log(r77140);
        float r77142 = r77139 - r77141;
        float r77143 = sqrt(r77135);
        float r77144 = r77114 + r77143;
        float r77145 = log(r77144);
        float r77146 = r77114 - r77143;
        float r77147 = log(r77146);
        float r77148 = r77145 + r77147;
        float r77149 = r77142 - r77148;
        float r77150 = r77103 * r77149;
        float r77151 = r77102 ? r77132 : r77150;
        return r77151;
}

double f_od(float x) {
        double r77152 = x;
        double r77153 = 1.0349480369446343e-38;
        bool r77154 = r77152 < r77153;
        double r77155 = 0.5;
        double r77156 = 1.0;
        double r77157 = r77156 - r77152;
        double r77158 = r77156 / r77157;
        double r77159 = r77158 * r77158;
        double r77160 = r77152 * r77152;
        double r77161 = r77159 * r77160;
        double r77162 = sqrt(r77161);
        double r77163 = r77158 + r77162;
        double r77164 = r77163 / r77156;
        double r77165 = log(r77164);
        double r77166 = sqrt(r77158);
        double r77167 = sqrt(r77162);
        double r77168 = r77166 + r77167;
        double r77169 = r77168 / r77156;
        double r77170 = log(r77169);
        double r77171 = sqrt(r77170);
        double r77172 = r77171 * r77171;
        double r77173 = r77166 * r77166;
        double r77174 = r77167 * r77167;
        double r77175 = r77173 - r77174;
        double r77176 = r77175 / r77168;
        double r77177 = r77152 / r77157;
        double r77178 = r77158 - r77177;
        double r77179 = 1.0/r77178;
        double r77180 = r77176 * r77179;
        double r77181 = log(r77180);
        double r77182 = r77172 + r77181;
        double r77183 = r77165 + r77182;
        double r77184 = r77155 * r77183;
        double r77185 = r77159 * r77159;
        double r77186 = 1.0/r77157;
        double r77187 = r77186 * r77152;
        double r77188 = r77187 * r77187;
        double r77189 = r77188 * r77188;
        double r77190 = r77185 - r77189;
        double r77191 = log(r77190);
        double r77192 = r77159 + r77188;
        double r77193 = log(r77192);
        double r77194 = r77191 - r77193;
        double r77195 = sqrt(r77187);
        double r77196 = r77166 + r77195;
        double r77197 = log(r77196);
        double r77198 = r77166 - r77195;
        double r77199 = log(r77198);
        double r77200 = r77197 + r77199;
        double r77201 = r77194 - r77200;
        double r77202 = r77155 * r77201;
        double r77203 = r77154 ? r77184 : r77202;
        return r77203;
}

double f_ol(float x) {
        long double r77204 = x;
        long double r77205 = 1.0349480369446343e-38;
        bool r77206 = r77204 < r77205;
        long double r77207 = 0.5;
        long double r77208 = 1.0;
        long double r77209 = r77208 - r77204;
        long double r77210 = r77208 / r77209;
        long double r77211 = r77210 * r77210;
        long double r77212 = r77204 * r77204;
        long double r77213 = r77211 * r77212;
        long double r77214 = sqrt(r77213);
        long double r77215 = r77210 + r77214;
        long double r77216 = r77215 / r77208;
        long double r77217 = log(r77216);
        long double r77218 = sqrt(r77210);
        long double r77219 = sqrt(r77214);
        long double r77220 = r77218 + r77219;
        long double r77221 = r77220 / r77208;
        long double r77222 = log(r77221);
        long double r77223 = sqrt(r77222);
        long double r77224 = r77223 * r77223;
        long double r77225 = r77218 * r77218;
        long double r77226 = r77219 * r77219;
        long double r77227 = r77225 - r77226;
        long double r77228 = r77227 / r77220;
        long double r77229 = r77204 / r77209;
        long double r77230 = r77210 - r77229;
        long double r77231 = 1.0/r77230;
        long double r77232 = r77228 * r77231;
        long double r77233 = log(r77232);
        long double r77234 = r77224 + r77233;
        long double r77235 = r77217 + r77234;
        long double r77236 = r77207 * r77235;
        long double r77237 = r77211 * r77211;
        long double r77238 = 1.0/r77209;
        long double r77239 = r77238 * r77204;
        long double r77240 = r77239 * r77239;
        long double r77241 = r77240 * r77240;
        long double r77242 = r77237 - r77241;
        long double r77243 = log(r77242);
        long double r77244 = r77211 + r77240;
        long double r77245 = log(r77244);
        long double r77246 = r77243 - r77245;
        long double r77247 = sqrt(r77239);
        long double r77248 = r77218 + r77247;
        long double r77249 = log(r77248);
        long double r77250 = r77218 - r77247;
        long double r77251 = log(r77250);
        long double r77252 = r77249 + r77251;
        long double r77253 = r77246 - r77252;
        long double r77254 = r77207 * r77253;
        long double r77255 = r77206 ? r77236 : r77254;
        return r77255;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r77256, r77257, r77258, r77259, r77260, r77261, r77262, r77263, r77264;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r77256);
        mpfr_init(r77257);
        mpfr_init(r77258);
        mpfr_init(r77259);
        mpfr_init(r77260);
        mpfr_init(r77261);
        mpfr_init(r77262);
        mpfr_init(r77263);
        mpfr_init(r77264);
}

double f_im(float x) {
        mpfr_init_set_str(r77256, "1", 10, MPFR_RNDN);
        mpfr_init_set_str(r77257, "2", 10, MPFR_RNDN);
        mpfr_div(r77258, r77256, r77257, MPFR_RNDN);
        mpfr_set_flt(r77259, x, MPFR_RNDN);
        mpfr_add(r77260, r77256, r77259, MPFR_RNDN);
        mpfr_sub(r77261, r77256, r77259, MPFR_RNDN);
        mpfr_div(r77262, r77260, r77261, MPFR_RNDN);
        mpfr_log(r77263, r77262, MPFR_RNDN);
        mpfr_mul(r77264, r77258, r77263, MPFR_RNDN);
        return mpfr_get_d(r77264, MPFR_RNDN);
}

