#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE example 3.1 */

double f_if(float x) {
        float r73522 = x;
        float r73523 = 1.0;
        float r73524 = r73522 + r73523;
        float r73525 = sqrt(r73524);
        float r73526 = sqrt(r73522);
        float r73527 = r73525 - r73526;
        return r73527;
}

double f_id(float x) {
        double r73528 = x;
        double r73529 = 1.0;
        double r73530 = r73528 + r73529;
        double r73531 = sqrt(r73530);
        double r73532 = sqrt(r73528);
        double r73533 = r73531 - r73532;
        return r73533;
}

double f_il(float x) {
        long double r73534 = x;
        long double r73535 = 1.0;
        long double r73536 = r73534 + r73535;
        long double r73537 = sqrt(r73536);
        long double r73538 = sqrt(r73534);
        long double r73539 = r73537 - r73538;
        return r73539;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r73540 = 1.0;
        float r73541 = x;
        float r73542 = r73541 + r73540;
        float r73543 = sqrt(r73542);
        float r73544 = sqrt(r73541);
        float r73545 = r73543 + r73544;
        float r73546 = r73540 / r73545;
        return r73546;
}

double f_od(float x) {
        double r73547 = 1.0;
        double r73548 = x;
        double r73549 = r73548 + r73547;
        double r73550 = sqrt(r73549);
        double r73551 = sqrt(r73548);
        double r73552 = r73550 + r73551;
        double r73553 = r73547 / r73552;
        return r73553;
}

double f_ol(float x) {
        long double r73554 = 1.0;
        long double r73555 = x;
        long double r73556 = r73555 + r73554;
        long double r73557 = sqrt(r73556);
        long double r73558 = sqrt(r73555);
        long double r73559 = r73557 + r73558;
        long double r73560 = r73554 / r73559;
        return r73560;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r73561, r73562, r73563, r73564, r73565, r73566;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r73561);
        mpfr_init(r73562);
        mpfr_init(r73563);
        mpfr_init(r73564);
        mpfr_init(r73565);
        mpfr_init(r73566);
}

double f_im(float x) {
        mpfr_set_flt(r73561, x, MPFR_RNDN);
        mpfr_init_set_str(r73562, "1", 10, MPFR_RNDN);
        mpfr_add(r73563, r73561, r73562, MPFR_RNDN);
        mpfr_sqrt(r73564, r73563, MPFR_RNDN);
        mpfr_sqrt(r73565, r73561, MPFR_RNDN);
        mpfr_sub(r73566, r73564, r73565, MPFR_RNDN);
        return mpfr_get_d(r73566, MPFR_RNDN);
}

