#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.cos on complex, imaginary part */

double f_if(float re, float im) {
        float r84734 = 0.5;
        float r84735 = re;
        float r84736 = sin(r84735);
        float r84737 = r84734 * r84736;
        float r84738 = im;
        float r84739 = -r84738;
        float r84740 = exp(r84739);
        float r84741 = exp(r84738);
        float r84742 = r84740 - r84741;
        float r84743 = r84737 * r84742;
        return r84743;
}

double f_id(float re, float im) {
        double r84744 = 0.5;
        double r84745 = re;
        double r84746 = sin(r84745);
        double r84747 = r84744 * r84746;
        double r84748 = im;
        double r84749 = -r84748;
        double r84750 = exp(r84749);
        double r84751 = exp(r84748);
        double r84752 = r84750 - r84751;
        double r84753 = r84747 * r84752;
        return r84753;
}

double f_il(float re, float im) {
        long double r84754 = 0.5;
        long double r84755 = re;
        long double r84756 = sin(r84755);
        long double r84757 = r84754 * r84756;
        long double r84758 = im;
        long double r84759 = -r84758;
        long double r84760 = exp(r84759);
        long double r84761 = exp(r84758);
        long double r84762 = r84760 - r84761;
        long double r84763 = r84757 * r84762;
        return r84763;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r84764 = re;
        float r84765 = 4.966376845546063e+37;
        bool r84766 = r84764 < r84765;
        float r84767 = im;
        float r84768 = -3.826838646424097e-16;
        bool r84769 = r84767 < r84768;
        float r84770 = 1.0;
        float r84771 = exp(r84767);
        float r84772 = 0.5;
        float r84773 = sin(r84764);
        float r84774 = r84772 * r84773;
        float r84775 = r84771 / r84774;
        float r84776 = r84775 * r84775;
        float r84777 = r84776 * r84776;
        float r84778 = r84770 / r84777;
        float r84779 = r84774 * r84771;
        float r84780 = r84779 * r84779;
        float r84781 = r84780 * r84780;
        float r84782 = r84778 - r84781;
        float r84783 = r84770 / r84776;
        float r84784 = r84783 * r84783;
        float r84785 = r84784 - r84781;
        float r84786 = log(r84785);
        float r84787 = exp(r84786);
        float r84788 = r84783 - r84780;
        float r84789 = r84787 / r84788;
        float r84790 = r84782 / r84789;
        float r84791 = r84770 / r84775;
        float r84792 = r84791 + r84779;
        float r84793 = r84790 / r84792;
        float r84794 = -2.162996615446435e-33;
        bool r84795 = r84767 < r84794;
        float r84796 = r84783 + r84780;
        float r84797 = sqrt(r84796);
        float r84798 = r84797 * r84797;
        float r84799 = r84782 / r84798;
        float r84800 = r84799 / r84792;
        float r84801 = 7.70013699955983e-24;
        bool r84802 = r84767 < r84801;
        float r84803 = exp(r84778);
        float r84804 = log(r84803);
        float r84805 = exp(r84781);
        float r84806 = log(r84805);
        float r84807 = r84804 - r84806;
        float r84808 = r84807 / r84796;
        float r84809 = r84808 / r84792;
        float r84810 = r84802 ? r84809 : r84800;
        float r84811 = r84795 ? r84800 : r84810;
        float r84812 = r84769 ? r84793 : r84811;
        float r84813 = r84791 * r84791;
        float r84814 = exp(r84813);
        float r84815 = log(r84814);
        float r84816 = log(r84815);
        float r84817 = exp(r84816);
        float r84818 = exp(r84770);
        float r84819 = log(r84780);
        float r84820 = pow(r84818, r84819);
        float r84821 = r84817 - r84820;
        float r84822 = r84821 / r84792;
        float r84823 = log(r84783);
        float r84824 = exp(r84823);
        float r84825 = r84824 - r84820;
        float r84826 = r84825 / r84792;
        float r84827 = r84795 ? r84822 : r84826;
        float r84828 = r84766 ? r84812 : r84827;
        return r84828;
}

double f_od(float re, float im) {
        double r84829 = re;
        double r84830 = 4.966376845546063e+37;
        bool r84831 = r84829 < r84830;
        double r84832 = im;
        double r84833 = -3.826838646424097e-16;
        bool r84834 = r84832 < r84833;
        double r84835 = 1.0;
        double r84836 = exp(r84832);
        double r84837 = 0.5;
        double r84838 = sin(r84829);
        double r84839 = r84837 * r84838;
        double r84840 = r84836 / r84839;
        double r84841 = r84840 * r84840;
        double r84842 = r84841 * r84841;
        double r84843 = r84835 / r84842;
        double r84844 = r84839 * r84836;
        double r84845 = r84844 * r84844;
        double r84846 = r84845 * r84845;
        double r84847 = r84843 - r84846;
        double r84848 = r84835 / r84841;
        double r84849 = r84848 * r84848;
        double r84850 = r84849 - r84846;
        double r84851 = log(r84850);
        double r84852 = exp(r84851);
        double r84853 = r84848 - r84845;
        double r84854 = r84852 / r84853;
        double r84855 = r84847 / r84854;
        double r84856 = r84835 / r84840;
        double r84857 = r84856 + r84844;
        double r84858 = r84855 / r84857;
        double r84859 = -2.162996615446435e-33;
        bool r84860 = r84832 < r84859;
        double r84861 = r84848 + r84845;
        double r84862 = sqrt(r84861);
        double r84863 = r84862 * r84862;
        double r84864 = r84847 / r84863;
        double r84865 = r84864 / r84857;
        double r84866 = 7.70013699955983e-24;
        bool r84867 = r84832 < r84866;
        double r84868 = exp(r84843);
        double r84869 = log(r84868);
        double r84870 = exp(r84846);
        double r84871 = log(r84870);
        double r84872 = r84869 - r84871;
        double r84873 = r84872 / r84861;
        double r84874 = r84873 / r84857;
        double r84875 = r84867 ? r84874 : r84865;
        double r84876 = r84860 ? r84865 : r84875;
        double r84877 = r84834 ? r84858 : r84876;
        double r84878 = r84856 * r84856;
        double r84879 = exp(r84878);
        double r84880 = log(r84879);
        double r84881 = log(r84880);
        double r84882 = exp(r84881);
        double r84883 = exp(r84835);
        double r84884 = log(r84845);
        double r84885 = pow(r84883, r84884);
        double r84886 = r84882 - r84885;
        double r84887 = r84886 / r84857;
        double r84888 = log(r84848);
        double r84889 = exp(r84888);
        double r84890 = r84889 - r84885;
        double r84891 = r84890 / r84857;
        double r84892 = r84860 ? r84887 : r84891;
        double r84893 = r84831 ? r84877 : r84892;
        return r84893;
}

double f_ol(float re, float im) {
        long double r84894 = re;
        long double r84895 = 4.966376845546063e+37;
        bool r84896 = r84894 < r84895;
        long double r84897 = im;
        long double r84898 = -3.826838646424097e-16;
        bool r84899 = r84897 < r84898;
        long double r84900 = 1.0;
        long double r84901 = exp(r84897);
        long double r84902 = 0.5;
        long double r84903 = sin(r84894);
        long double r84904 = r84902 * r84903;
        long double r84905 = r84901 / r84904;
        long double r84906 = r84905 * r84905;
        long double r84907 = r84906 * r84906;
        long double r84908 = r84900 / r84907;
        long double r84909 = r84904 * r84901;
        long double r84910 = r84909 * r84909;
        long double r84911 = r84910 * r84910;
        long double r84912 = r84908 - r84911;
        long double r84913 = r84900 / r84906;
        long double r84914 = r84913 * r84913;
        long double r84915 = r84914 - r84911;
        long double r84916 = log(r84915);
        long double r84917 = exp(r84916);
        long double r84918 = r84913 - r84910;
        long double r84919 = r84917 / r84918;
        long double r84920 = r84912 / r84919;
        long double r84921 = r84900 / r84905;
        long double r84922 = r84921 + r84909;
        long double r84923 = r84920 / r84922;
        long double r84924 = -2.162996615446435e-33;
        bool r84925 = r84897 < r84924;
        long double r84926 = r84913 + r84910;
        long double r84927 = sqrt(r84926);
        long double r84928 = r84927 * r84927;
        long double r84929 = r84912 / r84928;
        long double r84930 = r84929 / r84922;
        long double r84931 = 7.70013699955983e-24;
        bool r84932 = r84897 < r84931;
        long double r84933 = exp(r84908);
        long double r84934 = log(r84933);
        long double r84935 = exp(r84911);
        long double r84936 = log(r84935);
        long double r84937 = r84934 - r84936;
        long double r84938 = r84937 / r84926;
        long double r84939 = r84938 / r84922;
        long double r84940 = r84932 ? r84939 : r84930;
        long double r84941 = r84925 ? r84930 : r84940;
        long double r84942 = r84899 ? r84923 : r84941;
        long double r84943 = r84921 * r84921;
        long double r84944 = exp(r84943);
        long double r84945 = log(r84944);
        long double r84946 = log(r84945);
        long double r84947 = exp(r84946);
        long double r84948 = exp(r84900);
        long double r84949 = log(r84910);
        long double r84950 = pow(r84948, r84949);
        long double r84951 = r84947 - r84950;
        long double r84952 = r84951 / r84922;
        long double r84953 = log(r84913);
        long double r84954 = exp(r84953);
        long double r84955 = r84954 - r84950;
        long double r84956 = r84955 / r84922;
        long double r84957 = r84925 ? r84952 : r84956;
        long double r84958 = r84896 ? r84942 : r84957;
        return r84958;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r84959, r84960, r84961, r84962, r84963, r84964, r84965, r84966, r84967, r84968;

void setup_mpfr() {
        mpfr_set_default_prec(200);
        mpfr_init(r84959);
        mpfr_init(r84960);
        mpfr_init(r84961);
        mpfr_init(r84962);
        mpfr_init(r84963);
        mpfr_init(r84964);
        mpfr_init(r84965);
        mpfr_init(r84966);
        mpfr_init(r84967);
        mpfr_init(r84968);
}

double f_im(float re, float im) {
        mpfr_init_set_str(r84959, "0.5", 10, MPFR_RNDN);
        mpfr_set_flt(r84960, re, MPFR_RNDN);
        mpfr_sin(r84961, r84960, MPFR_RNDN);
        mpfr_mul(r84962, r84959, r84961, MPFR_RNDN);
        mpfr_set_flt(r84963, im, MPFR_RNDN);
        mpfr_neg(r84964, r84963, MPFR_RNDN);
        mpfr_exp(r84965, r84964, MPFR_RNDN);
        mpfr_exp(r84966, r84963, MPFR_RNDN);
        mpfr_sub(r84967, r84965, r84966, MPFR_RNDN);
        mpfr_mul(r84968, r84962, r84967, MPFR_RNDN);
        return mpfr_get_d(r84968, MPFR_RNDN);
}

