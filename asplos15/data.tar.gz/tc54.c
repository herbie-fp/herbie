#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Henrywood and Agarwal, Equation (3) */

double f_if(float c0, float A, float V, float l) {
        float r76814 = c0;
        float r76815 = A;
        float r76816 = V;
        float r76817 = l;
        float r76818 = r76816 * r76817;
        float r76819 = r76815 / r76818;
        float r76820 = sqrt(r76819);
        float r76821 = r76814 * r76820;
        return r76821;
}

double f_id(float c0, float A, float V, float l) {
        double r76822 = c0;
        double r76823 = A;
        double r76824 = V;
        double r76825 = l;
        double r76826 = r76824 * r76825;
        double r76827 = r76823 / r76826;
        double r76828 = sqrt(r76827);
        double r76829 = r76822 * r76828;
        return r76829;
}

double f_il(float c0, float A, float V, float l) {
        long double r76830 = c0;
        long double r76831 = A;
        long double r76832 = V;
        long double r76833 = l;
        long double r76834 = r76832 * r76833;
        long double r76835 = r76831 / r76834;
        long double r76836 = sqrt(r76835);
        long double r76837 = r76830 * r76836;
        return r76837;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float c0, float A, float V, float l) {
        float r76838 = c0;
        float r76839 = 1.0;
        float r76840 = V;
        float r76841 = l;
        float r76842 = A;
        float r76843 = r76841 / r76842;
        float r76844 = r76840 * r76843;
        float r76845 = r76839 / r76844;
        float r76846 = sqrt(r76845);
        float r76847 = r76838 * r76846;
        return r76847;
}

double f_od(float c0, float A, float V, float l) {
        double r76848 = c0;
        double r76849 = 1.0;
        double r76850 = V;
        double r76851 = l;
        double r76852 = A;
        double r76853 = r76851 / r76852;
        double r76854 = r76850 * r76853;
        double r76855 = r76849 / r76854;
        double r76856 = sqrt(r76855);
        double r76857 = r76848 * r76856;
        return r76857;
}

double f_ol(float c0, float A, float V, float l) {
        long double r76858 = c0;
        long double r76859 = 1.0;
        long double r76860 = V;
        long double r76861 = l;
        long double r76862 = A;
        long double r76863 = r76861 / r76862;
        long double r76864 = r76860 * r76863;
        long double r76865 = r76859 / r76864;
        long double r76866 = sqrt(r76865);
        long double r76867 = r76858 * r76866;
        return r76867;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r76868, r76869, r76870, r76871, r76872, r76873, r76874, r76875;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r76868);
        mpfr_init(r76869);
        mpfr_init(r76870);
        mpfr_init(r76871);
        mpfr_init(r76872);
        mpfr_init(r76873);
        mpfr_init(r76874);
        mpfr_init(r76875);
}

double f_im(float c0, float A, float V, float l) {
        mpfr_set_flt(r76868, c0, MPFR_RNDN);
        mpfr_set_flt(r76869, A, MPFR_RNDN);
        mpfr_set_flt(r76870, V, MPFR_RNDN);
        mpfr_set_flt(r76871, l, MPFR_RNDN);
        mpfr_mul(r76872, r76870, r76871, MPFR_RNDN);
        mpfr_div(r76873, r76869, r76872, MPFR_RNDN);
        mpfr_sqrt(r76874, r76873, MPFR_RNDN);
        mpfr_mul(r76875, r76868, r76874, MPFR_RNDN);
        return mpfr_get_d(r76875, MPFR_RNDN);
}

