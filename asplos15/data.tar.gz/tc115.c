#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.exp on complex, imaginary part */

double f_if(float re, float im) {
        float r85210 = re;
        float r85211 = exp(r85210);
        float r85212 = im;
        float r85213 = sin(r85212);
        float r85214 = r85211 * r85213;
        return r85214;
}

double f_id(float re, float im) {
        double r85215 = re;
        double r85216 = exp(r85215);
        double r85217 = im;
        double r85218 = sin(r85217);
        double r85219 = r85216 * r85218;
        return r85219;
}

double f_il(float re, float im) {
        long double r85220 = re;
        long double r85221 = exp(r85220);
        long double r85222 = im;
        long double r85223 = sin(r85222);
        long double r85224 = r85221 * r85223;
        return r85224;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r85225 = re;
        float r85226 = exp(r85225);
        float r85227 = im;
        float r85228 = sin(r85227);
        float r85229 = r85226 * r85228;
        return r85229;
}

double f_od(float re, float im) {
        double r85230 = re;
        double r85231 = exp(r85230);
        double r85232 = im;
        double r85233 = sin(r85232);
        double r85234 = r85231 * r85233;
        return r85234;
}

double f_ol(float re, float im) {
        long double r85235 = re;
        long double r85236 = exp(r85235);
        long double r85237 = im;
        long double r85238 = sin(r85237);
        long double r85239 = r85236 * r85238;
        return r85239;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r85240, r85241, r85242, r85243, r85244;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r85240);
        mpfr_init(r85241);
        mpfr_init(r85242);
        mpfr_init(r85243);
        mpfr_init(r85244);
}

double f_im(float re, float im) {
        mpfr_set_flt(r85240, re, MPFR_RNDN);
        mpfr_exp(r85241, r85240, MPFR_RNDN);
        mpfr_set_flt(r85242, im, MPFR_RNDN);
        mpfr_sin(r85243, r85242, MPFR_RNDN);
        mpfr_mul(r85244, r85241, r85243, MPFR_RNDN);
        return mpfr_get_d(r85244, MPFR_RNDN);
}

