#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Octave 3.8, oct_fill_randg */

double f_if(float a, float rand) {
        float r81746 = a;
        float r81747 = 1.0;
        float r81748 = 3.0;
        float r81749 = r81747 / r81748;
        float r81750 = r81746 - r81749;
        float r81751 = 1.0;
        float r81752 = 9.0;
        float r81753 = r81752 * r81750;
        float r81754 = sqrt(r81753);
        float r81755 = r81751 / r81754;
        float r81756 = rand;
        float r81757 = r81755 * r81756;
        float r81758 = r81751 + r81757;
        float r81759 = r81750 * r81758;
        return r81759;
}

double f_id(float a, float rand) {
        double r81760 = a;
        double r81761 = 1.0;
        double r81762 = 3.0;
        double r81763 = r81761 / r81762;
        double r81764 = r81760 - r81763;
        double r81765 = 1.0;
        double r81766 = 9.0;
        double r81767 = r81766 * r81764;
        double r81768 = sqrt(r81767);
        double r81769 = r81765 / r81768;
        double r81770 = rand;
        double r81771 = r81769 * r81770;
        double r81772 = r81765 + r81771;
        double r81773 = r81764 * r81772;
        return r81773;
}

double f_il(float a, float rand) {
        long double r81774 = a;
        long double r81775 = 1.0;
        long double r81776 = 3.0;
        long double r81777 = r81775 / r81776;
        long double r81778 = r81774 - r81777;
        long double r81779 = 1.0;
        long double r81780 = 9.0;
        long double r81781 = r81780 * r81778;
        long double r81782 = sqrt(r81781);
        long double r81783 = r81779 / r81782;
        long double r81784 = rand;
        long double r81785 = r81783 * r81784;
        long double r81786 = r81779 + r81785;
        long double r81787 = r81778 * r81786;
        return r81787;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a, float rand) {
        float r81788 = a;
        float r81789 = -0.3333333333333333;
        float r81790 = r81788 + r81789;
        float r81791 = rand;
        float r81792 = 9.0;
        float r81793 = r81792 * r81788;
        float r81794 = -3.0;
        float r81795 = r81793 + r81794;
        float r81796 = sqrt(r81795);
        float r81797 = r81791 / r81796;
        float r81798 = r81797 * r81788;
        float r81799 = 0.3333333333333333;
        float r81800 = r81797 * r81799;
        float r81801 = r81798 - r81800;
        float r81802 = r81790 + r81801;
        return r81802;
}

double f_od(float a, float rand) {
        double r81803 = a;
        double r81804 = -0.3333333333333333;
        double r81805 = r81803 + r81804;
        double r81806 = rand;
        double r81807 = 9.0;
        double r81808 = r81807 * r81803;
        double r81809 = -3.0;
        double r81810 = r81808 + r81809;
        double r81811 = sqrt(r81810);
        double r81812 = r81806 / r81811;
        double r81813 = r81812 * r81803;
        double r81814 = 0.3333333333333333;
        double r81815 = r81812 * r81814;
        double r81816 = r81813 - r81815;
        double r81817 = r81805 + r81816;
        return r81817;
}

double f_ol(float a, float rand) {
        long double r81818 = a;
        long double r81819 = -0.3333333333333333;
        long double r81820 = r81818 + r81819;
        long double r81821 = rand;
        long double r81822 = 9.0;
        long double r81823 = r81822 * r81818;
        long double r81824 = -3.0;
        long double r81825 = r81823 + r81824;
        long double r81826 = sqrt(r81825);
        long double r81827 = r81821 / r81826;
        long double r81828 = r81827 * r81818;
        long double r81829 = 0.3333333333333333;
        long double r81830 = r81827 * r81829;
        long double r81831 = r81828 - r81830;
        long double r81832 = r81820 + r81831;
        return r81832;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r81833, r81834, r81835, r81836, r81837, r81838, r81839, r81840, r81841, r81842, r81843, r81844, r81845, r81846;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r81833);
        mpfr_init(r81834);
        mpfr_init(r81835);
        mpfr_init(r81836);
        mpfr_init(r81837);
        mpfr_init(r81838);
        mpfr_init(r81839);
        mpfr_init(r81840);
        mpfr_init(r81841);
        mpfr_init(r81842);
        mpfr_init(r81843);
        mpfr_init(r81844);
        mpfr_init(r81845);
        mpfr_init(r81846);
}

double f_im(float a, float rand) {
        mpfr_set_flt(r81833, a, MPFR_RNDN);
        mpfr_init_set_str(r81834, "1.0", 10, MPFR_RNDN);
        mpfr_init_set_str(r81835, "3.0", 10, MPFR_RNDN);
        mpfr_div(r81836, r81834, r81835, MPFR_RNDN);
        mpfr_sub(r81837, r81833, r81836, MPFR_RNDN);
        mpfr_init_set_str(r81838, "1", 10, MPFR_RNDN);
        mpfr_init_set_str(r81839, "9", 10, MPFR_RNDN);
        mpfr_mul(r81840, r81839, r81837, MPFR_RNDN);
        mpfr_sqrt(r81841, r81840, MPFR_RNDN);
        mpfr_div(r81842, r81838, r81841, MPFR_RNDN);
        mpfr_set_flt(r81843, rand, MPFR_RNDN);
        mpfr_mul(r81844, r81842, r81843, MPFR_RNDN);
        mpfr_add(r81845, r81838, r81844, MPFR_RNDN);
        mpfr_mul(r81846, r81837, r81845, MPFR_RNDN);
        return mpfr_get_d(r81846, MPFR_RNDN);
}

