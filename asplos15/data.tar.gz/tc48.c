#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Falkner and Boettcher, Appendix B, 1 */

double f_if(float v) {
        float r75962 = 1.0;
        float r75963 = 5.0;
        float r75964 = v;
        float r75965 = r75964 * r75964;
        float r75966 = r75963 * r75965;
        float r75967 = r75962 - r75966;
        float r75968 = r75965 - r75962;
        float r75969 = r75967 / r75968;
        float r75970 = acos(r75969);
        return r75970;
}

double f_id(float v) {
        double r75971 = 1.0;
        double r75972 = 5.0;
        double r75973 = v;
        double r75974 = r75973 * r75973;
        double r75975 = r75972 * r75974;
        double r75976 = r75971 - r75975;
        double r75977 = r75974 - r75971;
        double r75978 = r75976 / r75977;
        double r75979 = acos(r75978);
        return r75979;
}

double f_il(float v) {
        long double r75980 = 1.0;
        long double r75981 = 5.0;
        long double r75982 = v;
        long double r75983 = r75982 * r75982;
        long double r75984 = r75981 * r75983;
        long double r75985 = r75980 - r75984;
        long double r75986 = r75983 - r75980;
        long double r75987 = r75985 / r75986;
        long double r75988 = acos(r75987);
        return r75988;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float v) {
        float r75989 = 1.0;
        float r75990 = 5.0;
        float r75991 = v;
        float r75992 = r75990 * r75991;
        float r75993 = r75992 * r75991;
        float r75994 = r75989 - r75993;
        float r75995 = r75991 * r75991;
        float r75996 = r75995 - r75989;
        float r75997 = r75994 / r75996;
        float r75998 = acos(r75997);
        return r75998;
}

double f_od(float v) {
        double r75999 = 1.0;
        double r76000 = 5.0;
        double r76001 = v;
        double r76002 = r76000 * r76001;
        double r76003 = r76002 * r76001;
        double r76004 = r75999 - r76003;
        double r76005 = r76001 * r76001;
        double r76006 = r76005 - r75999;
        double r76007 = r76004 / r76006;
        double r76008 = acos(r76007);
        return r76008;
}

double f_ol(float v) {
        long double r76009 = 1.0;
        long double r76010 = 5.0;
        long double r76011 = v;
        long double r76012 = r76010 * r76011;
        long double r76013 = r76012 * r76011;
        long double r76014 = r76009 - r76013;
        long double r76015 = r76011 * r76011;
        long double r76016 = r76015 - r76009;
        long double r76017 = r76014 / r76016;
        long double r76018 = acos(r76017);
        return r76018;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r76019, r76020, r76021, r76022, r76023, r76024, r76025, r76026, r76027;

void setup_mpfr() {
        mpfr_set_default_prec(136);
        mpfr_init(r76019);
        mpfr_init(r76020);
        mpfr_init(r76021);
        mpfr_init(r76022);
        mpfr_init(r76023);
        mpfr_init(r76024);
        mpfr_init(r76025);
        mpfr_init(r76026);
        mpfr_init(r76027);
}

double f_im(float v) {
        mpfr_init_set_str(r76019, "1", 10, MPFR_RNDN);
        mpfr_init_set_str(r76020, "5", 10, MPFR_RNDN);
        mpfr_set_flt(r76021, v, MPFR_RNDN);
        mpfr_mul(r76022, r76021, r76021, MPFR_RNDN);
        mpfr_mul(r76023, r76020, r76022, MPFR_RNDN);
        mpfr_sub(r76024, r76019, r76023, MPFR_RNDN);
        mpfr_sub(r76025, r76022, r76019, MPFR_RNDN);
        mpfr_div(r76026, r76024, r76025, MPFR_RNDN);
        mpfr_acos(r76027, r76026, MPFR_RNDN);
        return mpfr_get_d(r76027, MPFR_RNDN);
}

