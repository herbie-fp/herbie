#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE problem 3.4.5 */

double f_if(float x) {
        float r80923 = x;
        float r80924 = sin(r80923);
        float r80925 = r80923 - r80924;
        float r80926 = tan(r80923);
        float r80927 = r80923 - r80926;
        float r80928 = r80925 / r80927;
        return r80928;
}

double f_id(float x) {
        double r80929 = x;
        double r80930 = sin(r80929);
        double r80931 = r80929 - r80930;
        double r80932 = tan(r80929);
        double r80933 = r80929 - r80932;
        double r80934 = r80931 / r80933;
        return r80934;
}

double f_il(float x) {
        long double r80935 = x;
        long double r80936 = sin(r80935);
        long double r80937 = r80935 - r80936;
        long double r80938 = tan(r80935);
        long double r80939 = r80935 - r80938;
        long double r80940 = r80937 / r80939;
        return r80940;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r80941 = x;
        float r80942 = tan(r80941);
        float r80943 = r80941 - r80942;
        float r80944 = r80941 / r80943;
        float r80945 = sin(r80941);
        float r80946 = r80945 / r80943;
        float r80947 = r80944 - r80946;
        return r80947;
}

double f_od(float x) {
        double r80948 = x;
        double r80949 = tan(r80948);
        double r80950 = r80948 - r80949;
        double r80951 = r80948 / r80950;
        double r80952 = sin(r80948);
        double r80953 = r80952 / r80950;
        double r80954 = r80951 - r80953;
        return r80954;
}

double f_ol(float x) {
        long double r80955 = x;
        long double r80956 = tan(r80955);
        long double r80957 = r80955 - r80956;
        long double r80958 = r80955 / r80957;
        long double r80959 = sin(r80955);
        long double r80960 = r80959 / r80957;
        long double r80961 = r80958 - r80960;
        return r80961;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r80962, r80963, r80964, r80965, r80966, r80967;

void setup_mpfr() {
        mpfr_set_default_prec(344);
        mpfr_init(r80962);
        mpfr_init(r80963);
        mpfr_init(r80964);
        mpfr_init(r80965);
        mpfr_init(r80966);
        mpfr_init(r80967);
}

double f_im(float x) {
        mpfr_set_flt(r80962, x, MPFR_RNDN);
        mpfr_sin(r80963, r80962, MPFR_RNDN);
        mpfr_sub(r80964, r80962, r80963, MPFR_RNDN);
        mpfr_tan(r80965, r80962, MPFR_RNDN);
        mpfr_sub(r80966, r80962, r80965, MPFR_RNDN);
        mpfr_div(r80967, r80964, r80966, MPFR_RNDN);
        return mpfr_get_d(r80967, MPFR_RNDN);
}

