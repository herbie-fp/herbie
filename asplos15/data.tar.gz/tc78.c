#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE problem 3.2.1 */

double f_if(float a, float b_2F2, float c) {
        float r80350 = -2.0;
        float r80351 = b_2F2;
        float r80352 = r80350 * r80351;
        float r80353 = 2.0;
        float r80354 = r80353 * r80351;
        float r80355 = r80354 * r80354;
        float r80356 = 4.0;
        float r80357 = a;
        float r80358 = c;
        float r80359 = r80357 * r80358;
        float r80360 = r80356 * r80359;
        float r80361 = r80355 - r80360;
        float r80362 = sqrt(r80361);
        float r80363 = r80352 + r80362;
        float r80364 = r80353 * r80357;
        float r80365 = r80363 / r80364;
        return r80365;
}

double f_id(float a, float b_2F2, float c) {
        double r80366 = -2.0;
        double r80367 = b_2F2;
        double r80368 = r80366 * r80367;
        double r80369 = 2.0;
        double r80370 = r80369 * r80367;
        double r80371 = r80370 * r80370;
        double r80372 = 4.0;
        double r80373 = a;
        double r80374 = c;
        double r80375 = r80373 * r80374;
        double r80376 = r80372 * r80375;
        double r80377 = r80371 - r80376;
        double r80378 = sqrt(r80377);
        double r80379 = r80368 + r80378;
        double r80380 = r80369 * r80373;
        double r80381 = r80379 / r80380;
        return r80381;
}

double f_il(float a, float b_2F2, float c) {
        long double r80382 = -2.0;
        long double r80383 = b_2F2;
        long double r80384 = r80382 * r80383;
        long double r80385 = 2.0;
        long double r80386 = r80385 * r80383;
        long double r80387 = r80386 * r80386;
        long double r80388 = 4.0;
        long double r80389 = a;
        long double r80390 = c;
        long double r80391 = r80389 * r80390;
        long double r80392 = r80388 * r80391;
        long double r80393 = r80387 - r80392;
        long double r80394 = sqrt(r80393);
        long double r80395 = r80384 + r80394;
        long double r80396 = r80385 * r80389;
        long double r80397 = r80395 / r80396;
        return r80397;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a, float b_2F2, float c) {
        float r80398 = b_2F2;
        float r80399 = -0.0;
        bool r80400 = r80398 < r80399;
        float r80401 = -2.0;
        float r80402 = r80401 * r80398;
        float r80403 = 2.0;
        float r80404 = r80403 * r80398;
        float r80405 = r80404 * r80404;
        float r80406 = 4.0;
        float r80407 = a;
        float r80408 = c;
        float r80409 = r80407 * r80408;
        float r80410 = r80406 * r80409;
        float r80411 = r80405 - r80410;
        float r80412 = sqrt(r80411);
        float r80413 = r80402 + r80412;
        float r80414 = r80403 * r80407;
        float r80415 = r80413 / r80414;
        float r80416 = r80398 * r80398;
        float r80417 = r80406 * r80416;
        float r80418 = r80417 - r80410;
        float r80419 = sqrt(r80418);
        float r80420 = r80402 - r80419;
        float r80421 = r80410 / r80420;
        float r80422 = r80421 / r80414;
        float r80423 = r80400 ? r80415 : r80422;
        return r80423;
}

double f_od(float a, float b_2F2, float c) {
        double r80424 = b_2F2;
        double r80425 = -0.0;
        bool r80426 = r80424 < r80425;
        double r80427 = -2.0;
        double r80428 = r80427 * r80424;
        double r80429 = 2.0;
        double r80430 = r80429 * r80424;
        double r80431 = r80430 * r80430;
        double r80432 = 4.0;
        double r80433 = a;
        double r80434 = c;
        double r80435 = r80433 * r80434;
        double r80436 = r80432 * r80435;
        double r80437 = r80431 - r80436;
        double r80438 = sqrt(r80437);
        double r80439 = r80428 + r80438;
        double r80440 = r80429 * r80433;
        double r80441 = r80439 / r80440;
        double r80442 = r80424 * r80424;
        double r80443 = r80432 * r80442;
        double r80444 = r80443 - r80436;
        double r80445 = sqrt(r80444);
        double r80446 = r80428 - r80445;
        double r80447 = r80436 / r80446;
        double r80448 = r80447 / r80440;
        double r80449 = r80426 ? r80441 : r80448;
        return r80449;
}

double f_ol(float a, float b_2F2, float c) {
        long double r80450 = b_2F2;
        long double r80451 = -0.0;
        bool r80452 = r80450 < r80451;
        long double r80453 = -2.0;
        long double r80454 = r80453 * r80450;
        long double r80455 = 2.0;
        long double r80456 = r80455 * r80450;
        long double r80457 = r80456 * r80456;
        long double r80458 = 4.0;
        long double r80459 = a;
        long double r80460 = c;
        long double r80461 = r80459 * r80460;
        long double r80462 = r80458 * r80461;
        long double r80463 = r80457 - r80462;
        long double r80464 = sqrt(r80463);
        long double r80465 = r80454 + r80464;
        long double r80466 = r80455 * r80459;
        long double r80467 = r80465 / r80466;
        long double r80468 = r80450 * r80450;
        long double r80469 = r80458 * r80468;
        long double r80470 = r80469 - r80462;
        long double r80471 = sqrt(r80470);
        long double r80472 = r80454 - r80471;
        long double r80473 = r80462 / r80472;
        long double r80474 = r80473 / r80466;
        long double r80475 = r80452 ? r80467 : r80474;
        return r80475;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r80476, r80477, r80478, r80479, r80480, r80481, r80482, r80483, r80484, r80485, r80486, r80487, r80488, r80489, r80490, r80491;

void setup_mpfr() {
        mpfr_set_default_prec(536);
        mpfr_init(r80476);
        mpfr_init(r80477);
        mpfr_init(r80478);
        mpfr_init(r80479);
        mpfr_init(r80480);
        mpfr_init(r80481);
        mpfr_init(r80482);
        mpfr_init(r80483);
        mpfr_init(r80484);
        mpfr_init(r80485);
        mpfr_init(r80486);
        mpfr_init(r80487);
        mpfr_init(r80488);
        mpfr_init(r80489);
        mpfr_init(r80490);
        mpfr_init(r80491);
}

double f_im(float a, float b_2F2, float c) {
        mpfr_init_set_str(r80476, "-2", 10, MPFR_RNDN);
        mpfr_set_flt(r80477, b_2F2, MPFR_RNDN);
        mpfr_mul(r80478, r80476, r80477, MPFR_RNDN);
        mpfr_init_set_str(r80479, "2", 10, MPFR_RNDN);
        mpfr_mul(r80480, r80479, r80477, MPFR_RNDN);
        mpfr_mul(r80481, r80480, r80480, MPFR_RNDN);
        mpfr_init_set_str(r80482, "4", 10, MPFR_RNDN);
        mpfr_set_flt(r80483, a, MPFR_RNDN);
        mpfr_set_flt(r80484, c, MPFR_RNDN);
        mpfr_mul(r80485, r80483, r80484, MPFR_RNDN);
        mpfr_mul(r80486, r80482, r80485, MPFR_RNDN);
        mpfr_sub(r80487, r80481, r80486, MPFR_RNDN);
        mpfr_sqrt(r80488, r80487, MPFR_RNDN);
        mpfr_add(r80489, r80478, r80488, MPFR_RNDN);
        mpfr_mul(r80490, r80479, r80483, MPFR_RNDN);
        mpfr_div(r80491, r80489, r80490, MPFR_RNDN);
        return mpfr_get_d(r80491, MPFR_RNDN);
}

