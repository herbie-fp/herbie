#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Toniolo and Linder, Equation (10-) */

double f_if(float t, float l, float k) {
        float r83029 = 2.0;
        float r83030 = t;
        float r83031 = 3.0;
        float r83032 = pow(r83030, r83031);
        float r83033 = l;
        float r83034 = r83033 * r83033;
        float r83035 = r83032 / r83034;
        float r83036 = k;
        float r83037 = sin(r83036);
        float r83038 = r83035 * r83037;
        float r83039 = tan(r83036);
        float r83040 = r83038 * r83039;
        float r83041 = 1.0;
        float r83042 = r83036 / r83030;
        float r83043 = r83042 * r83042;
        float r83044 = r83041 + r83043;
        float r83045 = r83044 - r83041;
        float r83046 = r83040 * r83045;
        float r83047 = r83029 / r83046;
        return r83047;
}

double f_id(float t, float l, float k) {
        double r83048 = 2.0;
        double r83049 = t;
        double r83050 = 3.0;
        double r83051 = pow(r83049, r83050);
        double r83052 = l;
        double r83053 = r83052 * r83052;
        double r83054 = r83051 / r83053;
        double r83055 = k;
        double r83056 = sin(r83055);
        double r83057 = r83054 * r83056;
        double r83058 = tan(r83055);
        double r83059 = r83057 * r83058;
        double r83060 = 1.0;
        double r83061 = r83055 / r83049;
        double r83062 = r83061 * r83061;
        double r83063 = r83060 + r83062;
        double r83064 = r83063 - r83060;
        double r83065 = r83059 * r83064;
        double r83066 = r83048 / r83065;
        return r83066;
}

double f_il(float t, float l, float k) {
        long double r83067 = 2.0;
        long double r83068 = t;
        long double r83069 = 3.0;
        long double r83070 = pow(r83068, r83069);
        long double r83071 = l;
        long double r83072 = r83071 * r83071;
        long double r83073 = r83070 / r83072;
        long double r83074 = k;
        long double r83075 = sin(r83074);
        long double r83076 = r83073 * r83075;
        long double r83077 = tan(r83074);
        long double r83078 = r83076 * r83077;
        long double r83079 = 1.0;
        long double r83080 = r83074 / r83068;
        long double r83081 = r83080 * r83080;
        long double r83082 = r83079 + r83081;
        long double r83083 = r83082 - r83079;
        long double r83084 = r83078 * r83083;
        long double r83085 = r83067 / r83084;
        return r83085;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float t, float l, float k) {
        float r83086 = 2.0;
        float r83087 = t;
        float r83088 = 3.0;
        float r83089 = pow(r83087, r83088);
        float r83090 = l;
        float r83091 = r83090 * r83090;
        float r83092 = r83089 / r83091;
        float r83093 = k;
        float r83094 = sin(r83093);
        float r83095 = r83092 * r83094;
        float r83096 = tan(r83093);
        float r83097 = 1.0;
        float r83098 = r83097 / r83087;
        float r83099 = r83098 * r83098;
        float r83100 = r83093 * r83099;
        float r83101 = r83093 * r83100;
        float r83102 = r83097 * r83101;
        float r83103 = r83096 * r83102;
        float r83104 = r83095 * r83103;
        float r83105 = r83086 / r83104;
        return r83105;
}

double f_od(float t, float l, float k) {
        double r83106 = 2.0;
        double r83107 = t;
        double r83108 = 3.0;
        double r83109 = pow(r83107, r83108);
        double r83110 = l;
        double r83111 = r83110 * r83110;
        double r83112 = r83109 / r83111;
        double r83113 = k;
        double r83114 = sin(r83113);
        double r83115 = r83112 * r83114;
        double r83116 = tan(r83113);
        double r83117 = 1.0;
        double r83118 = r83117 / r83107;
        double r83119 = r83118 * r83118;
        double r83120 = r83113 * r83119;
        double r83121 = r83113 * r83120;
        double r83122 = r83117 * r83121;
        double r83123 = r83116 * r83122;
        double r83124 = r83115 * r83123;
        double r83125 = r83106 / r83124;
        return r83125;
}

double f_ol(float t, float l, float k) {
        long double r83126 = 2.0;
        long double r83127 = t;
        long double r83128 = 3.0;
        long double r83129 = pow(r83127, r83128);
        long double r83130 = l;
        long double r83131 = r83130 * r83130;
        long double r83132 = r83129 / r83131;
        long double r83133 = k;
        long double r83134 = sin(r83133);
        long double r83135 = r83132 * r83134;
        long double r83136 = tan(r83133);
        long double r83137 = 1.0;
        long double r83138 = r83137 / r83127;
        long double r83139 = r83138 * r83138;
        long double r83140 = r83133 * r83139;
        long double r83141 = r83133 * r83140;
        long double r83142 = r83137 * r83141;
        long double r83143 = r83136 * r83142;
        long double r83144 = r83135 * r83143;
        long double r83145 = r83126 / r83144;
        return r83145;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r83146, r83147, r83148, r83149, r83150, r83151, r83152, r83153, r83154, r83155, r83156, r83157, r83158, r83159, r83160, r83161, r83162, r83163, r83164;

void setup_mpfr() {
        mpfr_set_default_prec(568);
        mpfr_init(r83146);
        mpfr_init(r83147);
        mpfr_init(r83148);
        mpfr_init(r83149);
        mpfr_init(r83150);
        mpfr_init(r83151);
        mpfr_init(r83152);
        mpfr_init(r83153);
        mpfr_init(r83154);
        mpfr_init(r83155);
        mpfr_init(r83156);
        mpfr_init(r83157);
        mpfr_init(r83158);
        mpfr_init(r83159);
        mpfr_init(r83160);
        mpfr_init(r83161);
        mpfr_init(r83162);
        mpfr_init(r83163);
        mpfr_init(r83164);
}

double f_im(float t, float l, float k) {
        mpfr_init_set_str(r83146, "2", 10, MPFR_RNDN);
        mpfr_set_flt(r83147, t, MPFR_RNDN);
        mpfr_init_set_str(r83148, "3", 10, MPFR_RNDN);
        mpfr_pow(r83149, r83147, r83148, MPFR_RNDN);
        mpfr_set_flt(r83150, l, MPFR_RNDN);
        mpfr_mul(r83151, r83150, r83150, MPFR_RNDN);
        mpfr_div(r83152, r83149, r83151, MPFR_RNDN);
        mpfr_set_flt(r83153, k, MPFR_RNDN);
        mpfr_sin(r83154, r83153, MPFR_RNDN);
        mpfr_mul(r83155, r83152, r83154, MPFR_RNDN);
        mpfr_tan(r83156, r83153, MPFR_RNDN);
        mpfr_mul(r83157, r83155, r83156, MPFR_RNDN);
        mpfr_init_set_str(r83158, "1", 10, MPFR_RNDN);
        mpfr_div(r83159, r83153, r83147, MPFR_RNDN);
        mpfr_mul(r83160, r83159, r83159, MPFR_RNDN);
        mpfr_add(r83161, r83158, r83160, MPFR_RNDN);
        mpfr_sub(r83162, r83161, r83158, MPFR_RNDN);
        mpfr_mul(r83163, r83157, r83162, MPFR_RNDN);
        mpfr_div(r83164, r83146, r83163, MPFR_RNDN);
        return mpfr_get_d(r83164, MPFR_RNDN);
}

