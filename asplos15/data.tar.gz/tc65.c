#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Jmat.Real.erfi, branch x >= 5 */

double f_if(float x) {
        float r78331 = 1.0;
        float r78332 = atan2(1.0, 0.0);
        float r78333 = sqrt(r78332);
        float r78334 = r78331 / r78333;
        float r78335 = x;
        float r78336 = r78335 * r78335;
        float r78337 = exp(r78336);
        float r78338 = r78334 * r78337;
        float r78339 = r78331 / r78335;
        float r78340 = 2.0;
        float r78341 = r78331 / r78340;
        float r78342 = r78339 * r78339;
        float r78343 = r78342 * r78339;
        float r78344 = r78341 * r78343;
        float r78345 = r78339 + r78344;
        float r78346 = 3.0;
        float r78347 = 4.0;
        float r78348 = r78346 / r78347;
        float r78349 = r78343 * r78339;
        float r78350 = r78349 * r78339;
        float r78351 = r78348 * r78350;
        float r78352 = r78345 + r78351;
        float r78353 = 15.0;
        float r78354 = 8.0;
        float r78355 = r78353 / r78354;
        float r78356 = r78350 * r78339;
        float r78357 = r78356 * r78339;
        float r78358 = r78355 * r78357;
        float r78359 = r78352 + r78358;
        float r78360 = r78338 * r78359;
        return r78360;
}

double f_id(float x) {
        double r78361 = 1.0;
        double r78362 = atan2(1.0, 0.0);
        double r78363 = sqrt(r78362);
        double r78364 = r78361 / r78363;
        double r78365 = x;
        double r78366 = r78365 * r78365;
        double r78367 = exp(r78366);
        double r78368 = r78364 * r78367;
        double r78369 = r78361 / r78365;
        double r78370 = 2.0;
        double r78371 = r78361 / r78370;
        double r78372 = r78369 * r78369;
        double r78373 = r78372 * r78369;
        double r78374 = r78371 * r78373;
        double r78375 = r78369 + r78374;
        double r78376 = 3.0;
        double r78377 = 4.0;
        double r78378 = r78376 / r78377;
        double r78379 = r78373 * r78369;
        double r78380 = r78379 * r78369;
        double r78381 = r78378 * r78380;
        double r78382 = r78375 + r78381;
        double r78383 = 15.0;
        double r78384 = 8.0;
        double r78385 = r78383 / r78384;
        double r78386 = r78380 * r78369;
        double r78387 = r78386 * r78369;
        double r78388 = r78385 * r78387;
        double r78389 = r78382 + r78388;
        double r78390 = r78368 * r78389;
        return r78390;
}

double f_il(float x) {
        long double r78391 = 1.0;
        long double r78392 = atan2(1.0, 0.0);
        long double r78393 = sqrt(r78392);
        long double r78394 = r78391 / r78393;
        long double r78395 = x;
        long double r78396 = r78395 * r78395;
        long double r78397 = exp(r78396);
        long double r78398 = r78394 * r78397;
        long double r78399 = r78391 / r78395;
        long double r78400 = 2.0;
        long double r78401 = r78391 / r78400;
        long double r78402 = r78399 * r78399;
        long double r78403 = r78402 * r78399;
        long double r78404 = r78401 * r78403;
        long double r78405 = r78399 + r78404;
        long double r78406 = 3.0;
        long double r78407 = 4.0;
        long double r78408 = r78406 / r78407;
        long double r78409 = r78403 * r78399;
        long double r78410 = r78409 * r78399;
        long double r78411 = r78408 * r78410;
        long double r78412 = r78405 + r78411;
        long double r78413 = 15.0;
        long double r78414 = 8.0;
        long double r78415 = r78413 / r78414;
        long double r78416 = r78410 * r78399;
        long double r78417 = r78416 * r78399;
        long double r78418 = r78415 * r78417;
        long double r78419 = r78412 + r78418;
        long double r78420 = r78398 * r78419;
        return r78420;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r78421 = 1.0;
        float r78422 = atan2(1.0, 0.0);
        float r78423 = sqrt(r78422);
        float r78424 = r78421 / r78423;
        float r78425 = x;
        float r78426 = r78425 * r78425;
        float r78427 = exp(r78426);
        float r78428 = r78424 * r78427;
        float r78429 = r78421 / r78425;
        float r78430 = 2.0;
        float r78431 = r78421 / r78430;
        float r78432 = r78429 * r78429;
        float r78433 = r78432 * r78429;
        float r78434 = r78431 * r78433;
        float r78435 = r78429 + r78434;
        float r78436 = 3.0;
        float r78437 = 4.0;
        float r78438 = r78436 / r78437;
        float r78439 = r78433 * r78429;
        float r78440 = r78439 * r78429;
        float r78441 = r78438 * r78440;
        float r78442 = r78435 + r78441;
        float r78443 = 15.0;
        float r78444 = 8.0;
        float r78445 = r78443 / r78444;
        float r78446 = r78440 * r78429;
        float r78447 = r78446 * r78429;
        float r78448 = r78445 * r78447;
        float r78449 = r78442 + r78448;
        float r78450 = r78428 * r78449;
        return r78450;
}

double f_od(float x) {
        double r78451 = 1.0;
        double r78452 = atan2(1.0, 0.0);
        double r78453 = sqrt(r78452);
        double r78454 = r78451 / r78453;
        double r78455 = x;
        double r78456 = r78455 * r78455;
        double r78457 = exp(r78456);
        double r78458 = r78454 * r78457;
        double r78459 = r78451 / r78455;
        double r78460 = 2.0;
        double r78461 = r78451 / r78460;
        double r78462 = r78459 * r78459;
        double r78463 = r78462 * r78459;
        double r78464 = r78461 * r78463;
        double r78465 = r78459 + r78464;
        double r78466 = 3.0;
        double r78467 = 4.0;
        double r78468 = r78466 / r78467;
        double r78469 = r78463 * r78459;
        double r78470 = r78469 * r78459;
        double r78471 = r78468 * r78470;
        double r78472 = r78465 + r78471;
        double r78473 = 15.0;
        double r78474 = 8.0;
        double r78475 = r78473 / r78474;
        double r78476 = r78470 * r78459;
        double r78477 = r78476 * r78459;
        double r78478 = r78475 * r78477;
        double r78479 = r78472 + r78478;
        double r78480 = r78458 * r78479;
        return r78480;
}

double f_ol(float x) {
        long double r78481 = 1.0;
        long double r78482 = atan2(1.0, 0.0);
        long double r78483 = sqrt(r78482);
        long double r78484 = r78481 / r78483;
        long double r78485 = x;
        long double r78486 = r78485 * r78485;
        long double r78487 = exp(r78486);
        long double r78488 = r78484 * r78487;
        long double r78489 = r78481 / r78485;
        long double r78490 = 2.0;
        long double r78491 = r78481 / r78490;
        long double r78492 = r78489 * r78489;
        long double r78493 = r78492 * r78489;
        long double r78494 = r78491 * r78493;
        long double r78495 = r78489 + r78494;
        long double r78496 = 3.0;
        long double r78497 = 4.0;
        long double r78498 = r78496 / r78497;
        long double r78499 = r78493 * r78489;
        long double r78500 = r78499 * r78489;
        long double r78501 = r78498 * r78500;
        long double r78502 = r78495 + r78501;
        long double r78503 = 15.0;
        long double r78504 = 8.0;
        long double r78505 = r78503 / r78504;
        long double r78506 = r78500 * r78489;
        long double r78507 = r78506 * r78489;
        long double r78508 = r78505 * r78507;
        long double r78509 = r78502 + r78508;
        long double r78510 = r78488 * r78509;
        return r78510;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r78511, r78512, r78513, r78514, r78515, r78516, r78517, r78518, r78519, r78520, r78521, r78522, r78523, r78524, r78525, r78526, r78527, r78528, r78529, r78530, r78531, r78532, r78533, r78534, r78535, r78536, r78537, r78538, r78539, r78540;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r78511);
        mpfr_init(r78512);
        mpfr_init(r78513);
        mpfr_init(r78514);
        mpfr_init(r78515);
        mpfr_init(r78516);
        mpfr_init(r78517);
        mpfr_init(r78518);
        mpfr_init(r78519);
        mpfr_init(r78520);
        mpfr_init(r78521);
        mpfr_init(r78522);
        mpfr_init(r78523);
        mpfr_init(r78524);
        mpfr_init(r78525);
        mpfr_init(r78526);
        mpfr_init(r78527);
        mpfr_init(r78528);
        mpfr_init(r78529);
        mpfr_init(r78530);
        mpfr_init(r78531);
        mpfr_init(r78532);
        mpfr_init(r78533);
        mpfr_init(r78534);
        mpfr_init(r78535);
        mpfr_init(r78536);
        mpfr_init(r78537);
        mpfr_init(r78538);
        mpfr_init(r78539);
        mpfr_init(r78540);
}

double f_im(float x) {
        mpfr_init_set_str(r78511, "1", 10, MPFR_RNDN);
        mpfr_const_pi(r78512, MPFR_RNDN);
        mpfr_sqrt(r78513, r78512, MPFR_RNDN);
        mpfr_div(r78514, r78511, r78513, MPFR_RNDN);
        mpfr_set_flt(r78515, x, MPFR_RNDN);
        mpfr_mul(r78516, r78515, r78515, MPFR_RNDN);
        mpfr_exp(r78517, r78516, MPFR_RNDN);
        mpfr_mul(r78518, r78514, r78517, MPFR_RNDN);
        mpfr_div(r78519, r78511, r78515, MPFR_RNDN);
        mpfr_init_set_str(r78520, "2", 10, MPFR_RNDN);
        mpfr_div(r78521, r78511, r78520, MPFR_RNDN);
        mpfr_mul(r78522, r78519, r78519, MPFR_RNDN);
        mpfr_mul(r78523, r78522, r78519, MPFR_RNDN);
        mpfr_mul(r78524, r78521, r78523, MPFR_RNDN);
        mpfr_add(r78525, r78519, r78524, MPFR_RNDN);
        mpfr_init_set_str(r78526, "3", 10, MPFR_RNDN);
        mpfr_init_set_str(r78527, "4", 10, MPFR_RNDN);
        mpfr_div(r78528, r78526, r78527, MPFR_RNDN);
        mpfr_mul(r78529, r78523, r78519, MPFR_RNDN);
        mpfr_mul(r78530, r78529, r78519, MPFR_RNDN);
        mpfr_mul(r78531, r78528, r78530, MPFR_RNDN);
        mpfr_add(r78532, r78525, r78531, MPFR_RNDN);
        mpfr_init_set_str(r78533, "15", 10, MPFR_RNDN);
        mpfr_init_set_str(r78534, "8", 10, MPFR_RNDN);
        mpfr_div(r78535, r78533, r78534, MPFR_RNDN);
        mpfr_mul(r78536, r78530, r78519, MPFR_RNDN);
        mpfr_mul(r78537, r78536, r78519, MPFR_RNDN);
        mpfr_mul(r78538, r78535, r78537, MPFR_RNDN);
        mpfr_add(r78539, r78532, r78538, MPFR_RNDN);
        mpfr_mul(r78540, r78518, r78539, MPFR_RNDN);
        return mpfr_get_d(r78540, MPFR_RNDN);
}

