#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.arg on complex */

double f_if(float re, float im) {
        float r84713 = im;
        float r84714 = re;
        float r84715 = atan2(r84713, r84714);
        return r84715;
}

double f_id(float re, float im) {
        double r84716 = im;
        double r84717 = re;
        double r84718 = atan2(r84716, r84717);
        return r84718;
}

double f_il(float re, float im) {
        long double r84719 = im;
        long double r84720 = re;
        long double r84721 = atan2(r84719, r84720);
        return r84721;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r84722 = im;
        float r84723 = re;
        float r84724 = atan2(r84722, r84723);
        return r84724;
}

double f_od(float re, float im) {
        double r84725 = im;
        double r84726 = re;
        double r84727 = atan2(r84725, r84726);
        return r84727;
}

double f_ol(float re, float im) {
        long double r84728 = im;
        long double r84729 = re;
        long double r84730 = atan2(r84728, r84729);
        return r84730;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r84731, r84732, r84733;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r84731);
        mpfr_init(r84732);
        mpfr_init(r84733);
}

double f_im(float re, float im) {
        mpfr_set_flt(r84731, im, MPFR_RNDN);
        mpfr_set_flt(r84732, re, MPFR_RNDN);
        mpfr_atan2(r84733, r84731, r84732, MPFR_RNDN);
        return mpfr_get_d(r84733, MPFR_RNDN);
}

