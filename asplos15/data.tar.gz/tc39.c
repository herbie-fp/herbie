#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Quotient of sum of exps */

double f_if(float a, float b) {
        float r74872 = a;
        float r74873 = exp(r74872);
        float r74874 = b;
        float r74875 = exp(r74874);
        float r74876 = r74873 + r74875;
        float r74877 = r74873 / r74876;
        return r74877;
}

double f_id(float a, float b) {
        double r74878 = a;
        double r74879 = exp(r74878);
        double r74880 = b;
        double r74881 = exp(r74880);
        double r74882 = r74879 + r74881;
        double r74883 = r74879 / r74882;
        return r74883;
}

double f_il(float a, float b) {
        long double r74884 = a;
        long double r74885 = exp(r74884);
        long double r74886 = b;
        long double r74887 = exp(r74886);
        long double r74888 = r74885 + r74887;
        long double r74889 = r74885 / r74888;
        return r74889;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a, float b) {
        float r74890 = 1.0;
        float r74891 = b;
        float r74892 = a;
        float r74893 = r74891 - r74892;
        float r74894 = exp(r74893);
        float r74895 = r74890 + r74894;
        float r74896 = r74890 / r74895;
        return r74896;
}

double f_od(float a, float b) {
        double r74897 = 1.0;
        double r74898 = b;
        double r74899 = a;
        double r74900 = r74898 - r74899;
        double r74901 = exp(r74900);
        double r74902 = r74897 + r74901;
        double r74903 = r74897 / r74902;
        return r74903;
}

double f_ol(float a, float b) {
        long double r74904 = 1.0;
        long double r74905 = b;
        long double r74906 = a;
        long double r74907 = r74905 - r74906;
        long double r74908 = exp(r74907);
        long double r74909 = r74904 + r74908;
        long double r74910 = r74904 / r74909;
        return r74910;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r74911, r74912, r74913, r74914, r74915, r74916;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r74911);
        mpfr_init(r74912);
        mpfr_init(r74913);
        mpfr_init(r74914);
        mpfr_init(r74915);
        mpfr_init(r74916);
}

double f_im(float a, float b) {
        mpfr_set_flt(r74911, a, MPFR_RNDN);
        mpfr_exp(r74912, r74911, MPFR_RNDN);
        mpfr_set_flt(r74913, b, MPFR_RNDN);
        mpfr_exp(r74914, r74913, MPFR_RNDN);
        mpfr_add(r74915, r74912, r74914, MPFR_RNDN);
        mpfr_div(r74916, r74912, r74915, MPFR_RNDN);
        return mpfr_get_d(r74916, MPFR_RNDN);
}

