#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Toniolo and Linder, Equation (13) */

double f_if(float n, float U, float t, float l, float Om, float U_) {
        float r83168 = 2.0;
        float r83169 = n;
        float r83170 = r83168 * r83169;
        float r83171 = U;
        float r83172 = r83170 * r83171;
        float r83173 = t;
        float r83174 = l;
        float r83175 = r83174 * r83174;
        float r83176 = Om;
        float r83177 = r83175 / r83176;
        float r83178 = r83168 * r83177;
        float r83179 = r83173 - r83178;
        float r83180 = r83174 / r83176;
        float r83181 = r83180 * r83180;
        float r83182 = r83169 * r83181;
        float r83183 = U_;
        float r83184 = r83171 - r83183;
        float r83185 = r83182 * r83184;
        float r83186 = r83179 - r83185;
        float r83187 = r83172 * r83186;
        float r83188 = sqrt(r83187);
        return r83188;
}

double f_id(float n, float U, float t, float l, float Om, float U_) {
        double r83189 = 2.0;
        double r83190 = n;
        double r83191 = r83189 * r83190;
        double r83192 = U;
        double r83193 = r83191 * r83192;
        double r83194 = t;
        double r83195 = l;
        double r83196 = r83195 * r83195;
        double r83197 = Om;
        double r83198 = r83196 / r83197;
        double r83199 = r83189 * r83198;
        double r83200 = r83194 - r83199;
        double r83201 = r83195 / r83197;
        double r83202 = r83201 * r83201;
        double r83203 = r83190 * r83202;
        double r83204 = U_;
        double r83205 = r83192 - r83204;
        double r83206 = r83203 * r83205;
        double r83207 = r83200 - r83206;
        double r83208 = r83193 * r83207;
        double r83209 = sqrt(r83208);
        return r83209;
}

double f_il(float n, float U, float t, float l, float Om, float U_) {
        long double r83210 = 2.0;
        long double r83211 = n;
        long double r83212 = r83210 * r83211;
        long double r83213 = U;
        long double r83214 = r83212 * r83213;
        long double r83215 = t;
        long double r83216 = l;
        long double r83217 = r83216 * r83216;
        long double r83218 = Om;
        long double r83219 = r83217 / r83218;
        long double r83220 = r83210 * r83219;
        long double r83221 = r83215 - r83220;
        long double r83222 = r83216 / r83218;
        long double r83223 = r83222 * r83222;
        long double r83224 = r83211 * r83223;
        long double r83225 = U_;
        long double r83226 = r83213 - r83225;
        long double r83227 = r83224 * r83226;
        long double r83228 = r83221 - r83227;
        long double r83229 = r83214 * r83228;
        long double r83230 = sqrt(r83229);
        return r83230;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float n, float U, float t, float l, float Om, float U_) {
        float r83231 = 2.0;
        float r83232 = n;
        float r83233 = r83231 * r83232;
        float r83234 = U;
        float r83235 = r83233 * r83234;
        float r83236 = t;
        float r83237 = l;
        float r83238 = r83237 * r83237;
        float r83239 = Om;
        float r83240 = r83238 / r83239;
        float r83241 = r83231 * r83240;
        float r83242 = r83236 - r83241;
        float r83243 = r83239 * r83239;
        float r83244 = r83238 / r83243;
        float r83245 = r83232 * r83244;
        float r83246 = U_;
        float r83247 = r83234 - r83246;
        float r83248 = r83245 * r83247;
        float r83249 = r83242 - r83248;
        float r83250 = r83235 * r83249;
        float r83251 = sqrt(r83250);
        return r83251;
}

double f_od(float n, float U, float t, float l, float Om, float U_) {
        double r83252 = 2.0;
        double r83253 = n;
        double r83254 = r83252 * r83253;
        double r83255 = U;
        double r83256 = r83254 * r83255;
        double r83257 = t;
        double r83258 = l;
        double r83259 = r83258 * r83258;
        double r83260 = Om;
        double r83261 = r83259 / r83260;
        double r83262 = r83252 * r83261;
        double r83263 = r83257 - r83262;
        double r83264 = r83260 * r83260;
        double r83265 = r83259 / r83264;
        double r83266 = r83253 * r83265;
        double r83267 = U_;
        double r83268 = r83255 - r83267;
        double r83269 = r83266 * r83268;
        double r83270 = r83263 - r83269;
        double r83271 = r83256 * r83270;
        double r83272 = sqrt(r83271);
        return r83272;
}

double f_ol(float n, float U, float t, float l, float Om, float U_) {
        long double r83273 = 2.0;
        long double r83274 = n;
        long double r83275 = r83273 * r83274;
        long double r83276 = U;
        long double r83277 = r83275 * r83276;
        long double r83278 = t;
        long double r83279 = l;
        long double r83280 = r83279 * r83279;
        long double r83281 = Om;
        long double r83282 = r83280 / r83281;
        long double r83283 = r83273 * r83282;
        long double r83284 = r83278 - r83283;
        long double r83285 = r83281 * r83281;
        long double r83286 = r83280 / r83285;
        long double r83287 = r83274 * r83286;
        long double r83288 = U_;
        long double r83289 = r83276 - r83288;
        long double r83290 = r83287 * r83289;
        long double r83291 = r83284 - r83290;
        long double r83292 = r83277 * r83291;
        long double r83293 = sqrt(r83292);
        return r83293;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r83294, r83295, r83296, r83297, r83298, r83299, r83300, r83301, r83302, r83303, r83304, r83305, r83306, r83307, r83308, r83309, r83310, r83311, r83312, r83313, r83314;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r83294);
        mpfr_init(r83295);
        mpfr_init(r83296);
        mpfr_init(r83297);
        mpfr_init(r83298);
        mpfr_init(r83299);
        mpfr_init(r83300);
        mpfr_init(r83301);
        mpfr_init(r83302);
        mpfr_init(r83303);
        mpfr_init(r83304);
        mpfr_init(r83305);
        mpfr_init(r83306);
        mpfr_init(r83307);
        mpfr_init(r83308);
        mpfr_init(r83309);
        mpfr_init(r83310);
        mpfr_init(r83311);
        mpfr_init(r83312);
        mpfr_init(r83313);
        mpfr_init(r83314);
}

double f_im(float n, float U, float t, float l, float Om, float U_) {
        mpfr_init_set_str(r83294, "2", 10, MPFR_RNDN);
        mpfr_set_flt(r83295, n, MPFR_RNDN);
        mpfr_mul(r83296, r83294, r83295, MPFR_RNDN);
        mpfr_set_flt(r83297, U, MPFR_RNDN);
        mpfr_mul(r83298, r83296, r83297, MPFR_RNDN);
        mpfr_set_flt(r83299, t, MPFR_RNDN);
        mpfr_set_flt(r83300, l, MPFR_RNDN);
        mpfr_mul(r83301, r83300, r83300, MPFR_RNDN);
        mpfr_set_flt(r83302, Om, MPFR_RNDN);
        mpfr_div(r83303, r83301, r83302, MPFR_RNDN);
        mpfr_mul(r83304, r83294, r83303, MPFR_RNDN);
        mpfr_sub(r83305, r83299, r83304, MPFR_RNDN);
        mpfr_div(r83306, r83300, r83302, MPFR_RNDN);
        mpfr_mul(r83307, r83306, r83306, MPFR_RNDN);
        mpfr_mul(r83308, r83295, r83307, MPFR_RNDN);
        mpfr_set_flt(r83309, U_, MPFR_RNDN);
        mpfr_sub(r83310, r83297, r83309, MPFR_RNDN);
        mpfr_mul(r83311, r83308, r83310, MPFR_RNDN);
        mpfr_sub(r83312, r83305, r83311, MPFR_RNDN);
        mpfr_mul(r83313, r83298, r83312, MPFR_RNDN);
        mpfr_sqrt(r83314, r83313, MPFR_RNDN);
        return mpfr_get_d(r83314, MPFR_RNDN);
}

