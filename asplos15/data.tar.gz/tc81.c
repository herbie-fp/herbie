#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE problem 3.4.3 */

double f_if(float x) {
        float r80778 = 1.0;
        float r80779 = x;
        float r80780 = r80778 - r80779;
        float r80781 = r80778 + r80779;
        float r80782 = r80780 / r80781;
        float r80783 = log(r80782);
        return r80783;
}

double f_id(float x) {
        double r80784 = 1.0;
        double r80785 = x;
        double r80786 = r80784 - r80785;
        double r80787 = r80784 + r80785;
        double r80788 = r80786 / r80787;
        double r80789 = log(r80788);
        return r80789;
}

double f_il(float x) {
        long double r80790 = 1.0;
        long double r80791 = x;
        long double r80792 = r80790 - r80791;
        long double r80793 = r80790 + r80791;
        long double r80794 = r80792 / r80793;
        long double r80795 = log(r80794);
        return r80795;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r80796 = 1.0;
        float r80797 = x;
        float r80798 = r80796 - r80797;
        float r80799 = log(r80798);
        float r80800 = r80796 + r80797;
        float r80801 = log(r80800);
        float r80802 = r80799 - r80801;
        return r80802;
}

double f_od(float x) {
        double r80803 = 1.0;
        double r80804 = x;
        double r80805 = r80803 - r80804;
        double r80806 = log(r80805);
        double r80807 = r80803 + r80804;
        double r80808 = log(r80807);
        double r80809 = r80806 - r80808;
        return r80809;
}

double f_ol(float x) {
        long double r80810 = 1.0;
        long double r80811 = x;
        long double r80812 = r80810 - r80811;
        long double r80813 = log(r80812);
        long double r80814 = r80810 + r80811;
        long double r80815 = log(r80814);
        long double r80816 = r80813 - r80815;
        return r80816;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r80817, r80818, r80819, r80820, r80821, r80822;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r80817);
        mpfr_init(r80818);
        mpfr_init(r80819);
        mpfr_init(r80820);
        mpfr_init(r80821);
        mpfr_init(r80822);
}

double f_im(float x) {
        mpfr_init_set_str(r80817, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r80818, x, MPFR_RNDN);
        mpfr_sub(r80819, r80817, r80818, MPFR_RNDN);
        mpfr_add(r80820, r80817, r80818, MPFR_RNDN);
        mpfr_div(r80821, r80819, r80820, MPFR_RNDN);
        mpfr_log(r80822, r80821, MPFR_RNDN);
        return mpfr_get_d(r80822, MPFR_RNDN);
}

