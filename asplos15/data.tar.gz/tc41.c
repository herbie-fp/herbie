#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.sqrt on complex, real part */

double f_if(float re, float im) {
        float r74944 = 0.5;
        float r74945 = 2.0;
        float r74946 = re;
        float r74947 = r74946 * r74946;
        float r74948 = im;
        float r74949 = r74948 * r74948;
        float r74950 = r74947 + r74949;
        float r74951 = sqrt(r74950);
        float r74952 = r74951 + r74946;
        float r74953 = r74945 * r74952;
        float r74954 = sqrt(r74953);
        float r74955 = r74944 * r74954;
        return r74955;
}

double f_id(float re, float im) {
        double r74956 = 0.5;
        double r74957 = 2.0;
        double r74958 = re;
        double r74959 = r74958 * r74958;
        double r74960 = im;
        double r74961 = r74960 * r74960;
        double r74962 = r74959 + r74961;
        double r74963 = sqrt(r74962);
        double r74964 = r74963 + r74958;
        double r74965 = r74957 * r74964;
        double r74966 = sqrt(r74965);
        double r74967 = r74956 * r74966;
        return r74967;
}

double f_il(float re, float im) {
        long double r74968 = 0.5;
        long double r74969 = 2.0;
        long double r74970 = re;
        long double r74971 = r74970 * r74970;
        long double r74972 = im;
        long double r74973 = r74972 * r74972;
        long double r74974 = r74971 + r74973;
        long double r74975 = sqrt(r74974);
        long double r74976 = r74975 + r74970;
        long double r74977 = r74969 * r74976;
        long double r74978 = sqrt(r74977);
        long double r74979 = r74968 * r74978;
        return r74979;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r74980 = re;
        float r74981 = -3.121035821461699e-30;
        bool r74982 = r74980 < r74981;
        float r74983 = 0.5;
        float r74984 = 2.0;
        float r74985 = 1.0;
        float r74986 = im;
        float r74987 = r74986 * r74986;
        float r74988 = r74985 * r74987;
        float r74989 = r74980 * r74980;
        float r74990 = r74989 + r74987;
        float r74991 = sqrt(r74990);
        float r74992 = r74991 - r74980;
        float r74993 = r74988 / r74992;
        float r74994 = r74984 * r74993;
        float r74995 = sqrt(r74994);
        float r74996 = r74983 * r74995;
        float r74997 = r74986 * r74986;
        float r74998 = r74989 + r74997;
        float r74999 = sqrt(r74998);
        float r75000 = r74999 + r74980;
        float r75001 = r74984 * r75000;
        float r75002 = sqrt(r75001);
        float r75003 = r74983 * r75002;
        float r75004 = r74982 ? r74996 : r75003;
        return r75004;
}

double f_od(float re, float im) {
        double r75005 = re;
        double r75006 = -3.121035821461699e-30;
        bool r75007 = r75005 < r75006;
        double r75008 = 0.5;
        double r75009 = 2.0;
        double r75010 = 1.0;
        double r75011 = im;
        double r75012 = r75011 * r75011;
        double r75013 = r75010 * r75012;
        double r75014 = r75005 * r75005;
        double r75015 = r75014 + r75012;
        double r75016 = sqrt(r75015);
        double r75017 = r75016 - r75005;
        double r75018 = r75013 / r75017;
        double r75019 = r75009 * r75018;
        double r75020 = sqrt(r75019);
        double r75021 = r75008 * r75020;
        double r75022 = r75011 * r75011;
        double r75023 = r75014 + r75022;
        double r75024 = sqrt(r75023);
        double r75025 = r75024 + r75005;
        double r75026 = r75009 * r75025;
        double r75027 = sqrt(r75026);
        double r75028 = r75008 * r75027;
        double r75029 = r75007 ? r75021 : r75028;
        return r75029;
}

double f_ol(float re, float im) {
        long double r75030 = re;
        long double r75031 = -3.121035821461699e-30;
        bool r75032 = r75030 < r75031;
        long double r75033 = 0.5;
        long double r75034 = 2.0;
        long double r75035 = 1.0;
        long double r75036 = im;
        long double r75037 = r75036 * r75036;
        long double r75038 = r75035 * r75037;
        long double r75039 = r75030 * r75030;
        long double r75040 = r75039 + r75037;
        long double r75041 = sqrt(r75040);
        long double r75042 = r75041 - r75030;
        long double r75043 = r75038 / r75042;
        long double r75044 = r75034 * r75043;
        long double r75045 = sqrt(r75044);
        long double r75046 = r75033 * r75045;
        long double r75047 = r75036 * r75036;
        long double r75048 = r75039 + r75047;
        long double r75049 = sqrt(r75048);
        long double r75050 = r75049 + r75030;
        long double r75051 = r75034 * r75050;
        long double r75052 = sqrt(r75051);
        long double r75053 = r75033 * r75052;
        long double r75054 = r75032 ? r75046 : r75053;
        return r75054;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r75055, r75056, r75057, r75058, r75059, r75060, r75061, r75062, r75063, r75064, r75065, r75066;

void setup_mpfr() {
        mpfr_set_default_prec(584);
        mpfr_init(r75055);
        mpfr_init(r75056);
        mpfr_init(r75057);
        mpfr_init(r75058);
        mpfr_init(r75059);
        mpfr_init(r75060);
        mpfr_init(r75061);
        mpfr_init(r75062);
        mpfr_init(r75063);
        mpfr_init(r75064);
        mpfr_init(r75065);
        mpfr_init(r75066);
}

double f_im(float re, float im) {
        mpfr_init_set_str(r75055, "0.5", 10, MPFR_RNDN);
        mpfr_init_set_str(r75056, "2.0", 10, MPFR_RNDN);
        mpfr_set_flt(r75057, re, MPFR_RNDN);
        mpfr_mul(r75058, r75057, r75057, MPFR_RNDN);
        mpfr_set_flt(r75059, im, MPFR_RNDN);
        mpfr_mul(r75060, r75059, r75059, MPFR_RNDN);
        mpfr_add(r75061, r75058, r75060, MPFR_RNDN);
        mpfr_sqrt(r75062, r75061, MPFR_RNDN);
        mpfr_add(r75063, r75062, r75057, MPFR_RNDN);
        mpfr_mul(r75064, r75056, r75063, MPFR_RNDN);
        mpfr_sqrt(r75065, r75064, MPFR_RNDN);
        mpfr_mul(r75066, r75055, r75065, MPFR_RNDN);
        return mpfr_get_d(r75066, MPFR_RNDN);
}

