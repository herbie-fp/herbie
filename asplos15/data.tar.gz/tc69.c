#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Maksimov and Kolovsky, Equation (3) */

double f_if(float J, float K, float U) {
        float r79452 = -2.0;
        float r79453 = J;
        float r79454 = r79452 * r79453;
        float r79455 = K;
        float r79456 = 2.0;
        float r79457 = r79455 / r79456;
        float r79458 = cos(r79457);
        float r79459 = r79454 * r79458;
        float r79460 = 1.0;
        float r79461 = U;
        float r79462 = r79456 * r79453;
        float r79463 = r79462 * r79458;
        float r79464 = r79461 / r79463;
        float r79465 = r79464 * r79464;
        float r79466 = r79460 + r79465;
        float r79467 = sqrt(r79466);
        float r79468 = r79459 * r79467;
        return r79468;
}

double f_id(float J, float K, float U) {
        double r79469 = -2.0;
        double r79470 = J;
        double r79471 = r79469 * r79470;
        double r79472 = K;
        double r79473 = 2.0;
        double r79474 = r79472 / r79473;
        double r79475 = cos(r79474);
        double r79476 = r79471 * r79475;
        double r79477 = 1.0;
        double r79478 = U;
        double r79479 = r79473 * r79470;
        double r79480 = r79479 * r79475;
        double r79481 = r79478 / r79480;
        double r79482 = r79481 * r79481;
        double r79483 = r79477 + r79482;
        double r79484 = sqrt(r79483);
        double r79485 = r79476 * r79484;
        return r79485;
}

double f_il(float J, float K, float U) {
        long double r79486 = -2.0;
        long double r79487 = J;
        long double r79488 = r79486 * r79487;
        long double r79489 = K;
        long double r79490 = 2.0;
        long double r79491 = r79489 / r79490;
        long double r79492 = cos(r79491);
        long double r79493 = r79488 * r79492;
        long double r79494 = 1.0;
        long double r79495 = U;
        long double r79496 = r79490 * r79487;
        long double r79497 = r79496 * r79492;
        long double r79498 = r79495 / r79497;
        long double r79499 = r79498 * r79498;
        long double r79500 = r79494 + r79499;
        long double r79501 = sqrt(r79500);
        long double r79502 = r79493 * r79501;
        return r79502;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float J, float K, float U) {
        float r79503 = -2.0;
        float r79504 = J;
        float r79505 = r79503 * r79504;
        float r79506 = K;
        float r79507 = 2.0;
        float r79508 = r79506 / r79507;
        float r79509 = cos(r79508);
        float r79510 = r79505 * r79509;
        float r79511 = 1.0;
        float r79512 = U;
        float r79513 = r79507 * r79504;
        float r79514 = r79513 * r79509;
        float r79515 = r79512 / r79514;
        float r79516 = r79515 * r79515;
        float r79517 = r79511 + r79516;
        float r79518 = sqrt(r79517);
        float r79519 = r79510 * r79518;
        return r79519;
}

double f_od(float J, float K, float U) {
        double r79520 = -2.0;
        double r79521 = J;
        double r79522 = r79520 * r79521;
        double r79523 = K;
        double r79524 = 2.0;
        double r79525 = r79523 / r79524;
        double r79526 = cos(r79525);
        double r79527 = r79522 * r79526;
        double r79528 = 1.0;
        double r79529 = U;
        double r79530 = r79524 * r79521;
        double r79531 = r79530 * r79526;
        double r79532 = r79529 / r79531;
        double r79533 = r79532 * r79532;
        double r79534 = r79528 + r79533;
        double r79535 = sqrt(r79534);
        double r79536 = r79527 * r79535;
        return r79536;
}

double f_ol(float J, float K, float U) {
        long double r79537 = -2.0;
        long double r79538 = J;
        long double r79539 = r79537 * r79538;
        long double r79540 = K;
        long double r79541 = 2.0;
        long double r79542 = r79540 / r79541;
        long double r79543 = cos(r79542);
        long double r79544 = r79539 * r79543;
        long double r79545 = 1.0;
        long double r79546 = U;
        long double r79547 = r79541 * r79538;
        long double r79548 = r79547 * r79543;
        long double r79549 = r79546 / r79548;
        long double r79550 = r79549 * r79549;
        long double r79551 = r79545 + r79550;
        long double r79552 = sqrt(r79551);
        long double r79553 = r79544 * r79552;
        return r79553;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r79554, r79555, r79556, r79557, r79558, r79559, r79560, r79561, r79562, r79563, r79564, r79565, r79566, r79567, r79568, r79569, r79570;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r79554);
        mpfr_init(r79555);
        mpfr_init(r79556);
        mpfr_init(r79557);
        mpfr_init(r79558);
        mpfr_init(r79559);
        mpfr_init(r79560);
        mpfr_init(r79561);
        mpfr_init(r79562);
        mpfr_init(r79563);
        mpfr_init(r79564);
        mpfr_init(r79565);
        mpfr_init(r79566);
        mpfr_init(r79567);
        mpfr_init(r79568);
        mpfr_init(r79569);
        mpfr_init(r79570);
}

double f_im(float J, float K, float U) {
        mpfr_init_set_str(r79554, "-2", 10, MPFR_RNDN);
        mpfr_set_flt(r79555, J, MPFR_RNDN);
        mpfr_mul(r79556, r79554, r79555, MPFR_RNDN);
        mpfr_set_flt(r79557, K, MPFR_RNDN);
        mpfr_init_set_str(r79558, "2", 10, MPFR_RNDN);
        mpfr_div(r79559, r79557, r79558, MPFR_RNDN);
        mpfr_cos(r79560, r79559, MPFR_RNDN);
        mpfr_mul(r79561, r79556, r79560, MPFR_RNDN);
        mpfr_init_set_str(r79562, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r79563, U, MPFR_RNDN);
        mpfr_mul(r79564, r79558, r79555, MPFR_RNDN);
        mpfr_mul(r79565, r79564, r79560, MPFR_RNDN);
        mpfr_div(r79566, r79563, r79565, MPFR_RNDN);
        mpfr_mul(r79567, r79566, r79566, MPFR_RNDN);
        mpfr_add(r79568, r79562, r79567, MPFR_RNDN);
        mpfr_sqrt(r79569, r79568, MPFR_RNDN);
        mpfr_mul(r79570, r79561, r79569, MPFR_RNDN);
        return mpfr_get_d(r79570, MPFR_RNDN);
}

