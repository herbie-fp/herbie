#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Henrywood and Agarwal, Equation (12) */

double f_if(float d, float h, float l, float M, float D) {
        float r76420 = d;
        float r76421 = h;
        float r76422 = r76420 / r76421;
        float r76423 = 1.0;
        float r76424 = 2.0;
        float r76425 = r76423 / r76424;
        float r76426 = pow(r76422, r76425);
        float r76427 = l;
        float r76428 = r76420 / r76427;
        float r76429 = pow(r76428, r76425);
        float r76430 = r76426 * r76429;
        float r76431 = M;
        float r76432 = D;
        float r76433 = r76431 * r76432;
        float r76434 = r76424 * r76420;
        float r76435 = r76433 / r76434;
        float r76436 = r76435 * r76435;
        float r76437 = r76425 * r76436;
        float r76438 = r76421 / r76427;
        float r76439 = r76437 * r76438;
        float r76440 = r76423 - r76439;
        float r76441 = r76430 * r76440;
        return r76441;
}

double f_id(float d, float h, float l, float M, float D) {
        double r76442 = d;
        double r76443 = h;
        double r76444 = r76442 / r76443;
        double r76445 = 1.0;
        double r76446 = 2.0;
        double r76447 = r76445 / r76446;
        double r76448 = pow(r76444, r76447);
        double r76449 = l;
        double r76450 = r76442 / r76449;
        double r76451 = pow(r76450, r76447);
        double r76452 = r76448 * r76451;
        double r76453 = M;
        double r76454 = D;
        double r76455 = r76453 * r76454;
        double r76456 = r76446 * r76442;
        double r76457 = r76455 / r76456;
        double r76458 = r76457 * r76457;
        double r76459 = r76447 * r76458;
        double r76460 = r76443 / r76449;
        double r76461 = r76459 * r76460;
        double r76462 = r76445 - r76461;
        double r76463 = r76452 * r76462;
        return r76463;
}

double f_il(float d, float h, float l, float M, float D) {
        long double r76464 = d;
        long double r76465 = h;
        long double r76466 = r76464 / r76465;
        long double r76467 = 1.0;
        long double r76468 = 2.0;
        long double r76469 = r76467 / r76468;
        long double r76470 = pow(r76466, r76469);
        long double r76471 = l;
        long double r76472 = r76464 / r76471;
        long double r76473 = pow(r76472, r76469);
        long double r76474 = r76470 * r76473;
        long double r76475 = M;
        long double r76476 = D;
        long double r76477 = r76475 * r76476;
        long double r76478 = r76468 * r76464;
        long double r76479 = r76477 / r76478;
        long double r76480 = r76479 * r76479;
        long double r76481 = r76469 * r76480;
        long double r76482 = r76465 / r76471;
        long double r76483 = r76481 * r76482;
        long double r76484 = r76467 - r76483;
        long double r76485 = r76474 * r76484;
        return r76485;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float d, float h, float l, float M, float D) {
        float r76486 = l;
        float r76487 = 1.1956254977321259e-08;
        bool r76488 = r76486 < r76487;
        float r76489 = d;
        float r76490 = h;
        float r76491 = r76489 / r76490;
        float r76492 = 1.0;
        float r76493 = 2.0;
        float r76494 = r76492 / r76493;
        float r76495 = pow(r76491, r76494);
        float r76496 = r76489 / r76486;
        float r76497 = pow(r76496, r76494);
        float r76498 = sqrt(r76497);
        float r76499 = r76498 * r76498;
        float r76500 = r76495 * r76499;
        float r76501 = M;
        float r76502 = D;
        float r76503 = r76501 * r76502;
        float r76504 = r76503 * r76503;
        float r76505 = r76504 * r76490;
        float r76506 = r76493 * r76489;
        float r76507 = r76506 * r76506;
        float r76508 = r76493 * r76507;
        float r76509 = r76508 * r76486;
        float r76510 = r76505 / r76509;
        float r76511 = r76492 - r76510;
        float r76512 = r76500 * r76511;
        float r76513 = r76495 * r76497;
        float r76514 = r76503 / r76506;
        float r76515 = r76514 * r76514;
        float r76516 = r76494 * r76515;
        float r76517 = r76516 * r76490;
        float r76518 = r76517 / r76486;
        float r76519 = r76492 - r76518;
        float r76520 = r76513 * r76519;
        float r76521 = r76488 ? r76512 : r76520;
        return r76521;
}

double f_od(float d, float h, float l, float M, float D) {
        double r76522 = l;
        double r76523 = 1.1956254977321259e-08;
        bool r76524 = r76522 < r76523;
        double r76525 = d;
        double r76526 = h;
        double r76527 = r76525 / r76526;
        double r76528 = 1.0;
        double r76529 = 2.0;
        double r76530 = r76528 / r76529;
        double r76531 = pow(r76527, r76530);
        double r76532 = r76525 / r76522;
        double r76533 = pow(r76532, r76530);
        double r76534 = sqrt(r76533);
        double r76535 = r76534 * r76534;
        double r76536 = r76531 * r76535;
        double r76537 = M;
        double r76538 = D;
        double r76539 = r76537 * r76538;
        double r76540 = r76539 * r76539;
        double r76541 = r76540 * r76526;
        double r76542 = r76529 * r76525;
        double r76543 = r76542 * r76542;
        double r76544 = r76529 * r76543;
        double r76545 = r76544 * r76522;
        double r76546 = r76541 / r76545;
        double r76547 = r76528 - r76546;
        double r76548 = r76536 * r76547;
        double r76549 = r76531 * r76533;
        double r76550 = r76539 / r76542;
        double r76551 = r76550 * r76550;
        double r76552 = r76530 * r76551;
        double r76553 = r76552 * r76526;
        double r76554 = r76553 / r76522;
        double r76555 = r76528 - r76554;
        double r76556 = r76549 * r76555;
        double r76557 = r76524 ? r76548 : r76556;
        return r76557;
}

double f_ol(float d, float h, float l, float M, float D) {
        long double r76558 = l;
        long double r76559 = 1.1956254977321259e-08;
        bool r76560 = r76558 < r76559;
        long double r76561 = d;
        long double r76562 = h;
        long double r76563 = r76561 / r76562;
        long double r76564 = 1.0;
        long double r76565 = 2.0;
        long double r76566 = r76564 / r76565;
        long double r76567 = pow(r76563, r76566);
        long double r76568 = r76561 / r76558;
        long double r76569 = pow(r76568, r76566);
        long double r76570 = sqrt(r76569);
        long double r76571 = r76570 * r76570;
        long double r76572 = r76567 * r76571;
        long double r76573 = M;
        long double r76574 = D;
        long double r76575 = r76573 * r76574;
        long double r76576 = r76575 * r76575;
        long double r76577 = r76576 * r76562;
        long double r76578 = r76565 * r76561;
        long double r76579 = r76578 * r76578;
        long double r76580 = r76565 * r76579;
        long double r76581 = r76580 * r76558;
        long double r76582 = r76577 / r76581;
        long double r76583 = r76564 - r76582;
        long double r76584 = r76572 * r76583;
        long double r76585 = r76567 * r76569;
        long double r76586 = r76575 / r76578;
        long double r76587 = r76586 * r76586;
        long double r76588 = r76566 * r76587;
        long double r76589 = r76588 * r76562;
        long double r76590 = r76589 / r76558;
        long double r76591 = r76564 - r76590;
        long double r76592 = r76585 * r76591;
        long double r76593 = r76560 ? r76584 : r76592;
        return r76593;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r76594, r76595, r76596, r76597, r76598, r76599, r76600, r76601, r76602, r76603, r76604, r76605, r76606, r76607, r76608, r76609, r76610, r76611, r76612, r76613, r76614, r76615;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r76594);
        mpfr_init(r76595);
        mpfr_init(r76596);
        mpfr_init(r76597);
        mpfr_init(r76598);
        mpfr_init(r76599);
        mpfr_init(r76600);
        mpfr_init(r76601);
        mpfr_init(r76602);
        mpfr_init(r76603);
        mpfr_init(r76604);
        mpfr_init(r76605);
        mpfr_init(r76606);
        mpfr_init(r76607);
        mpfr_init(r76608);
        mpfr_init(r76609);
        mpfr_init(r76610);
        mpfr_init(r76611);
        mpfr_init(r76612);
        mpfr_init(r76613);
        mpfr_init(r76614);
        mpfr_init(r76615);
}

double f_im(float d, float h, float l, float M, float D) {
        mpfr_set_flt(r76594, d, MPFR_RNDN);
        mpfr_set_flt(r76595, h, MPFR_RNDN);
        mpfr_div(r76596, r76594, r76595, MPFR_RNDN);
        mpfr_init_set_str(r76597, "1", 10, MPFR_RNDN);
        mpfr_init_set_str(r76598, "2", 10, MPFR_RNDN);
        mpfr_div(r76599, r76597, r76598, MPFR_RNDN);
        mpfr_pow(r76600, r76596, r76599, MPFR_RNDN);
        mpfr_set_flt(r76601, l, MPFR_RNDN);
        mpfr_div(r76602, r76594, r76601, MPFR_RNDN);
        mpfr_pow(r76603, r76602, r76599, MPFR_RNDN);
        mpfr_mul(r76604, r76600, r76603, MPFR_RNDN);
        mpfr_set_flt(r76605, M, MPFR_RNDN);
        mpfr_set_flt(r76606, D, MPFR_RNDN);
        mpfr_mul(r76607, r76605, r76606, MPFR_RNDN);
        mpfr_mul(r76608, r76598, r76594, MPFR_RNDN);
        mpfr_div(r76609, r76607, r76608, MPFR_RNDN);
        mpfr_mul(r76610, r76609, r76609, MPFR_RNDN);
        mpfr_mul(r76611, r76599, r76610, MPFR_RNDN);
        mpfr_div(r76612, r76595, r76601, MPFR_RNDN);
        mpfr_mul(r76613, r76611, r76612, MPFR_RNDN);
        mpfr_sub(r76614, r76597, r76613, MPFR_RNDN);
        mpfr_mul(r76615, r76604, r76614, MPFR_RNDN);
        return mpfr_get_d(r76615, MPFR_RNDN);
}

