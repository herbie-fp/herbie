#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Commute and associate */

double f_if(float x, float y, float z) {
        float r72420 = x;
        float r72421 = y;
        float r72422 = r72420 + r72421;
        float r72423 = z;
        float r72424 = r72422 + r72423;
        float r72425 = r72421 + r72423;
        float r72426 = r72420 + r72425;
        float r72427 = r72424 - r72426;
        return r72427;
}

double f_id(float x, float y, float z) {
        double r72428 = x;
        double r72429 = y;
        double r72430 = r72428 + r72429;
        double r72431 = z;
        double r72432 = r72430 + r72431;
        double r72433 = r72429 + r72431;
        double r72434 = r72428 + r72433;
        double r72435 = r72432 - r72434;
        return r72435;
}

double f_il(float x, float y, float z) {
        long double r72436 = x;
        long double r72437 = y;
        long double r72438 = r72436 + r72437;
        long double r72439 = z;
        long double r72440 = r72438 + r72439;
        long double r72441 = r72437 + r72439;
        long double r72442 = r72436 + r72441;
        long double r72443 = r72440 - r72442;
        return r72443;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x, float y, float z) {
        float r72444 = 0.0;
        return r72444;
}

double f_od(float x, float y, float z) {
        double r72445 = 0.0;
        return r72445;
}

double f_ol(float x, float y, float z) {
        long double r72446 = 0.0;
        return r72446;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r72447, r72448, r72449, r72450, r72451, r72452, r72453, r72454;

void setup_mpfr() {
        mpfr_set_default_prec(312);
        mpfr_init(r72447);
        mpfr_init(r72448);
        mpfr_init(r72449);
        mpfr_init(r72450);
        mpfr_init(r72451);
        mpfr_init(r72452);
        mpfr_init(r72453);
        mpfr_init(r72454);
}

double f_im(float x, float y, float z) {
        mpfr_set_flt(r72447, x, MPFR_RNDN);
        mpfr_set_flt(r72448, y, MPFR_RNDN);
        mpfr_add(r72449, r72447, r72448, MPFR_RNDN);
        mpfr_set_flt(r72450, z, MPFR_RNDN);
        mpfr_add(r72451, r72449, r72450, MPFR_RNDN);
        mpfr_add(r72452, r72448, r72450, MPFR_RNDN);
        mpfr_add(r72453, r72447, r72452, MPFR_RNDN);
        mpfr_sub(r72454, r72451, r72453, MPFR_RNDN);
        return mpfr_get_d(r72454, MPFR_RNDN);
}

