#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE problem 3.4.6 */

double f_if(float x, float n) {
        float r80968 = x;
        float r80969 = 1.0;
        float r80970 = r80968 + r80969;
        float r80971 = n;
        float r80972 = r80969 / r80971;
        float r80973 = pow(r80970, r80972);
        float r80974 = pow(r80968, r80972);
        float r80975 = r80973 - r80974;
        return r80975;
}

double f_id(float x, float n) {
        double r80976 = x;
        double r80977 = 1.0;
        double r80978 = r80976 + r80977;
        double r80979 = n;
        double r80980 = r80977 / r80979;
        double r80981 = pow(r80978, r80980);
        double r80982 = pow(r80976, r80980);
        double r80983 = r80981 - r80982;
        return r80983;
}

double f_il(float x, float n) {
        long double r80984 = x;
        long double r80985 = 1.0;
        long double r80986 = r80984 + r80985;
        long double r80987 = n;
        long double r80988 = r80985 / r80987;
        long double r80989 = pow(r80986, r80988);
        long double r80990 = pow(r80984, r80988);
        long double r80991 = r80989 - r80990;
        return r80991;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x, float n) {
        float r80992 = x;
        float r80993 = 1.0;
        float r80994 = r80992 + r80993;
        float r80995 = n;
        float r80996 = 1.0/r80995;
        float r80997 = pow(r80994, r80996);
        float r80998 = r80993 / r80995;
        float r80999 = pow(r80992, r80998);
        float r81000 = r80997 - r80999;
        return r81000;
}

double f_od(float x, float n) {
        double r81001 = x;
        double r81002 = 1.0;
        double r81003 = r81001 + r81002;
        double r81004 = n;
        double r81005 = 1.0/r81004;
        double r81006 = pow(r81003, r81005);
        double r81007 = r81002 / r81004;
        double r81008 = pow(r81001, r81007);
        double r81009 = r81006 - r81008;
        return r81009;
}

double f_ol(float x, float n) {
        long double r81010 = x;
        long double r81011 = 1.0;
        long double r81012 = r81010 + r81011;
        long double r81013 = n;
        long double r81014 = 1.0/r81013;
        long double r81015 = pow(r81012, r81014);
        long double r81016 = r81011 / r81013;
        long double r81017 = pow(r81010, r81016);
        long double r81018 = r81015 - r81017;
        return r81018;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r81019, r81020, r81021, r81022, r81023, r81024, r81025, r81026;

void setup_mpfr() {
        mpfr_set_default_prec(344);
        mpfr_init(r81019);
        mpfr_init(r81020);
        mpfr_init(r81021);
        mpfr_init(r81022);
        mpfr_init(r81023);
        mpfr_init(r81024);
        mpfr_init(r81025);
        mpfr_init(r81026);
}

double f_im(float x, float n) {
        mpfr_set_flt(r81019, x, MPFR_RNDN);
        mpfr_init_set_str(r81020, "1", 10, MPFR_RNDN);
        mpfr_add(r81021, r81019, r81020, MPFR_RNDN);
        mpfr_set_flt(r81022, n, MPFR_RNDN);
        mpfr_div(r81023, r81020, r81022, MPFR_RNDN);
        mpfr_pow(r81024, r81021, r81023, MPFR_RNDN);
        mpfr_pow(r81025, r81019, r81023, MPFR_RNDN);
        mpfr_sub(r81026, r81024, r81025, MPFR_RNDN);
        return mpfr_get_d(r81026, MPFR_RNDN);
}

