#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* FastMath dist4 */

double f_if(float d1, float d2, float d3, float d4) {
        float r72674 = d1;
        float r72675 = d2;
        float r72676 = r72674 * r72675;
        float r72677 = d3;
        float r72678 = r72674 * r72677;
        float r72679 = r72676 - r72678;
        float r72680 = d4;
        float r72681 = r72680 * r72674;
        float r72682 = r72679 + r72681;
        float r72683 = r72674 * r72674;
        float r72684 = r72682 - r72683;
        return r72684;
}

double f_id(float d1, float d2, float d3, float d4) {
        double r72685 = d1;
        double r72686 = d2;
        double r72687 = r72685 * r72686;
        double r72688 = d3;
        double r72689 = r72685 * r72688;
        double r72690 = r72687 - r72689;
        double r72691 = d4;
        double r72692 = r72691 * r72685;
        double r72693 = r72690 + r72692;
        double r72694 = r72685 * r72685;
        double r72695 = r72693 - r72694;
        return r72695;
}

double f_il(float d1, float d2, float d3, float d4) {
        long double r72696 = d1;
        long double r72697 = d2;
        long double r72698 = r72696 * r72697;
        long double r72699 = d3;
        long double r72700 = r72696 * r72699;
        long double r72701 = r72698 - r72700;
        long double r72702 = d4;
        long double r72703 = r72702 * r72696;
        long double r72704 = r72701 + r72703;
        long double r72705 = r72696 * r72696;
        long double r72706 = r72704 - r72705;
        return r72706;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float d1, float d2, float d3, float d4) {
        float r72707 = d1;
        float r72708 = -5718546606.568445;
        bool r72709 = r72707 < r72708;
        float r72710 = d2;
        float r72711 = d3;
        float r72712 = r72710 - r72711;
        float r72713 = r72707 * r72712;
        float r72714 = d4;
        float r72715 = r72714 * r72707;
        float r72716 = r72713 + r72715;
        float r72717 = r72707 * r72707;
        float r72718 = r72716 - r72717;
        float r72719 = 2.427266233118075e-16;
        bool r72720 = r72707 < r72719;
        float r72721 = r72714 - r72707;
        float r72722 = r72712 + r72721;
        float r72723 = r72707 * r72722;
        float r72724 = r72720 ? r72723 : r72718;
        float r72725 = r72709 ? r72718 : r72724;
        return r72725;
}

double f_od(float d1, float d2, float d3, float d4) {
        double r72726 = d1;
        double r72727 = -5718546606.568445;
        bool r72728 = r72726 < r72727;
        double r72729 = d2;
        double r72730 = d3;
        double r72731 = r72729 - r72730;
        double r72732 = r72726 * r72731;
        double r72733 = d4;
        double r72734 = r72733 * r72726;
        double r72735 = r72732 + r72734;
        double r72736 = r72726 * r72726;
        double r72737 = r72735 - r72736;
        double r72738 = 2.427266233118075e-16;
        bool r72739 = r72726 < r72738;
        double r72740 = r72733 - r72726;
        double r72741 = r72731 + r72740;
        double r72742 = r72726 * r72741;
        double r72743 = r72739 ? r72742 : r72737;
        double r72744 = r72728 ? r72737 : r72743;
        return r72744;
}

double f_ol(float d1, float d2, float d3, float d4) {
        long double r72745 = d1;
        long double r72746 = -5718546606.568445;
        bool r72747 = r72745 < r72746;
        long double r72748 = d2;
        long double r72749 = d3;
        long double r72750 = r72748 - r72749;
        long double r72751 = r72745 * r72750;
        long double r72752 = d4;
        long double r72753 = r72752 * r72745;
        long double r72754 = r72751 + r72753;
        long double r72755 = r72745 * r72745;
        long double r72756 = r72754 - r72755;
        long double r72757 = 2.427266233118075e-16;
        bool r72758 = r72745 < r72757;
        long double r72759 = r72752 - r72745;
        long double r72760 = r72750 + r72759;
        long double r72761 = r72745 * r72760;
        long double r72762 = r72758 ? r72761 : r72756;
        long double r72763 = r72747 ? r72756 : r72762;
        return r72763;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r72764, r72765, r72766, r72767, r72768, r72769, r72770, r72771, r72772, r72773, r72774;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r72764);
        mpfr_init(r72765);
        mpfr_init(r72766);
        mpfr_init(r72767);
        mpfr_init(r72768);
        mpfr_init(r72769);
        mpfr_init(r72770);
        mpfr_init(r72771);
        mpfr_init(r72772);
        mpfr_init(r72773);
        mpfr_init(r72774);
}

double f_im(float d1, float d2, float d3, float d4) {
        mpfr_set_flt(r72764, d1, MPFR_RNDN);
        mpfr_set_flt(r72765, d2, MPFR_RNDN);
        mpfr_mul(r72766, r72764, r72765, MPFR_RNDN);
        mpfr_set_flt(r72767, d3, MPFR_RNDN);
        mpfr_mul(r72768, r72764, r72767, MPFR_RNDN);
        mpfr_sub(r72769, r72766, r72768, MPFR_RNDN);
        mpfr_set_flt(r72770, d4, MPFR_RNDN);
        mpfr_mul(r72771, r72770, r72764, MPFR_RNDN);
        mpfr_add(r72772, r72769, r72771, MPFR_RNDN);
        mpfr_mul(r72773, r72764, r72764, MPFR_RNDN);
        mpfr_sub(r72774, r72772, r72773, MPFR_RNDN);
        return mpfr_get_d(r72774, MPFR_RNDN);
}

