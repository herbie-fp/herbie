#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Jmat.Real.dawson */

double f_if(float x) {
        float r77595 = 1.0;
        float r77596 = 0.1049934947;
        float r77597 = x;
        float r77598 = r77597 * r77597;
        float r77599 = r77596 * r77598;
        float r77600 = r77595 + r77599;
        float r77601 = 0.0424060604;
        float r77602 = r77598 * r77598;
        float r77603 = r77601 * r77602;
        float r77604 = r77600 + r77603;
        float r77605 = 0.0072644182;
        float r77606 = r77602 * r77598;
        float r77607 = r77605 * r77606;
        float r77608 = r77604 + r77607;
        float r77609 = 0.0005064034;
        float r77610 = r77606 * r77598;
        float r77611 = r77609 * r77610;
        float r77612 = r77608 + r77611;
        float r77613 = 0.0001789971;
        float r77614 = r77610 * r77598;
        float r77615 = r77613 * r77614;
        float r77616 = r77612 + r77615;
        float r77617 = 0.7715471019;
        float r77618 = r77617 * r77598;
        float r77619 = r77595 + r77618;
        float r77620 = 0.2909738639;
        float r77621 = r77620 * r77602;
        float r77622 = r77619 + r77621;
        float r77623 = 0.0694555761;
        float r77624 = r77623 * r77606;
        float r77625 = r77622 + r77624;
        float r77626 = 0.0140005442;
        float r77627 = r77626 * r77610;
        float r77628 = r77625 + r77627;
        float r77629 = 0.0008327945;
        float r77630 = r77629 * r77614;
        float r77631 = r77628 + r77630;
        float r77632 = 2.0;
        float r77633 = r77632 * r77613;
        float r77634 = r77614 * r77598;
        float r77635 = r77633 * r77634;
        float r77636 = r77631 + r77635;
        float r77637 = r77616 / r77636;
        float r77638 = r77637 * r77597;
        return r77638;
}

double f_id(float x) {
        double r77639 = 1.0;
        double r77640 = 0.1049934947;
        double r77641 = x;
        double r77642 = r77641 * r77641;
        double r77643 = r77640 * r77642;
        double r77644 = r77639 + r77643;
        double r77645 = 0.0424060604;
        double r77646 = r77642 * r77642;
        double r77647 = r77645 * r77646;
        double r77648 = r77644 + r77647;
        double r77649 = 0.0072644182;
        double r77650 = r77646 * r77642;
        double r77651 = r77649 * r77650;
        double r77652 = r77648 + r77651;
        double r77653 = 0.0005064034;
        double r77654 = r77650 * r77642;
        double r77655 = r77653 * r77654;
        double r77656 = r77652 + r77655;
        double r77657 = 0.0001789971;
        double r77658 = r77654 * r77642;
        double r77659 = r77657 * r77658;
        double r77660 = r77656 + r77659;
        double r77661 = 0.7715471019;
        double r77662 = r77661 * r77642;
        double r77663 = r77639 + r77662;
        double r77664 = 0.2909738639;
        double r77665 = r77664 * r77646;
        double r77666 = r77663 + r77665;
        double r77667 = 0.0694555761;
        double r77668 = r77667 * r77650;
        double r77669 = r77666 + r77668;
        double r77670 = 0.0140005442;
        double r77671 = r77670 * r77654;
        double r77672 = r77669 + r77671;
        double r77673 = 0.0008327945;
        double r77674 = r77673 * r77658;
        double r77675 = r77672 + r77674;
        double r77676 = 2.0;
        double r77677 = r77676 * r77657;
        double r77678 = r77658 * r77642;
        double r77679 = r77677 * r77678;
        double r77680 = r77675 + r77679;
        double r77681 = r77660 / r77680;
        double r77682 = r77681 * r77641;
        return r77682;
}

double f_il(float x) {
        long double r77683 = 1.0;
        long double r77684 = 0.1049934947;
        long double r77685 = x;
        long double r77686 = r77685 * r77685;
        long double r77687 = r77684 * r77686;
        long double r77688 = r77683 + r77687;
        long double r77689 = 0.0424060604;
        long double r77690 = r77686 * r77686;
        long double r77691 = r77689 * r77690;
        long double r77692 = r77688 + r77691;
        long double r77693 = 0.0072644182;
        long double r77694 = r77690 * r77686;
        long double r77695 = r77693 * r77694;
        long double r77696 = r77692 + r77695;
        long double r77697 = 0.0005064034;
        long double r77698 = r77694 * r77686;
        long double r77699 = r77697 * r77698;
        long double r77700 = r77696 + r77699;
        long double r77701 = 0.0001789971;
        long double r77702 = r77698 * r77686;
        long double r77703 = r77701 * r77702;
        long double r77704 = r77700 + r77703;
        long double r77705 = 0.7715471019;
        long double r77706 = r77705 * r77686;
        long double r77707 = r77683 + r77706;
        long double r77708 = 0.2909738639;
        long double r77709 = r77708 * r77690;
        long double r77710 = r77707 + r77709;
        long double r77711 = 0.0694555761;
        long double r77712 = r77711 * r77694;
        long double r77713 = r77710 + r77712;
        long double r77714 = 0.0140005442;
        long double r77715 = r77714 * r77698;
        long double r77716 = r77713 + r77715;
        long double r77717 = 0.0008327945;
        long double r77718 = r77717 * r77702;
        long double r77719 = r77716 + r77718;
        long double r77720 = 2.0;
        long double r77721 = r77720 * r77701;
        long double r77722 = r77702 * r77686;
        long double r77723 = r77721 * r77722;
        long double r77724 = r77719 + r77723;
        long double r77725 = r77704 / r77724;
        long double r77726 = r77725 * r77685;
        return r77726;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r77727 = 1.0;
        float r77728 = 0.1049934947;
        float r77729 = x;
        float r77730 = r77729 * r77729;
        float r77731 = r77728 * r77730;
        float r77732 = r77727 + r77731;
        float r77733 = 0.0424060604;
        float r77734 = r77730 * r77730;
        float r77735 = r77733 * r77734;
        float r77736 = r77732 + r77735;
        float r77737 = 0.0072644182;
        float r77738 = log(r77730);
        float r77739 = exp(r77738);
        float r77740 = r77734 * r77739;
        float r77741 = r77737 * r77740;
        float r77742 = r77736 + r77741;
        float r77743 = 0.0005064034;
        float r77744 = r77734 * r77730;
        float r77745 = r77744 * r77730;
        float r77746 = r77743 * r77745;
        float r77747 = r77742 + r77746;
        float r77748 = 0.0001789971;
        float r77749 = r77745 * r77730;
        float r77750 = r77748 * r77749;
        float r77751 = r77747 + r77750;
        float r77752 = 0.7715471019;
        float r77753 = r77752 * r77730;
        float r77754 = r77727 + r77753;
        float r77755 = 0.2909738639;
        float r77756 = r77755 * r77734;
        float r77757 = r77754 + r77756;
        float r77758 = 0.0694555761;
        float r77759 = r77758 * r77744;
        float r77760 = r77757 + r77759;
        float r77761 = 0.0140005442;
        float r77762 = r77761 * r77745;
        float r77763 = r77760 + r77762;
        float r77764 = 0.0008327945;
        float r77765 = r77764 * r77749;
        float r77766 = r77763 + r77765;
        float r77767 = 2.0;
        float r77768 = r77767 * r77748;
        float r77769 = r77749 * r77730;
        float r77770 = r77768 * r77769;
        float r77771 = r77766 + r77770;
        float r77772 = r77751 / r77771;
        float r77773 = r77772 * r77729;
        return r77773;
}

double f_od(float x) {
        double r77774 = 1.0;
        double r77775 = 0.1049934947;
        double r77776 = x;
        double r77777 = r77776 * r77776;
        double r77778 = r77775 * r77777;
        double r77779 = r77774 + r77778;
        double r77780 = 0.0424060604;
        double r77781 = r77777 * r77777;
        double r77782 = r77780 * r77781;
        double r77783 = r77779 + r77782;
        double r77784 = 0.0072644182;
        double r77785 = log(r77777);
        double r77786 = exp(r77785);
        double r77787 = r77781 * r77786;
        double r77788 = r77784 * r77787;
        double r77789 = r77783 + r77788;
        double r77790 = 0.0005064034;
        double r77791 = r77781 * r77777;
        double r77792 = r77791 * r77777;
        double r77793 = r77790 * r77792;
        double r77794 = r77789 + r77793;
        double r77795 = 0.0001789971;
        double r77796 = r77792 * r77777;
        double r77797 = r77795 * r77796;
        double r77798 = r77794 + r77797;
        double r77799 = 0.7715471019;
        double r77800 = r77799 * r77777;
        double r77801 = r77774 + r77800;
        double r77802 = 0.2909738639;
        double r77803 = r77802 * r77781;
        double r77804 = r77801 + r77803;
        double r77805 = 0.0694555761;
        double r77806 = r77805 * r77791;
        double r77807 = r77804 + r77806;
        double r77808 = 0.0140005442;
        double r77809 = r77808 * r77792;
        double r77810 = r77807 + r77809;
        double r77811 = 0.0008327945;
        double r77812 = r77811 * r77796;
        double r77813 = r77810 + r77812;
        double r77814 = 2.0;
        double r77815 = r77814 * r77795;
        double r77816 = r77796 * r77777;
        double r77817 = r77815 * r77816;
        double r77818 = r77813 + r77817;
        double r77819 = r77798 / r77818;
        double r77820 = r77819 * r77776;
        return r77820;
}

double f_ol(float x) {
        long double r77821 = 1.0;
        long double r77822 = 0.1049934947;
        long double r77823 = x;
        long double r77824 = r77823 * r77823;
        long double r77825 = r77822 * r77824;
        long double r77826 = r77821 + r77825;
        long double r77827 = 0.0424060604;
        long double r77828 = r77824 * r77824;
        long double r77829 = r77827 * r77828;
        long double r77830 = r77826 + r77829;
        long double r77831 = 0.0072644182;
        long double r77832 = log(r77824);
        long double r77833 = exp(r77832);
        long double r77834 = r77828 * r77833;
        long double r77835 = r77831 * r77834;
        long double r77836 = r77830 + r77835;
        long double r77837 = 0.0005064034;
        long double r77838 = r77828 * r77824;
        long double r77839 = r77838 * r77824;
        long double r77840 = r77837 * r77839;
        long double r77841 = r77836 + r77840;
        long double r77842 = 0.0001789971;
        long double r77843 = r77839 * r77824;
        long double r77844 = r77842 * r77843;
        long double r77845 = r77841 + r77844;
        long double r77846 = 0.7715471019;
        long double r77847 = r77846 * r77824;
        long double r77848 = r77821 + r77847;
        long double r77849 = 0.2909738639;
        long double r77850 = r77849 * r77828;
        long double r77851 = r77848 + r77850;
        long double r77852 = 0.0694555761;
        long double r77853 = r77852 * r77838;
        long double r77854 = r77851 + r77853;
        long double r77855 = 0.0140005442;
        long double r77856 = r77855 * r77839;
        long double r77857 = r77854 + r77856;
        long double r77858 = 0.0008327945;
        long double r77859 = r77858 * r77843;
        long double r77860 = r77857 + r77859;
        long double r77861 = 2.0;
        long double r77862 = r77861 * r77842;
        long double r77863 = r77843 * r77824;
        long double r77864 = r77862 * r77863;
        long double r77865 = r77860 + r77864;
        long double r77866 = r77845 / r77865;
        long double r77867 = r77866 * r77823;
        return r77867;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r77868, r77869, r77870, r77871, r77872, r77873, r77874, r77875, r77876, r77877, r77878, r77879, r77880, r77881, r77882, r77883, r77884, r77885, r77886, r77887, r77888, r77889, r77890, r77891, r77892, r77893, r77894, r77895, r77896, r77897, r77898, r77899, r77900, r77901, r77902, r77903, r77904, r77905, r77906, r77907, r77908, r77909, r77910, r77911;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r77868);
        mpfr_init(r77869);
        mpfr_init(r77870);
        mpfr_init(r77871);
        mpfr_init(r77872);
        mpfr_init(r77873);
        mpfr_init(r77874);
        mpfr_init(r77875);
        mpfr_init(r77876);
        mpfr_init(r77877);
        mpfr_init(r77878);
        mpfr_init(r77879);
        mpfr_init(r77880);
        mpfr_init(r77881);
        mpfr_init(r77882);
        mpfr_init(r77883);
        mpfr_init(r77884);
        mpfr_init(r77885);
        mpfr_init(r77886);
        mpfr_init(r77887);
        mpfr_init(r77888);
        mpfr_init(r77889);
        mpfr_init(r77890);
        mpfr_init(r77891);
        mpfr_init(r77892);
        mpfr_init(r77893);
        mpfr_init(r77894);
        mpfr_init(r77895);
        mpfr_init(r77896);
        mpfr_init(r77897);
        mpfr_init(r77898);
        mpfr_init(r77899);
        mpfr_init(r77900);
        mpfr_init(r77901);
        mpfr_init(r77902);
        mpfr_init(r77903);
        mpfr_init(r77904);
        mpfr_init(r77905);
        mpfr_init(r77906);
        mpfr_init(r77907);
        mpfr_init(r77908);
        mpfr_init(r77909);
        mpfr_init(r77910);
        mpfr_init(r77911);
}

double f_im(float x) {
        mpfr_init_set_str(r77868, "1", 10, MPFR_RNDN);
        mpfr_init_set_str(r77869, "0.1049934947", 10, MPFR_RNDN);
        mpfr_set_flt(r77870, x, MPFR_RNDN);
        mpfr_mul(r77871, r77870, r77870, MPFR_RNDN);
        mpfr_mul(r77872, r77869, r77871, MPFR_RNDN);
        mpfr_add(r77873, r77868, r77872, MPFR_RNDN);
        mpfr_init_set_str(r77874, "0.0424060604", 10, MPFR_RNDN);
        mpfr_mul(r77875, r77871, r77871, MPFR_RNDN);
        mpfr_mul(r77876, r77874, r77875, MPFR_RNDN);
        mpfr_add(r77877, r77873, r77876, MPFR_RNDN);
        mpfr_init_set_str(r77878, "0.0072644182", 10, MPFR_RNDN);
        mpfr_mul(r77879, r77875, r77871, MPFR_RNDN);
        mpfr_mul(r77880, r77878, r77879, MPFR_RNDN);
        mpfr_add(r77881, r77877, r77880, MPFR_RNDN);
        mpfr_init_set_str(r77882, "0.0005064034", 10, MPFR_RNDN);
        mpfr_mul(r77883, r77879, r77871, MPFR_RNDN);
        mpfr_mul(r77884, r77882, r77883, MPFR_RNDN);
        mpfr_add(r77885, r77881, r77884, MPFR_RNDN);
        mpfr_init_set_str(r77886, "0.0001789971", 10, MPFR_RNDN);
        mpfr_mul(r77887, r77883, r77871, MPFR_RNDN);
        mpfr_mul(r77888, r77886, r77887, MPFR_RNDN);
        mpfr_add(r77889, r77885, r77888, MPFR_RNDN);
        mpfr_init_set_str(r77890, "0.7715471019", 10, MPFR_RNDN);
        mpfr_mul(r77891, r77890, r77871, MPFR_RNDN);
        mpfr_add(r77892, r77868, r77891, MPFR_RNDN);
        mpfr_init_set_str(r77893, "0.2909738639", 10, MPFR_RNDN);
        mpfr_mul(r77894, r77893, r77875, MPFR_RNDN);
        mpfr_add(r77895, r77892, r77894, MPFR_RNDN);
        mpfr_init_set_str(r77896, "0.0694555761", 10, MPFR_RNDN);
        mpfr_mul(r77897, r77896, r77879, MPFR_RNDN);
        mpfr_add(r77898, r77895, r77897, MPFR_RNDN);
        mpfr_init_set_str(r77899, "0.0140005442", 10, MPFR_RNDN);
        mpfr_mul(r77900, r77899, r77883, MPFR_RNDN);
        mpfr_add(r77901, r77898, r77900, MPFR_RNDN);
        mpfr_init_set_str(r77902, "0.0008327945", 10, MPFR_RNDN);
        mpfr_mul(r77903, r77902, r77887, MPFR_RNDN);
        mpfr_add(r77904, r77901, r77903, MPFR_RNDN);
        mpfr_init_set_str(r77905, "2", 10, MPFR_RNDN);
        mpfr_mul(r77906, r77905, r77886, MPFR_RNDN);
        mpfr_mul(r77907, r77887, r77871, MPFR_RNDN);
        mpfr_mul(r77908, r77906, r77907, MPFR_RNDN);
        mpfr_add(r77909, r77904, r77908, MPFR_RNDN);
        mpfr_div(r77910, r77889, r77909, MPFR_RNDN);
        mpfr_mul(r77911, r77910, r77870, MPFR_RNDN);
        return mpfr_get_d(r77911, MPFR_RNDN);
}

