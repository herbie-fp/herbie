#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Falkner and Boettcher, Appendix A */

double f_if(float a, float k, float m) {
        float r75861 = a;
        float r75862 = k;
        float r75863 = m;
        float r75864 = pow(r75862, r75863);
        float r75865 = r75861 * r75864;
        float r75866 = 1.0;
        float r75867 = 10.0;
        float r75868 = r75867 * r75862;
        float r75869 = r75866 + r75868;
        float r75870 = r75862 * r75862;
        float r75871 = r75869 + r75870;
        float r75872 = r75865 / r75871;
        return r75872;
}

double f_id(float a, float k, float m) {
        double r75873 = a;
        double r75874 = k;
        double r75875 = m;
        double r75876 = pow(r75874, r75875);
        double r75877 = r75873 * r75876;
        double r75878 = 1.0;
        double r75879 = 10.0;
        double r75880 = r75879 * r75874;
        double r75881 = r75878 + r75880;
        double r75882 = r75874 * r75874;
        double r75883 = r75881 + r75882;
        double r75884 = r75877 / r75883;
        return r75884;
}

double f_il(float a, float k, float m) {
        long double r75885 = a;
        long double r75886 = k;
        long double r75887 = m;
        long double r75888 = pow(r75886, r75887);
        long double r75889 = r75885 * r75888;
        long double r75890 = 1.0;
        long double r75891 = 10.0;
        long double r75892 = r75891 * r75886;
        long double r75893 = r75890 + r75892;
        long double r75894 = r75886 * r75886;
        long double r75895 = r75893 + r75894;
        long double r75896 = r75889 / r75895;
        return r75896;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a, float k, float m) {
        float r75897 = k;
        float r75898 = 8.4609035030177535e-19;
        bool r75899 = r75897 < r75898;
        float r75900 = a;
        float r75901 = m;
        float r75902 = pow(r75897, r75901);
        float r75903 = r75900 * r75902;
        float r75904 = 1.0;
        float r75905 = 10.0;
        float r75906 = r75905 * r75897;
        float r75907 = r75904 + r75906;
        float r75908 = r75897 * r75897;
        float r75909 = r75907 + r75908;
        float r75910 = r75903 / r75909;
        float r75911 = r75909 / r75903;
        float r75912 = r75904 / r75911;
        float r75913 = r75899 ? r75910 : r75912;
        return r75913;
}

double f_od(float a, float k, float m) {
        double r75914 = k;
        double r75915 = 8.4609035030177535e-19;
        bool r75916 = r75914 < r75915;
        double r75917 = a;
        double r75918 = m;
        double r75919 = pow(r75914, r75918);
        double r75920 = r75917 * r75919;
        double r75921 = 1.0;
        double r75922 = 10.0;
        double r75923 = r75922 * r75914;
        double r75924 = r75921 + r75923;
        double r75925 = r75914 * r75914;
        double r75926 = r75924 + r75925;
        double r75927 = r75920 / r75926;
        double r75928 = r75926 / r75920;
        double r75929 = r75921 / r75928;
        double r75930 = r75916 ? r75927 : r75929;
        return r75930;
}

double f_ol(float a, float k, float m) {
        long double r75931 = k;
        long double r75932 = 8.4609035030177535e-19;
        bool r75933 = r75931 < r75932;
        long double r75934 = a;
        long double r75935 = m;
        long double r75936 = pow(r75931, r75935);
        long double r75937 = r75934 * r75936;
        long double r75938 = 1.0;
        long double r75939 = 10.0;
        long double r75940 = r75939 * r75931;
        long double r75941 = r75938 + r75940;
        long double r75942 = r75931 * r75931;
        long double r75943 = r75941 + r75942;
        long double r75944 = r75937 / r75943;
        long double r75945 = r75943 / r75937;
        long double r75946 = r75938 / r75945;
        long double r75947 = r75933 ? r75944 : r75946;
        return r75947;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r75948, r75949, r75950, r75951, r75952, r75953, r75954, r75955, r75956, r75957, r75958, r75959;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r75948);
        mpfr_init(r75949);
        mpfr_init(r75950);
        mpfr_init(r75951);
        mpfr_init(r75952);
        mpfr_init(r75953);
        mpfr_init(r75954);
        mpfr_init(r75955);
        mpfr_init(r75956);
        mpfr_init(r75957);
        mpfr_init(r75958);
        mpfr_init(r75959);
}

double f_im(float a, float k, float m) {
        mpfr_set_flt(r75948, a, MPFR_RNDN);
        mpfr_set_flt(r75949, k, MPFR_RNDN);
        mpfr_set_flt(r75950, m, MPFR_RNDN);
        mpfr_pow(r75951, r75949, r75950, MPFR_RNDN);
        mpfr_mul(r75952, r75948, r75951, MPFR_RNDN);
        mpfr_init_set_str(r75953, "1", 10, MPFR_RNDN);
        mpfr_init_set_str(r75954, "10", 10, MPFR_RNDN);
        mpfr_mul(r75955, r75954, r75949, MPFR_RNDN);
        mpfr_add(r75956, r75953, r75955, MPFR_RNDN);
        mpfr_mul(r75957, r75949, r75949, MPFR_RNDN);
        mpfr_add(r75958, r75956, r75957, MPFR_RNDN);
        mpfr_div(r75959, r75952, r75958, MPFR_RNDN);
        return mpfr_get_d(r75959, MPFR_RNDN);
}

