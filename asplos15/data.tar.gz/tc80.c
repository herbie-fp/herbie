#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE problem 3.4.2 */

double f_if(float a, float b, float eps) {
        float r80640 = eps;
        float r80641 = a;
        float r80642 = b;
        float r80643 = r80641 + r80642;
        float r80644 = r80643 * r80640;
        float r80645 = exp(r80644);
        float r80646 = 1.0;
        float r80647 = r80645 - r80646;
        float r80648 = r80640 * r80647;
        float r80649 = r80641 * r80640;
        float r80650 = exp(r80649);
        float r80651 = r80650 - r80646;
        float r80652 = r80642 * r80640;
        float r80653 = exp(r80652);
        float r80654 = r80653 - r80646;
        float r80655 = r80651 * r80654;
        float r80656 = r80648 / r80655;
        return r80656;
}

double f_id(float a, float b, float eps) {
        double r80657 = eps;
        double r80658 = a;
        double r80659 = b;
        double r80660 = r80658 + r80659;
        double r80661 = r80660 * r80657;
        double r80662 = exp(r80661);
        double r80663 = 1.0;
        double r80664 = r80662 - r80663;
        double r80665 = r80657 * r80664;
        double r80666 = r80658 * r80657;
        double r80667 = exp(r80666);
        double r80668 = r80667 - r80663;
        double r80669 = r80659 * r80657;
        double r80670 = exp(r80669);
        double r80671 = r80670 - r80663;
        double r80672 = r80668 * r80671;
        double r80673 = r80665 / r80672;
        return r80673;
}

double f_il(float a, float b, float eps) {
        long double r80674 = eps;
        long double r80675 = a;
        long double r80676 = b;
        long double r80677 = r80675 + r80676;
        long double r80678 = r80677 * r80674;
        long double r80679 = exp(r80678);
        long double r80680 = 1.0;
        long double r80681 = r80679 - r80680;
        long double r80682 = r80674 * r80681;
        long double r80683 = r80675 * r80674;
        long double r80684 = exp(r80683);
        long double r80685 = r80684 - r80680;
        long double r80686 = r80676 * r80674;
        long double r80687 = exp(r80686);
        long double r80688 = r80687 - r80680;
        long double r80689 = r80685 * r80688;
        long double r80690 = r80682 / r80689;
        return r80690;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a, float b, float eps) {
        float r80691 = eps;
        float r80692 = a;
        float r80693 = b;
        float r80694 = r80692 + r80693;
        float r80695 = r80694 * r80691;
        float r80696 = exp(r80695);
        float r80697 = r80696 * r80696;
        float r80698 = 1.0;
        float r80699 = r80698 * r80698;
        float r80700 = r80697 - r80699;
        float r80701 = r80696 + r80698;
        float r80702 = sqrt(r80701);
        float r80703 = r80702 * r80702;
        float r80704 = r80700 / r80703;
        float r80705 = r80691 * r80704;
        float r80706 = r80692 * r80691;
        float r80707 = exp(r80706);
        float r80708 = r80707 - r80698;
        float r80709 = r80693 * r80691;
        float r80710 = exp(r80709);
        float r80711 = r80710 - r80698;
        float r80712 = r80708 * r80711;
        float r80713 = r80705 / r80712;
        return r80713;
}

double f_od(float a, float b, float eps) {
        double r80714 = eps;
        double r80715 = a;
        double r80716 = b;
        double r80717 = r80715 + r80716;
        double r80718 = r80717 * r80714;
        double r80719 = exp(r80718);
        double r80720 = r80719 * r80719;
        double r80721 = 1.0;
        double r80722 = r80721 * r80721;
        double r80723 = r80720 - r80722;
        double r80724 = r80719 + r80721;
        double r80725 = sqrt(r80724);
        double r80726 = r80725 * r80725;
        double r80727 = r80723 / r80726;
        double r80728 = r80714 * r80727;
        double r80729 = r80715 * r80714;
        double r80730 = exp(r80729);
        double r80731 = r80730 - r80721;
        double r80732 = r80716 * r80714;
        double r80733 = exp(r80732);
        double r80734 = r80733 - r80721;
        double r80735 = r80731 * r80734;
        double r80736 = r80728 / r80735;
        return r80736;
}

double f_ol(float a, float b, float eps) {
        long double r80737 = eps;
        long double r80738 = a;
        long double r80739 = b;
        long double r80740 = r80738 + r80739;
        long double r80741 = r80740 * r80737;
        long double r80742 = exp(r80741);
        long double r80743 = r80742 * r80742;
        long double r80744 = 1.0;
        long double r80745 = r80744 * r80744;
        long double r80746 = r80743 - r80745;
        long double r80747 = r80742 + r80744;
        long double r80748 = sqrt(r80747);
        long double r80749 = r80748 * r80748;
        long double r80750 = r80746 / r80749;
        long double r80751 = r80737 * r80750;
        long double r80752 = r80738 * r80737;
        long double r80753 = exp(r80752);
        long double r80754 = r80753 - r80744;
        long double r80755 = r80739 * r80737;
        long double r80756 = exp(r80755);
        long double r80757 = r80756 - r80744;
        long double r80758 = r80754 * r80757;
        long double r80759 = r80751 / r80758;
        return r80759;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r80760, r80761, r80762, r80763, r80764, r80765, r80766, r80767, r80768, r80769, r80770, r80771, r80772, r80773, r80774, r80775, r80776;

void setup_mpfr() {
        mpfr_set_default_prec(312);
        mpfr_init(r80760);
        mpfr_init(r80761);
        mpfr_init(r80762);
        mpfr_init(r80763);
        mpfr_init(r80764);
        mpfr_init(r80765);
        mpfr_init(r80766);
        mpfr_init(r80767);
        mpfr_init(r80768);
        mpfr_init(r80769);
        mpfr_init(r80770);
        mpfr_init(r80771);
        mpfr_init(r80772);
        mpfr_init(r80773);
        mpfr_init(r80774);
        mpfr_init(r80775);
        mpfr_init(r80776);
}

double f_im(float a, float b, float eps) {
        mpfr_set_flt(r80760, eps, MPFR_RNDN);
        mpfr_set_flt(r80761, a, MPFR_RNDN);
        mpfr_set_flt(r80762, b, MPFR_RNDN);
        mpfr_add(r80763, r80761, r80762, MPFR_RNDN);
        mpfr_mul(r80764, r80763, r80760, MPFR_RNDN);
        mpfr_exp(r80765, r80764, MPFR_RNDN);
        mpfr_init_set_str(r80766, "1", 10, MPFR_RNDN);
        mpfr_sub(r80767, r80765, r80766, MPFR_RNDN);
        mpfr_mul(r80768, r80760, r80767, MPFR_RNDN);
        mpfr_mul(r80769, r80761, r80760, MPFR_RNDN);
        mpfr_exp(r80770, r80769, MPFR_RNDN);
        mpfr_sub(r80771, r80770, r80766, MPFR_RNDN);
        mpfr_mul(r80772, r80762, r80760, MPFR_RNDN);
        mpfr_exp(r80773, r80772, MPFR_RNDN);
        mpfr_sub(r80774, r80773, r80766, MPFR_RNDN);
        mpfr_mul(r80775, r80771, r80774, MPFR_RNDN);
        mpfr_div(r80776, r80768, r80775, MPFR_RNDN);
        return mpfr_get_d(r80776, MPFR_RNDN);
}

