#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Jmat.Real.erfi, branch x <= 0.5 */

double f_if(float x) {
        float r78141 = 1.0;
        float r78142 = atan2(1.0, 0.0);
        float r78143 = sqrt(r78142);
        float r78144 = r78141 / r78143;
        float r78145 = 2.0;
        float r78146 = x;
        float r78147 = r78145 * r78146;
        float r78148 = 3.0;
        float r78149 = r78145 / r78148;
        float r78150 = r78146 * r78146;
        float r78151 = r78150 * r78146;
        float r78152 = r78149 * r78151;
        float r78153 = r78147 + r78152;
        float r78154 = 5.0;
        float r78155 = r78141 / r78154;
        float r78156 = r78151 * r78146;
        float r78157 = r78156 * r78146;
        float r78158 = r78155 * r78157;
        float r78159 = r78153 + r78158;
        float r78160 = 21.0;
        float r78161 = r78141 / r78160;
        float r78162 = r78157 * r78146;
        float r78163 = r78162 * r78146;
        float r78164 = r78161 * r78163;
        float r78165 = r78159 + r78164;
        float r78166 = r78144 * r78165;
        return r78166;
}

double f_id(float x) {
        double r78167 = 1.0;
        double r78168 = atan2(1.0, 0.0);
        double r78169 = sqrt(r78168);
        double r78170 = r78167 / r78169;
        double r78171 = 2.0;
        double r78172 = x;
        double r78173 = r78171 * r78172;
        double r78174 = 3.0;
        double r78175 = r78171 / r78174;
        double r78176 = r78172 * r78172;
        double r78177 = r78176 * r78172;
        double r78178 = r78175 * r78177;
        double r78179 = r78173 + r78178;
        double r78180 = 5.0;
        double r78181 = r78167 / r78180;
        double r78182 = r78177 * r78172;
        double r78183 = r78182 * r78172;
        double r78184 = r78181 * r78183;
        double r78185 = r78179 + r78184;
        double r78186 = 21.0;
        double r78187 = r78167 / r78186;
        double r78188 = r78183 * r78172;
        double r78189 = r78188 * r78172;
        double r78190 = r78187 * r78189;
        double r78191 = r78185 + r78190;
        double r78192 = r78170 * r78191;
        return r78192;
}

double f_il(float x) {
        long double r78193 = 1.0;
        long double r78194 = atan2(1.0, 0.0);
        long double r78195 = sqrt(r78194);
        long double r78196 = r78193 / r78195;
        long double r78197 = 2.0;
        long double r78198 = x;
        long double r78199 = r78197 * r78198;
        long double r78200 = 3.0;
        long double r78201 = r78197 / r78200;
        long double r78202 = r78198 * r78198;
        long double r78203 = r78202 * r78198;
        long double r78204 = r78201 * r78203;
        long double r78205 = r78199 + r78204;
        long double r78206 = 5.0;
        long double r78207 = r78193 / r78206;
        long double r78208 = r78203 * r78198;
        long double r78209 = r78208 * r78198;
        long double r78210 = r78207 * r78209;
        long double r78211 = r78205 + r78210;
        long double r78212 = 21.0;
        long double r78213 = r78193 / r78212;
        long double r78214 = r78209 * r78198;
        long double r78215 = r78214 * r78198;
        long double r78216 = r78213 * r78215;
        long double r78217 = r78211 + r78216;
        long double r78218 = r78196 * r78217;
        return r78218;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r78219 = 1.0;
        float r78220 = atan2(1.0, 0.0);
        float r78221 = sqrt(r78220);
        float r78222 = r78219 / r78221;
        float r78223 = 2.0;
        float r78224 = x;
        float r78225 = r78223 * r78224;
        float r78226 = 3.0;
        float r78227 = r78223 / r78226;
        float r78228 = r78224 * r78224;
        float r78229 = r78228 * r78224;
        float r78230 = r78227 * r78229;
        float r78231 = r78225 + r78230;
        float r78232 = 5.0;
        float r78233 = r78219 / r78232;
        float r78234 = r78229 * r78224;
        float r78235 = r78234 * r78224;
        float r78236 = r78233 * r78235;
        float r78237 = r78231 + r78236;
        float r78238 = 21.0;
        float r78239 = r78219 / r78238;
        float r78240 = r78239 * r78234;
        float r78241 = r78240 * r78224;
        float r78242 = r78241 * r78224;
        float r78243 = r78242 * r78224;
        float r78244 = r78237 + r78243;
        float r78245 = r78222 * r78244;
        return r78245;
}

double f_od(float x) {
        double r78246 = 1.0;
        double r78247 = atan2(1.0, 0.0);
        double r78248 = sqrt(r78247);
        double r78249 = r78246 / r78248;
        double r78250 = 2.0;
        double r78251 = x;
        double r78252 = r78250 * r78251;
        double r78253 = 3.0;
        double r78254 = r78250 / r78253;
        double r78255 = r78251 * r78251;
        double r78256 = r78255 * r78251;
        double r78257 = r78254 * r78256;
        double r78258 = r78252 + r78257;
        double r78259 = 5.0;
        double r78260 = r78246 / r78259;
        double r78261 = r78256 * r78251;
        double r78262 = r78261 * r78251;
        double r78263 = r78260 * r78262;
        double r78264 = r78258 + r78263;
        double r78265 = 21.0;
        double r78266 = r78246 / r78265;
        double r78267 = r78266 * r78261;
        double r78268 = r78267 * r78251;
        double r78269 = r78268 * r78251;
        double r78270 = r78269 * r78251;
        double r78271 = r78264 + r78270;
        double r78272 = r78249 * r78271;
        return r78272;
}

double f_ol(float x) {
        long double r78273 = 1.0;
        long double r78274 = atan2(1.0, 0.0);
        long double r78275 = sqrt(r78274);
        long double r78276 = r78273 / r78275;
        long double r78277 = 2.0;
        long double r78278 = x;
        long double r78279 = r78277 * r78278;
        long double r78280 = 3.0;
        long double r78281 = r78277 / r78280;
        long double r78282 = r78278 * r78278;
        long double r78283 = r78282 * r78278;
        long double r78284 = r78281 * r78283;
        long double r78285 = r78279 + r78284;
        long double r78286 = 5.0;
        long double r78287 = r78273 / r78286;
        long double r78288 = r78283 * r78278;
        long double r78289 = r78288 * r78278;
        long double r78290 = r78287 * r78289;
        long double r78291 = r78285 + r78290;
        long double r78292 = 21.0;
        long double r78293 = r78273 / r78292;
        long double r78294 = r78293 * r78288;
        long double r78295 = r78294 * r78278;
        long double r78296 = r78295 * r78278;
        long double r78297 = r78296 * r78278;
        long double r78298 = r78291 + r78297;
        long double r78299 = r78276 * r78298;
        return r78299;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r78300, r78301, r78302, r78303, r78304, r78305, r78306, r78307, r78308, r78309, r78310, r78311, r78312, r78313, r78314, r78315, r78316, r78317, r78318, r78319, r78320, r78321, r78322, r78323, r78324, r78325;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r78300);
        mpfr_init(r78301);
        mpfr_init(r78302);
        mpfr_init(r78303);
        mpfr_init(r78304);
        mpfr_init(r78305);
        mpfr_init(r78306);
        mpfr_init(r78307);
        mpfr_init(r78308);
        mpfr_init(r78309);
        mpfr_init(r78310);
        mpfr_init(r78311);
        mpfr_init(r78312);
        mpfr_init(r78313);
        mpfr_init(r78314);
        mpfr_init(r78315);
        mpfr_init(r78316);
        mpfr_init(r78317);
        mpfr_init(r78318);
        mpfr_init(r78319);
        mpfr_init(r78320);
        mpfr_init(r78321);
        mpfr_init(r78322);
        mpfr_init(r78323);
        mpfr_init(r78324);
        mpfr_init(r78325);
}

double f_im(float x) {
        mpfr_init_set_str(r78300, "1", 10, MPFR_RNDN);
        mpfr_const_pi(r78301, MPFR_RNDN);
        mpfr_sqrt(r78302, r78301, MPFR_RNDN);
        mpfr_div(r78303, r78300, r78302, MPFR_RNDN);
        mpfr_init_set_str(r78304, "2", 10, MPFR_RNDN);
        mpfr_set_flt(r78305, x, MPFR_RNDN);
        mpfr_mul(r78306, r78304, r78305, MPFR_RNDN);
        mpfr_init_set_str(r78307, "3", 10, MPFR_RNDN);
        mpfr_div(r78308, r78304, r78307, MPFR_RNDN);
        mpfr_mul(r78309, r78305, r78305, MPFR_RNDN);
        mpfr_mul(r78310, r78309, r78305, MPFR_RNDN);
        mpfr_mul(r78311, r78308, r78310, MPFR_RNDN);
        mpfr_add(r78312, r78306, r78311, MPFR_RNDN);
        mpfr_init_set_str(r78313, "5", 10, MPFR_RNDN);
        mpfr_div(r78314, r78300, r78313, MPFR_RNDN);
        mpfr_mul(r78315, r78310, r78305, MPFR_RNDN);
        mpfr_mul(r78316, r78315, r78305, MPFR_RNDN);
        mpfr_mul(r78317, r78314, r78316, MPFR_RNDN);
        mpfr_add(r78318, r78312, r78317, MPFR_RNDN);
        mpfr_init_set_str(r78319, "21", 10, MPFR_RNDN);
        mpfr_div(r78320, r78300, r78319, MPFR_RNDN);
        mpfr_mul(r78321, r78316, r78305, MPFR_RNDN);
        mpfr_mul(r78322, r78321, r78305, MPFR_RNDN);
        mpfr_mul(r78323, r78320, r78322, MPFR_RNDN);
        mpfr_add(r78324, r78318, r78323, MPFR_RNDN);
        mpfr_mul(r78325, r78303, r78324, MPFR_RNDN);
        return mpfr_get_d(r78325, MPFR_RNDN);
}

