#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Associate */

double f_if(float x) {
        float r72357 = 1.0;
        float r72358 = x;
        float r72359 = r72357 + r72358;
        float r72360 = r72359 - r72358;
        return r72360;
}

double f_id(float x) {
        double r72361 = 1.0;
        double r72362 = x;
        double r72363 = r72361 + r72362;
        double r72364 = r72363 - r72362;
        return r72364;
}

double f_il(float x) {
        long double r72365 = 1.0;
        long double r72366 = x;
        long double r72367 = r72365 + r72366;
        long double r72368 = r72367 - r72366;
        return r72368;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r72369 = 1.0;
        return r72369;
}

double f_od(float x) {
        double r72370 = 1.0;
        return r72370;
}

double f_ol(float x) {
        long double r72371 = 1.0;
        return r72371;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r72372, r72373, r72374, r72375;

void setup_mpfr() {
        mpfr_set_default_prec(152);
        mpfr_init(r72372);
        mpfr_init(r72373);
        mpfr_init(r72374);
        mpfr_init(r72375);
}

double f_im(float x) {
        mpfr_init_set_str(r72372, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r72373, x, MPFR_RNDN);
        mpfr_add(r72374, r72372, r72373, MPFR_RNDN);
        mpfr_sub(r72375, r72374, r72373, MPFR_RNDN);
        return mpfr_get_d(r72375, MPFR_RNDN);
}

