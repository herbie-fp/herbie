#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.sqrt on complex, imaginary part, im > 0 branch */

double f_if(float re, float im) {
        float r86179 = 0.5;
        float r86180 = 2.0;
        float r86181 = re;
        float r86182 = r86181 * r86181;
        float r86183 = im;
        float r86184 = r86183 * r86183;
        float r86185 = r86182 - r86184;
        float r86186 = sqrt(r86185);
        float r86187 = r86186 + r86181;
        float r86188 = r86180 * r86187;
        float r86189 = sqrt(r86188);
        float r86190 = r86179 * r86189;
        return r86190;
}

double f_id(float re, float im) {
        double r86191 = 0.5;
        double r86192 = 2.0;
        double r86193 = re;
        double r86194 = r86193 * r86193;
        double r86195 = im;
        double r86196 = r86195 * r86195;
        double r86197 = r86194 - r86196;
        double r86198 = sqrt(r86197);
        double r86199 = r86198 + r86193;
        double r86200 = r86192 * r86199;
        double r86201 = sqrt(r86200);
        double r86202 = r86191 * r86201;
        return r86202;
}

double f_il(float re, float im) {
        long double r86203 = 0.5;
        long double r86204 = 2.0;
        long double r86205 = re;
        long double r86206 = r86205 * r86205;
        long double r86207 = im;
        long double r86208 = r86207 * r86207;
        long double r86209 = r86206 - r86208;
        long double r86210 = sqrt(r86209);
        long double r86211 = r86210 + r86205;
        long double r86212 = r86204 * r86211;
        long double r86213 = sqrt(r86212);
        long double r86214 = r86203 * r86213;
        return r86214;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r86215 = 0.5;
        float r86216 = 2.0;
        float r86217 = re;
        float r86218 = r86217 * r86217;
        float r86219 = im;
        float r86220 = r86219 * r86219;
        float r86221 = r86218 - r86220;
        float r86222 = sqrt(r86221);
        float r86223 = r86222 + r86217;
        float r86224 = r86216 * r86223;
        float r86225 = sqrt(r86224);
        float r86226 = r86215 * r86225;
        return r86226;
}

double f_od(float re, float im) {
        double r86227 = 0.5;
        double r86228 = 2.0;
        double r86229 = re;
        double r86230 = r86229 * r86229;
        double r86231 = im;
        double r86232 = r86231 * r86231;
        double r86233 = r86230 - r86232;
        double r86234 = sqrt(r86233);
        double r86235 = r86234 + r86229;
        double r86236 = r86228 * r86235;
        double r86237 = sqrt(r86236);
        double r86238 = r86227 * r86237;
        return r86238;
}

double f_ol(float re, float im) {
        long double r86239 = 0.5;
        long double r86240 = 2.0;
        long double r86241 = re;
        long double r86242 = r86241 * r86241;
        long double r86243 = im;
        long double r86244 = r86243 * r86243;
        long double r86245 = r86242 - r86244;
        long double r86246 = sqrt(r86245);
        long double r86247 = r86246 + r86241;
        long double r86248 = r86240 * r86247;
        long double r86249 = sqrt(r86248);
        long double r86250 = r86239 * r86249;
        return r86250;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r86251, r86252, r86253, r86254, r86255, r86256, r86257, r86258, r86259, r86260, r86261, r86262;

void setup_mpfr() {
        mpfr_set_default_prec(520);
        mpfr_init(r86251);
        mpfr_init(r86252);
        mpfr_init(r86253);
        mpfr_init(r86254);
        mpfr_init(r86255);
        mpfr_init(r86256);
        mpfr_init(r86257);
        mpfr_init(r86258);
        mpfr_init(r86259);
        mpfr_init(r86260);
        mpfr_init(r86261);
        mpfr_init(r86262);
}

double f_im(float re, float im) {
        mpfr_init_set_str(r86251, "0.5", 10, MPFR_RNDN);
        mpfr_init_set_str(r86252, "2.0", 10, MPFR_RNDN);
        mpfr_set_flt(r86253, re, MPFR_RNDN);
        mpfr_mul(r86254, r86253, r86253, MPFR_RNDN);
        mpfr_set_flt(r86255, im, MPFR_RNDN);
        mpfr_mul(r86256, r86255, r86255, MPFR_RNDN);
        mpfr_sub(r86257, r86254, r86256, MPFR_RNDN);
        mpfr_sqrt(r86258, r86257, MPFR_RNDN);
        mpfr_add(r86259, r86258, r86253, MPFR_RNDN);
        mpfr_mul(r86260, r86252, r86259, MPFR_RNDN);
        mpfr_sqrt(r86261, r86260, MPFR_RNDN);
        mpfr_mul(r86262, r86251, r86261, MPFR_RNDN);
        return mpfr_get_d(r86262, MPFR_RNDN);
}

