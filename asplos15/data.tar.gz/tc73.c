#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Migdal et al, Equation (64) */

double f_if(float a1, float a2, float th) {
        float r79929 = th;
        float r79930 = cos(r79929);
        float r79931 = 2.0;
        float r79932 = sqrt(r79931);
        float r79933 = r79930 / r79932;
        float r79934 = a1;
        float r79935 = r79934 * r79934;
        float r79936 = r79933 * r79935;
        float r79937 = a2;
        float r79938 = r79937 * r79937;
        float r79939 = r79933 * r79938;
        float r79940 = r79936 + r79939;
        return r79940;
}

double f_id(float a1, float a2, float th) {
        double r79941 = th;
        double r79942 = cos(r79941);
        double r79943 = 2.0;
        double r79944 = sqrt(r79943);
        double r79945 = r79942 / r79944;
        double r79946 = a1;
        double r79947 = r79946 * r79946;
        double r79948 = r79945 * r79947;
        double r79949 = a2;
        double r79950 = r79949 * r79949;
        double r79951 = r79945 * r79950;
        double r79952 = r79948 + r79951;
        return r79952;
}

double f_il(float a1, float a2, float th) {
        long double r79953 = th;
        long double r79954 = cos(r79953);
        long double r79955 = 2.0;
        long double r79956 = sqrt(r79955);
        long double r79957 = r79954 / r79956;
        long double r79958 = a1;
        long double r79959 = r79958 * r79958;
        long double r79960 = r79957 * r79959;
        long double r79961 = a2;
        long double r79962 = r79961 * r79961;
        long double r79963 = r79957 * r79962;
        long double r79964 = r79960 + r79963;
        return r79964;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float a1, float a2, float th) {
        float r79965 = a1;
        float r79966 = -6.750405079007289e+21;
        bool r79967 = r79965 < r79966;
        float r79968 = th;
        float r79969 = cos(r79968);
        float r79970 = 0.7071067811865475;
        float r79971 = r79969 * r79970;
        float r79972 = r79965 * r79965;
        float r79973 = r79971 * r79972;
        float r79974 = a2;
        float r79975 = r79971 * r79974;
        float r79976 = r79975 * r79974;
        float r79977 = r79973 + r79976;
        float r79978 = 1.9369065289255582e-36;
        bool r79979 = r79965 < r79978;
        float r79980 = r79971 * r79965;
        float r79981 = r79980 * r79965;
        float r79982 = r79981 + r79976;
        float r79983 = 0.029848584963227114;
        bool r79984 = r79965 < r79983;
        float r79985 = sqrt(r79965);
        float r79986 = r79985 * r79985;
        float r79987 = r79971 * r79986;
        float r79988 = r79987 * r79965;
        float r79989 = r79974 * r79974;
        float r79990 = r79971 * r79989;
        float r79991 = r79988 + r79990;
        float r79992 = r79984 ? r79991 : r79977;
        float r79993 = r79979 ? r79982 : r79992;
        float r79994 = r79967 ? r79977 : r79993;
        return r79994;
}

double f_od(float a1, float a2, float th) {
        double r79995 = a1;
        double r79996 = -6.750405079007289e+21;
        bool r79997 = r79995 < r79996;
        double r79998 = th;
        double r79999 = cos(r79998);
        double r80000 = 0.7071067811865475;
        double r80001 = r79999 * r80000;
        double r80002 = r79995 * r79995;
        double r80003 = r80001 * r80002;
        double r80004 = a2;
        double r80005 = r80001 * r80004;
        double r80006 = r80005 * r80004;
        double r80007 = r80003 + r80006;
        double r80008 = 1.9369065289255582e-36;
        bool r80009 = r79995 < r80008;
        double r80010 = r80001 * r79995;
        double r80011 = r80010 * r79995;
        double r80012 = r80011 + r80006;
        double r80013 = 0.029848584963227114;
        bool r80014 = r79995 < r80013;
        double r80015 = sqrt(r79995);
        double r80016 = r80015 * r80015;
        double r80017 = r80001 * r80016;
        double r80018 = r80017 * r79995;
        double r80019 = r80004 * r80004;
        double r80020 = r80001 * r80019;
        double r80021 = r80018 + r80020;
        double r80022 = r80014 ? r80021 : r80007;
        double r80023 = r80009 ? r80012 : r80022;
        double r80024 = r79997 ? r80007 : r80023;
        return r80024;
}

double f_ol(float a1, float a2, float th) {
        long double r80025 = a1;
        long double r80026 = -6.750405079007289e+21;
        bool r80027 = r80025 < r80026;
        long double r80028 = th;
        long double r80029 = cos(r80028);
        long double r80030 = 0.7071067811865475;
        long double r80031 = r80029 * r80030;
        long double r80032 = r80025 * r80025;
        long double r80033 = r80031 * r80032;
        long double r80034 = a2;
        long double r80035 = r80031 * r80034;
        long double r80036 = r80035 * r80034;
        long double r80037 = r80033 + r80036;
        long double r80038 = 1.9369065289255582e-36;
        bool r80039 = r80025 < r80038;
        long double r80040 = r80031 * r80025;
        long double r80041 = r80040 * r80025;
        long double r80042 = r80041 + r80036;
        long double r80043 = 0.029848584963227114;
        bool r80044 = r80025 < r80043;
        long double r80045 = sqrt(r80025);
        long double r80046 = r80045 * r80045;
        long double r80047 = r80031 * r80046;
        long double r80048 = r80047 * r80025;
        long double r80049 = r80034 * r80034;
        long double r80050 = r80031 * r80049;
        long double r80051 = r80048 + r80050;
        long double r80052 = r80044 ? r80051 : r80037;
        long double r80053 = r80039 ? r80042 : r80052;
        long double r80054 = r80027 ? r80037 : r80053;
        return r80054;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r80055, r80056, r80057, r80058, r80059, r80060, r80061, r80062, r80063, r80064, r80065, r80066;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r80055);
        mpfr_init(r80056);
        mpfr_init(r80057);
        mpfr_init(r80058);
        mpfr_init(r80059);
        mpfr_init(r80060);
        mpfr_init(r80061);
        mpfr_init(r80062);
        mpfr_init(r80063);
        mpfr_init(r80064);
        mpfr_init(r80065);
        mpfr_init(r80066);
}

double f_im(float a1, float a2, float th) {
        mpfr_set_flt(r80055, th, MPFR_RNDN);
        mpfr_cos(r80056, r80055, MPFR_RNDN);
        mpfr_init_set_str(r80057, "2", 10, MPFR_RNDN);
        mpfr_sqrt(r80058, r80057, MPFR_RNDN);
        mpfr_div(r80059, r80056, r80058, MPFR_RNDN);
        mpfr_set_flt(r80060, a1, MPFR_RNDN);
        mpfr_mul(r80061, r80060, r80060, MPFR_RNDN);
        mpfr_mul(r80062, r80059, r80061, MPFR_RNDN);
        mpfr_set_flt(r80063, a2, MPFR_RNDN);
        mpfr_mul(r80064, r80063, r80063, MPFR_RNDN);
        mpfr_mul(r80065, r80059, r80064, MPFR_RNDN);
        mpfr_add(r80066, r80062, r80065, MPFR_RNDN);
        return mpfr_get_d(r80066, MPFR_RNDN);
}

