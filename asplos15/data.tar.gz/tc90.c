#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Rosa's Benchmark */

double f_if(float x) {
        float r81851 = 0.954929658551372;
        float r81852 = x;
        float r81853 = r81851 * r81852;
        float r81854 = 0.12900613773279798;
        float r81855 = r81852 * r81852;
        float r81856 = r81855 * r81852;
        float r81857 = r81854 * r81856;
        float r81858 = r81853 - r81857;
        return r81858;
}

double f_id(float x) {
        double r81859 = 0.954929658551372;
        double r81860 = x;
        double r81861 = r81859 * r81860;
        double r81862 = 0.12900613773279798;
        double r81863 = r81860 * r81860;
        double r81864 = r81863 * r81860;
        double r81865 = r81862 * r81864;
        double r81866 = r81861 - r81865;
        return r81866;
}

double f_il(float x) {
        long double r81867 = 0.954929658551372;
        long double r81868 = x;
        long double r81869 = r81867 * r81868;
        long double r81870 = 0.12900613773279798;
        long double r81871 = r81868 * r81868;
        long double r81872 = r81871 * r81868;
        long double r81873 = r81870 * r81872;
        long double r81874 = r81869 - r81873;
        return r81874;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r81875 = 0.954929658551372;
        float r81876 = x;
        float r81877 = r81875 * r81876;
        float r81878 = 0.12900613773279798;
        float r81879 = 2.0;
        float r81880 = 1.0;
        float r81881 = r81879 + r81880;
        float r81882 = pow(r81876, r81881);
        float r81883 = r81878 * r81882;
        float r81884 = r81877 - r81883;
        return r81884;
}

double f_od(float x) {
        double r81885 = 0.954929658551372;
        double r81886 = x;
        double r81887 = r81885 * r81886;
        double r81888 = 0.12900613773279798;
        double r81889 = 2.0;
        double r81890 = 1.0;
        double r81891 = r81889 + r81890;
        double r81892 = pow(r81886, r81891);
        double r81893 = r81888 * r81892;
        double r81894 = r81887 - r81893;
        return r81894;
}

double f_ol(float x) {
        long double r81895 = 0.954929658551372;
        long double r81896 = x;
        long double r81897 = r81895 * r81896;
        long double r81898 = 0.12900613773279798;
        long double r81899 = 2.0;
        long double r81900 = 1.0;
        long double r81901 = r81899 + r81900;
        long double r81902 = pow(r81896, r81901);
        long double r81903 = r81898 * r81902;
        long double r81904 = r81897 - r81903;
        return r81904;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r81905, r81906, r81907, r81908, r81909, r81910, r81911, r81912;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r81905);
        mpfr_init(r81906);
        mpfr_init(r81907);
        mpfr_init(r81908);
        mpfr_init(r81909);
        mpfr_init(r81910);
        mpfr_init(r81911);
        mpfr_init(r81912);
}

double f_im(float x) {
        mpfr_init_set_str(r81905, "0.954929658551372", 10, MPFR_RNDN);
        mpfr_set_flt(r81906, x, MPFR_RNDN);
        mpfr_mul(r81907, r81905, r81906, MPFR_RNDN);
        mpfr_init_set_str(r81908, "0.12900613773279798", 10, MPFR_RNDN);
        mpfr_mul(r81909, r81906, r81906, MPFR_RNDN);
        mpfr_mul(r81910, r81909, r81906, MPFR_RNDN);
        mpfr_mul(r81911, r81908, r81910, MPFR_RNDN);
        mpfr_sub(r81912, r81907, r81911, MPFR_RNDN);
        return mpfr_get_d(r81912, MPFR_RNDN);
}

