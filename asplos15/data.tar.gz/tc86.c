#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Octave 3.8, jcobi/2 */

double f_if(float alpha, float beta, float i) {
        float r81106 = alpha;
        float r81107 = beta;
        float r81108 = r81106 + r81107;
        float r81109 = r81107 - r81106;
        float r81110 = r81108 * r81109;
        float r81111 = 2.0;
        float r81112 = i;
        float r81113 = r81111 * r81112;
        float r81114 = r81108 + r81113;
        float r81115 = r81110 / r81114;
        float r81116 = 2.0;
        float r81117 = r81114 + r81116;
        float r81118 = r81115 / r81117;
        float r81119 = 1.0;
        float r81120 = r81118 + r81119;
        float r81121 = r81120 / r81116;
        return r81121;
}

double f_id(float alpha, float beta, float i) {
        double r81122 = alpha;
        double r81123 = beta;
        double r81124 = r81122 + r81123;
        double r81125 = r81123 - r81122;
        double r81126 = r81124 * r81125;
        double r81127 = 2.0;
        double r81128 = i;
        double r81129 = r81127 * r81128;
        double r81130 = r81124 + r81129;
        double r81131 = r81126 / r81130;
        double r81132 = 2.0;
        double r81133 = r81130 + r81132;
        double r81134 = r81131 / r81133;
        double r81135 = 1.0;
        double r81136 = r81134 + r81135;
        double r81137 = r81136 / r81132;
        return r81137;
}

double f_il(float alpha, float beta, float i) {
        long double r81138 = alpha;
        long double r81139 = beta;
        long double r81140 = r81138 + r81139;
        long double r81141 = r81139 - r81138;
        long double r81142 = r81140 * r81141;
        long double r81143 = 2.0;
        long double r81144 = i;
        long double r81145 = r81143 * r81144;
        long double r81146 = r81140 + r81145;
        long double r81147 = r81142 / r81146;
        long double r81148 = 2.0;
        long double r81149 = r81146 + r81148;
        long double r81150 = r81147 / r81149;
        long double r81151 = 1.0;
        long double r81152 = r81150 + r81151;
        long double r81153 = r81152 / r81148;
        return r81153;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float alpha, float beta, float i) {
        float r81154 = alpha;
        float r81155 = -5.603834303824399e+21;
        bool r81156 = r81154 < r81155;
        float r81157 = beta;
        float r81158 = r81154 + r81157;
        float r81159 = r81157 - r81154;
        float r81160 = r81158 * r81159;
        float r81161 = 2.0;
        float r81162 = i;
        float r81163 = r81161 * r81162;
        float r81164 = r81158 + r81163;
        float r81165 = r81160 / r81164;
        float r81166 = 2.0;
        float r81167 = r81164 + r81166;
        float r81168 = r81165 / r81167;
        float r81169 = 1.0;
        float r81170 = r81168 + r81169;
        float r81171 = exp(r81170);
        float r81172 = log(r81171);
        float r81173 = r81172 / r81166;
        float r81174 = -4.294236635768253e+16;
        bool r81175 = r81154 < r81174;
        float r81176 = 126797.82172630695;
        bool r81177 = r81157 < r81176;
        float r81178 = r81157 * r81157;
        float r81179 = r81178 * r81178;
        float r81180 = r81154 * r81154;
        float r81181 = r81180 * r81180;
        float r81182 = r81179 - r81181;
        float r81183 = r81178 + r81180;
        float r81184 = r81182 / r81183;
        float r81185 = r81164 * r81167;
        float r81186 = 1.0/r81185;
        float r81187 = r81184 * r81186;
        float r81188 = r81187 + r81169;
        float r81189 = r81188 / r81166;
        float r81190 = r81178 - r81180;
        float r81191 = r81183 * r81190;
        float r81192 = r81191 / r81183;
        float r81193 = 1.0/r81164;
        float r81194 = 1.0/r81167;
        float r81195 = r81193 * r81194;
        float r81196 = r81192 * r81195;
        float r81197 = r81196 + r81169;
        float r81198 = r81197 / r81166;
        float r81199 = r81177 ? r81189 : r81198;
        float r81200 = 3205281498.5237923;
        bool r81201 = r81154 < r81200;
        float r81202 = 1.0;
        float r81203 = r81167 / r81165;
        float r81204 = r81202 / r81203;
        float r81205 = r81204 + r81169;
        float r81206 = r81205 / r81166;
        float r81207 = 3.832151875870275e+23;
        bool r81208 = r81154 < r81207;
        float r81209 = exp(r81168);
        float r81210 = log(r81209);
        float r81211 = r81210 + r81169;
        float r81212 = r81211 / r81166;
        float r81213 = sqrt(r81194);
        float r81214 = r81213 * r81213;
        float r81215 = r81165 * r81214;
        float r81216 = r81215 + r81169;
        float r81217 = r81216 / r81166;
        float r81218 = r81208 ? r81212 : r81217;
        float r81219 = r81201 ? r81206 : r81218;
        float r81220 = r81175 ? r81199 : r81219;
        float r81221 = r81156 ? r81173 : r81220;
        return r81221;
}

double f_od(float alpha, float beta, float i) {
        double r81222 = alpha;
        double r81223 = -5.603834303824399e+21;
        bool r81224 = r81222 < r81223;
        double r81225 = beta;
        double r81226 = r81222 + r81225;
        double r81227 = r81225 - r81222;
        double r81228 = r81226 * r81227;
        double r81229 = 2.0;
        double r81230 = i;
        double r81231 = r81229 * r81230;
        double r81232 = r81226 + r81231;
        double r81233 = r81228 / r81232;
        double r81234 = 2.0;
        double r81235 = r81232 + r81234;
        double r81236 = r81233 / r81235;
        double r81237 = 1.0;
        double r81238 = r81236 + r81237;
        double r81239 = exp(r81238);
        double r81240 = log(r81239);
        double r81241 = r81240 / r81234;
        double r81242 = -4.294236635768253e+16;
        bool r81243 = r81222 < r81242;
        double r81244 = 126797.82172630695;
        bool r81245 = r81225 < r81244;
        double r81246 = r81225 * r81225;
        double r81247 = r81246 * r81246;
        double r81248 = r81222 * r81222;
        double r81249 = r81248 * r81248;
        double r81250 = r81247 - r81249;
        double r81251 = r81246 + r81248;
        double r81252 = r81250 / r81251;
        double r81253 = r81232 * r81235;
        double r81254 = 1.0/r81253;
        double r81255 = r81252 * r81254;
        double r81256 = r81255 + r81237;
        double r81257 = r81256 / r81234;
        double r81258 = r81246 - r81248;
        double r81259 = r81251 * r81258;
        double r81260 = r81259 / r81251;
        double r81261 = 1.0/r81232;
        double r81262 = 1.0/r81235;
        double r81263 = r81261 * r81262;
        double r81264 = r81260 * r81263;
        double r81265 = r81264 + r81237;
        double r81266 = r81265 / r81234;
        double r81267 = r81245 ? r81257 : r81266;
        double r81268 = 3205281498.5237923;
        bool r81269 = r81222 < r81268;
        double r81270 = 1.0;
        double r81271 = r81235 / r81233;
        double r81272 = r81270 / r81271;
        double r81273 = r81272 + r81237;
        double r81274 = r81273 / r81234;
        double r81275 = 3.832151875870275e+23;
        bool r81276 = r81222 < r81275;
        double r81277 = exp(r81236);
        double r81278 = log(r81277);
        double r81279 = r81278 + r81237;
        double r81280 = r81279 / r81234;
        double r81281 = sqrt(r81262);
        double r81282 = r81281 * r81281;
        double r81283 = r81233 * r81282;
        double r81284 = r81283 + r81237;
        double r81285 = r81284 / r81234;
        double r81286 = r81276 ? r81280 : r81285;
        double r81287 = r81269 ? r81274 : r81286;
        double r81288 = r81243 ? r81267 : r81287;
        double r81289 = r81224 ? r81241 : r81288;
        return r81289;
}

double f_ol(float alpha, float beta, float i) {
        long double r81290 = alpha;
        long double r81291 = -5.603834303824399e+21;
        bool r81292 = r81290 < r81291;
        long double r81293 = beta;
        long double r81294 = r81290 + r81293;
        long double r81295 = r81293 - r81290;
        long double r81296 = r81294 * r81295;
        long double r81297 = 2.0;
        long double r81298 = i;
        long double r81299 = r81297 * r81298;
        long double r81300 = r81294 + r81299;
        long double r81301 = r81296 / r81300;
        long double r81302 = 2.0;
        long double r81303 = r81300 + r81302;
        long double r81304 = r81301 / r81303;
        long double r81305 = 1.0;
        long double r81306 = r81304 + r81305;
        long double r81307 = exp(r81306);
        long double r81308 = log(r81307);
        long double r81309 = r81308 / r81302;
        long double r81310 = -4.294236635768253e+16;
        bool r81311 = r81290 < r81310;
        long double r81312 = 126797.82172630695;
        bool r81313 = r81293 < r81312;
        long double r81314 = r81293 * r81293;
        long double r81315 = r81314 * r81314;
        long double r81316 = r81290 * r81290;
        long double r81317 = r81316 * r81316;
        long double r81318 = r81315 - r81317;
        long double r81319 = r81314 + r81316;
        long double r81320 = r81318 / r81319;
        long double r81321 = r81300 * r81303;
        long double r81322 = 1.0/r81321;
        long double r81323 = r81320 * r81322;
        long double r81324 = r81323 + r81305;
        long double r81325 = r81324 / r81302;
        long double r81326 = r81314 - r81316;
        long double r81327 = r81319 * r81326;
        long double r81328 = r81327 / r81319;
        long double r81329 = 1.0/r81300;
        long double r81330 = 1.0/r81303;
        long double r81331 = r81329 * r81330;
        long double r81332 = r81328 * r81331;
        long double r81333 = r81332 + r81305;
        long double r81334 = r81333 / r81302;
        long double r81335 = r81313 ? r81325 : r81334;
        long double r81336 = 3205281498.5237923;
        bool r81337 = r81290 < r81336;
        long double r81338 = 1.0;
        long double r81339 = r81303 / r81301;
        long double r81340 = r81338 / r81339;
        long double r81341 = r81340 + r81305;
        long double r81342 = r81341 / r81302;
        long double r81343 = 3.832151875870275e+23;
        bool r81344 = r81290 < r81343;
        long double r81345 = exp(r81304);
        long double r81346 = log(r81345);
        long double r81347 = r81346 + r81305;
        long double r81348 = r81347 / r81302;
        long double r81349 = sqrt(r81330);
        long double r81350 = r81349 * r81349;
        long double r81351 = r81301 * r81350;
        long double r81352 = r81351 + r81305;
        long double r81353 = r81352 / r81302;
        long double r81354 = r81344 ? r81348 : r81353;
        long double r81355 = r81337 ? r81342 : r81354;
        long double r81356 = r81311 ? r81335 : r81355;
        long double r81357 = r81292 ? r81309 : r81356;
        return r81357;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r81358, r81359, r81360, r81361, r81362, r81363, r81364, r81365, r81366, r81367, r81368, r81369, r81370, r81371, r81372, r81373;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r81358);
        mpfr_init(r81359);
        mpfr_init(r81360);
        mpfr_init(r81361);
        mpfr_init(r81362);
        mpfr_init(r81363);
        mpfr_init(r81364);
        mpfr_init(r81365);
        mpfr_init(r81366);
        mpfr_init(r81367);
        mpfr_init(r81368);
        mpfr_init(r81369);
        mpfr_init(r81370);
        mpfr_init(r81371);
        mpfr_init(r81372);
        mpfr_init(r81373);
}

double f_im(float alpha, float beta, float i) {
        mpfr_set_flt(r81358, alpha, MPFR_RNDN);
        mpfr_set_flt(r81359, beta, MPFR_RNDN);
        mpfr_add(r81360, r81358, r81359, MPFR_RNDN);
        mpfr_sub(r81361, r81359, r81358, MPFR_RNDN);
        mpfr_mul(r81362, r81360, r81361, MPFR_RNDN);
        mpfr_init_set_str(r81363, "2", 10, MPFR_RNDN);
        mpfr_set_flt(r81364, i, MPFR_RNDN);
        mpfr_mul(r81365, r81363, r81364, MPFR_RNDN);
        mpfr_add(r81366, r81360, r81365, MPFR_RNDN);
        mpfr_div(r81367, r81362, r81366, MPFR_RNDN);
        mpfr_init_set_str(r81368, "2.0", 10, MPFR_RNDN);
        mpfr_add(r81369, r81366, r81368, MPFR_RNDN);
        mpfr_div(r81370, r81367, r81369, MPFR_RNDN);
        mpfr_init_set_str(r81371, "1.0", 10, MPFR_RNDN);
        mpfr_add(r81372, r81370, r81371, MPFR_RNDN);
        mpfr_div(r81373, r81372, r81368, MPFR_RNDN);
        return mpfr_get_d(r81373, MPFR_RNDN);
}

