#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Octave 3.8, jcobi/3 */

double f_if(float alpha, float beta, float i) {
        float r81377 = alpha;
        float r81378 = beta;
        float r81379 = r81377 + r81378;
        float r81380 = r81378 * r81377;
        float r81381 = r81379 + r81380;
        float r81382 = 1.0;
        float r81383 = r81381 + r81382;
        float r81384 = 2.0;
        float r81385 = i;
        float r81386 = r81384 * r81385;
        float r81387 = r81379 + r81386;
        float r81388 = r81383 / r81387;
        float r81389 = r81388 / r81387;
        float r81390 = r81387 + r81382;
        float r81391 = r81389 / r81390;
        return r81391;
}

double f_id(float alpha, float beta, float i) {
        double r81392 = alpha;
        double r81393 = beta;
        double r81394 = r81392 + r81393;
        double r81395 = r81393 * r81392;
        double r81396 = r81394 + r81395;
        double r81397 = 1.0;
        double r81398 = r81396 + r81397;
        double r81399 = 2.0;
        double r81400 = i;
        double r81401 = r81399 * r81400;
        double r81402 = r81394 + r81401;
        double r81403 = r81398 / r81402;
        double r81404 = r81403 / r81402;
        double r81405 = r81402 + r81397;
        double r81406 = r81404 / r81405;
        return r81406;
}

double f_il(float alpha, float beta, float i) {
        long double r81407 = alpha;
        long double r81408 = beta;
        long double r81409 = r81407 + r81408;
        long double r81410 = r81408 * r81407;
        long double r81411 = r81409 + r81410;
        long double r81412 = 1.0;
        long double r81413 = r81411 + r81412;
        long double r81414 = 2.0;
        long double r81415 = i;
        long double r81416 = r81414 * r81415;
        long double r81417 = r81409 + r81416;
        long double r81418 = r81413 / r81417;
        long double r81419 = r81418 / r81417;
        long double r81420 = r81417 + r81412;
        long double r81421 = r81419 / r81420;
        return r81421;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float alpha, float beta, float i) {
        float r81422 = alpha;
        float r81423 = -6.968213587055943e+21;
        bool r81424 = r81422 < r81423;
        float r81425 = beta;
        float r81426 = r81422 + r81425;
        float r81427 = r81425 * r81422;
        float r81428 = r81426 + r81427;
        float r81429 = 1.0;
        float r81430 = r81428 + r81429;
        float r81431 = 2.0;
        float r81432 = i;
        float r81433 = r81431 * r81432;
        float r81434 = r81426 + r81433;
        float r81435 = r81430 / r81434;
        float r81436 = r81425 + r81433;
        float r81437 = r81422 + r81436;
        float r81438 = r81435 / r81437;
        float r81439 = r81434 + r81429;
        float r81440 = 1.0/r81439;
        float r81441 = r81438 * r81440;
        float r81442 = -9.161047768334243e+16;
        bool r81443 = r81422 < r81442;
        float r81444 = 1.0/r81434;
        float r81445 = r81444 * r81444;
        float r81446 = r81430 * r81445;
        float r81447 = r81446 * r81440;
        float r81448 = 1.965251406615741e-20;
        bool r81449 = r81422 < r81448;
        float r81450 = 5.040479897553525e+25;
        bool r81451 = r81422 < r81450;
        float r81452 = 1.0;
        float r81453 = r81434 * r81434;
        float r81454 = r81452 / r81453;
        float r81455 = r81454 / r81439;
        float r81456 = r81430 * r81455;
        float r81457 = r81435 * r81444;
        float r81458 = r81457 / r81439;
        float r81459 = r81451 ? r81456 : r81458;
        float r81460 = r81449 ? r81441 : r81459;
        float r81461 = r81443 ? r81447 : r81460;
        float r81462 = r81424 ? r81441 : r81461;
        return r81462;
}

double f_od(float alpha, float beta, float i) {
        double r81463 = alpha;
        double r81464 = -6.968213587055943e+21;
        bool r81465 = r81463 < r81464;
        double r81466 = beta;
        double r81467 = r81463 + r81466;
        double r81468 = r81466 * r81463;
        double r81469 = r81467 + r81468;
        double r81470 = 1.0;
        double r81471 = r81469 + r81470;
        double r81472 = 2.0;
        double r81473 = i;
        double r81474 = r81472 * r81473;
        double r81475 = r81467 + r81474;
        double r81476 = r81471 / r81475;
        double r81477 = r81466 + r81474;
        double r81478 = r81463 + r81477;
        double r81479 = r81476 / r81478;
        double r81480 = r81475 + r81470;
        double r81481 = 1.0/r81480;
        double r81482 = r81479 * r81481;
        double r81483 = -9.161047768334243e+16;
        bool r81484 = r81463 < r81483;
        double r81485 = 1.0/r81475;
        double r81486 = r81485 * r81485;
        double r81487 = r81471 * r81486;
        double r81488 = r81487 * r81481;
        double r81489 = 1.965251406615741e-20;
        bool r81490 = r81463 < r81489;
        double r81491 = 5.040479897553525e+25;
        bool r81492 = r81463 < r81491;
        double r81493 = 1.0;
        double r81494 = r81475 * r81475;
        double r81495 = r81493 / r81494;
        double r81496 = r81495 / r81480;
        double r81497 = r81471 * r81496;
        double r81498 = r81476 * r81485;
        double r81499 = r81498 / r81480;
        double r81500 = r81492 ? r81497 : r81499;
        double r81501 = r81490 ? r81482 : r81500;
        double r81502 = r81484 ? r81488 : r81501;
        double r81503 = r81465 ? r81482 : r81502;
        return r81503;
}

double f_ol(float alpha, float beta, float i) {
        long double r81504 = alpha;
        long double r81505 = -6.968213587055943e+21;
        bool r81506 = r81504 < r81505;
        long double r81507 = beta;
        long double r81508 = r81504 + r81507;
        long double r81509 = r81507 * r81504;
        long double r81510 = r81508 + r81509;
        long double r81511 = 1.0;
        long double r81512 = r81510 + r81511;
        long double r81513 = 2.0;
        long double r81514 = i;
        long double r81515 = r81513 * r81514;
        long double r81516 = r81508 + r81515;
        long double r81517 = r81512 / r81516;
        long double r81518 = r81507 + r81515;
        long double r81519 = r81504 + r81518;
        long double r81520 = r81517 / r81519;
        long double r81521 = r81516 + r81511;
        long double r81522 = 1.0/r81521;
        long double r81523 = r81520 * r81522;
        long double r81524 = -9.161047768334243e+16;
        bool r81525 = r81504 < r81524;
        long double r81526 = 1.0/r81516;
        long double r81527 = r81526 * r81526;
        long double r81528 = r81512 * r81527;
        long double r81529 = r81528 * r81522;
        long double r81530 = 1.965251406615741e-20;
        bool r81531 = r81504 < r81530;
        long double r81532 = 5.040479897553525e+25;
        bool r81533 = r81504 < r81532;
        long double r81534 = 1.0;
        long double r81535 = r81516 * r81516;
        long double r81536 = r81534 / r81535;
        long double r81537 = r81536 / r81521;
        long double r81538 = r81512 * r81537;
        long double r81539 = r81517 * r81526;
        long double r81540 = r81539 / r81521;
        long double r81541 = r81533 ? r81538 : r81540;
        long double r81542 = r81531 ? r81523 : r81541;
        long double r81543 = r81525 ? r81529 : r81542;
        long double r81544 = r81506 ? r81523 : r81543;
        return r81544;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r81545, r81546, r81547, r81548, r81549, r81550, r81551, r81552, r81553, r81554, r81555, r81556, r81557, r81558, r81559;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r81545);
        mpfr_init(r81546);
        mpfr_init(r81547);
        mpfr_init(r81548);
        mpfr_init(r81549);
        mpfr_init(r81550);
        mpfr_init(r81551);
        mpfr_init(r81552);
        mpfr_init(r81553);
        mpfr_init(r81554);
        mpfr_init(r81555);
        mpfr_init(r81556);
        mpfr_init(r81557);
        mpfr_init(r81558);
        mpfr_init(r81559);
}

double f_im(float alpha, float beta, float i) {
        mpfr_set_flt(r81545, alpha, MPFR_RNDN);
        mpfr_set_flt(r81546, beta, MPFR_RNDN);
        mpfr_add(r81547, r81545, r81546, MPFR_RNDN);
        mpfr_mul(r81548, r81546, r81545, MPFR_RNDN);
        mpfr_add(r81549, r81547, r81548, MPFR_RNDN);
        mpfr_init_set_str(r81550, "1.0", 10, MPFR_RNDN);
        mpfr_add(r81551, r81549, r81550, MPFR_RNDN);
        mpfr_init_set_str(r81552, "2", 10, MPFR_RNDN);
        mpfr_set_flt(r81553, i, MPFR_RNDN);
        mpfr_mul(r81554, r81552, r81553, MPFR_RNDN);
        mpfr_add(r81555, r81547, r81554, MPFR_RNDN);
        mpfr_div(r81556, r81551, r81555, MPFR_RNDN);
        mpfr_div(r81557, r81556, r81555, MPFR_RNDN);
        mpfr_add(r81558, r81555, r81550, MPFR_RNDN);
        mpfr_div(r81559, r81557, r81558, MPFR_RNDN);
        return mpfr_get_d(r81559, MPFR_RNDN);
}

