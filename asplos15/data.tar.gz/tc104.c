#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* VandenBroeck and Keller, Equation (6) */

double f_if(float F, float l) {
        float r84286 = 3.141592653589793;
        float r84287 = l;
        float r84288 = r84286 * r84287;
        float r84289 = F;
        float r84290 = r84289 * r84289;
        float r84291 = 1.0/r84290;
        float r84292 = tan(r84288);
        float r84293 = r84291 * r84292;
        float r84294 = r84288 - r84293;
        return r84294;
}

double f_id(float F, float l) {
        double r84295 = 3.141592653589793;
        double r84296 = l;
        double r84297 = r84295 * r84296;
        double r84298 = F;
        double r84299 = r84298 * r84298;
        double r84300 = 1.0/r84299;
        double r84301 = tan(r84297);
        double r84302 = r84300 * r84301;
        double r84303 = r84297 - r84302;
        return r84303;
}

double f_il(float F, float l) {
        long double r84304 = 3.141592653589793;
        long double r84305 = l;
        long double r84306 = r84304 * r84305;
        long double r84307 = F;
        long double r84308 = r84307 * r84307;
        long double r84309 = 1.0/r84308;
        long double r84310 = tan(r84306);
        long double r84311 = r84309 * r84310;
        long double r84312 = r84306 - r84311;
        return r84312;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float F, float l) {
        float r84313 = 3.141592653589793;
        float r84314 = l;
        float r84315 = r84313 * r84314;
        float r84316 = sin(r84315);
        float r84317 = cos(r84315);
        float r84318 = exp(r84317);
        float r84319 = log(r84318);
        float r84320 = r84316 / r84319;
        float r84321 = F;
        float r84322 = r84321 * r84321;
        float r84323 = r84320 / r84322;
        float r84324 = r84315 - r84323;
        return r84324;
}

double f_od(float F, float l) {
        double r84325 = 3.141592653589793;
        double r84326 = l;
        double r84327 = r84325 * r84326;
        double r84328 = sin(r84327);
        double r84329 = cos(r84327);
        double r84330 = exp(r84329);
        double r84331 = log(r84330);
        double r84332 = r84328 / r84331;
        double r84333 = F;
        double r84334 = r84333 * r84333;
        double r84335 = r84332 / r84334;
        double r84336 = r84327 - r84335;
        return r84336;
}

double f_ol(float F, float l) {
        long double r84337 = 3.141592653589793;
        long double r84338 = l;
        long double r84339 = r84337 * r84338;
        long double r84340 = sin(r84339);
        long double r84341 = cos(r84339);
        long double r84342 = exp(r84341);
        long double r84343 = log(r84342);
        long double r84344 = r84340 / r84343;
        long double r84345 = F;
        long double r84346 = r84345 * r84345;
        long double r84347 = r84344 / r84346;
        long double r84348 = r84339 - r84347;
        return r84348;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r84349, r84350, r84351, r84352, r84353, r84354, r84355, r84356, r84357;

void setup_mpfr() {
        mpfr_set_default_prec(136);
        mpfr_init(r84349);
        mpfr_init(r84350);
        mpfr_init(r84351);
        mpfr_init(r84352);
        mpfr_init(r84353);
        mpfr_init(r84354);
        mpfr_init(r84355);
        mpfr_init(r84356);
        mpfr_init(r84357);
}

double f_im(float F, float l) {
        mpfr_init_set_str(r84349, "3.141592653589793", 10, MPFR_RNDN);
        mpfr_set_flt(r84350, l, MPFR_RNDN);
        mpfr_mul(r84351, r84349, r84350, MPFR_RNDN);
        mpfr_set_flt(r84352, F, MPFR_RNDN);
        mpfr_mul(r84353, r84352, r84352, MPFR_RNDN);
        mpfr_ui_div(r84354, 1, r84353, MPFR_RNDN);
        mpfr_tan(r84355, r84351, MPFR_RNDN);
        mpfr_mul(r84356, r84354, r84355, MPFR_RNDN);
        mpfr_sub(r84357, r84351, r84356, MPFR_RNDN);
        return mpfr_get_d(r84357, MPFR_RNDN);
}

