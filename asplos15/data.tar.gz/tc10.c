#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* FastMath repmul */

double f_if(float d1) {
        float r72775 = d1;
        float r72776 = r72775 * r72775;
        float r72777 = r72776 * r72775;
        float r72778 = r72777 * r72775;
        return r72778;
}

double f_id(float d1) {
        double r72779 = d1;
        double r72780 = r72779 * r72779;
        double r72781 = r72780 * r72779;
        double r72782 = r72781 * r72779;
        return r72782;
}

double f_il(float d1) {
        long double r72783 = d1;
        long double r72784 = r72783 * r72783;
        long double r72785 = r72784 * r72783;
        long double r72786 = r72785 * r72783;
        return r72786;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float d1) {
        float r72787 = d1;
        float r72788 = 2.0;
        float r72789 = 1.0;
        float r72790 = r72788 + r72789;
        float r72791 = r72790 + r72789;
        float r72792 = pow(r72787, r72791);
        return r72792;
}

double f_od(float d1) {
        double r72793 = d1;
        double r72794 = 2.0;
        double r72795 = 1.0;
        double r72796 = r72794 + r72795;
        double r72797 = r72796 + r72795;
        double r72798 = pow(r72793, r72797);
        return r72798;
}

double f_ol(float d1) {
        long double r72799 = d1;
        long double r72800 = 2.0;
        long double r72801 = 1.0;
        long double r72802 = r72800 + r72801;
        long double r72803 = r72802 + r72801;
        long double r72804 = pow(r72799, r72803);
        return r72804;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r72805, r72806, r72807, r72808;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r72805);
        mpfr_init(r72806);
        mpfr_init(r72807);
        mpfr_init(r72808);
}

double f_im(float d1) {
        mpfr_set_flt(r72805, d1, MPFR_RNDN);
        mpfr_mul(r72806, r72805, r72805, MPFR_RNDN);
        mpfr_mul(r72807, r72806, r72805, MPFR_RNDN);
        mpfr_mul(r72808, r72807, r72805, MPFR_RNDN);
        return mpfr_get_d(r72808, MPFR_RNDN);
}

