#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* powComplex, real part */

double f_if(float x_re, float x_im, float y_re, float y_im) {
        float r86633 = x_re;
        float r86634 = r86633 * r86633;
        float r86635 = x_im;
        float r86636 = r86635 * r86635;
        float r86637 = r86634 + r86636;
        float r86638 = sqrt(r86637);
        float r86639 = log(r86638);
        float r86640 = y_re;
        float r86641 = r86639 * r86640;
        float r86642 = atan2(r86635, r86633);
        float r86643 = y_im;
        float r86644 = r86642 * r86643;
        float r86645 = r86641 - r86644;
        float r86646 = exp(r86645);
        float r86647 = r86639 * r86643;
        float r86648 = r86642 * r86640;
        float r86649 = r86647 + r86648;
        float r86650 = cos(r86649);
        float r86651 = r86646 * r86650;
        return r86651;
}

double f_id(float x_re, float x_im, float y_re, float y_im) {
        double r86652 = x_re;
        double r86653 = r86652 * r86652;
        double r86654 = x_im;
        double r86655 = r86654 * r86654;
        double r86656 = r86653 + r86655;
        double r86657 = sqrt(r86656);
        double r86658 = log(r86657);
        double r86659 = y_re;
        double r86660 = r86658 * r86659;
        double r86661 = atan2(r86654, r86652);
        double r86662 = y_im;
        double r86663 = r86661 * r86662;
        double r86664 = r86660 - r86663;
        double r86665 = exp(r86664);
        double r86666 = r86658 * r86662;
        double r86667 = r86661 * r86659;
        double r86668 = r86666 + r86667;
        double r86669 = cos(r86668);
        double r86670 = r86665 * r86669;
        return r86670;
}

double f_il(float x_re, float x_im, float y_re, float y_im) {
        long double r86671 = x_re;
        long double r86672 = r86671 * r86671;
        long double r86673 = x_im;
        long double r86674 = r86673 * r86673;
        long double r86675 = r86672 + r86674;
        long double r86676 = sqrt(r86675);
        long double r86677 = log(r86676);
        long double r86678 = y_re;
        long double r86679 = r86677 * r86678;
        long double r86680 = atan2(r86673, r86671);
        long double r86681 = y_im;
        long double r86682 = r86680 * r86681;
        long double r86683 = r86679 - r86682;
        long double r86684 = exp(r86683);
        long double r86685 = r86677 * r86681;
        long double r86686 = r86680 * r86678;
        long double r86687 = r86685 + r86686;
        long double r86688 = cos(r86687);
        long double r86689 = r86684 * r86688;
        return r86689;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x_re, float x_im, float y_re, float y_im) {
        float r86690 = x_re;
        float r86691 = r86690 * r86690;
        float r86692 = x_im;
        float r86693 = r86692 * r86692;
        float r86694 = r86691 + r86693;
        float r86695 = sqrt(r86694);
        float r86696 = log(r86695);
        float r86697 = y_re;
        float r86698 = r86696 * r86697;
        float r86699 = atan2(r86692, r86690);
        float r86700 = y_im;
        float r86701 = r86699 * r86700;
        float r86702 = r86698 - r86701;
        float r86703 = exp(r86702);
        float r86704 = r86696 * r86700;
        float r86705 = r86699 * r86697;
        float r86706 = r86704 + r86705;
        float r86707 = cos(r86706);
        float r86708 = r86703 * r86707;
        return r86708;
}

double f_od(float x_re, float x_im, float y_re, float y_im) {
        double r86709 = x_re;
        double r86710 = r86709 * r86709;
        double r86711 = x_im;
        double r86712 = r86711 * r86711;
        double r86713 = r86710 + r86712;
        double r86714 = sqrt(r86713);
        double r86715 = log(r86714);
        double r86716 = y_re;
        double r86717 = r86715 * r86716;
        double r86718 = atan2(r86711, r86709);
        double r86719 = y_im;
        double r86720 = r86718 * r86719;
        double r86721 = r86717 - r86720;
        double r86722 = exp(r86721);
        double r86723 = r86715 * r86719;
        double r86724 = r86718 * r86716;
        double r86725 = r86723 + r86724;
        double r86726 = cos(r86725);
        double r86727 = r86722 * r86726;
        return r86727;
}

double f_ol(float x_re, float x_im, float y_re, float y_im) {
        long double r86728 = x_re;
        long double r86729 = r86728 * r86728;
        long double r86730 = x_im;
        long double r86731 = r86730 * r86730;
        long double r86732 = r86729 + r86731;
        long double r86733 = sqrt(r86732);
        long double r86734 = log(r86733);
        long double r86735 = y_re;
        long double r86736 = r86734 * r86735;
        long double r86737 = atan2(r86730, r86728);
        long double r86738 = y_im;
        long double r86739 = r86737 * r86738;
        long double r86740 = r86736 - r86739;
        long double r86741 = exp(r86740);
        long double r86742 = r86734 * r86738;
        long double r86743 = r86737 * r86735;
        long double r86744 = r86742 + r86743;
        long double r86745 = cos(r86744);
        long double r86746 = r86741 * r86745;
        return r86746;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r86747, r86748, r86749, r86750, r86751, r86752, r86753, r86754, r86755, r86756, r86757, r86758, r86759, r86760, r86761, r86762, r86763, r86764, r86765;

void setup_mpfr() {
        mpfr_set_default_prec(200);
        mpfr_init(r86747);
        mpfr_init(r86748);
        mpfr_init(r86749);
        mpfr_init(r86750);
        mpfr_init(r86751);
        mpfr_init(r86752);
        mpfr_init(r86753);
        mpfr_init(r86754);
        mpfr_init(r86755);
        mpfr_init(r86756);
        mpfr_init(r86757);
        mpfr_init(r86758);
        mpfr_init(r86759);
        mpfr_init(r86760);
        mpfr_init(r86761);
        mpfr_init(r86762);
        mpfr_init(r86763);
        mpfr_init(r86764);
        mpfr_init(r86765);
}

double f_im(float x_re, float x_im, float y_re, float y_im) {
        mpfr_set_flt(r86747, x_re, MPFR_RNDN);
        mpfr_mul(r86748, r86747, r86747, MPFR_RNDN);
        mpfr_set_flt(r86749, x_im, MPFR_RNDN);
        mpfr_mul(r86750, r86749, r86749, MPFR_RNDN);
        mpfr_add(r86751, r86748, r86750, MPFR_RNDN);
        mpfr_sqrt(r86752, r86751, MPFR_RNDN);
        mpfr_log(r86753, r86752, MPFR_RNDN);
        mpfr_set_flt(r86754, y_re, MPFR_RNDN);
        mpfr_mul(r86755, r86753, r86754, MPFR_RNDN);
        mpfr_atan2(r86756, r86749, r86747, MPFR_RNDN);
        mpfr_set_flt(r86757, y_im, MPFR_RNDN);
        mpfr_mul(r86758, r86756, r86757, MPFR_RNDN);
        mpfr_sub(r86759, r86755, r86758, MPFR_RNDN);
        mpfr_exp(r86760, r86759, MPFR_RNDN);
        mpfr_mul(r86761, r86753, r86757, MPFR_RNDN);
        mpfr_mul(r86762, r86756, r86754, MPFR_RNDN);
        mpfr_add(r86763, r86761, r86762, MPFR_RNDN);
        mpfr_cos(r86764, r86763, MPFR_RNDN);
        mpfr_mul(r86765, r86760, r86764, MPFR_RNDN);
        return mpfr_get_d(r86765, MPFR_RNDN);
}

