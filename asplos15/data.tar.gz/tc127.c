#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.square on complex, real part */

double f_if(float re, float im) {
        float r86300 = re;
        float r86301 = r86300 * r86300;
        float r86302 = im;
        float r86303 = r86302 * r86302;
        float r86304 = r86301 - r86303;
        return r86304;
}

double f_id(float re, float im) {
        double r86305 = re;
        double r86306 = r86305 * r86305;
        double r86307 = im;
        double r86308 = r86307 * r86307;
        double r86309 = r86306 - r86308;
        return r86309;
}

double f_il(float re, float im) {
        long double r86310 = re;
        long double r86311 = r86310 * r86310;
        long double r86312 = im;
        long double r86313 = r86312 * r86312;
        long double r86314 = r86311 - r86313;
        return r86314;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r86315 = re;
        float r86316 = im;
        float r86317 = r86315 + r86316;
        float r86318 = r86315 - r86316;
        float r86319 = r86317 * r86318;
        return r86319;
}

double f_od(float re, float im) {
        double r86320 = re;
        double r86321 = im;
        double r86322 = r86320 + r86321;
        double r86323 = r86320 - r86321;
        double r86324 = r86322 * r86323;
        return r86324;
}

double f_ol(float re, float im) {
        long double r86325 = re;
        long double r86326 = im;
        long double r86327 = r86325 + r86326;
        long double r86328 = r86325 - r86326;
        long double r86329 = r86327 * r86328;
        return r86329;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r86330, r86331, r86332, r86333, r86334;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r86330);
        mpfr_init(r86331);
        mpfr_init(r86332);
        mpfr_init(r86333);
        mpfr_init(r86334);
}

double f_im(float re, float im) {
        mpfr_set_flt(r86330, re, MPFR_RNDN);
        mpfr_mul(r86331, r86330, r86330, MPFR_RNDN);
        mpfr_set_flt(r86332, im, MPFR_RNDN);
        mpfr_mul(r86333, r86332, r86332, MPFR_RNDN);
        mpfr_sub(r86334, r86331, r86333, MPFR_RNDN);
        return mpfr_get_d(r86334, MPFR_RNDN);
}

