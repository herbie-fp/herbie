#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE problem 3.4.4 */

double f_if(float x) {
        float r80824 = 2.0;
        float r80825 = x;
        float r80826 = r80824 * r80825;
        float r80827 = exp(r80826);
        float r80828 = 1.0;
        float r80829 = r80827 - r80828;
        float r80830 = exp(r80825);
        float r80831 = r80830 - r80828;
        float r80832 = r80829 / r80831;
        float r80833 = sqrt(r80832);
        return r80833;
}

double f_id(float x) {
        double r80834 = 2.0;
        double r80835 = x;
        double r80836 = r80834 * r80835;
        double r80837 = exp(r80836);
        double r80838 = 1.0;
        double r80839 = r80837 - r80838;
        double r80840 = exp(r80835);
        double r80841 = r80840 - r80838;
        double r80842 = r80839 / r80841;
        double r80843 = sqrt(r80842);
        return r80843;
}

double f_il(float x) {
        long double r80844 = 2.0;
        long double r80845 = x;
        long double r80846 = r80844 * r80845;
        long double r80847 = exp(r80846);
        long double r80848 = 1.0;
        long double r80849 = r80847 - r80848;
        long double r80850 = exp(r80845);
        long double r80851 = r80850 - r80848;
        long double r80852 = r80849 / r80851;
        long double r80853 = sqrt(r80852);
        return r80853;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r80854 = 2.0;
        float r80855 = x;
        float r80856 = r80854 * r80855;
        float r80857 = exp(r80856);
        float r80858 = sqrt(r80857);
        float r80859 = 1.0;
        float r80860 = r80858 + r80859;
        float r80861 = exp(r80855);
        float r80862 = sqrt(r80861);
        float r80863 = r80862 + r80859;
        float r80864 = r80860 / r80863;
        float r80865 = sqrt(r80858);
        float r80866 = r80865 + r80859;
        float r80867 = r80865 - r80859;
        float r80868 = r80866 * r80867;
        float r80869 = r80862 - r80859;
        float r80870 = r80868 / r80869;
        float r80871 = r80864 * r80870;
        float r80872 = sqrt(r80871);
        return r80872;
}

double f_od(float x) {
        double r80873 = 2.0;
        double r80874 = x;
        double r80875 = r80873 * r80874;
        double r80876 = exp(r80875);
        double r80877 = sqrt(r80876);
        double r80878 = 1.0;
        double r80879 = r80877 + r80878;
        double r80880 = exp(r80874);
        double r80881 = sqrt(r80880);
        double r80882 = r80881 + r80878;
        double r80883 = r80879 / r80882;
        double r80884 = sqrt(r80877);
        double r80885 = r80884 + r80878;
        double r80886 = r80884 - r80878;
        double r80887 = r80885 * r80886;
        double r80888 = r80881 - r80878;
        double r80889 = r80887 / r80888;
        double r80890 = r80883 * r80889;
        double r80891 = sqrt(r80890);
        return r80891;
}

double f_ol(float x) {
        long double r80892 = 2.0;
        long double r80893 = x;
        long double r80894 = r80892 * r80893;
        long double r80895 = exp(r80894);
        long double r80896 = sqrt(r80895);
        long double r80897 = 1.0;
        long double r80898 = r80896 + r80897;
        long double r80899 = exp(r80893);
        long double r80900 = sqrt(r80899);
        long double r80901 = r80900 + r80897;
        long double r80902 = r80898 / r80901;
        long double r80903 = sqrt(r80896);
        long double r80904 = r80903 + r80897;
        long double r80905 = r80903 - r80897;
        long double r80906 = r80904 * r80905;
        long double r80907 = r80900 - r80897;
        long double r80908 = r80906 / r80907;
        long double r80909 = r80902 * r80908;
        long double r80910 = sqrt(r80909);
        return r80910;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r80911, r80912, r80913, r80914, r80915, r80916, r80917, r80918, r80919, r80920;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r80911);
        mpfr_init(r80912);
        mpfr_init(r80913);
        mpfr_init(r80914);
        mpfr_init(r80915);
        mpfr_init(r80916);
        mpfr_init(r80917);
        mpfr_init(r80918);
        mpfr_init(r80919);
        mpfr_init(r80920);
}

double f_im(float x) {
        mpfr_init_set_str(r80911, "2", 10, MPFR_RNDN);
        mpfr_set_flt(r80912, x, MPFR_RNDN);
        mpfr_mul(r80913, r80911, r80912, MPFR_RNDN);
        mpfr_exp(r80914, r80913, MPFR_RNDN);
        mpfr_init_set_str(r80915, "1", 10, MPFR_RNDN);
        mpfr_sub(r80916, r80914, r80915, MPFR_RNDN);
        mpfr_exp(r80917, r80912, MPFR_RNDN);
        mpfr_sub(r80918, r80917, r80915, MPFR_RNDN);
        mpfr_div(r80919, r80916, r80918, MPFR_RNDN);
        mpfr_sqrt(r80920, r80919, MPFR_RNDN);
        return mpfr_get_d(r80920, MPFR_RNDN);
}

