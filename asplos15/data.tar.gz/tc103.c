#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* VandenBroeck and Keller, Equation (24) */

double f_if(float B, float x) {
        float r84225 = x;
        float r84226 = B;
        float r84227 = 1.0 / tan(r84226);
        float r84228 = r84225 * r84227;
        float r84229 = -r84228;
        float r84230 = 1.0;
        float r84231 = sin(r84226);
        float r84232 = r84230 / r84231;
        float r84233 = r84229 + r84232;
        return r84233;
}

double f_id(float B, float x) {
        double r84234 = x;
        double r84235 = B;
        double r84236 = 1.0 / tan(r84235);
        double r84237 = r84234 * r84236;
        double r84238 = -r84237;
        double r84239 = 1.0;
        double r84240 = sin(r84235);
        double r84241 = r84239 / r84240;
        double r84242 = r84238 + r84241;
        return r84242;
}

double f_il(float B, float x) {
        long double r84243 = x;
        long double r84244 = B;
        long double r84245 = 1.0 / tan(r84244);
        long double r84246 = r84243 * r84245;
        long double r84247 = -r84246;
        long double r84248 = 1.0;
        long double r84249 = sin(r84244);
        long double r84250 = r84248 / r84249;
        long double r84251 = r84247 + r84250;
        return r84251;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float B, float x) {
        float r84252 = x;
        float r84253 = B;
        float r84254 = 1.0 / tan(r84253);
        float r84255 = r84252 * r84254;
        float r84256 = -r84255;
        float r84257 = sin(r84253);
        float r84258 = 1.0/r84257;
        float r84259 = r84256 + r84258;
        return r84259;
}

double f_od(float B, float x) {
        double r84260 = x;
        double r84261 = B;
        double r84262 = 1.0 / tan(r84261);
        double r84263 = r84260 * r84262;
        double r84264 = -r84263;
        double r84265 = sin(r84261);
        double r84266 = 1.0/r84265;
        double r84267 = r84264 + r84266;
        return r84267;
}

double f_ol(float B, float x) {
        long double r84268 = x;
        long double r84269 = B;
        long double r84270 = 1.0 / tan(r84269);
        long double r84271 = r84268 * r84270;
        long double r84272 = -r84271;
        long double r84273 = sin(r84269);
        long double r84274 = 1.0/r84273;
        long double r84275 = r84272 + r84274;
        return r84275;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r84276, r84277, r84278, r84279, r84280, r84281, r84282, r84283, r84284;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r84276);
        mpfr_init(r84277);
        mpfr_init(r84278);
        mpfr_init(r84279);
        mpfr_init(r84280);
        mpfr_init(r84281);
        mpfr_init(r84282);
        mpfr_init(r84283);
        mpfr_init(r84284);
}

double f_im(float B, float x) {
        mpfr_set_flt(r84276, x, MPFR_RNDN);
        mpfr_set_flt(r84277, B, MPFR_RNDN);
        mpfr_cot(r84278, r84277, MPFR_RNDN);
        mpfr_mul(r84279, r84276, r84278, MPFR_RNDN);
        mpfr_neg(r84280, r84279, MPFR_RNDN);
        mpfr_init_set_str(r84281, "1", 10, MPFR_RNDN);
        mpfr_sin(r84282, r84277, MPFR_RNDN);
        mpfr_div(r84283, r84281, r84282, MPFR_RNDN);
        mpfr_add(r84284, r84280, r84283, MPFR_RNDN);
        return mpfr_get_d(r84284, MPFR_RNDN);
}

