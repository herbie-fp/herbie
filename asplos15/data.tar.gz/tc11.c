#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* FastMath test1 */

double f_if(float d) {
        float r72809 = d;
        float r72810 = 10.0;
        float r72811 = r72809 * r72810;
        float r72812 = 20.0;
        float r72813 = r72809 * r72812;
        float r72814 = r72811 + r72813;
        return r72814;
}

double f_id(float d) {
        double r72815 = d;
        double r72816 = 10.0;
        double r72817 = r72815 * r72816;
        double r72818 = 20.0;
        double r72819 = r72815 * r72818;
        double r72820 = r72817 + r72819;
        return r72820;
}

double f_il(float d) {
        long double r72821 = d;
        long double r72822 = 10.0;
        long double r72823 = r72821 * r72822;
        long double r72824 = 20.0;
        long double r72825 = r72821 * r72824;
        long double r72826 = r72823 + r72825;
        return r72826;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float d) {
        float r72827 = 30.0;
        float r72828 = d;
        float r72829 = r72827 * r72828;
        return r72829;
}

double f_od(float d) {
        double r72830 = 30.0;
        double r72831 = d;
        double r72832 = r72830 * r72831;
        return r72832;
}

double f_ol(float d) {
        long double r72833 = 30.0;
        long double r72834 = d;
        long double r72835 = r72833 * r72834;
        return r72835;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r72836, r72837, r72838, r72839, r72840, r72841;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r72836);
        mpfr_init(r72837);
        mpfr_init(r72838);
        mpfr_init(r72839);
        mpfr_init(r72840);
        mpfr_init(r72841);
}

double f_im(float d) {
        mpfr_set_flt(r72836, d, MPFR_RNDN);
        mpfr_init_set_str(r72837, "10", 10, MPFR_RNDN);
        mpfr_mul(r72838, r72836, r72837, MPFR_RNDN);
        mpfr_init_set_str(r72839, "20", 10, MPFR_RNDN);
        mpfr_mul(r72840, r72836, r72839, MPFR_RNDN);
        mpfr_add(r72841, r72838, r72840, MPFR_RNDN);
        return mpfr_get_d(r72841, MPFR_RNDN);
}

