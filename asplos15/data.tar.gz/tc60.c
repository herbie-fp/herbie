#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Hyperbolic sine */

double f_if(float x) {
        float r77379 = x;
        float r77380 = exp(r77379);
        float r77381 = -r77379;
        float r77382 = exp(r77381);
        float r77383 = r77380 - r77382;
        float r77384 = 2.0;
        float r77385 = r77383 / r77384;
        return r77385;
}

double f_id(float x) {
        double r77386 = x;
        double r77387 = exp(r77386);
        double r77388 = -r77386;
        double r77389 = exp(r77388);
        double r77390 = r77387 - r77389;
        double r77391 = 2.0;
        double r77392 = r77390 / r77391;
        return r77392;
}

double f_il(float x) {
        long double r77393 = x;
        long double r77394 = exp(r77393);
        long double r77395 = -r77393;
        long double r77396 = exp(r77395);
        long double r77397 = r77394 - r77396;
        long double r77398 = 2.0;
        long double r77399 = r77397 / r77398;
        return r77399;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r77400 = x;
        float r77401 = -0.0;
        bool r77402 = r77400 < r77401;
        float r77403 = 0.5;
        float r77404 = exp(r77400);
        float r77405 = r77403 * r77404;
        float r77406 = r77405 * r77405;
        float r77407 = exp(r77406);
        float r77408 = log(r77407);
        float r77409 = 0.25;
        float r77410 = r77404 * r77404;
        float r77411 = r77409 / r77410;
        float r77412 = r77408 - r77411;
        float r77413 = r77403 / r77404;
        float r77414 = r77405 + r77413;
        float r77415 = r77412 / r77414;
        float r77416 = r77413 * r77413;
        float r77417 = exp(r77416);
        float r77418 = log(r77417);
        float r77419 = r77406 - r77418;
        float r77420 = r77419 / r77414;
        float r77421 = r77402 ? r77415 : r77420;
        return r77421;
}

double f_od(float x) {
        double r77422 = x;
        double r77423 = -0.0;
        bool r77424 = r77422 < r77423;
        double r77425 = 0.5;
        double r77426 = exp(r77422);
        double r77427 = r77425 * r77426;
        double r77428 = r77427 * r77427;
        double r77429 = exp(r77428);
        double r77430 = log(r77429);
        double r77431 = 0.25;
        double r77432 = r77426 * r77426;
        double r77433 = r77431 / r77432;
        double r77434 = r77430 - r77433;
        double r77435 = r77425 / r77426;
        double r77436 = r77427 + r77435;
        double r77437 = r77434 / r77436;
        double r77438 = r77435 * r77435;
        double r77439 = exp(r77438);
        double r77440 = log(r77439);
        double r77441 = r77428 - r77440;
        double r77442 = r77441 / r77436;
        double r77443 = r77424 ? r77437 : r77442;
        return r77443;
}

double f_ol(float x) {
        long double r77444 = x;
        long double r77445 = -0.0;
        bool r77446 = r77444 < r77445;
        long double r77447 = 0.5;
        long double r77448 = exp(r77444);
        long double r77449 = r77447 * r77448;
        long double r77450 = r77449 * r77449;
        long double r77451 = exp(r77450);
        long double r77452 = log(r77451);
        long double r77453 = 0.25;
        long double r77454 = r77448 * r77448;
        long double r77455 = r77453 / r77454;
        long double r77456 = r77452 - r77455;
        long double r77457 = r77447 / r77448;
        long double r77458 = r77449 + r77457;
        long double r77459 = r77456 / r77458;
        long double r77460 = r77457 * r77457;
        long double r77461 = exp(r77460);
        long double r77462 = log(r77461);
        long double r77463 = r77450 - r77462;
        long double r77464 = r77463 / r77458;
        long double r77465 = r77446 ? r77459 : r77464;
        return r77465;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r77466, r77467, r77468, r77469, r77470, r77471, r77472;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r77466);
        mpfr_init(r77467);
        mpfr_init(r77468);
        mpfr_init(r77469);
        mpfr_init(r77470);
        mpfr_init(r77471);
        mpfr_init(r77472);
}

double f_im(float x) {
        mpfr_set_flt(r77466, x, MPFR_RNDN);
        mpfr_exp(r77467, r77466, MPFR_RNDN);
        mpfr_neg(r77468, r77466, MPFR_RNDN);
        mpfr_exp(r77469, r77468, MPFR_RNDN);
        mpfr_sub(r77470, r77467, r77469, MPFR_RNDN);
        mpfr_init_set_str(r77471, "2", 10, MPFR_RNDN);
        mpfr_div(r77472, r77470, r77471, MPFR_RNDN);
        return mpfr_get_d(r77472, MPFR_RNDN);
}

