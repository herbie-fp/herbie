#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE example 3.4 */

double f_if(float x) {
        float r73655 = 1.0;
        float r73656 = x;
        float r73657 = cos(r73656);
        float r73658 = r73655 - r73657;
        float r73659 = sin(r73656);
        float r73660 = r73658 / r73659;
        return r73660;
}

double f_id(float x) {
        double r73661 = 1.0;
        double r73662 = x;
        double r73663 = cos(r73662);
        double r73664 = r73661 - r73663;
        double r73665 = sin(r73662);
        double r73666 = r73664 / r73665;
        return r73666;
}

double f_il(float x) {
        long double r73667 = 1.0;
        long double r73668 = x;
        long double r73669 = cos(r73668);
        long double r73670 = r73667 - r73669;
        long double r73671 = sin(r73668);
        long double r73672 = r73670 / r73671;
        return r73672;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r73673 = x;
        float r73674 = sin(r73673);
        float r73675 = r73674 * r73674;
        float r73676 = 1.0;
        float r73677 = cos(r73673);
        float r73678 = r73676 + r73677;
        float r73679 = r73675 / r73678;
        float r73680 = exp(r73676);
        float r73681 = log(r73680);
        float r73682 = pow(r73679, r73681);
        float r73683 = r73682 / r73674;
        return r73683;
}

double f_od(float x) {
        double r73684 = x;
        double r73685 = sin(r73684);
        double r73686 = r73685 * r73685;
        double r73687 = 1.0;
        double r73688 = cos(r73684);
        double r73689 = r73687 + r73688;
        double r73690 = r73686 / r73689;
        double r73691 = exp(r73687);
        double r73692 = log(r73691);
        double r73693 = pow(r73690, r73692);
        double r73694 = r73693 / r73685;
        return r73694;
}

double f_ol(float x) {
        long double r73695 = x;
        long double r73696 = sin(r73695);
        long double r73697 = r73696 * r73696;
        long double r73698 = 1.0;
        long double r73699 = cos(r73695);
        long double r73700 = r73698 + r73699;
        long double r73701 = r73697 / r73700;
        long double r73702 = exp(r73698);
        long double r73703 = log(r73702);
        long double r73704 = pow(r73701, r73703);
        long double r73705 = r73704 / r73696;
        return r73705;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r73706, r73707, r73708, r73709, r73710, r73711;

void setup_mpfr() {
        mpfr_set_default_prec(344);
        mpfr_init(r73706);
        mpfr_init(r73707);
        mpfr_init(r73708);
        mpfr_init(r73709);
        mpfr_init(r73710);
        mpfr_init(r73711);
}

double f_im(float x) {
        mpfr_init_set_str(r73706, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r73707, x, MPFR_RNDN);
        mpfr_cos(r73708, r73707, MPFR_RNDN);
        mpfr_sub(r73709, r73706, r73708, MPFR_RNDN);
        mpfr_sin(r73710, r73707, MPFR_RNDN);
        mpfr_div(r73711, r73709, r73710, MPFR_RNDN);
        return mpfr_get_d(r73711, MPFR_RNDN);
}

