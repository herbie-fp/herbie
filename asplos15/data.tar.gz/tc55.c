#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Henrywood and Agarwal, Equation (9a) */

double f_if(float w0, float M, float D, float h, float l, float d) {
        float r76876 = w0;
        float r76877 = 1.0;
        float r76878 = M;
        float r76879 = D;
        float r76880 = r76878 * r76879;
        float r76881 = 2.0;
        float r76882 = d;
        float r76883 = r76881 * r76882;
        float r76884 = r76880 / r76883;
        float r76885 = r76884 * r76884;
        float r76886 = h;
        float r76887 = l;
        float r76888 = r76886 / r76887;
        float r76889 = r76885 * r76888;
        float r76890 = r76877 - r76889;
        float r76891 = sqrt(r76890);
        float r76892 = r76876 * r76891;
        return r76892;
}

double f_id(float w0, float M, float D, float h, float l, float d) {
        double r76893 = w0;
        double r76894 = 1.0;
        double r76895 = M;
        double r76896 = D;
        double r76897 = r76895 * r76896;
        double r76898 = 2.0;
        double r76899 = d;
        double r76900 = r76898 * r76899;
        double r76901 = r76897 / r76900;
        double r76902 = r76901 * r76901;
        double r76903 = h;
        double r76904 = l;
        double r76905 = r76903 / r76904;
        double r76906 = r76902 * r76905;
        double r76907 = r76894 - r76906;
        double r76908 = sqrt(r76907);
        double r76909 = r76893 * r76908;
        return r76909;
}

double f_il(float w0, float M, float D, float h, float l, float d) {
        long double r76910 = w0;
        long double r76911 = 1.0;
        long double r76912 = M;
        long double r76913 = D;
        long double r76914 = r76912 * r76913;
        long double r76915 = 2.0;
        long double r76916 = d;
        long double r76917 = r76915 * r76916;
        long double r76918 = r76914 / r76917;
        long double r76919 = r76918 * r76918;
        long double r76920 = h;
        long double r76921 = l;
        long double r76922 = r76920 / r76921;
        long double r76923 = r76919 * r76922;
        long double r76924 = r76911 - r76923;
        long double r76925 = sqrt(r76924);
        long double r76926 = r76910 * r76925;
        return r76926;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float w0, float M, float D, float h, float l, float d) {
        float r76927 = w0;
        float r76928 = 1.0;
        float r76929 = M;
        float r76930 = 2.0;
        float r76931 = r76929 / r76930;
        float r76932 = r76931 * r76931;
        float r76933 = D;
        float r76934 = d;
        float r76935 = r76933 / r76934;
        float r76936 = r76935 * r76935;
        float r76937 = h;
        float r76938 = l;
        float r76939 = r76937 / r76938;
        float r76940 = r76936 * r76939;
        float r76941 = r76932 * r76940;
        float r76942 = r76928 - r76941;
        float r76943 = sqrt(r76942);
        float r76944 = r76927 * r76943;
        return r76944;
}

double f_od(float w0, float M, float D, float h, float l, float d) {
        double r76945 = w0;
        double r76946 = 1.0;
        double r76947 = M;
        double r76948 = 2.0;
        double r76949 = r76947 / r76948;
        double r76950 = r76949 * r76949;
        double r76951 = D;
        double r76952 = d;
        double r76953 = r76951 / r76952;
        double r76954 = r76953 * r76953;
        double r76955 = h;
        double r76956 = l;
        double r76957 = r76955 / r76956;
        double r76958 = r76954 * r76957;
        double r76959 = r76950 * r76958;
        double r76960 = r76946 - r76959;
        double r76961 = sqrt(r76960);
        double r76962 = r76945 * r76961;
        return r76962;
}

double f_ol(float w0, float M, float D, float h, float l, float d) {
        long double r76963 = w0;
        long double r76964 = 1.0;
        long double r76965 = M;
        long double r76966 = 2.0;
        long double r76967 = r76965 / r76966;
        long double r76968 = r76967 * r76967;
        long double r76969 = D;
        long double r76970 = d;
        long double r76971 = r76969 / r76970;
        long double r76972 = r76971 * r76971;
        long double r76973 = h;
        long double r76974 = l;
        long double r76975 = r76973 / r76974;
        long double r76976 = r76972 * r76975;
        long double r76977 = r76968 * r76976;
        long double r76978 = r76964 - r76977;
        long double r76979 = sqrt(r76978);
        long double r76980 = r76963 * r76979;
        return r76980;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r76981, r76982, r76983, r76984, r76985, r76986, r76987, r76988, r76989, r76990, r76991, r76992, r76993, r76994, r76995, r76996, r76997;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r76981);
        mpfr_init(r76982);
        mpfr_init(r76983);
        mpfr_init(r76984);
        mpfr_init(r76985);
        mpfr_init(r76986);
        mpfr_init(r76987);
        mpfr_init(r76988);
        mpfr_init(r76989);
        mpfr_init(r76990);
        mpfr_init(r76991);
        mpfr_init(r76992);
        mpfr_init(r76993);
        mpfr_init(r76994);
        mpfr_init(r76995);
        mpfr_init(r76996);
        mpfr_init(r76997);
}

double f_im(float w0, float M, float D, float h, float l, float d) {
        mpfr_set_flt(r76981, w0, MPFR_RNDN);
        mpfr_init_set_str(r76982, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r76983, M, MPFR_RNDN);
        mpfr_set_flt(r76984, D, MPFR_RNDN);
        mpfr_mul(r76985, r76983, r76984, MPFR_RNDN);
        mpfr_init_set_str(r76986, "2", 10, MPFR_RNDN);
        mpfr_set_flt(r76987, d, MPFR_RNDN);
        mpfr_mul(r76988, r76986, r76987, MPFR_RNDN);
        mpfr_div(r76989, r76985, r76988, MPFR_RNDN);
        mpfr_mul(r76990, r76989, r76989, MPFR_RNDN);
        mpfr_set_flt(r76991, h, MPFR_RNDN);
        mpfr_set_flt(r76992, l, MPFR_RNDN);
        mpfr_div(r76993, r76991, r76992, MPFR_RNDN);
        mpfr_mul(r76994, r76990, r76993, MPFR_RNDN);
        mpfr_sub(r76995, r76982, r76994, MPFR_RNDN);
        mpfr_sqrt(r76996, r76995, MPFR_RNDN);
        mpfr_mul(r76997, r76981, r76996, MPFR_RNDN);
        return mpfr_get_d(r76997, MPFR_RNDN);
}

