#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Maksimov and Kolovsky, Equation (4) */

double f_if(float J, float l, float K, float U) {
        float r79737 = J;
        float r79738 = l;
        float r79739 = exp(r79738);
        float r79740 = -r79738;
        float r79741 = exp(r79740);
        float r79742 = r79739 - r79741;
        float r79743 = r79737 * r79742;
        float r79744 = K;
        float r79745 = 2.0;
        float r79746 = r79744 / r79745;
        float r79747 = cos(r79746);
        float r79748 = r79743 * r79747;
        float r79749 = U;
        float r79750 = r79748 + r79749;
        return r79750;
}

double f_id(float J, float l, float K, float U) {
        double r79751 = J;
        double r79752 = l;
        double r79753 = exp(r79752);
        double r79754 = -r79752;
        double r79755 = exp(r79754);
        double r79756 = r79753 - r79755;
        double r79757 = r79751 * r79756;
        double r79758 = K;
        double r79759 = 2.0;
        double r79760 = r79758 / r79759;
        double r79761 = cos(r79760);
        double r79762 = r79757 * r79761;
        double r79763 = U;
        double r79764 = r79762 + r79763;
        return r79764;
}

double f_il(float J, float l, float K, float U) {
        long double r79765 = J;
        long double r79766 = l;
        long double r79767 = exp(r79766);
        long double r79768 = -r79766;
        long double r79769 = exp(r79768);
        long double r79770 = r79767 - r79769;
        long double r79771 = r79765 * r79770;
        long double r79772 = K;
        long double r79773 = 2.0;
        long double r79774 = r79772 / r79773;
        long double r79775 = cos(r79774);
        long double r79776 = r79771 * r79775;
        long double r79777 = U;
        long double r79778 = r79776 + r79777;
        return r79778;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float J, float l, float K, float U) {
        float r79779 = K;
        float r79780 = 0.5;
        float r79781 = r79779 * r79780;
        float r79782 = cos(r79781);
        float r79783 = J;
        float r79784 = l;
        float r79785 = exp(r79784);
        float r79786 = r79783 * r79785;
        float r79787 = r79782 * r79786;
        float r79788 = r79783 / r79785;
        float r79789 = r79782 * r79788;
        float r79790 = r79787 - r79789;
        float r79791 = U;
        float r79792 = r79790 + r79791;
        return r79792;
}

double f_od(float J, float l, float K, float U) {
        double r79793 = K;
        double r79794 = 0.5;
        double r79795 = r79793 * r79794;
        double r79796 = cos(r79795);
        double r79797 = J;
        double r79798 = l;
        double r79799 = exp(r79798);
        double r79800 = r79797 * r79799;
        double r79801 = r79796 * r79800;
        double r79802 = r79797 / r79799;
        double r79803 = r79796 * r79802;
        double r79804 = r79801 - r79803;
        double r79805 = U;
        double r79806 = r79804 + r79805;
        return r79806;
}

double f_ol(float J, float l, float K, float U) {
        long double r79807 = K;
        long double r79808 = 0.5;
        long double r79809 = r79807 * r79808;
        long double r79810 = cos(r79809);
        long double r79811 = J;
        long double r79812 = l;
        long double r79813 = exp(r79812);
        long double r79814 = r79811 * r79813;
        long double r79815 = r79810 * r79814;
        long double r79816 = r79811 / r79813;
        long double r79817 = r79810 * r79816;
        long double r79818 = r79815 - r79817;
        long double r79819 = U;
        long double r79820 = r79818 + r79819;
        return r79820;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r79821, r79822, r79823, r79824, r79825, r79826, r79827, r79828, r79829, r79830, r79831, r79832, r79833, r79834;

void setup_mpfr() {
        mpfr_set_default_prec(200);
        mpfr_init(r79821);
        mpfr_init(r79822);
        mpfr_init(r79823);
        mpfr_init(r79824);
        mpfr_init(r79825);
        mpfr_init(r79826);
        mpfr_init(r79827);
        mpfr_init(r79828);
        mpfr_init(r79829);
        mpfr_init(r79830);
        mpfr_init(r79831);
        mpfr_init(r79832);
        mpfr_init(r79833);
        mpfr_init(r79834);
}

double f_im(float J, float l, float K, float U) {
        mpfr_set_flt(r79821, J, MPFR_RNDN);
        mpfr_set_flt(r79822, l, MPFR_RNDN);
        mpfr_exp(r79823, r79822, MPFR_RNDN);
        mpfr_neg(r79824, r79822, MPFR_RNDN);
        mpfr_exp(r79825, r79824, MPFR_RNDN);
        mpfr_sub(r79826, r79823, r79825, MPFR_RNDN);
        mpfr_mul(r79827, r79821, r79826, MPFR_RNDN);
        mpfr_set_flt(r79828, K, MPFR_RNDN);
        mpfr_init_set_str(r79829, "2", 10, MPFR_RNDN);
        mpfr_div(r79830, r79828, r79829, MPFR_RNDN);
        mpfr_cos(r79831, r79830, MPFR_RNDN);
        mpfr_mul(r79832, r79827, r79831, MPFR_RNDN);
        mpfr_set_flt(r79833, U, MPFR_RNDN);
        mpfr_add(r79834, r79832, r79833, MPFR_RNDN);
        return mpfr_get_d(r79834, MPFR_RNDN);
}

