#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* VandenBroeck and Keller, Equation (23) */

double f_if(float F, float B, float x) {
        float r84096 = x;
        float r84097 = B;
        float r84098 = 1.0 / tan(r84097);
        float r84099 = r84096 * r84098;
        float r84100 = -r84099;
        float r84101 = F;
        float r84102 = sin(r84097);
        float r84103 = r84101 / r84102;
        float r84104 = r84101 * r84101;
        float r84105 = 2.0;
        float r84106 = r84104 + r84105;
        float r84107 = r84105 * r84096;
        float r84108 = r84106 + r84107;
        float r84109 = 1.0;
        float r84110 = r84109 / r84105;
        float r84111 = -r84110;
        float r84112 = pow(r84108, r84111);
        float r84113 = r84103 * r84112;
        float r84114 = r84100 + r84113;
        return r84114;
}

double f_id(float F, float B, float x) {
        double r84115 = x;
        double r84116 = B;
        double r84117 = 1.0 / tan(r84116);
        double r84118 = r84115 * r84117;
        double r84119 = -r84118;
        double r84120 = F;
        double r84121 = sin(r84116);
        double r84122 = r84120 / r84121;
        double r84123 = r84120 * r84120;
        double r84124 = 2.0;
        double r84125 = r84123 + r84124;
        double r84126 = r84124 * r84115;
        double r84127 = r84125 + r84126;
        double r84128 = 1.0;
        double r84129 = r84128 / r84124;
        double r84130 = -r84129;
        double r84131 = pow(r84127, r84130);
        double r84132 = r84122 * r84131;
        double r84133 = r84119 + r84132;
        return r84133;
}

double f_il(float F, float B, float x) {
        long double r84134 = x;
        long double r84135 = B;
        long double r84136 = 1.0 / tan(r84135);
        long double r84137 = r84134 * r84136;
        long double r84138 = -r84137;
        long double r84139 = F;
        long double r84140 = sin(r84135);
        long double r84141 = r84139 / r84140;
        long double r84142 = r84139 * r84139;
        long double r84143 = 2.0;
        long double r84144 = r84142 + r84143;
        long double r84145 = r84143 * r84134;
        long double r84146 = r84144 + r84145;
        long double r84147 = 1.0;
        long double r84148 = r84147 / r84143;
        long double r84149 = -r84148;
        long double r84150 = pow(r84146, r84149);
        long double r84151 = r84141 * r84150;
        long double r84152 = r84138 + r84151;
        return r84152;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float F, float B, float x) {
        float r84153 = x;
        float r84154 = B;
        float r84155 = 1.0 / tan(r84154);
        float r84156 = r84153 * r84155;
        float r84157 = -r84156;
        float r84158 = F;
        float r84159 = r84158 * r84158;
        float r84160 = 2.0;
        float r84161 = r84159 + r84160;
        float r84162 = r84160 * r84153;
        float r84163 = r84161 + r84162;
        float r84164 = -0.5;
        float r84165 = pow(r84163, r84164);
        float r84166 = r84158 * r84165;
        float r84167 = sin(r84154);
        float r84168 = r84166 / r84167;
        float r84169 = r84157 + r84168;
        return r84169;
}

double f_od(float F, float B, float x) {
        double r84170 = x;
        double r84171 = B;
        double r84172 = 1.0 / tan(r84171);
        double r84173 = r84170 * r84172;
        double r84174 = -r84173;
        double r84175 = F;
        double r84176 = r84175 * r84175;
        double r84177 = 2.0;
        double r84178 = r84176 + r84177;
        double r84179 = r84177 * r84170;
        double r84180 = r84178 + r84179;
        double r84181 = -0.5;
        double r84182 = pow(r84180, r84181);
        double r84183 = r84175 * r84182;
        double r84184 = sin(r84171);
        double r84185 = r84183 / r84184;
        double r84186 = r84174 + r84185;
        return r84186;
}

double f_ol(float F, float B, float x) {
        long double r84187 = x;
        long double r84188 = B;
        long double r84189 = 1.0 / tan(r84188);
        long double r84190 = r84187 * r84189;
        long double r84191 = -r84190;
        long double r84192 = F;
        long double r84193 = r84192 * r84192;
        long double r84194 = 2.0;
        long double r84195 = r84193 + r84194;
        long double r84196 = r84194 * r84187;
        long double r84197 = r84195 + r84196;
        long double r84198 = -0.5;
        long double r84199 = pow(r84197, r84198);
        long double r84200 = r84192 * r84199;
        long double r84201 = sin(r84188);
        long double r84202 = r84200 / r84201;
        long double r84203 = r84191 + r84202;
        return r84203;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r84204, r84205, r84206, r84207, r84208, r84209, r84210, r84211, r84212, r84213, r84214, r84215, r84216, r84217, r84218, r84219, r84220, r84221, r84222;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r84204);
        mpfr_init(r84205);
        mpfr_init(r84206);
        mpfr_init(r84207);
        mpfr_init(r84208);
        mpfr_init(r84209);
        mpfr_init(r84210);
        mpfr_init(r84211);
        mpfr_init(r84212);
        mpfr_init(r84213);
        mpfr_init(r84214);
        mpfr_init(r84215);
        mpfr_init(r84216);
        mpfr_init(r84217);
        mpfr_init(r84218);
        mpfr_init(r84219);
        mpfr_init(r84220);
        mpfr_init(r84221);
        mpfr_init(r84222);
}

double f_im(float F, float B, float x) {
        mpfr_set_flt(r84204, x, MPFR_RNDN);
        mpfr_set_flt(r84205, B, MPFR_RNDN);
        mpfr_cot(r84206, r84205, MPFR_RNDN);
        mpfr_mul(r84207, r84204, r84206, MPFR_RNDN);
        mpfr_neg(r84208, r84207, MPFR_RNDN);
        mpfr_set_flt(r84209, F, MPFR_RNDN);
        mpfr_sin(r84210, r84205, MPFR_RNDN);
        mpfr_div(r84211, r84209, r84210, MPFR_RNDN);
        mpfr_mul(r84212, r84209, r84209, MPFR_RNDN);
        mpfr_init_set_str(r84213, "2", 10, MPFR_RNDN);
        mpfr_add(r84214, r84212, r84213, MPFR_RNDN);
        mpfr_mul(r84215, r84213, r84204, MPFR_RNDN);
        mpfr_add(r84216, r84214, r84215, MPFR_RNDN);
        mpfr_init_set_str(r84217, "1", 10, MPFR_RNDN);
        mpfr_div(r84218, r84217, r84213, MPFR_RNDN);
        mpfr_neg(r84219, r84218, MPFR_RNDN);
        mpfr_pow(r84220, r84216, r84219, MPFR_RNDN);
        mpfr_mul(r84221, r84211, r84220, MPFR_RNDN);
        mpfr_add(r84222, r84208, r84221, MPFR_RNDN);
        return mpfr_get_d(r84222, MPFR_RNDN);
}

