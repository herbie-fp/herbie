#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.sin on complex, real part */

double f_if(float re, float im) {
        float r86106 = 0.5;
        float r86107 = re;
        float r86108 = sin(r86107);
        float r86109 = r86106 * r86108;
        float r86110 = 0.0;
        float r86111 = im;
        float r86112 = r86110 - r86111;
        float r86113 = exp(r86112);
        float r86114 = exp(r86111);
        float r86115 = r86113 + r86114;
        float r86116 = r86109 * r86115;
        return r86116;
}

double f_id(float re, float im) {
        double r86117 = 0.5;
        double r86118 = re;
        double r86119 = sin(r86118);
        double r86120 = r86117 * r86119;
        double r86121 = 0.0;
        double r86122 = im;
        double r86123 = r86121 - r86122;
        double r86124 = exp(r86123);
        double r86125 = exp(r86122);
        double r86126 = r86124 + r86125;
        double r86127 = r86120 * r86126;
        return r86127;
}

double f_il(float re, float im) {
        long double r86128 = 0.5;
        long double r86129 = re;
        long double r86130 = sin(r86129);
        long double r86131 = r86128 * r86130;
        long double r86132 = 0.0;
        long double r86133 = im;
        long double r86134 = r86132 - r86133;
        long double r86135 = exp(r86134);
        long double r86136 = exp(r86133);
        long double r86137 = r86135 + r86136;
        long double r86138 = r86131 * r86137;
        return r86138;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r86139 = 0.5;
        float r86140 = re;
        float r86141 = sin(r86140);
        float r86142 = r86139 * r86141;
        float r86143 = im;
        float r86144 = exp(r86143);
        float r86145 = 1.0/r86144;
        float r86146 = r86145 + r86144;
        float r86147 = r86142 * r86146;
        return r86147;
}

double f_od(float re, float im) {
        double r86148 = 0.5;
        double r86149 = re;
        double r86150 = sin(r86149);
        double r86151 = r86148 * r86150;
        double r86152 = im;
        double r86153 = exp(r86152);
        double r86154 = 1.0/r86153;
        double r86155 = r86154 + r86153;
        double r86156 = r86151 * r86155;
        return r86156;
}

double f_ol(float re, float im) {
        long double r86157 = 0.5;
        long double r86158 = re;
        long double r86159 = sin(r86158);
        long double r86160 = r86157 * r86159;
        long double r86161 = im;
        long double r86162 = exp(r86161);
        long double r86163 = 1.0/r86162;
        long double r86164 = r86163 + r86162;
        long double r86165 = r86160 * r86164;
        return r86165;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r86166, r86167, r86168, r86169, r86170, r86171, r86172, r86173, r86174, r86175, r86176;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r86166);
        mpfr_init(r86167);
        mpfr_init(r86168);
        mpfr_init(r86169);
        mpfr_init(r86170);
        mpfr_init(r86171);
        mpfr_init(r86172);
        mpfr_init(r86173);
        mpfr_init(r86174);
        mpfr_init(r86175);
        mpfr_init(r86176);
}

double f_im(float re, float im) {
        mpfr_init_set_str(r86166, "0.5", 10, MPFR_RNDN);
        mpfr_set_flt(r86167, re, MPFR_RNDN);
        mpfr_sin(r86168, r86167, MPFR_RNDN);
        mpfr_mul(r86169, r86166, r86168, MPFR_RNDN);
        mpfr_init_set_str(r86170, "0", 10, MPFR_RNDN);
        mpfr_set_flt(r86171, im, MPFR_RNDN);
        mpfr_sub(r86172, r86170, r86171, MPFR_RNDN);
        mpfr_exp(r86173, r86172, MPFR_RNDN);
        mpfr_exp(r86174, r86171, MPFR_RNDN);
        mpfr_add(r86175, r86173, r86174, MPFR_RNDN);
        mpfr_mul(r86176, r86169, r86175, MPFR_RNDN);
        return mpfr_get_d(r86176, MPFR_RNDN);
}

