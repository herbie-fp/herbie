#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Toniolo and Linder, Equation (10+) */

double f_if(float t, float l, float k) {
        float r82848 = 2.0;
        float r82849 = t;
        float r82850 = 3.0;
        float r82851 = pow(r82849, r82850);
        float r82852 = l;
        float r82853 = r82852 * r82852;
        float r82854 = r82851 / r82853;
        float r82855 = k;
        float r82856 = sin(r82855);
        float r82857 = r82854 * r82856;
        float r82858 = tan(r82855);
        float r82859 = r82857 * r82858;
        float r82860 = 1.0;
        float r82861 = r82855 / r82849;
        float r82862 = r82861 * r82861;
        float r82863 = r82860 + r82862;
        float r82864 = r82863 + r82860;
        float r82865 = r82859 * r82864;
        float r82866 = r82848 / r82865;
        return r82866;
}

double f_id(float t, float l, float k) {
        double r82867 = 2.0;
        double r82868 = t;
        double r82869 = 3.0;
        double r82870 = pow(r82868, r82869);
        double r82871 = l;
        double r82872 = r82871 * r82871;
        double r82873 = r82870 / r82872;
        double r82874 = k;
        double r82875 = sin(r82874);
        double r82876 = r82873 * r82875;
        double r82877 = tan(r82874);
        double r82878 = r82876 * r82877;
        double r82879 = 1.0;
        double r82880 = r82874 / r82868;
        double r82881 = r82880 * r82880;
        double r82882 = r82879 + r82881;
        double r82883 = r82882 + r82879;
        double r82884 = r82878 * r82883;
        double r82885 = r82867 / r82884;
        return r82885;
}

double f_il(float t, float l, float k) {
        long double r82886 = 2.0;
        long double r82887 = t;
        long double r82888 = 3.0;
        long double r82889 = pow(r82887, r82888);
        long double r82890 = l;
        long double r82891 = r82890 * r82890;
        long double r82892 = r82889 / r82891;
        long double r82893 = k;
        long double r82894 = sin(r82893);
        long double r82895 = r82892 * r82894;
        long double r82896 = tan(r82893);
        long double r82897 = r82895 * r82896;
        long double r82898 = 1.0;
        long double r82899 = r82893 / r82887;
        long double r82900 = r82899 * r82899;
        long double r82901 = r82898 + r82900;
        long double r82902 = r82901 + r82898;
        long double r82903 = r82897 * r82902;
        long double r82904 = r82886 / r82903;
        return r82904;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float t, float l, float k) {
        float r82905 = t;
        float r82906 = -6.968214905354539e+21;
        bool r82907 = r82905 < r82906;
        float r82908 = 2.0;
        float r82909 = 3.0;
        float r82910 = pow(r82905, r82909);
        float r82911 = l;
        float r82912 = r82910 / r82911;
        float r82913 = k;
        float r82914 = sin(r82913);
        float r82915 = r82914 / r82911;
        float r82916 = r82912 * r82915;
        float r82917 = tan(r82913);
        float r82918 = r82916 * r82917;
        float r82919 = 1.0;
        float r82920 = r82913 / r82905;
        float r82921 = r82920 * r82920;
        float r82922 = r82919 + r82921;
        float r82923 = r82922 + r82919;
        float r82924 = r82918 * r82923;
        float r82925 = r82908 / r82924;
        float r82926 = -9.161047768334243e+16;
        bool r82927 = r82905 < r82926;
        float r82928 = r82910 * r82914;
        float r82929 = r82911 * r82911;
        float r82930 = r82928 / r82929;
        float r82931 = r82930 * r82917;
        float r82932 = r82931 * r82923;
        float r82933 = r82908 / r82932;
        float r82934 = -6.141236723096619e-32;
        bool r82935 = r82905 < r82934;
        float r82936 = r82935 ? r82925 : r82933;
        float r82937 = r82927 ? r82933 : r82936;
        float r82938 = r82907 ? r82925 : r82937;
        return r82938;
}

double f_od(float t, float l, float k) {
        double r82939 = t;
        double r82940 = -6.968214905354539e+21;
        bool r82941 = r82939 < r82940;
        double r82942 = 2.0;
        double r82943 = 3.0;
        double r82944 = pow(r82939, r82943);
        double r82945 = l;
        double r82946 = r82944 / r82945;
        double r82947 = k;
        double r82948 = sin(r82947);
        double r82949 = r82948 / r82945;
        double r82950 = r82946 * r82949;
        double r82951 = tan(r82947);
        double r82952 = r82950 * r82951;
        double r82953 = 1.0;
        double r82954 = r82947 / r82939;
        double r82955 = r82954 * r82954;
        double r82956 = r82953 + r82955;
        double r82957 = r82956 + r82953;
        double r82958 = r82952 * r82957;
        double r82959 = r82942 / r82958;
        double r82960 = -9.161047768334243e+16;
        bool r82961 = r82939 < r82960;
        double r82962 = r82944 * r82948;
        double r82963 = r82945 * r82945;
        double r82964 = r82962 / r82963;
        double r82965 = r82964 * r82951;
        double r82966 = r82965 * r82957;
        double r82967 = r82942 / r82966;
        double r82968 = -6.141236723096619e-32;
        bool r82969 = r82939 < r82968;
        double r82970 = r82969 ? r82959 : r82967;
        double r82971 = r82961 ? r82967 : r82970;
        double r82972 = r82941 ? r82959 : r82971;
        return r82972;
}

double f_ol(float t, float l, float k) {
        long double r82973 = t;
        long double r82974 = -6.968214905354539e+21;
        bool r82975 = r82973 < r82974;
        long double r82976 = 2.0;
        long double r82977 = 3.0;
        long double r82978 = pow(r82973, r82977);
        long double r82979 = l;
        long double r82980 = r82978 / r82979;
        long double r82981 = k;
        long double r82982 = sin(r82981);
        long double r82983 = r82982 / r82979;
        long double r82984 = r82980 * r82983;
        long double r82985 = tan(r82981);
        long double r82986 = r82984 * r82985;
        long double r82987 = 1.0;
        long double r82988 = r82981 / r82973;
        long double r82989 = r82988 * r82988;
        long double r82990 = r82987 + r82989;
        long double r82991 = r82990 + r82987;
        long double r82992 = r82986 * r82991;
        long double r82993 = r82976 / r82992;
        long double r82994 = -9.161047768334243e+16;
        bool r82995 = r82973 < r82994;
        long double r82996 = r82978 * r82982;
        long double r82997 = r82979 * r82979;
        long double r82998 = r82996 / r82997;
        long double r82999 = r82998 * r82985;
        long double r83000 = r82999 * r82991;
        long double r83001 = r82976 / r83000;
        long double r83002 = -6.141236723096619e-32;
        bool r83003 = r82973 < r83002;
        long double r83004 = r83003 ? r82993 : r83001;
        long double r83005 = r82995 ? r83001 : r83004;
        long double r83006 = r82975 ? r82993 : r83005;
        return r83006;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r83007, r83008, r83009, r83010, r83011, r83012, r83013, r83014, r83015, r83016, r83017, r83018, r83019, r83020, r83021, r83022, r83023, r83024, r83025;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r83007);
        mpfr_init(r83008);
        mpfr_init(r83009);
        mpfr_init(r83010);
        mpfr_init(r83011);
        mpfr_init(r83012);
        mpfr_init(r83013);
        mpfr_init(r83014);
        mpfr_init(r83015);
        mpfr_init(r83016);
        mpfr_init(r83017);
        mpfr_init(r83018);
        mpfr_init(r83019);
        mpfr_init(r83020);
        mpfr_init(r83021);
        mpfr_init(r83022);
        mpfr_init(r83023);
        mpfr_init(r83024);
        mpfr_init(r83025);
}

double f_im(float t, float l, float k) {
        mpfr_init_set_str(r83007, "2", 10, MPFR_RNDN);
        mpfr_set_flt(r83008, t, MPFR_RNDN);
        mpfr_init_set_str(r83009, "3", 10, MPFR_RNDN);
        mpfr_pow(r83010, r83008, r83009, MPFR_RNDN);
        mpfr_set_flt(r83011, l, MPFR_RNDN);
        mpfr_mul(r83012, r83011, r83011, MPFR_RNDN);
        mpfr_div(r83013, r83010, r83012, MPFR_RNDN);
        mpfr_set_flt(r83014, k, MPFR_RNDN);
        mpfr_sin(r83015, r83014, MPFR_RNDN);
        mpfr_mul(r83016, r83013, r83015, MPFR_RNDN);
        mpfr_tan(r83017, r83014, MPFR_RNDN);
        mpfr_mul(r83018, r83016, r83017, MPFR_RNDN);
        mpfr_init_set_str(r83019, "1", 10, MPFR_RNDN);
        mpfr_div(r83020, r83014, r83008, MPFR_RNDN);
        mpfr_mul(r83021, r83020, r83020, MPFR_RNDN);
        mpfr_add(r83022, r83019, r83021, MPFR_RNDN);
        mpfr_add(r83023, r83022, r83019, MPFR_RNDN);
        mpfr_mul(r83024, r83018, r83023, MPFR_RNDN);
        mpfr_div(r83025, r83007, r83024, MPFR_RNDN);
        return mpfr_get_d(r83025, MPFR_RNDN);
}

