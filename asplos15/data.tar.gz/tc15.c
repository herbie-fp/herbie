#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Harley's example */

double f_if(float e_2B, float e_, float t, float s) {
        float r73024 = 1.0;
        float r73025 = s;
        float r73026 = -r73025;
        float r73027 = exp(r73026);
        float r73028 = r73024 + r73027;
        float r73029 = 1.0/r73028;
        float r73030 = e_2B;
        float r73031 = pow(r73029, r73030);
        float r73032 = r73024 - r73029;
        float r73033 = e_;
        float r73034 = pow(r73032, r73033);
        float r73035 = r73031 * r73034;
        float r73036 = t;
        float r73037 = -r73036;
        float r73038 = exp(r73037);
        float r73039 = r73024 + r73038;
        float r73040 = 1.0/r73039;
        float r73041 = pow(r73040, r73030);
        float r73042 = r73024 - r73040;
        float r73043 = pow(r73042, r73033);
        float r73044 = r73041 * r73043;
        float r73045 = r73035 / r73044;
        return r73045;
}

double f_id(float e_2B, float e_, float t, float s) {
        double r73046 = 1.0;
        double r73047 = s;
        double r73048 = -r73047;
        double r73049 = exp(r73048);
        double r73050 = r73046 + r73049;
        double r73051 = 1.0/r73050;
        double r73052 = e_2B;
        double r73053 = pow(r73051, r73052);
        double r73054 = r73046 - r73051;
        double r73055 = e_;
        double r73056 = pow(r73054, r73055);
        double r73057 = r73053 * r73056;
        double r73058 = t;
        double r73059 = -r73058;
        double r73060 = exp(r73059);
        double r73061 = r73046 + r73060;
        double r73062 = 1.0/r73061;
        double r73063 = pow(r73062, r73052);
        double r73064 = r73046 - r73062;
        double r73065 = pow(r73064, r73055);
        double r73066 = r73063 * r73065;
        double r73067 = r73057 / r73066;
        return r73067;
}

double f_il(float e_2B, float e_, float t, float s) {
        long double r73068 = 1.0;
        long double r73069 = s;
        long double r73070 = -r73069;
        long double r73071 = exp(r73070);
        long double r73072 = r73068 + r73071;
        long double r73073 = 1.0/r73072;
        long double r73074 = e_2B;
        long double r73075 = pow(r73073, r73074);
        long double r73076 = r73068 - r73073;
        long double r73077 = e_;
        long double r73078 = pow(r73076, r73077);
        long double r73079 = r73075 * r73078;
        long double r73080 = t;
        long double r73081 = -r73080;
        long double r73082 = exp(r73081);
        long double r73083 = r73068 + r73082;
        long double r73084 = 1.0/r73083;
        long double r73085 = pow(r73084, r73074);
        long double r73086 = r73068 - r73084;
        long double r73087 = pow(r73086, r73077);
        long double r73088 = r73085 * r73087;
        long double r73089 = r73079 / r73088;
        return r73089;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float e_2B, float e_, float t, float s) {
        float r73090 = 1.0;
        float r73091 = s;
        float r73092 = exp(r73091);
        float r73093 = r73090 / r73092;
        float r73094 = r73090 + r73093;
        float r73095 = r73090 / r73094;
        float r73096 = log(r73095);
        float r73097 = e_2B;
        float r73098 = r73096 * r73097;
        float r73099 = r73090 - r73095;
        float r73100 = log(r73099);
        float r73101 = e_;
        float r73102 = r73100 * r73101;
        float r73103 = r73098 + r73102;
        float r73104 = t;
        float r73105 = exp(r73104);
        float r73106 = r73090 / r73105;
        float r73107 = r73090 + r73106;
        float r73108 = r73090 / r73107;
        float r73109 = log(r73108);
        float r73110 = r73109 * r73097;
        float r73111 = r73090 - r73108;
        float r73112 = log(r73111);
        float r73113 = r73112 * r73101;
        float r73114 = r73110 + r73113;
        float r73115 = r73103 - r73114;
        float r73116 = exp(r73115);
        return r73116;
}

double f_od(float e_2B, float e_, float t, float s) {
        double r73117 = 1.0;
        double r73118 = s;
        double r73119 = exp(r73118);
        double r73120 = r73117 / r73119;
        double r73121 = r73117 + r73120;
        double r73122 = r73117 / r73121;
        double r73123 = log(r73122);
        double r73124 = e_2B;
        double r73125 = r73123 * r73124;
        double r73126 = r73117 - r73122;
        double r73127 = log(r73126);
        double r73128 = e_;
        double r73129 = r73127 * r73128;
        double r73130 = r73125 + r73129;
        double r73131 = t;
        double r73132 = exp(r73131);
        double r73133 = r73117 / r73132;
        double r73134 = r73117 + r73133;
        double r73135 = r73117 / r73134;
        double r73136 = log(r73135);
        double r73137 = r73136 * r73124;
        double r73138 = r73117 - r73135;
        double r73139 = log(r73138);
        double r73140 = r73139 * r73128;
        double r73141 = r73137 + r73140;
        double r73142 = r73130 - r73141;
        double r73143 = exp(r73142);
        return r73143;
}

double f_ol(float e_2B, float e_, float t, float s) {
        long double r73144 = 1.0;
        long double r73145 = s;
        long double r73146 = exp(r73145);
        long double r73147 = r73144 / r73146;
        long double r73148 = r73144 + r73147;
        long double r73149 = r73144 / r73148;
        long double r73150 = log(r73149);
        long double r73151 = e_2B;
        long double r73152 = r73150 * r73151;
        long double r73153 = r73144 - r73149;
        long double r73154 = log(r73153);
        long double r73155 = e_;
        long double r73156 = r73154 * r73155;
        long double r73157 = r73152 + r73156;
        long double r73158 = t;
        long double r73159 = exp(r73158);
        long double r73160 = r73144 / r73159;
        long double r73161 = r73144 + r73160;
        long double r73162 = r73144 / r73161;
        long double r73163 = log(r73162);
        long double r73164 = r73163 * r73151;
        long double r73165 = r73144 - r73162;
        long double r73166 = log(r73165);
        long double r73167 = r73166 * r73155;
        long double r73168 = r73164 + r73167;
        long double r73169 = r73157 - r73168;
        long double r73170 = exp(r73169);
        return r73170;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r73171, r73172, r73173, r73174, r73175, r73176, r73177, r73178, r73179, r73180, r73181, r73182, r73183, r73184, r73185, r73186, r73187, r73188, r73189, r73190, r73191, r73192;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r73171);
        mpfr_init(r73172);
        mpfr_init(r73173);
        mpfr_init(r73174);
        mpfr_init(r73175);
        mpfr_init(r73176);
        mpfr_init(r73177);
        mpfr_init(r73178);
        mpfr_init(r73179);
        mpfr_init(r73180);
        mpfr_init(r73181);
        mpfr_init(r73182);
        mpfr_init(r73183);
        mpfr_init(r73184);
        mpfr_init(r73185);
        mpfr_init(r73186);
        mpfr_init(r73187);
        mpfr_init(r73188);
        mpfr_init(r73189);
        mpfr_init(r73190);
        mpfr_init(r73191);
        mpfr_init(r73192);
}

double f_im(float e_2B, float e_, float t, float s) {
        mpfr_init_set_str(r73171, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r73172, s, MPFR_RNDN);
        mpfr_neg(r73173, r73172, MPFR_RNDN);
        mpfr_exp(r73174, r73173, MPFR_RNDN);
        mpfr_add(r73175, r73171, r73174, MPFR_RNDN);
        mpfr_ui_div(r73176, 1, r73175, MPFR_RNDN);
        mpfr_set_flt(r73177, e_2B, MPFR_RNDN);
        mpfr_pow(r73178, r73176, r73177, MPFR_RNDN);
        mpfr_sub(r73179, r73171, r73176, MPFR_RNDN);
        mpfr_set_flt(r73180, e_, MPFR_RNDN);
        mpfr_pow(r73181, r73179, r73180, MPFR_RNDN);
        mpfr_mul(r73182, r73178, r73181, MPFR_RNDN);
        mpfr_set_flt(r73183, t, MPFR_RNDN);
        mpfr_neg(r73184, r73183, MPFR_RNDN);
        mpfr_exp(r73185, r73184, MPFR_RNDN);
        mpfr_add(r73186, r73171, r73185, MPFR_RNDN);
        mpfr_ui_div(r73187, 1, r73186, MPFR_RNDN);
        mpfr_pow(r73188, r73187, r73177, MPFR_RNDN);
        mpfr_sub(r73189, r73171, r73187, MPFR_RNDN);
        mpfr_pow(r73190, r73189, r73180, MPFR_RNDN);
        mpfr_mul(r73191, r73188, r73190, MPFR_RNDN);
        mpfr_div(r73192, r73182, r73191, MPFR_RNDN);
        return mpfr_get_d(r73192, MPFR_RNDN);
}

