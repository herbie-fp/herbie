#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE problem 3.3.1 */

double f_if(float x) {
        float r74091 = 1.0;
        float r74092 = x;
        float r74093 = r74092 + r74091;
        float r74094 = r74091 / r74093;
        float r74095 = r74091 / r74092;
        float r74096 = r74094 - r74095;
        return r74096;
}

double f_id(float x) {
        double r74097 = 1.0;
        double r74098 = x;
        double r74099 = r74098 + r74097;
        double r74100 = r74097 / r74099;
        double r74101 = r74097 / r74098;
        double r74102 = r74100 - r74101;
        return r74102;
}

double f_il(float x) {
        long double r74103 = 1.0;
        long double r74104 = x;
        long double r74105 = r74104 + r74103;
        long double r74106 = r74103 / r74105;
        long double r74107 = r74103 / r74104;
        long double r74108 = r74106 - r74107;
        return r74108;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r74109 = -1.0;
        float r74110 = x;
        float r74111 = 1.0;
        float r74112 = r74110 + r74111;
        float r74113 = r74112 * r74110;
        float r74114 = r74109 / r74113;
        return r74114;
}

double f_od(float x) {
        double r74115 = -1.0;
        double r74116 = x;
        double r74117 = 1.0;
        double r74118 = r74116 + r74117;
        double r74119 = r74118 * r74116;
        double r74120 = r74115 / r74119;
        return r74120;
}

double f_ol(float x) {
        long double r74121 = -1.0;
        long double r74122 = x;
        long double r74123 = 1.0;
        long double r74124 = r74122 + r74123;
        long double r74125 = r74124 * r74122;
        long double r74126 = r74121 / r74125;
        return r74126;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r74127, r74128, r74129, r74130, r74131, r74132;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r74127);
        mpfr_init(r74128);
        mpfr_init(r74129);
        mpfr_init(r74130);
        mpfr_init(r74131);
        mpfr_init(r74132);
}

double f_im(float x) {
        mpfr_init_set_str(r74127, "1", 10, MPFR_RNDN);
        mpfr_set_flt(r74128, x, MPFR_RNDN);
        mpfr_add(r74129, r74128, r74127, MPFR_RNDN);
        mpfr_div(r74130, r74127, r74129, MPFR_RNDN);
        mpfr_div(r74131, r74127, r74128, MPFR_RNDN);
        mpfr_sub(r74132, r74130, r74131, MPFR_RNDN);
        return mpfr_get_d(r74132, MPFR_RNDN);
}

