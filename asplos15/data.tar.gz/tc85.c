#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Octave 3.8, jcobi/1 */

double f_if(float alpha, float beta) {
        float r81028 = beta;
        float r81029 = alpha;
        float r81030 = r81028 - r81029;
        float r81031 = r81029 + r81028;
        float r81032 = 2.0;
        float r81033 = r81031 + r81032;
        float r81034 = r81030 / r81033;
        float r81035 = 1.0;
        float r81036 = r81034 + r81035;
        float r81037 = r81036 / r81032;
        return r81037;
}

double f_id(float alpha, float beta) {
        double r81038 = beta;
        double r81039 = alpha;
        double r81040 = r81038 - r81039;
        double r81041 = r81039 + r81038;
        double r81042 = 2.0;
        double r81043 = r81041 + r81042;
        double r81044 = r81040 / r81043;
        double r81045 = 1.0;
        double r81046 = r81044 + r81045;
        double r81047 = r81046 / r81042;
        return r81047;
}

double f_il(float alpha, float beta) {
        long double r81048 = beta;
        long double r81049 = alpha;
        long double r81050 = r81048 - r81049;
        long double r81051 = r81049 + r81048;
        long double r81052 = 2.0;
        long double r81053 = r81051 + r81052;
        long double r81054 = r81050 / r81053;
        long double r81055 = 1.0;
        long double r81056 = r81054 + r81055;
        long double r81057 = r81056 / r81052;
        return r81057;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float alpha, float beta) {
        float r81058 = beta;
        float r81059 = alpha;
        float r81060 = r81059 + r81058;
        float r81061 = 2.0;
        float r81062 = r81060 + r81061;
        float r81063 = r81058 / r81062;
        float r81064 = r81059 / r81062;
        float r81065 = -r81064;
        float r81066 = 1.0;
        float r81067 = r81065 + r81066;
        float r81068 = r81063 + r81067;
        float r81069 = r81068 / r81061;
        return r81069;
}

double f_od(float alpha, float beta) {
        double r81070 = beta;
        double r81071 = alpha;
        double r81072 = r81071 + r81070;
        double r81073 = 2.0;
        double r81074 = r81072 + r81073;
        double r81075 = r81070 / r81074;
        double r81076 = r81071 / r81074;
        double r81077 = -r81076;
        double r81078 = 1.0;
        double r81079 = r81077 + r81078;
        double r81080 = r81075 + r81079;
        double r81081 = r81080 / r81073;
        return r81081;
}

double f_ol(float alpha, float beta) {
        long double r81082 = beta;
        long double r81083 = alpha;
        long double r81084 = r81083 + r81082;
        long double r81085 = 2.0;
        long double r81086 = r81084 + r81085;
        long double r81087 = r81082 / r81086;
        long double r81088 = r81083 / r81086;
        long double r81089 = -r81088;
        long double r81090 = 1.0;
        long double r81091 = r81089 + r81090;
        long double r81092 = r81087 + r81091;
        long double r81093 = r81092 / r81085;
        return r81093;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r81094, r81095, r81096, r81097, r81098, r81099, r81100, r81101, r81102, r81103;

void setup_mpfr() {
        mpfr_set_default_prec(216);
        mpfr_init(r81094);
        mpfr_init(r81095);
        mpfr_init(r81096);
        mpfr_init(r81097);
        mpfr_init(r81098);
        mpfr_init(r81099);
        mpfr_init(r81100);
        mpfr_init(r81101);
        mpfr_init(r81102);
        mpfr_init(r81103);
}

double f_im(float alpha, float beta) {
        mpfr_set_flt(r81094, beta, MPFR_RNDN);
        mpfr_set_flt(r81095, alpha, MPFR_RNDN);
        mpfr_sub(r81096, r81094, r81095, MPFR_RNDN);
        mpfr_add(r81097, r81095, r81094, MPFR_RNDN);
        mpfr_init_set_str(r81098, "2.0", 10, MPFR_RNDN);
        mpfr_add(r81099, r81097, r81098, MPFR_RNDN);
        mpfr_div(r81100, r81096, r81099, MPFR_RNDN);
        mpfr_init_set_str(r81101, "1.0", 10, MPFR_RNDN);
        mpfr_add(r81102, r81100, r81101, MPFR_RNDN);
        mpfr_div(r81103, r81102, r81098, MPFR_RNDN);
        return mpfr_get_d(r81103, MPFR_RNDN);
}

