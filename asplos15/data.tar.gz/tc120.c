#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.log/2 on complex, real part */

double f_if(float re, float im, float base) {
        float r85498 = re;
        float r85499 = r85498 * r85498;
        float r85500 = im;
        float r85501 = r85500 * r85500;
        float r85502 = r85499 + r85501;
        float r85503 = sqrt(r85502);
        float r85504 = log(r85503);
        float r85505 = base;
        float r85506 = log(r85505);
        float r85507 = r85504 * r85506;
        float r85508 = atan2(r85500, r85498);
        float r85509 = 0.0;
        float r85510 = r85508 * r85509;
        float r85511 = r85507 + r85510;
        float r85512 = r85506 * r85506;
        float r85513 = r85509 * r85509;
        float r85514 = r85512 + r85513;
        float r85515 = r85511 / r85514;
        return r85515;
}

double f_id(float re, float im, float base) {
        double r85516 = re;
        double r85517 = r85516 * r85516;
        double r85518 = im;
        double r85519 = r85518 * r85518;
        double r85520 = r85517 + r85519;
        double r85521 = sqrt(r85520);
        double r85522 = log(r85521);
        double r85523 = base;
        double r85524 = log(r85523);
        double r85525 = r85522 * r85524;
        double r85526 = atan2(r85518, r85516);
        double r85527 = 0.0;
        double r85528 = r85526 * r85527;
        double r85529 = r85525 + r85528;
        double r85530 = r85524 * r85524;
        double r85531 = r85527 * r85527;
        double r85532 = r85530 + r85531;
        double r85533 = r85529 / r85532;
        return r85533;
}

double f_il(float re, float im, float base) {
        long double r85534 = re;
        long double r85535 = r85534 * r85534;
        long double r85536 = im;
        long double r85537 = r85536 * r85536;
        long double r85538 = r85535 + r85537;
        long double r85539 = sqrt(r85538);
        long double r85540 = log(r85539);
        long double r85541 = base;
        long double r85542 = log(r85541);
        long double r85543 = r85540 * r85542;
        long double r85544 = atan2(r85536, r85534);
        long double r85545 = 0.0;
        long double r85546 = r85544 * r85545;
        long double r85547 = r85543 + r85546;
        long double r85548 = r85542 * r85542;
        long double r85549 = r85545 * r85545;
        long double r85550 = r85548 + r85549;
        long double r85551 = r85547 / r85550;
        return r85551;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im, float base) {
        float r85552 = re;
        float r85553 = r85552 * r85552;
        float r85554 = im;
        float r85555 = r85554 * r85554;
        float r85556 = r85553 + r85555;
        float r85557 = sqrt(r85556);
        float r85558 = log(r85557);
        float r85559 = base;
        float r85560 = log(r85559);
        float r85561 = r85558 * r85560;
        float r85562 = 1.0;
        float r85563 = 0.0;
        float r85564 = r85562 * r85563;
        float r85565 = r85561 + r85564;
        float r85566 = r85560 * r85560;
        float r85567 = r85563 * r85563;
        float r85568 = r85566 + r85567;
        float r85569 = 1.0/r85568;
        float r85570 = r85565 * r85569;
        return r85570;
}

double f_od(float re, float im, float base) {
        double r85571 = re;
        double r85572 = r85571 * r85571;
        double r85573 = im;
        double r85574 = r85573 * r85573;
        double r85575 = r85572 + r85574;
        double r85576 = sqrt(r85575);
        double r85577 = log(r85576);
        double r85578 = base;
        double r85579 = log(r85578);
        double r85580 = r85577 * r85579;
        double r85581 = 1.0;
        double r85582 = 0.0;
        double r85583 = r85581 * r85582;
        double r85584 = r85580 + r85583;
        double r85585 = r85579 * r85579;
        double r85586 = r85582 * r85582;
        double r85587 = r85585 + r85586;
        double r85588 = 1.0/r85587;
        double r85589 = r85584 * r85588;
        return r85589;
}

double f_ol(float re, float im, float base) {
        long double r85590 = re;
        long double r85591 = r85590 * r85590;
        long double r85592 = im;
        long double r85593 = r85592 * r85592;
        long double r85594 = r85591 + r85593;
        long double r85595 = sqrt(r85594);
        long double r85596 = log(r85595);
        long double r85597 = base;
        long double r85598 = log(r85597);
        long double r85599 = r85596 * r85598;
        long double r85600 = 1.0;
        long double r85601 = 0.0;
        long double r85602 = r85600 * r85601;
        long double r85603 = r85599 + r85602;
        long double r85604 = r85598 * r85598;
        long double r85605 = r85601 * r85601;
        long double r85606 = r85604 + r85605;
        long double r85607 = 1.0/r85606;
        long double r85608 = r85603 * r85607;
        return r85608;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r85609, r85610, r85611, r85612, r85613, r85614, r85615, r85616, r85617, r85618, r85619, r85620, r85621, r85622, r85623, r85624, r85625, r85626;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r85609);
        mpfr_init(r85610);
        mpfr_init(r85611);
        mpfr_init(r85612);
        mpfr_init(r85613);
        mpfr_init(r85614);
        mpfr_init(r85615);
        mpfr_init(r85616);
        mpfr_init(r85617);
        mpfr_init(r85618);
        mpfr_init(r85619);
        mpfr_init(r85620);
        mpfr_init(r85621);
        mpfr_init(r85622);
        mpfr_init(r85623);
        mpfr_init(r85624);
        mpfr_init(r85625);
        mpfr_init(r85626);
}

double f_im(float re, float im, float base) {
        mpfr_set_flt(r85609, re, MPFR_RNDN);
        mpfr_mul(r85610, r85609, r85609, MPFR_RNDN);
        mpfr_set_flt(r85611, im, MPFR_RNDN);
        mpfr_mul(r85612, r85611, r85611, MPFR_RNDN);
        mpfr_add(r85613, r85610, r85612, MPFR_RNDN);
        mpfr_sqrt(r85614, r85613, MPFR_RNDN);
        mpfr_log(r85615, r85614, MPFR_RNDN);
        mpfr_set_flt(r85616, base, MPFR_RNDN);
        mpfr_log(r85617, r85616, MPFR_RNDN);
        mpfr_mul(r85618, r85615, r85617, MPFR_RNDN);
        mpfr_atan2(r85619, r85611, r85609, MPFR_RNDN);
        mpfr_init_set_str(r85620, "0", 10, MPFR_RNDN);
        mpfr_mul(r85621, r85619, r85620, MPFR_RNDN);
        mpfr_add(r85622, r85618, r85621, MPFR_RNDN);
        mpfr_mul(r85623, r85617, r85617, MPFR_RNDN);
        mpfr_mul(r85624, r85620, r85620, MPFR_RNDN);
        mpfr_add(r85625, r85623, r85624, MPFR_RNDN);
        mpfr_div(r85626, r85622, r85625, MPFR_RNDN);
        return mpfr_get_d(r85626, MPFR_RNDN);
}

