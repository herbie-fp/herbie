#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* NMSE example 3.5 */

double f_if(float N) {
        float r73713 = N;
        float r73714 = 1.0;
        float r73715 = r73713 + r73714;
        float r73716 = atan(r73715);
        float r73717 = atan(r73713);
        float r73718 = r73716 - r73717;
        return r73718;
}

double f_id(float N) {
        double r73719 = N;
        double r73720 = 1.0;
        double r73721 = r73719 + r73720;
        double r73722 = atan(r73721);
        double r73723 = atan(r73719);
        double r73724 = r73722 - r73723;
        return r73724;
}

double f_il(float N) {
        long double r73725 = N;
        long double r73726 = 1.0;
        long double r73727 = r73725 + r73726;
        long double r73728 = atan(r73727);
        long double r73729 = atan(r73725);
        long double r73730 = r73728 - r73729;
        return r73730;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float N) {
        float r73731 = 1.0;
        float r73732 = N;
        float r73733 = r73732 * r73732;
        float r73734 = r73733 + r73732;
        float r73735 = r73731 + r73734;
        float r73736 = r73731 / r73735;
        float r73737 = atan(r73736);
        return r73737;
}

double f_od(float N) {
        double r73738 = 1.0;
        double r73739 = N;
        double r73740 = r73739 * r73739;
        double r73741 = r73740 + r73739;
        double r73742 = r73738 + r73741;
        double r73743 = r73738 / r73742;
        double r73744 = atan(r73743);
        return r73744;
}

double f_ol(float N) {
        long double r73745 = 1.0;
        long double r73746 = N;
        long double r73747 = r73746 * r73746;
        long double r73748 = r73747 + r73746;
        long double r73749 = r73745 + r73748;
        long double r73750 = r73745 / r73749;
        long double r73751 = atan(r73750);
        return r73751;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r73752, r73753, r73754, r73755, r73756, r73757;

void setup_mpfr() {
        mpfr_set_default_prec(344);
        mpfr_init(r73752);
        mpfr_init(r73753);
        mpfr_init(r73754);
        mpfr_init(r73755);
        mpfr_init(r73756);
        mpfr_init(r73757);
}

double f_im(float N) {
        mpfr_set_flt(r73752, N, MPFR_RNDN);
        mpfr_init_set_str(r73753, "1", 10, MPFR_RNDN);
        mpfr_add(r73754, r73752, r73753, MPFR_RNDN);
        mpfr_atan(r73755, r73754, MPFR_RNDN);
        mpfr_atan(r73756, r73752, MPFR_RNDN);
        mpfr_sub(r73757, r73755, r73756, MPFR_RNDN);
        return mpfr_get_d(r73757, MPFR_RNDN);
}

