#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.log10 on complex, real part */

double f_if(float re, float im) {
        float r85719 = re;
        float r85720 = r85719 * r85719;
        float r85721 = im;
        float r85722 = r85721 * r85721;
        float r85723 = r85720 + r85722;
        float r85724 = sqrt(r85723);
        float r85725 = log(r85724);
        float r85726 = 10.0;
        float r85727 = log(r85726);
        float r85728 = r85725 / r85727;
        return r85728;
}

double f_id(float re, float im) {
        double r85729 = re;
        double r85730 = r85729 * r85729;
        double r85731 = im;
        double r85732 = r85731 * r85731;
        double r85733 = r85730 + r85732;
        double r85734 = sqrt(r85733);
        double r85735 = log(r85734);
        double r85736 = 10.0;
        double r85737 = log(r85736);
        double r85738 = r85735 / r85737;
        return r85738;
}

double f_il(float re, float im) {
        long double r85739 = re;
        long double r85740 = r85739 * r85739;
        long double r85741 = im;
        long double r85742 = r85741 * r85741;
        long double r85743 = r85740 + r85742;
        long double r85744 = sqrt(r85743);
        long double r85745 = log(r85744);
        long double r85746 = 10.0;
        long double r85747 = log(r85746);
        long double r85748 = r85745 / r85747;
        return r85748;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r85749 = re;
        float r85750 = r85749 * r85749;
        float r85751 = im;
        float r85752 = r85751 * r85751;
        float r85753 = r85750 + r85752;
        float r85754 = sqrt(r85753);
        float r85755 = log(r85754);
        float r85756 = 0.4342944819032518;
        float r85757 = r85755 * r85756;
        return r85757;
}

double f_od(float re, float im) {
        double r85758 = re;
        double r85759 = r85758 * r85758;
        double r85760 = im;
        double r85761 = r85760 * r85760;
        double r85762 = r85759 + r85761;
        double r85763 = sqrt(r85762);
        double r85764 = log(r85763);
        double r85765 = 0.4342944819032518;
        double r85766 = r85764 * r85765;
        return r85766;
}

double f_ol(float re, float im) {
        long double r85767 = re;
        long double r85768 = r85767 * r85767;
        long double r85769 = im;
        long double r85770 = r85769 * r85769;
        long double r85771 = r85768 + r85770;
        long double r85772 = sqrt(r85771);
        long double r85773 = log(r85772);
        long double r85774 = 0.4342944819032518;
        long double r85775 = r85773 * r85774;
        return r85775;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r85776, r85777, r85778, r85779, r85780, r85781, r85782, r85783, r85784, r85785;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r85776);
        mpfr_init(r85777);
        mpfr_init(r85778);
        mpfr_init(r85779);
        mpfr_init(r85780);
        mpfr_init(r85781);
        mpfr_init(r85782);
        mpfr_init(r85783);
        mpfr_init(r85784);
        mpfr_init(r85785);
}

double f_im(float re, float im) {
        mpfr_set_flt(r85776, re, MPFR_RNDN);
        mpfr_mul(r85777, r85776, r85776, MPFR_RNDN);
        mpfr_set_flt(r85778, im, MPFR_RNDN);
        mpfr_mul(r85779, r85778, r85778, MPFR_RNDN);
        mpfr_add(r85780, r85777, r85779, MPFR_RNDN);
        mpfr_sqrt(r85781, r85780, MPFR_RNDN);
        mpfr_log(r85782, r85781, MPFR_RNDN);
        mpfr_init_set_str(r85783, "10", 10, MPFR_RNDN);
        mpfr_log(r85784, r85783, MPFR_RNDN);
        mpfr_div(r85785, r85782, r85784, MPFR_RNDN);
        return mpfr_get_d(r85785, MPFR_RNDN);
}

