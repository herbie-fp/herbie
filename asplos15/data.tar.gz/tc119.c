#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.log/2 on complex, imaginary part */

double f_if(float re, float im, float base) {
        float r85356 = im;
        float r85357 = re;
        float r85358 = atan2(r85356, r85357);
        float r85359 = base;
        float r85360 = log(r85359);
        float r85361 = r85358 * r85360;
        float r85362 = r85357 * r85357;
        float r85363 = r85356 * r85356;
        float r85364 = r85362 + r85363;
        float r85365 = sqrt(r85364);
        float r85366 = log(r85365);
        float r85367 = 0.0;
        float r85368 = r85366 * r85367;
        float r85369 = r85361 - r85368;
        float r85370 = r85360 * r85360;
        float r85371 = r85367 * r85367;
        float r85372 = r85370 + r85371;
        float r85373 = r85369 / r85372;
        return r85373;
}

double f_id(float re, float im, float base) {
        double r85374 = im;
        double r85375 = re;
        double r85376 = atan2(r85374, r85375);
        double r85377 = base;
        double r85378 = log(r85377);
        double r85379 = r85376 * r85378;
        double r85380 = r85375 * r85375;
        double r85381 = r85374 * r85374;
        double r85382 = r85380 + r85381;
        double r85383 = sqrt(r85382);
        double r85384 = log(r85383);
        double r85385 = 0.0;
        double r85386 = r85384 * r85385;
        double r85387 = r85379 - r85386;
        double r85388 = r85378 * r85378;
        double r85389 = r85385 * r85385;
        double r85390 = r85388 + r85389;
        double r85391 = r85387 / r85390;
        return r85391;
}

double f_il(float re, float im, float base) {
        long double r85392 = im;
        long double r85393 = re;
        long double r85394 = atan2(r85392, r85393);
        long double r85395 = base;
        long double r85396 = log(r85395);
        long double r85397 = r85394 * r85396;
        long double r85398 = r85393 * r85393;
        long double r85399 = r85392 * r85392;
        long double r85400 = r85398 + r85399;
        long double r85401 = sqrt(r85400);
        long double r85402 = log(r85401);
        long double r85403 = 0.0;
        long double r85404 = r85402 * r85403;
        long double r85405 = r85397 - r85404;
        long double r85406 = r85396 * r85396;
        long double r85407 = r85403 * r85403;
        long double r85408 = r85406 + r85407;
        long double r85409 = r85405 / r85408;
        return r85409;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im, float base) {
        float r85410 = re;
        float r85411 = 1.1428477879034925e-15;
        bool r85412 = r85410 < r85411;
        float r85413 = im;
        float r85414 = atan2(r85413, r85410);
        float r85415 = r85414 * r85414;
        float r85416 = base;
        float r85417 = log(r85416);
        float r85418 = r85417 * r85417;
        float r85419 = r85415 * r85418;
        float r85420 = r85414 * r85417;
        float r85421 = r85419 / r85420;
        float r85422 = r85417 * r85417;
        float r85423 = 0.0;
        float r85424 = r85423 * r85423;
        float r85425 = r85422 + r85424;
        float r85426 = 1.0/r85425;
        float r85427 = r85421 * r85426;
        float r85428 = 0.5;
        float r85429 = r85428 * r85423;
        float r85430 = r85420 - r85429;
        float r85431 = r85430 / r85425;
        float r85432 = r85412 ? r85427 : r85431;
        return r85432;
}

double f_od(float re, float im, float base) {
        double r85433 = re;
        double r85434 = 1.1428477879034925e-15;
        bool r85435 = r85433 < r85434;
        double r85436 = im;
        double r85437 = atan2(r85436, r85433);
        double r85438 = r85437 * r85437;
        double r85439 = base;
        double r85440 = log(r85439);
        double r85441 = r85440 * r85440;
        double r85442 = r85438 * r85441;
        double r85443 = r85437 * r85440;
        double r85444 = r85442 / r85443;
        double r85445 = r85440 * r85440;
        double r85446 = 0.0;
        double r85447 = r85446 * r85446;
        double r85448 = r85445 + r85447;
        double r85449 = 1.0/r85448;
        double r85450 = r85444 * r85449;
        double r85451 = 0.5;
        double r85452 = r85451 * r85446;
        double r85453 = r85443 - r85452;
        double r85454 = r85453 / r85448;
        double r85455 = r85435 ? r85450 : r85454;
        return r85455;
}

double f_ol(float re, float im, float base) {
        long double r85456 = re;
        long double r85457 = 1.1428477879034925e-15;
        bool r85458 = r85456 < r85457;
        long double r85459 = im;
        long double r85460 = atan2(r85459, r85456);
        long double r85461 = r85460 * r85460;
        long double r85462 = base;
        long double r85463 = log(r85462);
        long double r85464 = r85463 * r85463;
        long double r85465 = r85461 * r85464;
        long double r85466 = r85460 * r85463;
        long double r85467 = r85465 / r85466;
        long double r85468 = r85463 * r85463;
        long double r85469 = 0.0;
        long double r85470 = r85469 * r85469;
        long double r85471 = r85468 + r85470;
        long double r85472 = 1.0/r85471;
        long double r85473 = r85467 * r85472;
        long double r85474 = 0.5;
        long double r85475 = r85474 * r85469;
        long double r85476 = r85466 - r85475;
        long double r85477 = r85476 / r85471;
        long double r85478 = r85458 ? r85473 : r85477;
        return r85478;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r85479, r85480, r85481, r85482, r85483, r85484, r85485, r85486, r85487, r85488, r85489, r85490, r85491, r85492, r85493, r85494, r85495, r85496;

void setup_mpfr() {
        mpfr_set_default_prec(104);
        mpfr_init(r85479);
        mpfr_init(r85480);
        mpfr_init(r85481);
        mpfr_init(r85482);
        mpfr_init(r85483);
        mpfr_init(r85484);
        mpfr_init(r85485);
        mpfr_init(r85486);
        mpfr_init(r85487);
        mpfr_init(r85488);
        mpfr_init(r85489);
        mpfr_init(r85490);
        mpfr_init(r85491);
        mpfr_init(r85492);
        mpfr_init(r85493);
        mpfr_init(r85494);
        mpfr_init(r85495);
        mpfr_init(r85496);
}

double f_im(float re, float im, float base) {
        mpfr_set_flt(r85479, im, MPFR_RNDN);
        mpfr_set_flt(r85480, re, MPFR_RNDN);
        mpfr_atan2(r85481, r85479, r85480, MPFR_RNDN);
        mpfr_set_flt(r85482, base, MPFR_RNDN);
        mpfr_log(r85483, r85482, MPFR_RNDN);
        mpfr_mul(r85484, r85481, r85483, MPFR_RNDN);
        mpfr_mul(r85485, r85480, r85480, MPFR_RNDN);
        mpfr_mul(r85486, r85479, r85479, MPFR_RNDN);
        mpfr_add(r85487, r85485, r85486, MPFR_RNDN);
        mpfr_sqrt(r85488, r85487, MPFR_RNDN);
        mpfr_log(r85489, r85488, MPFR_RNDN);
        mpfr_init_set_str(r85490, "0", 10, MPFR_RNDN);
        mpfr_mul(r85491, r85489, r85490, MPFR_RNDN);
        mpfr_sub(r85492, r85484, r85491, MPFR_RNDN);
        mpfr_mul(r85493, r85483, r85483, MPFR_RNDN);
        mpfr_mul(r85494, r85490, r85490, MPFR_RNDN);
        mpfr_add(r85495, r85493, r85494, MPFR_RNDN);
        mpfr_div(r85496, r85492, r85495, MPFR_RNDN);
        return mpfr_get_d(r85496, MPFR_RNDN);
}

