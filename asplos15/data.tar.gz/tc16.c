#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* Hyperbolic arcsine */

double f_if(float x) {
        float r73194 = x;
        float r73195 = r73194 * r73194;
        float r73196 = 1.0;
        float r73197 = r73195 + r73196;
        float r73198 = sqrt(r73197);
        float r73199 = r73194 + r73198;
        float r73200 = log(r73199);
        return r73200;
}

double f_id(float x) {
        double r73201 = x;
        double r73202 = r73201 * r73201;
        double r73203 = 1.0;
        double r73204 = r73202 + r73203;
        double r73205 = sqrt(r73204);
        double r73206 = r73201 + r73205;
        double r73207 = log(r73206);
        return r73207;
}

double f_il(float x) {
        long double r73208 = x;
        long double r73209 = r73208 * r73208;
        long double r73210 = 1.0;
        long double r73211 = r73209 + r73210;
        long double r73212 = sqrt(r73211);
        long double r73213 = r73208 + r73212;
        long double r73214 = log(r73213);
        return r73214;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float x) {
        float r73215 = x;
        float r73216 = -0.08995093186150388;
        bool r73217 = r73215 < r73216;
        float r73218 = 1.0;
        float r73219 = -1.0;
        float r73220 = r73218 * r73219;
        float r73221 = r73215 * r73215;
        float r73222 = r73221 + r73218;
        float r73223 = sqrt(r73222);
        float r73224 = r73215 - r73223;
        float r73225 = r73220 / r73224;
        float r73226 = log(r73225);
        float r73227 = r73215 + r73223;
        float r73228 = log(r73227);
        float r73229 = r73217 ? r73226 : r73228;
        return r73229;
}

double f_od(float x) {
        double r73230 = x;
        double r73231 = -0.08995093186150388;
        bool r73232 = r73230 < r73231;
        double r73233 = 1.0;
        double r73234 = -1.0;
        double r73235 = r73233 * r73234;
        double r73236 = r73230 * r73230;
        double r73237 = r73236 + r73233;
        double r73238 = sqrt(r73237);
        double r73239 = r73230 - r73238;
        double r73240 = r73235 / r73239;
        double r73241 = log(r73240);
        double r73242 = r73230 + r73238;
        double r73243 = log(r73242);
        double r73244 = r73232 ? r73241 : r73243;
        return r73244;
}

double f_ol(float x) {
        long double r73245 = x;
        long double r73246 = -0.08995093186150388;
        bool r73247 = r73245 < r73246;
        long double r73248 = 1.0;
        long double r73249 = -1.0;
        long double r73250 = r73248 * r73249;
        long double r73251 = r73245 * r73245;
        long double r73252 = r73251 + r73248;
        long double r73253 = sqrt(r73252);
        long double r73254 = r73245 - r73253;
        long double r73255 = r73250 / r73254;
        long double r73256 = log(r73255);
        long double r73257 = r73245 + r73253;
        long double r73258 = log(r73257);
        long double r73259 = r73247 ? r73256 : r73258;
        return r73259;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r73260, r73261, r73262, r73263, r73264, r73265, r73266;

void setup_mpfr() {
        mpfr_set_default_prec(328);
        mpfr_init(r73260);
        mpfr_init(r73261);
        mpfr_init(r73262);
        mpfr_init(r73263);
        mpfr_init(r73264);
        mpfr_init(r73265);
        mpfr_init(r73266);
}

double f_im(float x) {
        mpfr_set_flt(r73260, x, MPFR_RNDN);
        mpfr_mul(r73261, r73260, r73260, MPFR_RNDN);
        mpfr_init_set_str(r73262, "1", 10, MPFR_RNDN);
        mpfr_add(r73263, r73261, r73262, MPFR_RNDN);
        mpfr_sqrt(r73264, r73263, MPFR_RNDN);
        mpfr_add(r73265, r73260, r73264, MPFR_RNDN);
        mpfr_log(r73266, r73265, MPFR_RNDN);
        return mpfr_get_d(r73266, MPFR_RNDN);
}

