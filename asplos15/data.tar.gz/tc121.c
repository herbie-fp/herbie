#include <tgmath.h>
#include <gmp.h>
#include <mpfr.h>

#include <stdbool.h>

/* math.log10 on complex, imaginary part */

double f_if(float re, float im) {
        float r85628 = im;
        float r85629 = re;
        float r85630 = atan2(r85628, r85629);
        float r85631 = 10.0;
        float r85632 = log(r85631);
        float r85633 = r85630 / r85632;
        return r85633;
}

double f_id(float re, float im) {
        double r85634 = im;
        double r85635 = re;
        double r85636 = atan2(r85634, r85635);
        double r85637 = 10.0;
        double r85638 = log(r85637);
        double r85639 = r85636 / r85638;
        return r85639;
}

double f_il(float re, float im) {
        long double r85640 = im;
        long double r85641 = re;
        long double r85642 = atan2(r85640, r85641);
        long double r85643 = 10.0;
        long double r85644 = log(r85643);
        long double r85645 = r85642 / r85644;
        return r85645;
}

long double fmod2(long double n, long double d) {
        double r = fmodl(n, d);
        return r < 0 ? r + d : r;
}


double f_of(float re, float im) {
        float r85646 = re;
        float r85647 = 1.5809476077071226e-38;
        bool r85648 = r85646 < r85647;
        float r85649 = -0.011017152606901292;
        bool r85650 = r85646 < r85649;
        float r85651 = 2.0;
        float r85652 = sqrt(r85651);
        float r85653 = r85652 * r85652;
        float r85654 = 0.5;
        float r85655 = 0.43429448190325176;
        float r85656 = r85654 * r85655;
        float r85657 = im;
        float r85658 = atan2(r85657, r85646);
        float r85659 = r85656 * r85658;
        float r85660 = r85653 * r85659;
        float r85661 = r85658 * r85655;
        float r85662 = exp(r85661);
        float r85663 = sqrt(r85662);
        float r85664 = log(r85663);
        float r85665 = r85653 * r85664;
        float r85666 = r85650 ? r85660 : r85665;
        float r85667 = r85648 ? r85666 : r85661;
        return r85667;
}

double f_od(float re, float im) {
        double r85668 = re;
        double r85669 = 1.5809476077071226e-38;
        bool r85670 = r85668 < r85669;
        double r85671 = -0.011017152606901292;
        bool r85672 = r85668 < r85671;
        double r85673 = 2.0;
        double r85674 = sqrt(r85673);
        double r85675 = r85674 * r85674;
        double r85676 = 0.5;
        double r85677 = 0.43429448190325176;
        double r85678 = r85676 * r85677;
        double r85679 = im;
        double r85680 = atan2(r85679, r85668);
        double r85681 = r85678 * r85680;
        double r85682 = r85675 * r85681;
        double r85683 = r85680 * r85677;
        double r85684 = exp(r85683);
        double r85685 = sqrt(r85684);
        double r85686 = log(r85685);
        double r85687 = r85675 * r85686;
        double r85688 = r85672 ? r85682 : r85687;
        double r85689 = r85670 ? r85688 : r85683;
        return r85689;
}

double f_ol(float re, float im) {
        long double r85690 = re;
        long double r85691 = 1.5809476077071226e-38;
        bool r85692 = r85690 < r85691;
        long double r85693 = -0.011017152606901292;
        bool r85694 = r85690 < r85693;
        long double r85695 = 2.0;
        long double r85696 = sqrt(r85695);
        long double r85697 = r85696 * r85696;
        long double r85698 = 0.5;
        long double r85699 = 0.43429448190325176;
        long double r85700 = r85698 * r85699;
        long double r85701 = im;
        long double r85702 = atan2(r85701, r85690);
        long double r85703 = r85700 * r85702;
        long double r85704 = r85697 * r85703;
        long double r85705 = r85702 * r85699;
        long double r85706 = exp(r85705);
        long double r85707 = sqrt(r85706);
        long double r85708 = log(r85707);
        long double r85709 = r85697 * r85708;
        long double r85710 = r85694 ? r85704 : r85709;
        long double r85711 = r85692 ? r85710 : r85705;
        return r85711;
}

void mpfr_fmod2(mpfr_t r, mpfr_t n, mpfr_t d) {
        mpfr_fmod(r, n, d, MPFR_RNDN);
        if (mpfr_cmp_ui(r, 0) < 0) mpfr_add(r, r, d, MPFR_RNDN);
}


static mpfr_t r85712, r85713, r85714, r85715, r85716, r85717;

void setup_mpfr() {
        mpfr_set_default_prec(88);
        mpfr_init(r85712);
        mpfr_init(r85713);
        mpfr_init(r85714);
        mpfr_init(r85715);
        mpfr_init(r85716);
        mpfr_init(r85717);
}

double f_im(float re, float im) {
        mpfr_set_flt(r85712, im, MPFR_RNDN);
        mpfr_set_flt(r85713, re, MPFR_RNDN);
        mpfr_atan2(r85714, r85712, r85713, MPFR_RNDN);
        mpfr_init_set_str(r85715, "10", 10, MPFR_RNDN);
        mpfr_log(r85716, r85715, MPFR_RNDN);
        mpfr_div(r85717, r85714, r85716, MPFR_RNDN);
        return mpfr_get_d(r85717, MPFR_RNDN);
}

