/*
 *  align3d.c
 *  align3d
 *
 *  Created by Brian Ross on 2/15/08.
 *  Copyright 2008 __MyCompanyName__. All rights reserved.
 *
 */

#include <gsl/gsl_sf_gamma.h>
#include <gsl/gsl_multimin.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <float.h>
#include <math.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>
#include "align3d.h"
#include "LinMath.h"
#include "userfn.h"
#include "lnklst.h"
#include "Interpolation.h"
#include "lnklst.h"


double tiny = 1.e-15, tinylog = -100;

typedef struct {
    double *x, *y, *z, *dx, *dy, *dz;
    Ulong dots_num, *color_bottoms, *color_tops;
} field_type;

typedef struct {
    double *l;
    unsigned char *color, *mask;
    Ulong dots_num;
} contour_type;

typedef struct {
    linkedlist *p, *Z_1x, *Z_xN, *prop_u_or_d, *epsilon_1x, *epsilon_xN, *epsilon_1N, *Neighbors, *sensitivity;
    Ulong colors_num, neighbor_lengths_num, alpha_0, alpha_base, n_skip_max, alpha_0_base;
    double *CSumProbs, *FSumProbs, *Z_1x_norm, *Z_xN_norm, *Z, *dC_dZ, *sensitivity_norm, *calcs, *prop_u_or_d_norm;
    double *one_epsilon, *f, *grad_f, multiplier, dC_dZ_factor, lp, l_step, p_value, l, p_fn, fd_weight, other_norm;
    double NOF_length, w, K1, N_difference, *other_layer, w_norm, w_factor, exaggeration;
    unsigned char f_or_w, no_overlap_range;
    Slong boundary, direction, cdot_0, cdot, cdot_ext, *alphas;
    Boolean over_boundary, prop_mode, pa_SetGradWSource, *alpha_mask;
double *pLR;
} cc_params_type;

field_type field;
contour_type contour;
cc_params_type cc_params;

gsl_multimin_fminimizer *opt_struct_no_grad;
gsl_multimin_fdfminimizer *opt_struct_grad;
const gsl_rng_type *gsl_rand_gen_type;
gsl_rng *gsl_rand_gen;

const char pa_FillZ = 0, fa_CalcP = 0;
const char pa_BridgeZ = 1, fa_DivZ = 1;
const char pa_BridgeS = 2, fa_dC_dZ = 2;
const char pa_PropS = 3;
const char pa_Bridge_dC_dZ = 4;
const char pa_GetGradW = 5;
const char fa_SetS1x = 4;
const char fa_AddS1x = 5;
const char fa_SetSxN = 6;
const char fa_AddSxN = 7;

Boolean dbg = yz_false;
Ulong dbg1, dbg2;

extern void do_pLR(Ulong);


// *********** GetNeigbors() ***********

// Finds the neighbors of each spot and stores them in the Neighbors linked lists

int call_GetNeighbors(int argc, char **argv)
{
    Ulong c1;
    double p_cutoff;
	arg_info *ArgInfo;
	Boolean ArgsOK = yz_true;
    LL_retrn linkedLretrn;
    
	const signed long ArgTypes[] = { double_type, double_type, double_type, double_type, double_type, double_type,
                                                Ulong_type, Ulong_type, string_type, double_type, double_type, double_type };
	const signed long ArgIndices[] = { -1, -1, -1, -1, -1, -1, -2, -2, -3, 1, 1, 1 };
    const Ulong argc_target = sizeof(ArgTypes)/sizeof(long);
	
	ArgInfo = (arg_info *) *(argv+argc);
	
	if (argc != argc_target)  ArgsOK = yz_false;
	else if (CheckArgInfo(ArgInfo, ArgTypes, ArgIndices, argc) != passed)  ArgsOK = yz_false;
    
 	if (ArgsOK == yz_false)  {
		printf("usage: rtrn = call(\"GetNeighbors\", (doubles) x[], y[], z[], dx[], dy[], dz[], ");
		printf("(Ulongs) color_bottoms[], color_tops[], (string) Neighbors[], (double) l_step, p_cutoff, lp)\n");
		return 1;		}
	
	field.x = (double *) *(argv);
	field.y = (double *) *(argv+1);
	field.z = (double *) *(argv+2);
	field.dx = (double *) *(argv+3);
	field.dy = (double *) *(argv+4);
	field.dz = (double *) *(argv+5);
    
	field.color_bottoms = (Ulong *) *(argv+6);
	field.color_tops = (Ulong *) *(argv+7);
    
	cc_params.Neighbors = (linkedlist *) *(argv+8);
	cc_params.l_step = *(double *) *(argv+9);
	p_cutoff = *(double *) *(argv+10);
	cc_params.lp = *(double *) *(argv+11);
    
    cc_params.exaggeration = 1.;
    
	field.dots_num = ArgInfo->arg_indices;
    if (field.dots_num == 0)  {  printf("GetNeighbors error:  number of field dots must be greater than zero\n");  return 1;  }
    cc_params.colors_num = (ArgInfo+6)->arg_indices;
    cc_params.neighbor_lengths_num = ((ArgInfo+8)->arg_indices) / (field.dots_num*cc_params.colors_num);
    
    if ( (ArgInfo+8)->arg_indices < cc_params.neighbor_lengths_num*field.dots_num*cc_params.colors_num )     {
        printf("GetNeighbors() error: top(Neighbors[]) must be a multiple of field-dots-num * colors_num\n");
        return 3;           }
    
    for (c1 = 0; c1 < (ArgInfo+8)->arg_indices; c1++)     {
        if ( (cc_params.Neighbors+c1)->memory == 0 )
            linkedLretrn = NewLinkedList(cc_params.Neighbors+c1, 0, 1, 200, yz_true);
        else if ((cc_params.Neighbors+c1)->elementnum > 0)
            linkedLretrn = DeleteElements(cc_params.Neighbors+c1, 1, (cc_params.Neighbors+c1)->elementnum);
        if (linkedLretrn != passed)     
            {  printf("GetNeighbors(): out of memory\n");  return 6;  }
    }
	
    for (c1 = 0; c1 < field.dots_num; c1++)     {
        linkedLretrn = GetNeighbors(c1, p_cutoff, cc_params.Neighbors + (c1*cc_params.colors_num*cc_params.neighbor_lengths_num));
        if (linkedLretrn != passed)    
            {  printf("GetNeighbors():  out of memory\n");  return 8;  }           }
    
	return passed;
}


// GetNeighbors() finds the neighbors of a single given field spot, storing them in NeighborLL

LL_retrn GetNeighbors(Ulong StartingFD, double p_cutoff, linkedlist *NeighborLL)
{
    Ulong FieldDotCounter, l_counter, ColorCounter, longest_list, *PutFD;
    double L, calcs;
    linkedlist *theLL;
    LL_retrn linkedLretrn;
    
    cc_params.calcs = &calcs;
    
    for (ColorCounter = 0; ColorCounter < cc_params.colors_num; ColorCounter++)        {
    for (FieldDotCounter = *(field.color_bottoms+ColorCounter) - 1; FieldDotCounter < *(field.color_tops+ColorCounter); FieldDotCounter++)      {
    if (FieldDotCounter != StartingFD)      {

        longest_list = cc_params.neighbor_lengths_num;
        for (l_counter = 0; l_counter < cc_params.neighbor_lengths_num; l_counter++)       {
            L = (l_counter+1) * cc_params.l_step;
            if (GaussProb(L, StartingFD, FieldDotCounter, 1) >= p_cutoff)  {
                longest_list = l_counter;
                l_counter = cc_params.neighbor_lengths_num;
        }   }

        if (longest_list != cc_params.neighbor_lengths_num)       {

            theLL = NeighborLL + cc_params.neighbor_lengths_num*ColorCounter + longest_list;
            linkedLretrn = FAddElements(theLL, sizeof(Ulong), uncleared);
            if (linkedLretrn != passed)  return linkedLretrn;

            PutFD = (Ulong *) FElement(theLL, theLL->elementnum-sizeof(Ulong)+1);
            if (PutFD != (Ulong *) (((char *) FElement(theLL, theLL->elementnum)) - sizeof(Ulong) + 1))     {
                linkedLretrn = DefragmentLinkedList(theLL);
                if (linkedLretrn != passed)    
                    {  printf("GetNeighbors():  out of memory\n");  return 8;  }           }

            *PutFD = FieldDotCounter;            }
    }}}
    
    return passed;
}


// ForEachNeighbor() performs a given operation (ToDo()) for each neighbor of FDot, where the neighbor range is determined by 'l'

void ForEachNeighbor(Ulong FDot, double l, Ulong NeighborColor, void(*ToDo)(Ulong))
{
    Ulong MaxNeighborList, cNL, *loopNeighbor, ListTop, cN;
    linkedlist *loopLL;
    
    MaxNeighborList = floor(l / cc_params.l_step);
    
    if (cc_params.over_boundary == yz_true)  {
    for (cN = *(field.color_bottoms + NeighborColor) - 1; cN < *(field.color_tops + NeighborColor); cN++)  {
        ToDo(cN);
    }}
    
    else if (MaxNeighborList < cc_params.neighbor_lengths_num)  {
    for (cNL = 0; cNL <= MaxNeighborList; cNL++)   {
        loopLL = cc_params.Neighbors + cc_params.neighbor_lengths_num*(cc_params.colors_num * FDot + NeighborColor) + cNL;
        if (loopLL->elementnum > 0)      {
            loopNeighbor = LL_ULong(loopLL, 1);
            ListTop = loopLL->elementnum/sizeof(Ulong);
            for (cN = 0; cN < ListTop; cN++)   {
                ToDo(*loopNeighbor);
                loopNeighbor++;
    }}  }   }
    
    else    {
    for (cN = *(field.color_bottoms + NeighborColor) - 1; cN < *(field.color_tops + NeighborColor); cN++)  {
        if (cN != FDot)  ToDo(cN);
    }}
    
    if ((cc_params.no_overlap_range < 1) && (ToDo != &AddFDot) && (ToDo != CountNeighbors))  {
    if (NeighborColor == *(contour.color + cc_params.cdot_0))  {
        ToDo(FDot);     }}
}






// *********** GetEpsilon() ***********


int call_GetEpsilon(int argc, char **argv)
{
    Ulong c1, colored_dots_num;
    double NO_contour_length, NO_field_radius, step_volume, *w_bar;
    unsigned char highest_color;
	arg_info *ArgInfo;
	Boolean ArgsOK = yz_true;
    LL_retrn linkedLretrn;

	const signed long ArgTypes[] = { double_type, double_type, double_type, double_type, double_type, double_type,
                                    Ulong_type, Ulong_type, double_type, Ubyte_type, Ubyte_type,
                                    string_type, string_type, string_type, double_type, double_type, string_type, string_type, string_type,
                                    string_type, double_type, double_type, double_type, double_type, double_type, double_type, double_type };
	const signed long ArgIndices[] = { -1, -1, -1, -1, -1, -1, -2, -2, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -3, -4, 1, 1, 1, 1, 1, 1, 1 };
    const Ulong argc_target = sizeof(ArgTypes)/sizeof(long);
	
	ArgInfo = (arg_info *) *(argv+argc);
	
	if (argc != argc_target)  ArgsOK = yz_false;
	else if (CheckArgInfo(ArgInfo, ArgTypes, ArgIndices, argc) != passed)  ArgsOK = yz_false;

 	if (ArgsOK == yz_false)  {
		printf("usage: rtrn = call(\"GetEpsilon\", (doubles) x[], y[], z[], dx[], dy[], dz[], ");
		printf("(Ulongs) color_bottoms[], color_tops[], (double) l[], (ubyte) oligo_color[], (ubyte) mask[], ");
        printf("(strings) p[], Z_1x[], Z_xN[], (doubles) Z_1x_norm[], Z_xN_norm[], (strings) epsilon_1x[], epsilon_xN, epsilon_1N, ");
        printf("(doubles) Neighbors[], l_step, lp, false_negative_FE, NO_contour_length, NO_field_radius, step_accessible_volume, w_bar)\n");
		return 1;		}
	
	field.x = (double *) *(argv);
	field.y = (double *) *(argv+1);
	field.z = (double *) *(argv+2);
	field.dx = (double *) *(argv+3);
	field.dy = (double *) *(argv+4);
	field.dz = (double *) *(argv+5);
    
	field.color_bottoms = (Ulong *) *(argv+6);
	field.color_tops = (Ulong *) *(argv+7);

	contour.l = (double *) *(argv+8);
	contour.color = (unsigned char *) *(argv+9);
	contour.mask = (unsigned char *) *(argv+10);

	cc_params.p = (linkedlist *) *(argv+11);
	cc_params.Z_1x = (linkedlist *) *(argv+12);
	cc_params.Z_xN = (linkedlist *) *(argv+13);
	cc_params.Z_1x_norm = (double *) *(argv+14);
	cc_params.Z_xN_norm = (double *) *(argv+15);
	cc_params.epsilon_1x = (linkedlist *) *(argv+16);
	cc_params.epsilon_xN = (linkedlist *) *(argv+17);
	cc_params.epsilon_1N = (linkedlist *) *(argv+18);

    cc_params.Neighbors = (linkedlist *) *(argv+19);
    cc_params.l_step = *(double *) *(argv+20);

	cc_params.lp = *(double *) *(argv+21);
	cc_params.p_fn = *(double *) *(argv+22);
	NO_contour_length = *(double *) *(argv+23);
	NO_field_radius = *(double *) *(argv+24);
	step_volume = *(double *) *(argv+25);
    w_bar = (double *) *(argv+26);

	field.dots_num = ArgInfo->arg_indices;
	contour.dots_num = (ArgInfo+8)->arg_indices;
    if (field.dots_num == 0)  {  printf("GetEpsilon error:  number of field dots must be greater than zero\n");  return 1;  }
    
    if (contour.dots_num == 0)  return passed;
	
    highest_color = 0;
    for (c1 = 0; c1 < contour.dots_num; c1++)
        if (*(contour.color + c1) > highest_color)  highest_color = *(contour.color + c1);

    if ( (ArgInfo+6)->arg_indices < highest_color+1 )     {
        printf("GetEpsilon() error: lowest_color[], highest_color[] need to be of the same length > max(contour.color, field.color)\n");
        return 3;           }

    cc_params.colors_num = (ArgInfo+6)->arg_indices;
    cc_params.neighbor_lengths_num = ((ArgInfo+19)->arg_indices) / (field.dots_num*cc_params.colors_num);

    if ( (ArgInfo+19)->arg_indices < cc_params.neighbor_lengths_num*field.dots_num*cc_params.colors_num )     {
        printf("GetEpsilon() error: top(Neighbors[]) must be a multiple of field-dots-num * colors_num\n");
        return 4;           }

    for (c1 = 0; c1 < contour.dots_num; c1++)     {
        colored_dots_num = (*(field.color_tops + *(contour.color + c1)) + 1) - *(field.color_bottoms + *(contour.color + c1));

        if (colored_dots_num > 0)       {
            if ( ( (cc_params.p+c1)->memory == 0 )
                     || ( (cc_params.Z_1x+c1)->memory == 0 ) || ( (cc_params.Z_xN+c1)->memory == 0 )
                     || ( (cc_params.epsilon_1x+c1)->memory == 0 ) || ( (cc_params.epsilon_xN+c1)->memory == 0 ) || ( (cc_params.epsilon_1N+c1)->memory == 0 )
                     || ( (cc_params.p+c1)->elementnum != colored_dots_num*sizeof(double) )
                     || ( (cc_params.Z_1x+c1)->elementnum != colored_dots_num*sizeof(double) )
                     || ( (cc_params.Z_xN+c1)->elementnum != colored_dots_num*sizeof(double) )
                     || ( (cc_params.epsilon_1x+c1)->elementnum != colored_dots_num*sizeof(double) )
                     || ( (cc_params.epsilon_xN+c1)->elementnum != colored_dots_num*sizeof(double) )
                     || ( (cc_params.epsilon_1N+c1)->elementnum != colored_dots_num*sizeof(double) ) )       {
                printf("GetEpsilon(): ODotProbs[%i], Z_1x/xN[%i] and epsilon_1x/xN/1N[%i] need to be initialized to the same size (%i)\n",
                    (int) c1, (int) c1, (int) c1, (int) c1, colored_dots_num);
                return 5;           }

            linkedLretrn = FDefragmentLinkedList(cc_params.p+c1);
            if (linkedLretrn == passed)  linkedLretrn = FDefragmentLinkedList(cc_params.Z_1x+c1);
            if (linkedLretrn == passed)  linkedLretrn = FDefragmentLinkedList(cc_params.Z_xN+c1);
            if (linkedLretrn == passed)  linkedLretrn = FDefragmentLinkedList(cc_params.epsilon_1x+c1);
            if (linkedLretrn == passed)  linkedLretrn = FDefragmentLinkedList(cc_params.epsilon_xN+c1);
            if (linkedLretrn == passed)  linkedLretrn = FDefragmentLinkedList(cc_params.epsilon_1N+c1);
            if (linkedLretrn != passed)     {
                printf("GetEpsilon(): out of memory\n");
                return 6;
    }   }   }
    
    for (c1 = 0; c1 < (ArgInfo+19)->arg_indices; c1++)     {
        linkedLretrn = FDefragmentLinkedList(cc_params.Neighbors+c1);
        if (linkedLretrn != passed)     {
            printf("GetEpsilon(): out of memory\n");
            return 6;
    }   }
	
    if (NO_field_radius*NO_field_radius*NO_contour_length > 0)      {
        double p_no_ol, p_in_Ri;
        
        p_no_ol = 1. - (*w_bar) * pow(3. / (4.*pi*cc_params.lp*(*(contour.l + contour.dots_num - 1))/contour.dots_num), 1.5);
        if (p_no_ol > 1)  p_no_ol = 1;
        p_in_Ri = 1.3 * (1 - 1. / (1. + 2*NO_field_radius*NO_field_radius/EffectiveL2(NO_contour_length)));
        if (p_in_Ri > 1)  p_in_Ri = 1;
        
        if ((p_no_ol*p_in_Ri >= 1) || (p_no_ol*p_in_Ri < 0))  *w_bar = tiny;
        else  *w_bar = 1. - p_no_ol * p_in_Ri;
        if (*w_bar < tiny)  *w_bar = tiny;             }
    
    GetEpsilon(NO_contour_length, NO_field_radius, step_volume, *w_bar);
    
	return passed;
}



void GetEpsilon(double NO_contour_length, double NO_field_radius, double step_volume, double w_bar)
{
    Ulong one_color, loop_color, alpha_base, alpha;
    signed long i, cl, cr, cnum, fnum, n;
    double *one_Z, *one_epsilon, V, eps_num, eps_denom;
    
    V = (4.*pi/3.)*NO_field_radius*NO_field_radius*NO_field_radius;

    for (i = 0; i < contour.dots_num; i++)  {
    if (AreSpots(i) == yz_true)     {
        one_Z = LL_Double(cc_params.Z_1x + i, 1);
        one_epsilon = LL_Double(cc_params.epsilon_1x + i, 1);
        one_color = *(contour.color + i);
        
        alpha_base = *(field.color_bottoms + one_color) - 1;
        for (alpha = alpha_base; alpha < *(field.color_tops + one_color); alpha++)     {

            if (NO_contour_length == 0)
                *(one_epsilon + alpha - alpha_base) = 1;
            else if (i > 0)        {
                cnum = GetCNum(i, one_color, NO_contour_length, -1);
                fnum = GetFNum(alpha, one_color, NO_field_radius);
                if ( (*(contour.color + i - 1) == one_color) && (SqDotDistance(i-1, i, 1, 1, 1) <= NO_field_radius*NO_field_radius) )
                    {  if (cnum >= 1)  cnum--;  if (fnum >= 1)  fnum--;  }          // since the last dot automatically doesn't overlap, we won't count it

                eps_num = eps_denom = tinylog;
                for (n = max(0, cnum-fnum); n <= cnum; n++)
                    eps_num = AddLog(eps_num, gsl_sf_lngamma(fnum+1) - gsl_sf_lngamma(fnum-cnum+n+1) + max(cnum-n-1, 0)*log(step_volume/V) + n*log(w_bar), 1.);
                for (n = max(0, cnum-fnum-1); n <= cnum; n++)
                    eps_denom = AddLog(eps_denom, gsl_sf_lngamma(fnum+2) - gsl_sf_lngamma(fnum-cnum+n+2) + max(cnum-n-1, 0)*log(step_volume/V) + n*log(w_bar), 1.);

                *(one_epsilon + alpha - alpha_base) *= exp(eps_num - eps_denom);
    }}  }   }

    for (i = contour.dots_num - 1; i >= 0; i--)  {
    if (AreSpots(i) == yz_true)     {
        one_Z = LL_Double(cc_params.Z_xN + i, 1);
        one_epsilon = LL_Double(cc_params.epsilon_xN + i, 1);
        one_color = *(contour.color + i);
        
        alpha_base = *(field.color_bottoms + one_color) - 1;
        for (alpha = alpha_base; alpha < *(field.color_tops + one_color); alpha++)     {

            if (NO_contour_length == 0)
                *(one_epsilon + alpha - alpha_base) = 1;
            else if (i < contour.dots_num - 1)       {
                cnum = GetCNum(i, one_color, NO_contour_length, 1);
                fnum = GetFNum(alpha, one_color, NO_field_radius);
                if ( (*(contour.color + i + 1) == one_color) && (SqDotDistance(i+1, i, 1, 1, 1) <= NO_field_radius*NO_field_radius) )
                    {  if (cnum >= 1)  cnum--;  if (fnum >= 1)  fnum--;  }          // since the last dot automatically doesn't overlap, we won't count it
                
                eps_num = eps_denom = tinylog;
                for (n = max(0, cnum-fnum); n <= cnum; n++)
                    eps_num = AddLog(eps_num, gsl_sf_lngamma(fnum+1) - gsl_sf_lngamma(fnum-cnum+n+1) + max(cnum-n-1, 0)*log(step_volume/V) + n*log(w_bar), 1.);
                for (n = max(0, cnum-fnum-1); n <= cnum; n++)
                    eps_denom = AddLog(eps_denom, gsl_sf_lngamma(fnum+2) - gsl_sf_lngamma(fnum-cnum+n+2) + max(cnum-n-1, 0)*log(step_volume/V) + n*log(w_bar), 1.);

                *(one_epsilon + alpha - alpha_base) *= exp(eps_num - eps_denom);
    }}  }   }

    for (i = 0; i < contour.dots_num; i++)  {
    if (AreSpots(i) == yz_true)     {
        one_Z = LL_Double(cc_params.p + i, 1);
        one_epsilon = LL_Double(cc_params.epsilon_1N + i, 1);
        one_color = *(contour.color + i);
        
        alpha_base = *(field.color_bottoms + one_color) - 1;
        for (alpha = alpha_base; alpha < *(field.color_tops + one_color); alpha++)     {

            if (NO_contour_length == 0)
                *(one_epsilon + alpha - alpha_base) = 1;
            else if ((i > 0) && (i < contour.dots_num - 1))       {
                for (loop_color = 0; loop_color < cc_params.colors_num; loop_color++)       {
                    eps_num = eps_denom = tinylog;

                    cl = GetCNum(i, loop_color, NO_contour_length, -1);
                    cr = GetCNum(i, loop_color, NO_contour_length, 1);
                    fnum = GetFNum(alpha, loop_color, NO_field_radius);

                    for (n = max(0, cl+cr-fnum); n <= cl + cr; n++)              // here n plays the role of m + n
                        eps_num = AddLog(eps_num, gsl_sf_lngamma(fnum+1) - gsl_sf_lngamma(fnum-cl-cr+n+1) + (cl+cr-n)*log(step_volume/V) + n*log(w_bar), 1.);
                    for (n = max(0, cl-fnum); n <= cl; n++)                   // and here n = m
                        eps_denom = AddLog(eps_denom, gsl_sf_lngamma(fnum+1) - gsl_sf_lngamma(fnum-cl+n+1) + (cl-n)*log(step_volume/V) + n*log(w_bar), 1.);
                    for (n = max(0, cr-fnum); n <= cr; n++)
                        eps_denom = AddLog(eps_denom, gsl_sf_lngamma(fnum+1) - gsl_sf_lngamma(fnum-cr+n+1) + (cr-n)*log(step_volume/V) + n*log(w_bar), 1.);

                    *(one_epsilon + alpha - alpha_base) *= exp(eps_num - eps_denom);
                }
    }}  }   }
}



Ulong GetCNum(Ulong CDot, Ulong sought_color, Ulong distance, signed long direction)
{
    Ulong num;
    signed long CDot2;
    double l;

    num = 0;
    for (CDot2 = CDot + direction; (CDot2 >= 0) && (CDot2 < contour.dots_num); CDot2 += direction)        {
        l = fabs((*(contour.l + CDot2)) - (*(contour.l + CDot)));
        if (l > distance)  break;
        if (*(contour.color + CDot2) == sought_color)
            num++;     }
    
    return num;
}


Ulong GetFNum(Ulong FDot, Ulong sought_color, double distance)
{
    cc_params.alpha_0 = FDot;
    cc_params.fd_weight = 0;
    cc_params.NOF_length = distance;
    cc_params.over_boundary = yz_false;

    ForEachNeighbor(FDot, distance, sought_color, &AddFDot);

    return (Ulong) cc_params.fd_weight;
}


void AddFDot(Ulong alpha)
{
    if (SqDotDistance(cc_params.alpha_0, alpha, 1, 1, 1) <= cc_params.NOF_length*cc_params.NOF_length)
        cc_params.fd_weight++;
}






// *********** IterateZ() ***********



// This is run by call("Iterate", ...).  It runs the overlap-potential optimizer for a given number of iterations,
// or until convergence.

int call_IterateProbs(int argc, char **argv)
{
    Ulong loop_iteration, c1, colored_dots_num, *iterations, logsize;
    double *calc_time, *C, *LogSource, *LogOutput, *FE, init_step_size;
    double line_min_param, convergence_limit;
    int conv_test;
    unsigned char highest_color, opt_method;
    gsl_multimin_function opt_fun_no_grad;
    gsl_multimin_function_fdf opt_fun_grad;
    gsl_vector *start_f, *one_step_size;
    clock_t t_start, t_end;
	arg_info *ArgInfo;
	Boolean ArgsOK = yz_true, calc_exact;
    LL_retrn linkedLretrn;
    
    const gsl_multimin_fdfminimizer_type *opt_alg_types[] = { gsl_multimin_fdfminimizer_conjugate_fr,
                                    gsl_multimin_fdfminimizer_conjugate_pr, gsl_multimin_fdfminimizer_vector_bfgs2, gsl_multimin_fdfminimizer_steepest_descent };
    
	const signed long ArgTypes[] = { double_type, double_type, double_type, double_type, double_type, double_type, double_type, double_type, double_type,
                                    Ulong_type, Ulong_type, double_type, Ubyte_type, Ubyte_type,
                                    string_type, string_type, string_type, double_type, double_type, double_type, double_type, string_type,
                                    string_type, string_type, string_type, double_type, double_type, string_type, double_type,
                                    double_type, Ulong_type, double_type, double_type, double_type, double_type, double_type, double_type, double_type,
                                    double_type, double_type, double_type, double_type, double_type, Ulong_type, double_type, Ubyte_type, Ubyte_type,
                                    Ubyte_type, Ubyte_type, double_type };
	const signed long ArgIndices[] = { -1, -1, -1, -1, -1, -1, -1, -2, -2, -3, -3, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -4, -5,
                                            1, 1, 1, 1, 1, 1, 1, 1, 1, -6, -7, -8, 1, 1, 1, 1, 1, 1, 1, 1, 1, -9 };
    const Ulong argc_target = sizeof(ArgTypes)/sizeof(long);
	
	ArgInfo = (arg_info *) *(argv+argc);
	
	if (argc != argc_target)  ArgsOK = yz_false;
	else if (CheckArgInfo(ArgInfo, ArgTypes, ArgIndices, argc) != passed)  ArgsOK = yz_false;
    
 	if (ArgsOK == yz_false)  {
		printf("usage: rtrn = call(\"IterateProbs\", (doubles) x[], y[], z[], dx[], dy[], dz[], FSumProbs[], f[], f_gradient[], ");
		printf("(Ulongs) color_bottoms[], color_tops[], (double) l[], (ubyte) oligo_color[], (ubyte) mask[], ");
        printf("(strings) p[], Z_1x[], Z_xN[], (doubles) Z_1x_norm[], Z_xN_norm[], Z[], dC_dZ[], (strings) epsilon_1x[], epsilon_xN[], epsilon_1N[], ");
        printf("sensitivity[], (doubles) sensitivity_norm[], CSumProbs[], Neighbors[], (double) l_step, ");
        printf("lp, n_skip_max, false_negative_FE, exaggeration, K1, initial_step_size, line_min_param, Cs[], LogSource[], LogOutput[], ");
        printf("calc_count, calc_time, FE, max_iterations, convergence_limit, opt_method, f_or_w, no_overlap_range)\n");
		return 1;		}
	
	field.x = (double *) *(argv);
	field.y = (double *) *(argv+1);
	field.z = (double *) *(argv+2);
	field.dx = (double *) *(argv+3);
	field.dy = (double *) *(argv+4);
	field.dz = (double *) *(argv+5);
    
    cc_params.FSumProbs = (double *) *(argv+6);
    
    cc_params.f = (double *) *(argv+7);
    cc_params.grad_f = (double *) *(argv+8);
    
	field.color_bottoms = (Ulong *) *(argv+9);
	field.color_tops = (Ulong *) *(argv+10);
    
	contour.l = (double *) *(argv+11);
	contour.color = (unsigned char *) *(argv+12);
	contour.mask = (unsigned char *) *(argv+13);
    
	cc_params.p = (linkedlist *) *(argv+14);
	cc_params.Z_1x = (linkedlist *) *(argv+15);
	cc_params.Z_xN = (linkedlist *) *(argv+16);
	cc_params.Z_1x_norm = (double *) *(argv+17);
	cc_params.Z_xN_norm = (double *) *(argv+18);
	cc_params.Z = (double *) *(argv+19);
	cc_params.dC_dZ = (double *) *(argv+20);
	cc_params.epsilon_1x = (linkedlist *) *(argv+21);
	cc_params.epsilon_xN = (linkedlist *) *(argv+22);
	cc_params.epsilon_1N = (linkedlist *) *(argv+23);
	cc_params.sensitivity = (linkedlist *) *(argv+24);
	cc_params.sensitivity_norm = (double *) *(argv+25);
	cc_params.CSumProbs = (double *) *(argv+26);
    
    cc_params.Neighbors = (linkedlist *) *(argv+27);
    cc_params.l_step = *(double *) *(argv+28);
    
	cc_params.lp = *(double *) *(argv+29);
	cc_params.n_skip_max = *(Ulong *) *(argv+30);
	cc_params.p_fn = *(double *) *(argv+31);
    cc_params.exaggeration = *(double *) *(argv+32);
    cc_params.K1 = *(double *) *(argv+33);
//    cc_params.end_factor = exp(-*(double *) *(argv+34));
	init_step_size = *(double *) *(argv+35);
	line_min_param = *(double *) *(argv+36);
    
	C = (double *) *(argv+37);
	LogSource = (double *) *(argv+38);
	LogOutput = (double *) *(argv+39);
    
    cc_params.calcs = (double *) *(argv+40);
    calc_time = (double *) *(argv+41);
    FE = (double *) *(argv+42);
    iterations = (Ulong *) *(argv+43);
    convergence_limit = *(double *) *(argv+44);
    opt_method = *(unsigned char *) *(argv+45);
    cc_params.f_or_w = *(unsigned char *) *(argv+46);
    cc_params.no_overlap_range = *(unsigned char *) *(argv+47);
    calc_exact = *(unsigned char *) *(argv+48);
cc_params.pLR = (double *) *(argv+49);
    
	field.dots_num = ArgInfo->arg_indices;
	contour.dots_num = (ArgInfo+11)->arg_indices;
    
    if (contour.dots_num*field.dots_num == 0)  return passed;
    
    if ((ArgInfo+7)->arg_indices != field.dots_num+1)       {
        printf("IterateProbs() error:  top(f) and top(grad_f) must be field_dots_num+1\n");
        return 2;           }
	
    logsize = (ArgInfo+38)->arg_indices;
    if (*iterations > 0)     {
    if ( ((ArgInfo+37)->arg_indices != ((*iterations)+1)*2) || ((ArgInfo+39)->arg_indices != logsize * ((*iterations)+1)) )         {
        printf("IterateProbs() error:  must have iterations+1 = top(Cs) and top(LogSource)*(iterations+1) = top(LogOutput)\n");
        return 3;           }}
    
    if (opt_method > 4)  {  printf("IterateProbs() error:  opt_method must be from 0-4\n");  return 3;  }
    
    highest_color = 0;
    for (c1 = 0; c1 < contour.dots_num; c1++)
        if (*(contour.color + c1) > highest_color)  highest_color = *(contour.color + c1);

    if ( (ArgInfo+9)->arg_indices < highest_color+1 )     {
        printf("IterateProbs() error: lowest_color[], highest_color[] need to be of the same length > max(contour.color, field.color)\n");
        return 3;           }

    cc_params.colors_num = (ArgInfo+9)->arg_indices;
    cc_params.neighbor_lengths_num = ((ArgInfo+27)->arg_indices) / (field.dots_num*cc_params.colors_num);

    if ( (ArgInfo+27)->arg_indices < cc_params.neighbor_lengths_num*field.dots_num*cc_params.colors_num )     {
        printf("IterateProbs() error: top(Neighbors[]) must be a multiple of field-dots-num * colors_num\n");
        return 4;           }

    for (c1 = 0; c1 < contour.dots_num; c1++)     {
    if (AreSpots(c1) == yz_true)     {
        colored_dots_num = (*(field.color_tops + *(contour.color + c1)) + 1) - *(field.color_bottoms + *(contour.color + c1));
        
        if (colored_dots_num > 0)       {
            if ( ( (cc_params.p+c1)->memory == 0 )
                     || ( (cc_params.Z_1x+c1)->memory == 0 ) || ( (cc_params.Z_xN+c1)->memory == 0 )
                     || ( (cc_params.epsilon_1x+c1)->memory == 0 ) || ( (cc_params.epsilon_xN+c1)->memory == 0 ) || ( (cc_params.epsilon_1N+c1)->memory == 0 )
                     || ( (cc_params.p+c1)->elementnum != colored_dots_num*sizeof(double) )
                     || ( (cc_params.Z_1x+c1)->elementnum != colored_dots_num*sizeof(double) )
                     || ( (cc_params.Z_xN+c1)->elementnum != colored_dots_num*sizeof(double) )
                     || ( (cc_params.epsilon_1x+c1)->elementnum != colored_dots_num*sizeof(double) )
                     || ( (cc_params.epsilon_xN+c1)->elementnum != colored_dots_num*sizeof(double) )
                     || ( (cc_params.epsilon_1N+c1)->elementnum != colored_dots_num*sizeof(double) ) )       {
                printf("IterateProbs(): ODotProbs[%i], Z_1x/xN[%i] and epsilon_1x/xN/1N[%i] need to be initialized to the same size (%i)\n", 
                            (int) c1, (int) c1, (int) c1, (int) c1, colored_dots_num);
                return 5;           }

            linkedLretrn = FDefragmentLinkedList(cc_params.p+c1);
            if (linkedLretrn == passed)  linkedLretrn = FDefragmentLinkedList(cc_params.Z_1x+c1);
            if (linkedLretrn == passed)  linkedLretrn = FDefragmentLinkedList(cc_params.Z_xN+c1);
            if (linkedLretrn == passed)  linkedLretrn = FDefragmentLinkedList(cc_params.epsilon_1x+c1);
            if (linkedLretrn == passed)  linkedLretrn = FDefragmentLinkedList(cc_params.epsilon_xN+c1);
            if (linkedLretrn == passed)  linkedLretrn = FDefragmentLinkedList(cc_params.epsilon_1N+c1);
            if (linkedLretrn != passed)     {
                printf("IterateProbs(): out of memory\n");
                return 6;
    }}   }  }
    
    for (c1 = 0; c1 < (ArgInfo+27)->arg_indices; c1++)     {
        linkedLretrn = FDefragmentLinkedList(cc_params.Neighbors+c1);
        if (linkedLretrn != passed)     {
            printf("IterateProbs(): out of memory\n");
            return 6;
    }   }
	
    t_start = clock();
    
    if (calc_exact == yz_true)  {
        
        Ulong i, alpha;
        
        cc_params.alphas = (Slong *) malloc(contour.dots_num * sizeof(Slong));
        cc_params.alpha_mask = (Boolean *) malloc(contour.dots_num * sizeof(Boolean));
        
        *(cc_params.f + field.dots_num) = exp(-(*(cc_params.f + field.dots_num)));
        InitW();
        *(cc_params.f + field.dots_num) = -log(*(cc_params.f + field.dots_num));
        
        for (i = 0; i < contour.dots_num; i++) {
            
            Ulong one_color = *(contour.color + i);
            Ulong alpha_base = *(field.color_bottoms + one_color) - 1;
            
            for (alpha = alpha_base; alpha < *(field.color_tops + one_color); alpha++)    {
                *(LL_Double(cc_params.p + i, 1) + alpha - alpha_base) = 0.;
        }   }
        
        for (alpha = 0; alpha < field.dots_num; alpha++)
            *(cc_params.alpha_mask + alpha) = yz_false;
        
        *(cc_params.Z) = 0.;
        //GetAllChainsDebug(0, -1, -1, 1., yz_false);
        GetAllChains(0, -1, 1.);
        
        for (i = 0; i < contour.dots_num; i++)  {
            
            Ulong one_color = *(contour.color + i);
            Ulong alpha_base = *(field.color_bottoms + one_color) - 1;
            
            for (alpha = alpha_base; alpha < *(field.color_tops + one_color); alpha++)    {
                *(LL_Double(cc_params.p + i, 1) + alpha - alpha_base) /= *(cc_params.Z);
        }   }
        
        free(cc_params.alphas);
        free(cc_params.alpha_mask);
    }
    
    else if (*iterations == 0)       {

        load_f(NULL);
        
        *(C + 0) = IterateProbs(2);
        
        save_grad_f(NULL);
        for (c1 = 0; c1 < field.dots_num+1; c1++)  *(cc_params.f + c1) = -log(*(cc_params.f + c1));
        
        *(C + 1) = 0;
        for (c1 = 0; c1 < field.dots_num+1; c1++)  *(C + 1) += (*(cc_params.grad_f + c1)) * (*(cc_params.grad_f + c1));
        *(C + 1) = sqrt(*(C + 1));          }
        
    else        {
        
        opt_fun_no_grad.n = opt_fun_grad.n = field.dots_num+1;
        opt_fun_no_grad.params = opt_fun_grad.params = 0;
        opt_fun_no_grad.f = opt_fun_grad.f = &GetZ;
        opt_fun_grad.df = &GetGradZ;
        opt_fun_grad.fdf = &GetZAndGradZ;
        
        start_f = gsl_vector_alloc(field.dots_num+1);
        for (c1 = 0; c1 < field.dots_num+1; c1++)
            gsl_vector_set(start_f, c1, *(cc_params.f + c1));
        
        if (opt_method == 0)     {
            opt_struct_no_grad = gsl_multimin_fminimizer_alloc(gsl_multimin_fminimizer_nmsimplex2, field.dots_num+1);
            if (opt_struct_no_grad == 0)  return 10;
            
            one_step_size = gsl_vector_alloc(field.dots_num+1);
            for (c1 = 0; c1 < field.dots_num+1; c1++)
                gsl_vector_set(one_step_size, c1, init_step_size);
            gsl_multimin_fminimizer_set(opt_struct_no_grad, &opt_fun_no_grad, start_f, one_step_size);         }
        else        {
            opt_struct_grad = gsl_multimin_fdfminimizer_alloc(*(opt_alg_types + opt_method - 1), field.dots_num+1);
            if (opt_struct_grad == 0)  return 10;
            gsl_multimin_fdfminimizer_set(opt_struct_grad, &opt_fun_grad, start_f, init_step_size, line_min_param);        }
        
        conv_test = GetC(C, 0, convergence_limit, opt_method);
        
        for (loop_iteration = 0; loop_iteration < *iterations; loop_iteration++)     {
            
            if (opt_method == 0)     {
                gsl_multimin_fminimizer_iterate(opt_struct_no_grad);        }
            else        {
                gsl_multimin_fdfminimizer_iterate(opt_struct_grad);         }
            
            conv_test = GetC(C, loop_iteration+1, convergence_limit, opt_method);
            
            if (logsize > 0)        {
            for (c1 = 0; c1 < logsize; c1++)        {
                *(LogOutput + logsize*(loop_iteration + 1) + c1) = *(LogSource + c1);      }}
            
            if (conv_test == GSL_SUCCESS)  {  *iterations = loop_iteration + 1;  break;  }
        }
    }
    
    t_end = clock();
    *calc_time += ((double) t_end - t_start) / CLOCKS_PER_SEC;
    
    if ((calc_exact == yz_false) && (*iterations > 0))        {
        
        if (opt_method == 0)        {
            gsl_multimin_fminimizer_free(opt_struct_no_grad);
            gsl_vector_free(one_step_size);         }
        else
            gsl_multimin_fdfminimizer_free(opt_struct_grad);
        
        gsl_vector_free(start_f);           }
    
	return passed;
}


// GetC() stores the state of the minimization (f (best guess), C), and returns true iff converged

int GetC(double *C, Ulong C_offset, double convergence_limit, unsigned char opt_method)
{
    Ulong c1;
    double conv_param, alg0_size;
    int conv_test;
    gsl_vector *one_f, *one_grad;
    
    if (opt_method == 0)     {
        one_f = gsl_multimin_fminimizer_x(opt_struct_no_grad);
        *(C + 2*C_offset) = gsl_multimin_fminimizer_minimum(opt_struct_no_grad);
        conv_param = alg0_size = gsl_multimin_fminimizer_size(opt_struct_no_grad);
        conv_test = gsl_multimin_test_size(alg0_size, convergence_limit);               }
    else        {
        one_f = gsl_multimin_fdfminimizer_x(opt_struct_grad);
        *(C + 2*C_offset) = gsl_multimin_fdfminimizer_minimum(opt_struct_grad);
        one_grad = gsl_multimin_fdfminimizer_gradient(opt_struct_grad);
        conv_param = gsl_blas_dnrm2(one_grad);
        conv_test = gsl_multimin_test_gradient(one_grad, convergence_limit);
        
        for (c1 = 0; c1 < field.dots_num+1; c1++)
            *(cc_params.grad_f + c1) = gsl_vector_get(one_grad, c1);           }
    
    for (c1 = 0; c1 < field.dots_num+1; c1++)
        *(cc_params.f + c1) = gsl_vector_get(one_f, c1);
    
    *(C + 2*C_offset + 1) = conv_param;
    
    return conv_test;
}


// Next three routines:  return C and/or grad-C (used by various optimization routines)

double GetZ(const gsl_vector *OF, void *dummy)
{
    load_f(OF);
    
    return IterateProbs(1);
}


void GetGradZ(const gsl_vector *OF, void *dummy, gsl_vector *grad_OF)
{
    load_f(OF);
    
    IterateProbs(2);
    
    save_grad_f(grad_OF);
}


void GetZAndGradZ(const gsl_vector *OF, void *dummy, double *C, gsl_vector *grad_OF)
{
    load_f(OF);
    
    *C = IterateProbs(2);
    
    save_grad_f(grad_OF);
}


// load_f() converts (-log f) to f

void load_f(const gsl_vector *OF)
{
    Ulong c1;
    double one_f;
    
    for (c1 = 0; c1 < field.dots_num+1; c1++)       {
        if (OF == NULL)  one_f = *(cc_params.f + c1);
        else  one_f = gsl_vector_get(OF, c1);
        
        *(cc_params.f + c1) = exp(-one_f);            }
}


// save_grad_f() converts dC/df to dC/d(-log f)

void save_grad_f(const gsl_vector *grad_OF)
{
    Ulong c1;
    double one_grad_f;
    
    for (c1 = 0; c1 < field.dots_num+1; c1++)       {
        one_grad_f = -(*(cc_params.grad_f + c1)) * (*(cc_params.f + c1));
        
        if (grad_OF == NULL)  *(cc_params.grad_f + c1) = one_grad_f;
        else  gsl_vector_set((gsl_vector *) grad_OF, c1, one_grad_f);           }
}



// Forward-propagates the Z matrices, and back-propagates the sensitivities.  Three modes:
// 0: do nothing
// 1: prop. Zs to calculate p
// 2: (1) plus: sensitivities

double IterateProbs(unsigned char ToDo)
{
    Ulong alpha, alpha_base, one_color;
    signed long i;
    double olf, *first_p, C, p_tot;

if (cc_params.f_or_w == 1)  *(cc_params.f + field.dots_num) = 1;
else  for (alpha = 0; alpha < field.dots_num; alpha++)  *(cc_params.f + alpha) = 1;
    
    InitW();
    
    if (ToDo >= 1)     {
        
        PropArray(cc_params.Z_1x, cc_params.Z_1x_norm, &Z_prop, 1, pa_FillZ);
        PropArray(cc_params.Z_xN, cc_params.Z_xN_norm, &Z_prop, -1, pa_FillZ);
        FillArray(fa_CalcP);        // p0 = Z_1x * Z_xN
        PropArray(cc_params.Z_xN, cc_params.Z_xN_norm, &Z_bridge, -1, pa_BridgeZ);
        FillArray(fa_DivZ);         // p = p0 / Z
    }
//PropArray(cc_params.Z_1x, cc_params.Z_1x_norm, &do_pLR, 1, 100);
    
    
            // Sum probs along the contour
    
    p_tot = 0;
    for (i = 0; i < contour.dots_num; i++)  {
        
        *(cc_params.CSumProbs + i) = 0;
        
        if (AreSpots(i) == yz_true)     {
            first_p = LL_Double(cc_params.p + i, 1);
            one_color = *(contour.color + i);
            
            for (alpha = 0; alpha < (*(field.color_tops + one_color) + 1) - *(field.color_bottoms + one_color); alpha++)     {
                *(cc_params.CSumProbs + i) += *(first_p + alpha);
                p_tot += *(first_p + alpha);
    }   }   }
    
    
            // Sum probs over the field
    
    for (one_color = 0; one_color < cc_params.colors_num; one_color++)  {
        alpha_base = *(field.color_bottoms + one_color) - 1;
        for (alpha = alpha_base; alpha < *(field.color_tops + one_color); alpha++)    {
            
            olf = 0;
            for (i = 0; i < contour.dots_num; i++)  {
            if (*(contour.color + i) == one_color)  {
                olf += *(LL_Double(cc_params.p + i, 1) + alpha - alpha_base);
            }}
            *(cc_params.FSumProbs + alpha) = olf;
    }   }
    
    cc_params.N_difference = p_tot - (1. - cc_params.p_fn) * contour.dots_num;
    C = 0.5 * cc_params.K1 * cc_params.N_difference * cc_params.N_difference;
    for (alpha = 0; alpha < field.dots_num; alpha++)        {
        if (*(cc_params.FSumProbs + alpha) > 1)         {
            C += 0.5 * ((*(cc_params.FSumProbs + alpha)) - 1.) * ((*(cc_params.FSumProbs + alpha)) - 1.);
    }   }
    C /= contour.dots_num;
    
    
    if (ToDo <= 1)  return C;
    
    
        // compute the gradient dC/df and dC/dw
    
    for (alpha = 0; alpha < field.dots_num; alpha++)
        *(cc_params.grad_f + alpha) = 0;
    *(cc_params.grad_f + field.dots_num) = 0;
    
    FillArray(fa_dC_dZ);
    PropArray(cc_params.Z_xN, cc_params.Z_xN_norm, &Z_bridge, -1, pa_Bridge_dC_dZ);
    
    FillArray(fa_SetS1x);
    PropArray(cc_params.Z_xN, cc_params.Z_xN_norm, &Z_bridge, -1, pa_BridgeS);
    PropArray(cc_params.sensitivity, cc_params.sensitivity_norm, &Z_prop, -1, pa_PropS);
    FillArray(fa_AddS1x);
    if (cc_params.f_or_w == 2)  PropArray(cc_params.Z_1x, cc_params.Z_1x_norm, &Z_prop, 1, pa_GetGradW);/**/
    
    FillArray(fa_SetSxN);
    PropArray(cc_params.Z_1x, cc_params.Z_1x_norm, &Z_bridge, 1, pa_BridgeS);
    PropArray(cc_params.sensitivity, cc_params.sensitivity_norm, &Z_prop, 1, pa_PropS);
    FillArray(fa_AddSxN);
    if (cc_params.f_or_w == 2)  PropArray(cc_params.Z_xN, cc_params.Z_xN_norm, &Z_prop, -1, pa_GetGradW);/**/
    
if (cc_params.f_or_w == 1)  *(cc_params.grad_f + field.dots_num) = 0;
else  for (alpha = 0; alpha < field.dots_num; alpha++)  *(cc_params.grad_f + alpha) = 0;
    return C;
}



// PropArray() fills the elements of arrays like Z_1x, etc. whose fill rule is like a layered neural network.

void PropArray(linkedlist *prop_list, double *prop_list_norm,
                    void(*NeighborFunction)(Ulong), signed long direction, unsigned char mode)
{
    signed long i, n_skip, one_color, skip_counter, boundary_overshoot;
    Ulong alpha, other_boundary, alpha_base, alpha_top;
    Slong n_skip_2;
    double *one_layer, *other_norm_list, *end_layer, *one_sense, norm_offset;
    double new_norm;
    linkedlist *other_list;
    
    if (direction == 1)  {  cc_params.boundary = 0;  other_boundary = contour.dots_num - 1;  }
    else  {  cc_params.boundary = contour.dots_num - 1;  other_boundary = 0;  }
    cc_params.direction = direction;
    
    cc_params.prop_u_or_d = prop_list;
    cc_params.prop_u_or_d_norm = prop_list_norm;
    cc_params.prop_mode = mode;
    
    if ((mode == pa_BridgeS) && (direction < 0) && (cc_params.f_or_w == /*1*/2))  cc_params.pa_SetGradWSource = yz_true;
    else  cc_params.pa_SetGradWSource = yz_false;
    
    boundary_overshoot = 0;
    if ((mode == pa_BridgeZ) || (mode == pa_Bridge_dC_dZ) || (mode == pa_BridgeS) || (mode == pa_GetGradW))
          {  if (mode != pa_GetGradW)  boundary_overshoot = 1;  }
    
    if ((prop_list == cc_params.Z_1x) || ((cc_params.prop_mode == pa_PropS) && (direction == 1)))
          {  other_list = cc_params.Z_xN;  other_norm_list = cc_params.Z_xN_norm;  }
    else  {  other_list = cc_params.Z_1x;  other_norm_list = cc_params.Z_1x_norm;  }
    
    for (i = cc_params.boundary; (i+boundary_overshoot >= 0) && (i-boundary_overshoot < (Slong) contour.dots_num); i += direction)  {
    if (AreSpots(i) == yz_true)     {
        
        if ((i < 0) || (i >= contour.dots_num))  {
            cc_params.over_boundary = yz_true;
            cc_params.other_norm = 0;
            alpha_base = 0;
            alpha_top = 1;     }
        
        else  {
            
            cc_params.over_boundary = yz_false;
            
            cc_params.other_norm = *(other_norm_list + i);
            
            one_layer = LL_Double(prop_list + i, 1);
            cc_params.other_layer = LL_Double(other_list + i, 1);
            
            one_sense = LL_Double(cc_params.sensitivity + i, 1);
            one_color = *(contour.color + i);
            
            alpha_base = *(field.color_bottoms + one_color) - 1;
            alpha_top = *(field.color_tops + one_color);            }
        
        
        for (alpha = alpha_base; alpha < alpha_top; alpha++)     {
            
            if (mode == pa_FillZ)  *(one_layer + alpha - alpha_base) = 0.;
            cc_params.alpha_0 = alpha;
            
            for (n_skip = 0; n_skip <= cc_params.n_skip_max; n_skip++)        {
                
                if (abs(i - cc_params.boundary) < n_skip)  break;
                
                cc_params.cdot = i - (n_skip + 1) * direction;
                cc_params.cdot_0 = i;
                
                if (AreSpots(cc_params.cdot) == yz_true)     {
                for (n_skip_2 = -1; n_skip_2 <= (Slong) cc_params.n_skip_max; n_skip_2++)  {
                    
                    Slong tot_skip;
                    
                    cc_params.cdot_ext = cc_params.cdot - (n_skip_2 + 1) * direction;
                    
                    if ((n_skip_2 >= 0) && ((abs(i - cc_params.boundary) == n_skip)
                                    || (abs(cc_params.cdot - cc_params.boundary) <= n_skip_2)))  break;
                    
                    if (n_skip_2 == -1)  tot_skip = n_skip;
                    else  tot_skip = n_skip+n_skip_2;
                    cc_params.w_factor = tot_skip*cc_params.w;
                    
                    if (AreSpots(cc_params.cdot_ext) == yz_true)  {
                    if ((n_skip_2 == -1) || (*(contour.color + cc_params.cdot_ext) == *(contour.color + i)))  {
                        
                        if (abs(i - cc_params.boundary) == n_skip)  {
                            cc_params.p_value = 0.;
                            for (one_color = 0; one_color < cc_params.colors_num; one_color++)
                                ForEachNeighbor(alpha, ((*(contour.l + contour.dots_num - 1))*(abs(i-cc_params.boundary)+1.))/contour.dots_num, one_color, &CountNeighbors);
cc_params.p_value = 1.;
                            if (cc_params.p_value == 0.)  cc_params.p_value = 1.;
                            new_norm = 0.;       }
                        
                        else    {
                            cc_params.p_value = 0;
                            cc_params.l = fabs( (*(contour.l + cc_params.cdot)) - (*(contour.l + i)) );
                            cc_params.alpha_base = *(field.color_bottoms + (*(contour.color + cc_params.cdot))) - 1;
                            cc_params.alpha_0_base = alpha_base;
                            
                            new_norm = *(prop_list_norm + cc_params.cdot_ext);        }
                        
                        if (NeighborFunction == &Z_bridge)     {
                            
                            if (cc_params.over_boundary == yz_true)  cc_params.multiplier = 1.;
                            else if (mode == pa_BridgeS)  cc_params.multiplier = sqrt(*(cc_params.f + alpha));
                            else  cc_params.multiplier = sqrt(*(cc_params.f + alpha)) * (*(LL_Double(cc_params.Z_1x + i, 1) + (alpha - alpha_base)));
                            if (abs(i - cc_params.boundary) == n_skip)  cc_params.p_value = cc_params.multiplier;
                            
                            if (mode == pa_Bridge_dC_dZ)  {
                                cc_params.dC_dZ_factor = 0.;
                                for (skip_counter = 1; skip_counter <= n_skip+n_skip_2+1; skip_counter++)   {
                                    cc_params.dC_dZ_factor += 0.5 * (*(cc_params.dC_dZ + i - skip_counter*direction)) * exp( cc_params.w_factor + cc_params.other_norm
                                            + new_norm - (*(cc_params.Z_1x_norm + i - skip_counter*direction)) - (*(cc_params.Z_xN_norm + i - skip_counter*direction)) );
                        }   }   }
                        
                        if (abs(i - cc_params.boundary) != n_skip)
                            ForEachNeighbor(alpha, cc_params.l, *(contour.color + cc_params.cdot), NeighborFunction);
                        
                        if (mode == pa_FillZ)      {
                            double next_norm = 0., cdot_norm = 0.;
                            if (i != cc_params.boundary)  next_norm = *(prop_list_norm + i - direction);
                            if (abs(i - cc_params.boundary) != n_skip)  cdot_norm = *(prop_list_norm + cc_params.cdot);
                            *(one_layer + alpha - alpha_base) += cc_params.p_value * sqrt(*(cc_params.f + alpha))
                                                    * exp(cc_params.w_factor + new_norm - next_norm);        }
                        
                        else if (mode == pa_GetGradW)      {
                            *(cc_params.grad_f + field.dots_num) += cc_params.w_norm * tot_skip * cc_params.p_value * sqrt(*(cc_params.f + alpha))
                                    * (*(one_sense + alpha - alpha_base)) * exp(cc_params.w_factor - cc_params.w + new_norm + (*(cc_params.sensitivity_norm + i)));    }
                        
                        else if (mode == pa_BridgeZ)     {
                            for (skip_counter = 1; skip_counter <= n_skip+n_skip_2+1; skip_counter++)      {
                                *(cc_params.Z + i - skip_counter*direction) += cc_params.p_value * exp( cc_params.w_factor + cc_params.other_norm + new_norm
                                        - (*(cc_params.Z_1x_norm + i - skip_counter*direction)) - (*(cc_params.Z_xN_norm + i - skip_counter*direction)) );
                        }   }
                        
                        else if ((mode == pa_Bridge_dC_dZ) && (cc_params.over_boundary == yz_false))     {
                            *(cc_params.grad_f + alpha) += cc_params.p_value * cc_params.dC_dZ_factor / (*(cc_params.f + alpha));          }
                        
                        else if (mode == pa_BridgeS)     {
                            double to_add;
                            
                            for (skip_counter = 1; skip_counter <= n_skip+n_skip_2+1; skip_counter++)      {
                                
                                if (cc_params.over_boundary == yz_false)  {
                                    end_layer = LL_Double(cc_params.sensitivity + i, 1);
                                    
                                    to_add = (*(cc_params.dC_dZ + i - skip_counter*direction)) * cc_params.p_value
                                                * exp( cc_params.w_factor + new_norm - (*(cc_params.Z_1x_norm + i - skip_counter*direction))
                                                        - (*(cc_params.Z_xN_norm + i - skip_counter*direction)) - (*(cc_params.sensitivity_norm + i)) );
                                    
                                    *(end_layer + alpha - alpha_base) += to_add;     // next line:  -(1/2) Z^i (dC/dZ^i) / f_i  (or with Z_i)
                                    *(cc_params.grad_f + alpha) -= 0.5 * (*(cc_params.other_layer + alpha - alpha_base)) * to_add
                                                     * exp( cc_params.other_norm + (*(cc_params.sensitivity_norm + i)) ) / (*(cc_params.f + alpha));   }
                                
                                if (cc_params.pa_SetGradWSource == yz_true)     {
                                    to_add = cc_params.w_norm * tot_skip * (*(cc_params.dC_dZ + i - skip_counter*direction))
                                            * cc_params.p_value * exp( cc_params.w_factor - cc_params.w + new_norm + cc_params.other_norm
                                                    - (*(cc_params.Z_1x_norm + i - skip_counter*direction)) - (*(cc_params.Z_xN_norm + i - skip_counter*direction)) );
                                    if (cc_params.over_boundary == yz_false)  to_add *= (*(LL_Double(cc_params.Z_1x + i, 1) + (alpha - alpha_base)));
                                    *(cc_params.grad_f + field.dots_num) += to_add;
                        }   }   }
                        
                        else if ((mode == pa_PropS) && (abs(i - cc_params.boundary) != n_skip))  {
                            double to_add = cc_params.p_value * sqrt(*(cc_params.f + alpha))
                                                * exp(cc_params.w_factor + (*(prop_list_norm + cc_params.cdot_ext)) - (*(prop_list_norm + i)));
                            *(one_layer + alpha - alpha_base) += to_add;                }
                    }}
                    
                    if ((cc_params.no_overlap_range < 2) || (cc_params.over_boundary == yz_true))  break;
                }}
            }
        }
        
            // renormalize the Z/s arrays
        
        if (mode == pa_FillZ)      {
            if (i == cc_params.boundary)  norm_offset = 0;
            else  norm_offset = *(prop_list_norm + (i - direction));
            RenormZ(one_layer, alpha_top - alpha_base, prop_list_norm + i, norm_offset);            }
        
        else if (mode == pa_PropS)      {
            norm_offset = *(prop_list_norm + i);
            RenormZ(one_layer, alpha_top - alpha_base, prop_list_norm + i, norm_offset);            }
    }}
}



// FillArray() iterates -- not propagates -- over each element of some array.

void FillArray(unsigned char mode)
{
    Ulong i, alpha, alpha_base, one_color;
    double *first_p, *one_Z_1x, *one_Z_xN, *one_sense, one_p, dC_dp;
    
    for (i = 0; i < contour.dots_num; i++)  {
    if (*(contour.mask + i) != 0)    {
    if (AreSpots(i) == yz_true)     {
        
        first_p = LL_Double(cc_params.p + i, 1);
        one_Z_1x = LL_Double(cc_params.Z_1x + i, 1);
        one_Z_xN = LL_Double(cc_params.Z_xN + i, 1);
        one_sense = LL_Double(cc_params.sensitivity + i, 1);
        one_color = *(contour.color + i);
        
        alpha_base = *(field.color_bottoms + one_color) - 1;
        
        if (mode == fa_CalcP)  *(cc_params.Z + i) = 0;
        else if (mode == fa_dC_dZ)  *(cc_params.dC_dZ + i) = 0;
        
        for (alpha = alpha_base; alpha < *(field.color_tops + one_color); alpha++)   {
            
            dC_dp = cc_params.K1 * cc_params.N_difference;
            if (*(cc_params.FSumProbs + alpha) > 1.)  dC_dp += *(cc_params.FSumProbs + alpha) - 1.;
            
            if (mode == fa_CalcP)      {
                one_p = (*(one_Z_1x + alpha - alpha_base)) * (*(one_Z_xN + alpha - alpha_base));
                *(first_p + alpha - alpha_base) = one_p;
                *(cc_params.Z + i) += one_p;            }
            
            else if ((mode == fa_DivZ) && (*(cc_params.Z + i) > 0.))  {
                *(first_p + alpha - alpha_base) /= *(cc_params.Z + i);  }
            
            else if (mode == fa_dC_dZ)        {
                *(cc_params.dC_dZ + i) -= dC_dp * (*(first_p + alpha - alpha_base)) / (*(cc_params.Z + i));     }
            
            else if (mode == fa_SetS1x)         {
                double to_add = (*(cc_params.dC_dZ + i)) * (*(one_Z_xN + alpha - alpha_base));
                if (*(one_Z_1x + alpha - alpha_base) > 0)
                    to_add += dC_dp * (*(one_Z_xN + alpha - alpha_base)) / (*(cc_params.Z + i));
                
                *(one_sense + alpha - alpha_base) = to_add;
                *(cc_params.grad_f + alpha) -= 0.5 * (*(one_Z_1x + alpha - alpha_base)) * to_add / (*(cc_params.f + alpha));      }
            
            else if (mode == fa_AddS1x)  {
                *(cc_params.grad_f + alpha) += (*(one_Z_1x + alpha - alpha_base)) * (*(one_sense + alpha - alpha_base))
                                            * exp((*(cc_params.Z_1x_norm + i)) + (*(cc_params.sensitivity_norm + i))) / (*(cc_params.f + alpha));  }
            
            else if (mode == fa_SetSxN)         {
                double to_add = (*(cc_params.dC_dZ + i)) * (*(one_Z_1x + alpha - alpha_base));
                if (*(one_Z_xN + alpha - alpha_base) > 0)
                    to_add += dC_dp * (*(one_Z_1x + alpha - alpha_base)) / (*(cc_params.Z + i));
                
                *(one_sense + alpha - alpha_base) = to_add;
                *(cc_params.grad_f + alpha) -= 0.5 * (*(one_Z_xN + alpha - alpha_base)) * to_add / (*(cc_params.f + alpha));      }
            
            else if (mode == fa_AddSxN)  {
                *(cc_params.grad_f + alpha) += (*(one_Z_xN + alpha - alpha_base)) * (*(one_sense + alpha - alpha_base))
                                            * exp((*(cc_params.Z_xN_norm + i)) + (*(cc_params.sensitivity_norm + i))) / (*(cc_params.f + alpha));  }
        }
    }}}
    
        // set the initial normalizations of the Z/s arrays
    
    if (mode == fa_SetS1x)  {
    for (i = 0; i < contour.dots_num; i++)  {
        *(cc_params.sensitivity_norm + i) = -*(cc_params.Z_1x_norm + i);     }}
    else if (mode == fa_SetSxN)  {
    for (i = 0; i < contour.dots_num; i++)  {
        *(cc_params.sensitivity_norm + i) = -*(cc_params.Z_xN_norm + i);     }}
}



// RenormZ() rescales one column of a Z/s array along with its normalization factor, stored in a separate array.

void RenormZ(double *first_z, Ulong zs_num, double *Norm, double norm_offset)
{
    Ulong c1;
    double tot, norm;
    
    tot = 0;
    for (c1 = 0; c1 < zs_num; c1++)  tot += fabs(*(first_z + c1));
    
    norm = tot;
    if (norm == 0)  { *Norm = norm_offset;  return;  }
    
    for (c1 = 0; c1 < zs_num; c1++)  *(first_z + c1) /= norm;
    *Norm = log(norm) + norm_offset;
}



// Z_prop() -- the basic routine propagating terms in the Z/s arrays

void Z_prop(Ulong alpha)
{
    if (cc_params.cdot == cc_params.cdot_ext)  {
        cc_params.p_value += (*(LL_Double(cc_params.prop_u_or_d + cc_params.cdot, 1) + (alpha - cc_params.alpha_base)))
                        * GaussProb(cc_params.l, cc_params.alpha_0, alpha, 0) * sqrt(*(cc_params.f + alpha));           }
    
    else  {
        double sub_term = (*(LL_Double(cc_params.prop_u_or_d + cc_params.cdot_ext, 1) + (cc_params.alpha_0 - cc_params.alpha_0_base)))
                        * GaussProb(fabs( (*(contour.l + cc_params.cdot)) - (*(contour.l + cc_params.cdot_ext)) ), alpha, cc_params.alpha_0, 0)
                        * GaussProb(cc_params.l, cc_params.alpha_0, alpha, 0)
                        * sqrt(*(cc_params.f + cc_params.alpha_0)) * (*(cc_params.f + alpha));
        
        cc_params.p_value -= sub_term;
        
        if (cc_params.prop_mode == pa_PropS)  {     // compute 'other terms' in df = s_i Z_i + s^i Z^i + O.T.
            
            sub_term *= (*(cc_params.other_layer + (cc_params.alpha_0 - cc_params.alpha_0_base)))
                        * exp(cc_params.other_norm + (*(cc_params.sensitivity_norm + cc_params.cdot_ext)))
                        * sqrt(*(cc_params.f + cc_params.alpha_0)) * exp(cc_params.w_factor);
            
            *(cc_params.grad_f + alpha) -= sub_term / (*(cc_params.f + alpha));
    }   }
}


// Z_bridge() introduces terms coming from false negatives

void Z_bridge(Ulong alpha)
{
    if (cc_params.cdot == cc_params.cdot_ext)  {
    if (abs(cc_params.cdot_0 - cc_params.cdot) > 1)  {
        
        double to_add = (*(LL_Double(cc_params.prop_u_or_d + cc_params.cdot, 1) + (alpha - cc_params.alpha_base)))
                        * sqrt(*(cc_params.f + alpha)) * cc_params.multiplier;
        if (cc_params.over_boundary == yz_false)  to_add *= GaussProb(cc_params.l, cc_params.alpha_0, alpha, 0);
        
        if (cc_params.prop_mode == pa_Bridge_dC_dZ)  {
            *(cc_params.grad_f + alpha) += to_add * cc_params.dC_dZ_factor / (*(cc_params.f + alpha));    }
        cc_params.p_value += to_add;               }}
    
    else  {
        
        double Z_sub = (*(LL_Double(cc_params.prop_u_or_d + cc_params.cdot_ext, 1) + (cc_params.alpha_0 - cc_params.alpha_0_base)))
                        * GaussProb(fabs( (*(contour.l + cc_params.cdot)) - (*(contour.l + cc_params.cdot_ext)) ), alpha, cc_params.alpha_0, 0)
                        * GaussProb(cc_params.l, cc_params.alpha_0, alpha, 0)
                        * sqrt(*(cc_params.f + cc_params.alpha_0)) * (*(cc_params.f + alpha)) * cc_params.multiplier;
        double p_sub;
        double dC_dp = cc_params.K1 * cc_params.N_difference;
        if (*(cc_params.FSumProbs + alpha) > 1.)  dC_dp += *(cc_params.FSumProbs + alpha) - 1.;
        
        p_sub = Z_sub * exp( cc_params.w_factor + (*(cc_params.prop_u_or_d_norm + cc_params.cdot_ext)) + cc_params.other_norm
                            - (*(cc_params.Z_1x_norm + cc_params.cdot)) - (*(cc_params.Z_xN_norm + cc_params.cdot)) );
        
        if (cc_params.prop_mode == pa_BridgeZ)  {
            double *ps = LL_Double(cc_params.p + cc_params.cdot, 1);        // don't divide by Z since we haven't done p = p/Z yet
            *(ps + alpha - cc_params.alpha_base) -= p_sub;          }
        
        else if (cc_params.prop_mode == pa_Bridge_dC_dZ)  {
            p_sub /= (*(cc_params.Z + cc_params.cdot));
            *(cc_params.grad_f + cc_params.alpha_0) -= (p_sub*dC_dp + Z_sub*cc_params.dC_dZ_factor) / (*(cc_params.f + cc_params.alpha_0));
            *(cc_params.grad_f + alpha) -= (p_sub*dC_dp + 2*Z_sub*cc_params.dC_dZ_factor) / (*(cc_params.f + alpha));      }
        
        else if (cc_params.prop_mode == pa_BridgeS)  {
            double sub_term;
            p_sub *= dC_dp / (*(cc_params.Z + cc_params.cdot));
            sub_term = p_sub * exp(-cc_params.other_norm - (*(cc_params.sensitivity_norm + cc_params.cdot_0)));
            
            *(LL_Double(cc_params.sensitivity + cc_params.cdot_0, 1) + cc_params.alpha_0 - cc_params.alpha_0_base) -= sub_term;
            *(cc_params.grad_f + cc_params.alpha_0) += 0.5 * (*(cc_params.other_layer + cc_params.alpha_0 - cc_params.alpha_0_base))
                             * p_sub / (*(cc_params.f + cc_params.alpha_0));
            
            if (cc_params.pa_SetGradWSource == yz_true)
                *(cc_params.grad_f + field.dots_num) -= sub_term * cc_params.w_norm * (abs(cc_params.cdot_ext - cc_params.cdot_0) - 2) * exp( -cc_params.w )
                        * (*(LL_Double(cc_params.Z_1x + cc_params.cdot_0, 1) + (cc_params.alpha_0 - cc_params.alpha_0_base)));      }
        
        cc_params.p_value -= Z_sub;           }
}


void CountNeighbors(Ulong alpha)
{
    cc_params.p_value += 1.;
}

void do_pLR(Ulong alpha)
{
    double L = cc_params.l;
    double R = sqrt(SqDotDistance(alpha, cc_params.alpha_0, 1., 1., 1.));
    Slong x_bin = L / 2;
    Slong y_bin = R / 2;
    
    if ((x_bin >= 0) && (y_bin >= 0) && (x_bin < 100) && (y_bin < 100))
        *(cc_params.pLR + y_bin*100 + x_bin) += GaussProb(cc_params.l, cc_params.alpha_0, alpha, 0)*exp(cc_params.w*(cc_params.cdot_0-cc_params.cdot-1))
                * (*(LL_Double(cc_params.Z_1x + cc_params.cdot, 1) + (alpha - cc_params.alpha_base)))
                * (*(LL_Double(cc_params.Z_xN + cc_params.cdot_0, 1) + (cc_params.alpha_0 - cc_params.alpha_0_base)))
                * exp((*(cc_params.Z_1x_norm + cc_params.cdot)) - (*(cc_params.Z_1x_norm + cc_params.cdot_0)))
                / (*(cc_params.Z + cc_params.cdot_0));
}


// InitW() computes the w-factor based on a 'w_norm' that compares sensibly with the mean terms connecting pairs of spots.

void InitW()
{
    double L_avg = (*(contour.l + contour.dots_num - 1)) / (contour.dots_num * (1. - cc_params.p_fn));
    cc_params.w_norm = GaussProb(L_avg, 0, 0, 2) * GaussProb(L_avg, 0, 0, 2) / GaussProb(L_avg*(2. - cc_params.p_fn), 0, 0, 2);
    cc_params.w = log( (*(cc_params.f + field.dots_num)) * cc_params.w_norm );
}


void GetAllChains(Ulong dot_num, Slong last_dot, double p)
{
    Ulong one_color = *(contour.color + dot_num);
    Slong alpha_base = *(field.color_bottoms + one_color) - 1, alpha;
    
    if (dot_num == contour.dots_num)  {
        
        Ulong j;
        
        *(cc_params.Z) += p;
        
        for (j = 0; j < contour.dots_num; j++)  {
            
            Ulong j_color = *(contour.color + j);
            Slong j_alpha_base = (Slong) *(field.color_bottoms + j_color) - 1;
            Slong j_alpha = *(cc_params.alphas + j);
            
            if (j_alpha >= j_alpha_base)  {
                *(LL_Double(cc_params.p + j, 1) + j_alpha - j_alpha_base) += p;
        }   }
    }
    
    else  {
    for (alpha = alpha_base-1; alpha < (Slong) *(field.color_tops + one_color); alpha++)  {
        
        Boolean if_masked = yz_false;
        if (alpha > alpha_base-1)  if_masked = *(cc_params.alpha_mask + alpha);
        
        if (if_masked == yz_false)  {
            
            *(cc_params.alphas + dot_num) = alpha;
            if (alpha > alpha_base-1)  *(cc_params.alpha_mask + alpha) = yz_true;
            
            if (alpha == alpha_base - 1)  {
            if (dot_num - last_dot < cc_params.n_skip_max)  {
                GetAllChains(dot_num+1, last_dot, p * exp(cc_params.w) / cc_params.w_norm);
            }}
            
            else  {
                
                double extra_p = 1.;
                if (last_dot != -1)  {
                    double l = fabs( (*(contour.l + dot_num)) - (*(contour.l + last_dot)) );
                    extra_p = GaussProb(l, alpha, *(cc_params.alphas+last_dot), 0) / cc_params.w_norm;     }
                
                GetAllChains(dot_num+1, dot_num, p*extra_p);        }
            
            if (alpha > alpha_base-1)  *(cc_params.alpha_mask + alpha) = yz_false;
    }}  }
}


void GetAllChainsDebug(Ulong dot_num, Slong last_dot, Slong last_last_dot, double p, Boolean sub)
{
    Ulong one_color = *(contour.color + dot_num);
    Slong alpha_base = *(field.color_bottoms + one_color) - 1, alpha;
    
    if (dot_num == contour.dots_num)  {
        
        Ulong j;
        
        *(cc_params.Z) += p;
        
        for (j = 0; j < contour.dots_num; j++)  {
            
            Ulong j_color = *(contour.color + j);
            Slong j_alpha_base = (Slong) *(field.color_bottoms + j_color) - 1;
            Slong j_alpha = *(cc_params.alphas + j);
            
//if (j_alpha < j_alpha_base)  printf("- ");
            if (j_alpha >= j_alpha_base)  {
//printf("%i ", j_alpha);
                *(LL_Double(cc_params.p + j, 1) + j_alpha - j_alpha_base) += p;
        }   }
        if (sub == yz_true)  printf("  (-)");
//printf("\n");
    }
    
    else  {
    for (alpha = alpha_base-1; alpha < (Slong) *(field.color_tops + one_color); alpha++)  {
        
        Boolean if_masked = yz_false;
        if ((alpha != alpha_base-1) && (last_dot > -1))  {
        if (alpha == *(cc_params.alphas + last_dot))  {
            if_masked = yz_true;        }}
        /*if ((alpha != alpha_base-1) && (last_last_dot > -1))  {
        if (alpha == *(cc_params.alphas + last_last_dot))  {
            if_masked = yz_true;        }}/**/
        /**/if ((if_masked == yz_false) && (last_dot > -1) && (dot_num < contour.dots_num-1) && (alpha > alpha_base-1))  {
        if (*(contour.color + last_dot) == *(contour.color + dot_num+1))  {
            double l1 = fabs( (*(contour.l + dot_num)) - (*(contour.l + last_dot)) );
            double l2 = fabs( (*(contour.l + dot_num+1)) - (*(contour.l + dot_num)) );
            double extra_p = -GaussProb(l1, *(cc_params.alphas+last_dot), alpha, 0)
                        * GaussProb(l2, alpha, *(cc_params.alphas+last_dot), 0) / (cc_params.w_norm*cc_params.w_norm);
            *(cc_params.alphas + dot_num) = alpha;
            *(cc_params.alphas + dot_num+1) = *(cc_params.alphas + dot_num-1);
            GetAllChainsDebug(dot_num+2, dot_num+1, dot_num, p*extra_p, yz_true);     }}/**/
        
        if (if_masked == yz_false)  {
            
            *(cc_params.alphas + dot_num) = alpha;
            
            if (alpha == alpha_base - 1)  {
            if (dot_num - last_dot < cc_params.n_skip_max)  {
                GetAllChainsDebug(dot_num+1, last_dot, last_last_dot, p * exp(cc_params.w) / cc_params.w_norm, sub);
            }}
            
            else  {
                
                double extra_p = 1.;
                if (last_dot != -1)  {
                    double l = fabs( (*(contour.l + dot_num)) - (*(contour.l + last_dot)) );
                    extra_p = GaussProb(l, alpha, *(cc_params.alphas+last_dot), 0) / cc_params.w_norm;     }
                
                GetAllChainsDebug(dot_num+1, dot_num, last_dot, p*extra_p, sub);        }
    }}  }
}





// *********** Misc ***********



int call_GaussianChain(int argc, char **argv)
{
	arg_info *ArgInfo;
	Boolean ArgsOK = yz_true;
    Ulong FD1, FD2;
    double L, dummy_calcs, *result;

	const signed long ArgTypes[] = { double_type, double_type, double_type, double_type, double_type, double_type,
                                     double_type, double_type, Ulong_type, Ulong_type, double_type };
	const signed long ArgIndices[] = { -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, 1 };
    const Ulong argc_target = sizeof(ArgTypes)/sizeof(long);
	
	ArgInfo = (arg_info *) *(argv+argc);
	
	if (argc != argc_target)  ArgsOK = yz_false;
	else if (CheckArgInfo(ArgInfo, ArgTypes, ArgIndices, argc) != passed)  ArgsOK = yz_false;

 	if (ArgsOK == yz_false)  {
		printf("usage: rtrn = call(\"GaussianChain\", (doubles) x[], y[], z[], dx[], dy[], dz[], L, persistence_length, dot1, dot2, result)\n");
		return 1;		}
	
	field.x = (double *) *(argv);
	field.y = (double *) *(argv+1);
	field.z = (double *) *(argv+2);
	field.dx = (double *) *(argv+3);
	field.dy = (double *) *(argv+4);
	field.dz = (double *) *(argv+5);

	L = *(double *) *(argv+6);
	cc_params.lp = *(double *) *(argv+7);
    
    cc_params.exaggeration = 1.;
    
	FD1 = *(Ulong *) *(argv+8);
	FD2 = *(Ulong *) *(argv+9);
    
    if ((FD1 == 0) || (FD2 == 0) || (FD1 > field.dots_num) || (FD2 > field.dots_num))       {
        printf("GaussianChain():  field dot 1 or 2 out of range\n");
        return 2;               }

	result = (double *) *(argv+10);
    
    cc_params.calcs = &dummy_calcs;
    
    *result = GaussProb(L, FD1-1, FD2-1, 0);
    
    return passed;
}



double GaussProb(double l, Ulong FieldDot1, Ulong FieldDot2, char GN_mode)
{
    double alpha, ax, ay, az, ans;
    const double pi3 = pi*pi*pi;
    
    *(cc_params.calcs) += 1;

    alpha = 3/(2*EffectiveL2(l));

    ax = 1./(1./alpha + 2*(*(field.dx+FieldDot1))*(*(field.dx+FieldDot1)) + 2*(*(field.dx+FieldDot2))*(*(field.dx+FieldDot2)));
    ay = 1./(1./alpha + 2*(*(field.dy+FieldDot1))*(*(field.dy+FieldDot1)) + 2*(*(field.dy+FieldDot2))*(*(field.dy+FieldDot2)));
    az = 1./(1./alpha + 2*(*(field.dz+FieldDot1))*(*(field.dz+FieldDot1)) + 2*(*(field.dz+FieldDot2))*(*(field.dz+FieldDot2)));

    if (GN_mode == 0)
        ans = sqrt(ax*ay*az/pi3)*exp(-SqDotDistance(FieldDot1, FieldDot2, ax, ay, az));
    else if (GN_mode == 1)
        ans = exp(-SqDotDistance(FieldDot1, FieldDot2, ax, ay, az));
    else
        ans = sqrt(ax*ay*az/pi3);
    
    if (cc_params.exaggeration != 1.)
        ans = pow(ans, cc_params.exaggeration);
//    if (cc_params.exaggeration != 1.)  ans = pow(ans, cc_params.exaggeration);
    return ans;
}



double EffectiveL2(double l)
{
    if (l > 2*cc_params.lp)  return 2*l*cc_params.lp;
    else if (l*l > 0)  return l*l;
    else  return 1.;            // 1 bp
}


double SqDotDistance(Ulong dot1, Ulong dot2, double wx, double wy, double wz)
{
	double dx, dy, dz;

    dx = (*(field.x+dot1)) - (*(field.x+dot2));
    dy = (*(field.y+dot1)) - (*(field.y+dot2));
    dz = (*(field.z+dot1)) - (*(field.z+dot2));

    return wx*dx*dx + wy*dy*dy + wz*dz*dz;
}

double AddLog(double x1, double x2, double sgn)
{
    if (x1 > x2)  return x1 + log(1 + sgn*exp(x2 - x1));
    else  return x2 + log(1 + sgn*exp(x1 - x2));
}

double max(double d1, double d2)
{
    if (d1 > d2)  return d1;
    else  return d2;
}



int call_InitGaussRand(int argc, char **argv)
{
	arg_info *ArgInfo;
	Boolean ArgsOK = yz_true;
    clock_t rand_seed;

	const signed long ArgTypes[] = {  };
	const signed long ArgIndices[] = {  };
    const Ulong argc_target = sizeof(ArgTypes)/sizeof(long);
	
	ArgInfo = (arg_info *) *(argv+argc);
	
	if (argc != argc_target)  ArgsOK = yz_false;
	else if (CheckArgInfo(ArgInfo, ArgTypes, ArgIndices, argc) != passed)  ArgsOK = yz_false;

 	if (ArgsOK == yz_false)  {
		printf("usage: rtrn = call(\"InitGaussRand\")\n");
		return 1;		}
    
    rand_seed = clock();

    gsl_rng_env_setup();
    gsl_rand_gen_type = gsl_rng_default;
    gsl_rand_gen = gsl_rng_alloc(gsl_rand_gen_type);
    if ((void *) gsl_rand_gen == NULL)  return 1;
    gsl_rng_set(gsl_rand_gen, (Ulong) rand_seed);
    
    return passed;
}



int call_GaussRand(int argc, char **argv)
{
    double *result, sigma;
	arg_info *ArgInfo;
	Boolean ArgsOK = yz_true;

	const signed long ArgTypes[] = { double_type, double_type };
	const signed long ArgIndices[] = { 1, 1 };
    const Ulong argc_target = sizeof(ArgTypes)/sizeof(long);
	
	ArgInfo = (arg_info *) *(argv+argc);
	
	if (argc != argc_target)  ArgsOK = yz_false;
	else if (CheckArgInfo(ArgInfo, ArgTypes, ArgIndices, argc) != passed)  ArgsOK = yz_false;

 	if (ArgsOK == yz_false)  {
		printf("usage: rtrn = call(\"GaussRand\", (doubles) sigma, result)\n");
		return 1;		}

	sigma = *(double *) *(argv + 0);
	result = (double *) *(argv + 1);
    
    *result = gsl_ran_gaussian(gsl_rand_gen, sigma);
    
    return 0;
}







// *********** Diagnostics ***********


int call_Entropy(int argc, char **argv)
{
    Ulong c1, alpha_base, alpha, one_color, *C2F;
	arg_info *ArgInfo;
    double *info, prob_sum, *first_p, one_p, x_res, y_res, z_res, alpha_x, alpha_y, alpha_z, one_tot_p;
	Boolean IfAvg, IfZeroNorm, ArgsOK = yz_true;

	const signed long ArgTypes[] = { double_type, double_type, double_type, string_type, Ubyte_type,
                                    Ulong_type, Ulong_type, Ulong_type, double_type, double_type, double_type, double_type };
	const signed long ArgIndices[] = { -1, -1, -1, -2, -2, -3, -3, -4, 1, 1, 1, 1 };
    const Ulong argc_target = sizeof(ArgTypes)/sizeof(long);
	
	ArgInfo = (arg_info *) *(argv+argc);
	
	if (argc != argc_target)  ArgsOK = yz_false;
	else if (CheckArgInfo(ArgInfo, ArgTypes, ArgIndices, argc) != passed)  ArgsOK = yz_false;

 	if (ArgsOK == yz_false)  {
		printf("usage: rtrn = call(\"Entropy\", (doubles) x[], y[], z[], (strings) p[], (ubyte) colors[], ");
        printf("(ulongs) color_bottoms[], color_tops[], C2F[], (double) x_res, y_res, z_res, result)\n");
		return 1;		}
	
	field.x = (double *) *(argv);
	field.y = (double *) *(argv+1);
	field.z = (double *) *(argv+2);
    
	cc_params.p = (linkedlist *) *(argv+3);
	contour.color = (unsigned char *) *(argv+4);

	field.color_bottoms = (Ulong *) *(argv+5);
	field.color_tops = (Ulong *) *(argv+6);

	C2F = (Ulong *) *(argv+7);
	x_res = *(double *) *(argv+8);
	y_res = *(double *) *(argv+9);
	z_res = *(double *) *(argv+10);

	info = (double *) *(argv+11);
    
    contour.dots_num = (ArgInfo+3)->arg_indices;

    IfZeroNorm = yz_false;
    if (x_res*y_res*z_res == 0)  IfZeroNorm = yz_true;
    else        {
        alpha_x = 1. / (2 * x_res * x_res);
        alpha_y = 1. / (2 * y_res * y_res);
        alpha_z = 1. / (2 * z_res * z_res);         }
    
    IfAvg = yz_false;
    if ((ArgInfo+7)->arg_indices == 0)  IfAvg = yz_true;
    else if ((ArgInfo+7)->arg_indices != (ArgInfo+3)->arg_indices)  {
        printf("Entropy() error:  C2F and p[] must be the same length");
        return 1;           }
    
    *info = 0;
    for (c1 = 0; c1 < contour.dots_num; c1++)       {
    if (AreSpots(c1) == yz_true)     {
        if ((cc_params.p + c1)->memory == 0)  {
            printf("Entropy() error:  p[] is not initialized\n");
            return 2;           }

        first_p = LL_Double(cc_params.p + c1, 1);
        one_color = *(contour.color + c1);
        
        prob_sum = one_tot_p = 0;
        alpha_base = *(field.color_bottoms + one_color) - 1;
        for (alpha = alpha_base; alpha < *(field.color_tops + one_color); alpha++)     {
            one_p = *(first_p + alpha - alpha_base);
            prob_sum += one_p;
            
            if (IfAvg == yz_true)       {
                if (one_p > 0)  *info -= one_p*log(one_p);    }

            else        {
                if ((IfZeroNorm == yz_false) && (*(C2F + c1) >= 1))
                    one_tot_p += one_p * exp(-SqDotDistance(alpha, *(C2F + c1) - 1, alpha_x, alpha_y, alpha_z));
                else if ((IfZeroNorm == yz_true) && (alpha == *(C2F + c1) - 1))
                    one_tot_p += one_p;            }
        }

        if (prob_sum >= 0)      {
            if (IfAvg == yz_true)  {
                if (prob_sum < 1.)  *info -= (1. - prob_sum)*log(1. - prob_sum);         }
            else  {
                if (*(C2F + c1) == 0)  *info -= log(1. - prob_sum);
                else if (one_tot_p < 1.)  *info -= log(one_tot_p);        // screen out the > 1 case
        }   }
    }}

	return passed;
}


Boolean AreSpots(Slong i)
{
    if ((i < 0) || (i >= contour.dots_num))  return yz_true;
    
    if ( (*(field.color_tops + *(contour.color + i)) + 1) - *(field.color_bottoms + *(contour.color + i)) > 0 )  return yz_true;
    
    return yz_false;
}
