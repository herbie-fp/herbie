float linear_activate(float x){return x;}
float sigmoid_activate(float x){return 1./(1. + exp(-x));}
float relu_activate(float x){return x*(x>0);}
float ramp_activate(float x){return x*(x>0)+.1*x;}
float tanh_activate(float x){return (exp(2*x)-1)/(exp(2*x)+1);}

float linear_gradient(float x){return 1;}
float sigmoid_gradient(float x){return (1-x)*x;}
float relu_gradient(float x){return (x>0);}
float ramp_gradient(float x){return (x>0)+.1;}
float tanh_gradient(float x){return 1-x*x;}


    int max_scale = 1+floor((double)log((double)m/(5.*sbin))/log(scale));

    if(max_scale < interval) error("max_scale must be >= interval");

    image *ims = calloc(max_scale+interval, sizeof(image));


    for(i = 0; i < interval; ++i){

        double factor = 1./pow(scale, i);

        double ih =  round(h*factor);

        double iw =  round(w*factor);

        int ex_h = round(ih/4.) - 2;

        int ex_w = round(iw/4.) - 2;

        ims[i] = features_output_size(net, src, ex_h, ex_w);


        ih =  round(h*factor);

        iw =  round(w*factor);

        ex_h = round(ih/8.) - 2;

        ex_w = round(iw/8.) - 2;

        ims[i+interval] = features_output_size(net, src, ex_h, ex_w);

        for(j = i+interval; j < max_scale; j += interval){

            factor /= 2.;

            ih =  round(h*factor);

            iw =  round(w*factor);

            ex_h = round(ih/8.) - 2;

            ex_w = round(iw/8.) - 2;

            ims[j+interval] = features_output_size(net, src, ex_h, ex_w);

        }

    }

void update_connected_layer(connected_layer layer)

{

    int i;

    for(i = 0; i < layer.outputs; ++i){

        layer.bias_momentum[i] =
layer.learning_rate*(layer.bias_updates[i]) +
layer.momentum*layer.bias_momentum[i];

        layer.biases[i] += layer.bias_momentum[i];

    }

    for(i = 0; i < layer.outputs*layer.inputs; ++i){

        layer.weight_momentum[i] =
layer.learning_rate*(layer.weight_updates[i] -
layer.decay*layer.weights[i]) + layer.momentum*layer.weight_momentum[i];

        layer.weights[i] += layer.weight_momentum[i];

    }

    memset(layer.bias_updates, 0, layer.outputs*sizeof(float));

    memset(layer.weight_updates, 0,
layer.outputs*layer.inputs*sizeof(float));

}



/* UNSTABLE!

void forward_softmax_layer(const softmax_layer layer, float *input)

{

    int i;

    float sum = 0;

    for(i = 0; i < layer.inputs; ++i){

        sum += exp(input[i]);

    }

    for(i = 0; i < layer.inputs; ++i){

        layer.output[i] = exp(input[i])/sum;

    }

}

*/

void forward_softmax_layer(const softmax_layer layer, float *input)

{

    int i,b;

    for(b = 0; b < layer.batch; ++b){

        float sum = 0;

        float largest = 0;

        for(i = 0; i < layer.inputs; ++i){

            if(input[i+b*layer.inputs] > largest) largest =
input[i+b*layer.inputs];

        }

        for(i = 0; i < layer.inputs; ++i){

            sum += exp(input[i+b*layer.inputs]-largest);

            //printf("%f, ", input[i]);

        }

        //printf("\n");

        if(sum) sum = largest+log(sum);

        else sum = largest-100;

        for(i = 0; i < layer.inputs; ++i){

            layer.output[i+b*layer.inputs] =
exp(input[i+b*layer.inputs]-sum);

        }

    }

}


void backward_softmax_layer(const softmax_layer layer, float *input, float
*delta)

{

/*

    int i,j,b;

    for(b = 0; b < layer.batch; ++b){

        for(i = 0; i < layer.inputs; ++i){

            for(j = 0; j < layer.inputs; ++j){

                int d = (i==j);

                layer.jacobian[b*layer.inputs*layer.inputs + i*layer.inputs
+ j] =

                        layer.output[b*layer.inputs + i] * (d -
layer.output[b*layer.inputs + j]);

            }

        }

    }

    for(b = 0; b < layer.batch; ++b){

        int M = layer.inputs;

        int N = 1;

        int K = layer.inputs;

        float *A = layer.jacobian + b*layer.inputs*layer.inputs;

        float *B = layer.delta + b*layer.inputs;

        float *C = delta + b*layer.inputs;

        gemm(0,0,M,N,K,1,A,K,B,N,0,C,N);

    }

    */


    int i;

    for(i = 0; i < layer.inputs*layer.batch; ++i){

        delta[i] = layer.delta[i];

    }

}


float sum_array(float *a, int n)

{

    int i;

    float sum = 0;

    for(i = 0; i < n; ++i) sum += a[i];

    return sum;

}


float mean_array(float *a, int n)

{

    return sum_array(a,n)/n;

}


float variance_array(float *a, int n)

{

    int i;

    float sum = 0;

    float mean = mean_array(a, n);

    for(i = 0; i < n; ++i) sum += (a[i] - mean)*(a[i]-mean);

    float variance = sum/n;

    return variance;

}


void normalize_array(float *a, int n)

{

    int i;

    float mu = mean_array(a,n);

    float sigma = sqrt(variance_array(a,n));

    for(i = 0; i < n; ++i){

        a[i] = (a[i] - mu)/sigma;

    }

    mu = mean_array(a,n);

    sigma = sqrt(variance_array(a,n));

}


float rand_normal()

{

    int i;

    float sum= 0;

    for(i = 0; i < 12; ++i) sum += (float)rand()/RAND_MAX;

    return sum-6.;

}
